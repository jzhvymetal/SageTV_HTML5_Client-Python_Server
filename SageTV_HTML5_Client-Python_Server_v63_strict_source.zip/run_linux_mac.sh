#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 -m venv .venv || true
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
export SAGETV_SERVER="${SAGETV_SERVER:-192.168.10.175:31099}"
export SAGETV_WEB_PORT="${SAGETV_WEB_PORT:-8088}"
python -m uvicorn app.main:app --host 0.0.0.0 --port "$SAGETV_WEB_PORT"
