@echo off
setlocal EnableExtensions
cd /d "%~dp0"

rem ---------------------------------------------------------------------------
rem SageTV Pure Python HTML5 GUI Windows launcher
rem v42: no batch subroutines/labels so it works correctly with all line endings.
rem It also auto-installs FFmpeg if missing.
rem ---------------------------------------------------------------------------

set "NEED_FFMPEG=1"

rem 1) If FFMPEG is explicitly set and exists, use it.
if defined FFMPEG (
  if exist "%FFMPEG%" (
    echo Using FFmpeg from FFMPEG=%FFMPEG%
    set "NEED_FFMPEG=0"
  ) else (
    echo FFMPEG is set but does not exist: %FFMPEG%
  )
)

rem 2) Prefer the local project FFmpeg install.
if "%NEED_FFMPEG%"=="1" (
  if exist "%~dp0tools\ffmpeg\bin\ffmpeg.exe" (
    set "FFMPEG=%~dp0tools\ffmpeg\bin\ffmpeg.exe"
    if exist "%~dp0tools\ffmpeg\bin\ffprobe.exe" set "FFPROBE=%~dp0tools\ffmpeg\bin\ffprobe.exe"
    echo Using local FFmpeg: %~dp0tools\ffmpeg\bin\ffmpeg.exe
    set "NEED_FFMPEG=0"
  )
)

rem 3) If ffmpeg is already on PATH, do not download another copy.
if "%NEED_FFMPEG%"=="1" (
  where ffmpeg.exe >nul 2>nul
  if not errorlevel 1 (
    echo Using FFmpeg from PATH.
    set "NEED_FFMPEG=0"
  )
)

rem 4) Download and install the latest Gyan.dev release full build if missing.
if "%NEED_FFMPEG%"=="1" (
  echo FFmpeg was not found.
  echo Downloading latest Gyan.dev release full build to tools\ffmpeg\bin ...
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\install_ffmpeg.ps1"
  if errorlevel 1 (
    echo.
    echo FFmpeg auto-install failed.
    echo You can manually install FFmpeg at tools\ffmpeg\bin\ffmpeg.exe,
    echo install 7-Zip so the .7z can be extracted, or set FFMPEG=C:\path\to\ffmpeg.exe.
    pause
    exit /b 1
  )
  if exist "%~dp0tools\ffmpeg\bin\ffmpeg.exe" (
    set "FFMPEG=%~dp0tools\ffmpeg\bin\ffmpeg.exe"
    if exist "%~dp0tools\ffmpeg\bin\ffprobe.exe" set "FFPROBE=%~dp0tools\ffmpeg\bin\ffprobe.exe"
  )
)

if not exist .venv (
  py -3 -m venv .venv
  if errorlevel 1 exit /b 1
)

call .venv\Scripts\activate.bat
if errorlevel 1 exit /b 1

python -m pip install --upgrade pip
if errorlevel 1 exit /b 1

python -m pip install -r requirements.txt
if errorlevel 1 exit /b 1

if "%SAGETV_SERVER%"=="" set "SAGETV_SERVER=192.168.10.175:31099"
if "%SAGETV_WEB_PORT%"=="" set "SAGETV_WEB_PORT=8088"

echo Starting pure Python SageTV HTML5 GUI on port %SAGETV_WEB_PORT%
echo Default SageTV server: %SAGETV_SERVER%
if defined FFMPEG echo FFmpeg: %FFMPEG%

python -m uvicorn app.main:app --host 0.0.0.0 --port %SAGETV_WEB_PORT%
exit /b %ERRORLEVEL%
