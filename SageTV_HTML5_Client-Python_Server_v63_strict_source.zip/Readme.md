# SageTV Pure Python HTML5 GUI v63

Pure Python + HTML5/JavaScript SageTV MiniClient experiment.

This project connects to a SageTV server as a MiniClient, renders the SageTV GUI in a browser canvas, sends keyboard/mouse/remote events back to SageTV, and can transcode SageTV media playback to browser video.

It does **not** use Java, Gradle, Android, Firebase, Crashlytics, ExoPlayer, or IJKPlayer.

## Current focus

The GUI and remote path are working. Video playback is experimental. v63 removes the **Strict source mode** checkbox. Explicit **Source** and **Player** selections are always strict. Use **Source = Auto Direct/PULL/PUSH** when you want source fallback. The browser settings are grouped into Connection, Source, Player, and Quality/Encoder sections.

Recommended first Direct File/SMB video test:

```text
Source: Direct File/SMB
Sage Root: /var/media/tv
Local Root: \\192.168.10.175\sagemedia\tv
Player: HLS hls.js TS
Encoder: libx264
Max H: Source
Bitrate: Source
HLS Segments: Stable during playback
```

If `bp=` or backpressure messages rise quickly in the debug panel, the transcode is falling behind. Lower Max H or Bitrate, or use Intel QSV if it is stable. In Direct File/SMB mode, FFmpeg reads the media file directly instead of waiting for SageTV PUSHBUFFER chunks.

## Run on Windows

Run:

```cmd
run_windows.bat
```

Open:

```text
http://localhost:8088
```

Default SageTV server:

```text
192.168.10.175:31099
```

The Windows launcher checks for FFmpeg in this order:

```text
1. FFMPEG environment variable
2. tools\ffmpeg\bin\ffmpeg.exe
3. ffmpeg.exe on PATH
4. Auto-download Gyan.dev ffmpeg-release-full.7z
```

The auto-install location is:

```text
tools\ffmpeg\bin\ffmpeg.exe
tools\ffmpeg\bin\ffprobe.exe
```

## Run tests

```cmd
test_windows.bat
```

Expected:

```text
16 passed
```

## Main browser settings

### Media/video caps

Enable this to advertise media capability to SageTV. Leave it disabled for GUI-only testing.

### Source controls the input method

The old **Force PUSH** checkbox and the **Strict source mode** checkbox have both been removed. Use the **Source** dropdown instead:

```text
Direct File/SMB: advertise stv/file URLs so Python can map them to SMB/local files
SageTV PULL: advertise stv:// PULL and read from SageTV's PULL socket
PUSHBUFFER: advertise PUSHBUFFER only
Auto Direct/PULL/PUSH: allow the app to try Direct, then PULL, then PUSH
```

Explicit source selections stay fixed. If Direct fails, it stops and logs the reason instead of silently switching to PULL or PUSH. Use **Auto Direct/PULL/PUSH** when you want fallback.

### Source

```text
Direct File/SMB
SageTV PULL
PUSHBUFFER
Auto Direct/PULL/PUSH
```

`PUSHBUFFER` is the original path. SageTV pushes transport-stream chunks to Python, and Python feeds FFmpeg over stdin.

`SageTV PULL` asks SageTV to use `stv://` pull URLs when possible. Python then reads from SageTV's pull socket and feeds FFmpeg. This is experimental and restarts from the beginning after seek/flush because byte-accurate PULL seeking is not implemented yet.

`Direct File/SMB` tries to resolve a SageTV file or `stv://` path into a local path that Python/FFmpeg can read directly. Use `Sage Root` and `Local Root` to map the SageTV path to your mounted SMB/NFS path. Example:

```text
Sage Root:  /var/media/tv
Local Root: \\192.168.10.175\sagemedia\tv
```

Linux example:

```text
Sage Root:  /var/media/tv
Local Root: /mnt/sagetv
```

You can also set multiple mappings with:

```text
SAGEWEB_DIRECT_PATH_MAP=\\SAGETV\Recordings=Z:\Recordings|/var/media/tv=/mnt/sagetv
```

`Auto Direct/PULL/PUSH` tries direct file playback for non-push URLs, then PULL for `stv://`, then PUSHBUFFER if SageTV still sends PUSH.

### Player

```text
HLS hls.js TS
HLS hls.js fMP4
MSE separate A/V
MSE fMP4 combined
Video.js HLS TS
Video.js HLS fMP4
```

`MSE separate A/V` uses separate FFmpeg fragmented MP4 outputs for video and audio, then creates separate browser SourceBuffers. It allows player-side audio sync adjustment, but HLS usually has better natural audio sync.

`MSE fMP4 combined` uses FFmpeg fragmented MP4 output streamed directly to the browser through Media Source Extensions. This avoids HLS playlists and `.ts` segment selection.

`HLS hls.js TS` uses FFmpeg HLS output with `.m3u8` and `.ts` segments and hls.js in the browser. This is the v62 default player because it worked with Direct File/SMB while Video.js was still being tested.

`HLS hls.js fMP4` uses FFmpeg HLS output with `init.mp4` and `.m4s` segments.

`Video.js HLS TS` and `Video.js HLS fMP4` use the same FFmpeg HLS output, but play it through Video.js/VHS. Use these modes for comparison after hls.js works.

### Encoder

Start with:

```text
libx264
```

Hardware encoders can be tested later, but software x264 is usually better for debugging stability.

### Max H

```text
Source
1080p
720p
576p
480p
360p
240p
```

`Source` does not scale the source video. v63 defaults to Source. If the PC falls behind, lower this to 720p or 480p.

### Bitrate

```text
Source
Auto
800k
1200k
1600k
2500k
3500k
5000k
8000k
```

v63 defaults to Source. If the PC falls behind, lower this to Auto, 2500k, or 1600k.

### Audio Sync

```text
Audio -500ms
Audio -300ms
Audio -200ms
Audio -100ms
0ms
Audio +100ms
Audio +200ms
Audio +300ms
Audio +500ms
```

Positive values delay audio. Negative values advance audio. Changing this live restarts only the FFmpeg/browser video stream; SageTV playback keeps running.

### HLS Segments

```text
Stable during playback
Rolling cleanup
Debug keep all
```

`Stable during playback` keeps all `.ts` files for the active playback session and cleans the session when playback stops. This prevents the browser from requesting a segment that was just deleted.

`Rolling cleanup` deletes old `.ts` files during playback. It saves disk space but can cause jumps if the browser falls behind.

`Debug keep all` keeps everything and enables `push_capture.ts` for troubleshooting.

## Video pipelines

### Direct File/SMB pipeline

```text
SageTV file/stv path
  -> Python path mapping
  -> local SMB/NFS path
  -> FFmpeg reads file directly
  -> stream.m3u8 + segments or MSE fMP4
  -> browser player
```

### SageTV PULL pipeline

```text
SageTV stv:// URL
  -> Python pull socket reader
  -> FFmpeg stdin
  -> stream.m3u8 + segments or MSE fMP4
  -> browser player
```

### HLS PUSH pipeline

```text
SageTV PUSHBUFFER
  -> Python
  -> FFmpeg stdin
  -> stream.m3u8 + seg_00001.ts, seg_00002.ts, ...
  -> hls.js or Video.js/VHS
  -> HTML5 video
```

### MSE fMP4 pipeline

```text
SageTV PUSHBUFFER
  -> Python
  -> FFmpeg stdin
  -> fragmented MP4 stdout
  -> /mse/<session>/stream.mp4
  -> browser MediaSource SourceBuffer
  -> HTML5 video
```

MSE mode avoids HLS segment deletion and live-edge behavior. v63 defaults to separate MSE audio/video streams and avoids dropping SageTV TS input or fMP4 fragments when the pipeline falls behind.

## Troubleshooting

### Browser still shows an old version

Hard refresh:

```text
Ctrl + F5
```

Confirm the debug panel says:

```text
Media / Video Debug v63
```

### Video jumps or gets jerky

Use:

```text
Player: MSE separate A/V
Encoder: libx264
Max H: Source first, then 480p if needed
Bitrate: Source first, then 1600k if needed
```

Watch the debug status:

```text
bp=<number> drop=<number>
```

`bp` means backpressure. If it climbs, the player/encoder/browser is falling behind. v63 defaults to Source height/bitrate and should avoid dropping in MSE mode, but the video may drift behind. Lower bitrate or height.

`drop` should stay at 0 in MSE mode. If it increases, report the debug panel text.

### NVIDIA NVENC does not start

Use the encoder dropdown in this order:

```text
h264_nvenc NVIDIA safe
h264_nvenc NVIDIA bare compat
h264_nvenc NVIDIA CUDA upload
h264_nvenc NVIDIA low latency
```

If all NVIDIA modes fail but Intel QSV and x264 work, run these commands from the project folder and copy the output:

```cmd
tools\ffmpeg\bin\ffmpeg.exe -hide_banner -encoders | findstr /i nvenc
nvidia-smi
tools\ffmpeg\bin\ffmpeg.exe -hide_banner -f lavfi -i testsrc2=size=1280x720:rate=30 -t 5 -pix_fmt yuv420p -c:v h264_nvenc -f null -
```

If the test command fails, FFmpeg or the NVIDIA driver cannot access NVENC outside the app. If it passes, the `CUDA upload` mode is the next best app-side test.

### Playback stops or SageTV shows an error after stopping

Stop the server and kill leftover FFmpeg:

```cmd
taskkill /IM ffmpeg.exe /F
```

Then restart `run_windows.bat`.

### Clean HLS files manually

After stopping the app:

```powershell
Remove-Item -Recurse -Force .\runtime_hls\*
```

## Changelog

### v63 - Remove No fallback and make explicit modes strict

- Removed the **No fallback** checkbox from the UI.
- Explicit Source choices are now always strict:
  - Direct File/SMB only uses the mapped file path.
  - SageTV PULL only uses `stv://` PULL.
  - PUSHBUFFER only uses pushed chunks.
- `Auto Direct/PULL/PUSH` is now the only source mode that falls back.
- Explicit Player choices are also strict; Video.js no longer switches to hls.js unless a future Auto Player option is added.
- Updated debug text to show strict source behavior more clearly.

### v62 - Settings cleanup and Source-only streaming selection

- Removed the old **Force PUSH** checkbox.
- The **Source** dropdown now fully controls how SageTV media is requested and played:
  - Direct File/SMB advertises stv/file URLs and maps them to SMB/local paths.
  - SageTV PULL advertises stv:// PULL.
  - PUSHBUFFER advertises PUSH only.
  - Auto allows Direct/PULL/PUSH selection.
- Kept **Strict source mode** as the strict testing control.
- Reorganized browser settings into Connection, Source, Player, and Quality/Encoder groups.
- Updated defaults to Direct File/SMB + hls.js HLS TS for the current SMB/direct-file test path.
- Debug status now shows the selected source before FFmpeg starts instead of always showing push when the bridge is stopped.

### v61 - Video.js HLS source fix

- Added explicit Video.js HTTP Streaming/VHS CDN script after Video.js.
- Video.js now applies HLS playlists using multiple MIME spellings: `application/vnd.apple.mpegurl`, `application/x-mpegURL`, and `application/mpegurl`.
- Desktop browsers now force Video.js/VHS for HLS instead of relying on native HLS detection.
- Video.js recovery now re-applies the same selected playlist only if the source list becomes empty, instead of immediately changing player modes when Strict source mode is enabled.
- Direct File/SMB fixes from v60 remain unchanged.

### v60 - Direct File/SMB stv:// parser fix
- Fixed `Direct File/SMB not used: could not parse stv:// path: name 'parse_stv_url' is not defined`.
- Direct File/SMB now imports the same SageTV `stv://` parser used by the PULL reader.
- Direct File/SMB no longer refuses to start only because `Path.exists()` cannot verify a UNC/share path. It now starts FFmpeg and shows the real FFmpeg/open error if the share is not reachable.
- Keep `strict Source mode when testing Direct File/SMB so the debug panel shows only the selected source and does not hide failures by switching to PULL/PUSH.

### v58 - Direct File/SMB and SageTV PULL source modes
- Added `Source` dropdown with `PUSHBUFFER`, `SageTV PULL`, `Direct File/SMB`, and `Auto Direct/PULL/PUSH`.
- Added optional `Sage Root` and `Local Root` mapping fields for SMB/NFS direct-file playback.
- FFmpeg can now read a mapped file path directly instead of only using `pipe:0`.
- Added Direct File/SMB seek restart using the current SageTV media time as FFmpeg `-ss`.
- Promoted the existing `stv://` PULL reader into a selectable playback source.
- Debug panel now shows the active input source, direct path, pull URL, and direct seek offset.
- Kept PUSHBUFFER as the default and fallback path.

### v57 - HLS no-drop input mode
- HLS now uses no-drop input mode by default.
- Increased HLS FFmpeg input queue size.
- If FFmpeg falls behind, it waits/backpressures instead of dropping SageTV chunks.
- Added forced HLS keyframes at segment boundaries.
- Kept the v56 fMP4 HLS `init.mp4` fix.

### v56 - fMP4 HLS init segment fix
- Fixed fMP4 HLS startup. FFmpeg now runs from the per-session HLS folder so `init.mp4` is created beside `stream.m3u8` and the `.m4s` segments.
- Added a fallback for FFmpeg `stream_m3u8.tmp` startup playlists. If FFmpeg has generated `.m4s` segments but the final `stream.m3u8` is not visible yet, the server can use the temp playlist snapshot instead of waiting forever.
- This fixes the symptom where the debug panel showed many `.m4s` segments but `ready:false`, and the browser stayed at "Waiting for HLS playlist from FFmpeg" forever.
- Kept the v55 player choices: HLS hls.js TS, HLS hls.js fMP4, Video.js HLS TS, and Video.js HLS fMP4.




### v55 - HLS fMP4 stability test mode

- Added `HLS hls.js fMP4` and `Video.js HLS fMP4` player modes.
- fMP4 HLS uses `init.mp4` plus `.m4s` segments instead of MPEG-TS `.ts` segments. This keeps the HLS audio/video sync path but gives browsers cleaner fragmented MP4 media.
- HLS fMP4 readiness now waits for both the playlist and the init segment before starting playback.
- The `/hls` route now serves `.m4s` and `.mp4` files as `video/mp4`.
- Increased hls.js seek-hole tolerance slightly for rough SageTV stream boundaries.

### v54 - Optional Video.js HLS player

- Added `Video.js HLS` to the Player dropdown.
- Added Video.js CSS/JS from jsDelivr CDN.
- Added a separate Video.js video element so the custom MSE modes are not taken over by Video.js.
- Kept `MSE separate A/V` as the default for player-side audio sync.
- Added Video.js recovery that reloads the current HLS playlist after Video.js player errors.
- Updated the server player-mode normalization so `videojs`, `video-js`, and `vjs` map to the HLS backend while reporting `videojs` to the browser.

### v53 - Separate MSE audio/video streams, player-side sync, cookies

- Added Player mode `MSE separate A/V` as the default.
- FFmpeg now writes separate fragmented MP4 outputs for video and audio.
- Browser creates separate MSE SourceBuffers for video and audio.
- Audio Sync is now applied on the browser side in separate A/V mode.
- Default Audio Sync is `Audio -200ms`. Negative values delay video; positive values delay audio.
- Added coarse audio sync values from -2000 ms to +2000 ms.
- Saved UI settings in cookies and localStorage so browser settings survive refresh/restart.

### v51 - NVIDIA profiles and audio sync

- Removed a duplicate `pipe:1` from the MSE fMP4 FFmpeg command.
- Changed MSE video timestamp default to `PTS-STARTPTS` instead of rebuilding every timestamp from frame count. This should reduce long-play audio drift on some MPEG-TS captures.
- Changed audio resampling to `aresample=async=1000:first_pts=0` for better long-play audio/video sync.
- Added an `Audio Sync` dropdown from -500 ms to +500 ms.
- Added `h264_nvenc NVIDIA bare compat` for a minimal NVENC command path.
- Added `h264_nvenc NVIDIA CUDA upload` for systems where implicit NVIDIA upload fails.
- NVIDIA modes now use `nv12` format before NVENC instead of `yuv420p`.

### v50 - NVIDIA NVENC compatibility options

- Added encoder aliases so `h264_NVenc`, `NVENC`, `nvidia`, and `h264_nvenc` all normalize to the correct lowercase FFmpeg encoder name.
- Changed the normal `h264_nvenc` option to a conservative NVIDIA-safe command path.
- Added `h264_nvenc NVIDIA low latency` as a separate option for testing the newer low-latency NVENC settings after the safe option works.
- Kept `h264_qsv Intel UHD` as a separate explicit option because Intel Quick Sync has been working on this test machine.
- If the FFmpeg build does not expose the selected hardware encoder, the server falls back to `libx264` instead of starting a doomed FFmpeg process.

NVIDIA test commands for Windows:

```cmd
tools\ffmpeg\bin\ffmpeg.exe -hide_banner -encoders | findstr /i nvenc
nvidia-smi
tools\ffmpeg\bin\ffmpeg.exe -hide_banner -f lavfi -i testsrc2=size=1280x720:rate=30 -t 5 -pix_fmt yuv420p -c:v h264_nvenc -bf 0 -f null -
```

If that last command fails, the issue is outside the MiniClient app. Check the NVIDIA driver and whether FFmpeg can see NVENC on the RTX A2000. If it passes, use `h264_nvenc NVIDIA safe` first, then try `h264_nvenc NVIDIA low latency`.


### v50 - MSE and Source defaults

- Defaults Player to `MSE fMP4 test`.
- Defaults Max H to `Source`, so FFmpeg does not scale unless requested.
- Defaults Bitrate to `Source`, so FFmpeg uses the SageTV push URL bitrate when available.
- Server-side defaults now match the browser UI defaults when a saved/cached value is missing.

### v48 - MSE no-drop / backpressure playback

- MSE mode no longer drops SageTV `PUSHBUFFER` input when FFmpeg input is backed up.
- MSE waits and applies backpressure instead of corrupting the fMP4 stream.
- Browser MSE append queue no longer drops complete fMP4 fragments.
- Browser fetch loop slows down when the SourceBuffer is already far ahead.
- Old MSE back-buffer is trimmed behind the playhead to avoid quota errors.
- MSE video timestamps are regenerated with FFmpeg `setpts` by default.
- Debug status shows backpressure events and dropped input count.
- Consolidated all project markdown into this single `Readme.md`.

### v47 - MSE recovery and live settings

- Parses MP4 boxes before appending to `SourceBuffer`.
- Appends complete fMP4 init/media fragments instead of random fetch chunks.
- Recovers if the browser hits an `HTMLMediaElement.error`.
- Larger FFmpeg input queue in MSE mode.
- Live setting changes restart only the FFmpeg/browser stream while SageTV playback continues.

### v46 - MSE fMP4 test mode

- Added `Player` dropdown with `HLS` and `MSE fMP4 test`.
- Added `/mse/<session>/stream.mp4` direct fragmented MP4 stream.
- Added browser MediaSource / SourceBuffer playback path.
- Avoids HLS `.m3u8` playlists and `.ts` files in MSE mode.

### v45 - Stable-session HLS

- Added `Stable during playback` HLS segment mode.
- Keeps all `.ts` segments during active playback.
- Cleans the session folder on stop, disconnect, media reconnect, or new video.
- hls.js starts from the first segment of the current playback session.

### v44 - Stable HLS and fixed debug panel

- Changed hls.js from low-latency mode to stable buffering mode.
- Increased HLS live buffer sizes.
- Changed FFmpeg HLS segment time from 1 second to 2 seconds.
- Fixed the Media / Video Debug panel height to stop layout jumps.
- Reduced video status updates in the hot `PUSHBUFFER` path.

### v43 - Clean disconnect

- Fixed WebSocket disconnect error after the Disconnect button, refresh, tab close, or network disconnect.
- Stops SageTV/media/FFmpeg first, then exits the WebSocket loop cleanly.
- Prevents late debug/status sends after browser close.

### v42 - Windows batch fix

- Fixed `The system cannot find the batch label specified - ensure_ffmpeg`.
- Reworked `run_windows.bat` to avoid batch subroutine labels.
- Saved the batch file with Windows CRLF line endings.

### v41 - FFmpeg auto-install

- `run_windows.bat` checks for FFmpeg and auto-downloads Gyan.dev `ffmpeg-release-full.7z` if missing.
- Installs FFmpeg to `tools\ffmpeg\bin`.
- Added `tools/install_ffmpeg.ps1`.

### v40 - Connect fix

- Fixed v39 browser-side recursion in `hideVideoBox()`.
- Added defensive connect startup error logging.

### v39 - GUI overlay repaint

- Video debug box hidden by default.
- Removed yellow dashed startup overlay during normal playback.
- Video remains under the SageTV GUI canvas.
- GUI canvas repaints during playback.
- SageTV timeline, OSD, and menus can draw on top of video.
- Stage fallback background changed to SageMC-style blue.

### v38 - Video under GUI

- Video element moved under the SageTV GUI canvas.
- Canvas background changed to transparent during video playback.
- Video mask/color-key rectangles are treated as transparent.
- `PUSHBUFFER` debug status throttled for better responsiveness.

### v37 - HLS cleanup

- Added `HLS Segments` dropdown.
- Added rolling cleanup and debug keep-all modes.
- Added startup cleanup for abandoned `runtime_hls` folders.

### v36 - Quality dropdowns

- Added Max H dropdown with Source, 1080p, 720p, 576p, 480p, 360p, and 240p.
- Added Bitrate dropdown with Source, Auto, and fixed bitrates.
- Debug panel shows requested and effective quality.

### v35 - Playback lifecycle

- Replaced StaticFiles HLS serving with a byte-snapshot route.
- Fixed `Response content longer than Content-Length`.
- Added SageTV GFX `MEDIA_RECONNECT` handling.
- Stops FFmpeg and clears HLS files on STOP / DEINIT.
- Cancels stale browser HLS wait loops.
- FFmpeg input queue changed to non-blocking for HLS mode.

### v34 - Diagnostics

- Added no-cache headers for browser files.
- Simplified FFmpeg HLS command for live SageTV PUSH testing.
- Defaults first-test video to 480p / 1600k.
- Added raw aligned SageTV PUSH capture as `runtime_hls\<session>\push_capture.ts` in debug mode.
- Retries video-only if audio blocks HLS startup.

### v33 - Hardware fallback

- Hardware encoder stalls fall back to `libx264`.
- Re-feeds SageTV TS prebuffer after fallback.
- HLS uses `split_by_time` during testing.

### v32 - TS sync

- Defaults encoder to `libx264` for stability.
- Waits for MPEG-TS `0x47` sync before feeding FFmpeg.
- Shows TS sync status in the debug panel.
- Removes HLS temp-file mode so playlist and segments appear sooner.

### v31 - PUSH autostart

- Media/video caps checked by default.
- FFmpeg auto-starts on the first non-empty SageTV `PUSHBUFFER`.
- PUSHBUFFER data is fed to FFmpeg even if OPENURL startup was missed.
- FFmpeg start/write errors appear in the debug panel.

### v30 - HLS fallback

- Added rolling SageTV TS prebuffer.
- Auto mode falls back from `h264_nvenc` to `libx264` if no HLS segment appears.
- Re-feeds prebuffer after fallback.
- Adds deinterlace, scale, format, and timestamp reset filters.

### v29 - HLS stability

- Browser polls `/api/hls_ready/<session>` instead of directly polling `/hls/...` before playlist exists.
- Increased HLS wait timeout.
- Added FFmpeg log tail to the debug panel.
- Forced FFmpeg input as MPEG-TS for known TS streams.
- Kept HLS segments during testing.

### v28 - Force PUSH and pull fallback

- Added Force PUSH checkbox.
- Advertises `PULL_AV_CONTAINERS=NONE` when forcing PUSH.
- Added fallback SageTV port 7818 pull reader for `stv://` URLs.

### v27 - First FFmpeg/HLS video bridge

- Added experimental SageTV `PUSHBUFFER -> FFmpeg stdin -> HLS -> HTML5 video` path.
- HTML5 video positioned using SageTV `SETVIDEORECT` destination rectangle.

### v26 - Navigation overlay

- Long-click navigation overlay centered over the SageTV render area.
- Right-click reserved for SageTV context menus.

### v25 - Right-click handling

- Right-click forwards to SageTV as mouse button 3.
- Browser context menu suppressed.

### v24 - Click fix

- Short canvas clicks send mouse move, press, release, and click events to SageTV.

### v23 - Remote keys

- Added long-click/touch navigation overlay and media key buttons.

### v22 - Media trace

- Added media command parser/stub player.
- Traces OPENURL, PLAY, PAUSE, PUSHBUFFER, FLUSH, SEEK, and SETVIDEORECT.

### v21 - SageMC fixes

- Corrected Sage command IDs.
- Changed renderer capabilities for SageMC/custom STVs.
- Disabled surfaces and hires surfaces.

### v20 - GUI performance

- Batches GFX draw commands between STARTFRAME and FLIPBUFFER.
- Reduced browser log spam and capped log size.

### v19 - SET_PROPERTY fix

- Fixed SET_PROPERTY decoding.
- Honored `ADVANCED_IMAGE_CACHING=FALSE`.
- Added GFX packet trace.

### v18 and earlier

- Initial pure Python + HTML5 GUI starter.
- Basic MiniClient socket handshake.
- Initial GFX parser and browser canvas renderer.
