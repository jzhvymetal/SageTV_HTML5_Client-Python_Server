$ErrorActionPreference = "Stop"

# Auto-install the latest Gyan.dev FFmpeg release full build for this project.
# Target layout used by the Python video bridge:
#   tools\ffmpeg\bin\ffmpeg.exe
#   tools\ffmpeg\bin\ffprobe.exe

$ProjectRoot = Resolve-Path (Join-Path $PSScriptRoot "..")
$FfmpegRoot  = Join-Path $ProjectRoot "tools\ffmpeg"
$BinDir      = Join-Path $FfmpegRoot "bin"
$TargetExe   = Join-Path $BinDir "ffmpeg.exe"
$TargetProbe = Join-Path $BinDir "ffprobe.exe"
$WorkDir     = Join-Path $FfmpegRoot "_download"
$ExtractDir  = Join-Path $WorkDir "extract"
$ArchivePath = Join-Path $WorkDir "ffmpeg-release-full.7z"
$VersionPath = Join-Path $FfmpegRoot "GYAN_RELEASE_VERSION.txt"

$FullUrl     = "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-full.7z"
$VersionUrl  = "https://www.gyan.dev/ffmpeg/builds/release-version"

function Write-Step($msg) {
    Write-Host "[ffmpeg] $msg"
}

if (Test-Path $TargetExe) {
    Write-Step "Already installed at $TargetExe"
    exit 0
}

New-Item -ItemType Directory -Force -Path $WorkDir | Out-Null
New-Item -ItemType Directory -Force -Path $FfmpegRoot | Out-Null

try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
} catch {
    # Older PowerShell may not expose the enum in the same way. Continue and let Invoke-WebRequest decide.
}

try {
    Write-Step "Checking latest Gyan.dev release version..."
    $version = (Invoke-WebRequest -UseBasicParsing -Uri $VersionUrl -TimeoutSec 30).Content.Trim()
    if ($version) {
        Set-Content -Path $VersionPath -Value $version -Encoding ASCII
        Write-Step "Release version: $version"
    }
} catch {
    Write-Step "Could not read release-version. Continuing with latest full URL. $($_.Exception.Message)"
}

Write-Step "Downloading latest full build from Gyan.dev..."
Write-Step $FullUrl
Invoke-WebRequest -UseBasicParsing -Uri $FullUrl -OutFile $ArchivePath

if (Test-Path $ExtractDir) {
    Remove-Item -Recurse -Force $ExtractDir
}
New-Item -ItemType Directory -Force -Path $ExtractDir | Out-Null

$extracted = $false
$tar = Get-Command tar.exe -ErrorAction SilentlyContinue
if ($tar) {
    Write-Step "Extracting .7z with Windows tar..."
    & $tar.Source -xf $ArchivePath -C $ExtractDir
    if ($LASTEXITCODE -eq 0) {
        $extracted = $true
    } else {
        Write-Step "tar extraction failed with exit code $LASTEXITCODE."
    }
}

if (-not $extracted) {
    $sevenZip = Get-Command 7z.exe -ErrorAction SilentlyContinue
    if ($sevenZip) {
        Write-Step "Extracting .7z with 7-Zip..."
        & $sevenZip.Source x -y "-o$ExtractDir" $ArchivePath | Out-Host
        if ($LASTEXITCODE -eq 0) {
            $extracted = $true
        } else {
            Write-Step "7-Zip extraction failed with exit code $LASTEXITCODE."
        }
    }
}

if (-not $extracted) {
    throw "Could not extract ffmpeg-release-full.7z. Windows tar.exe or 7z.exe is required. Install 7-Zip or set FFMPEG to an existing ffmpeg.exe path."
}

$ffmpegExe = Get-ChildItem -Path $ExtractDir -Filter ffmpeg.exe -Recurse -ErrorAction SilentlyContinue |
    Where-Object { $_.FullName -match "[\\/]bin[\\/]ffmpeg\.exe$" } |
    Select-Object -First 1

if (-not $ffmpegExe) {
    throw "Downloaded package extracted, but ffmpeg.exe was not found under a bin folder."
}

$sourceBin = Split-Path -Parent $ffmpegExe.FullName
Write-Step "Installing from $sourceBin"

if (Test-Path $BinDir) {
    Remove-Item -Recurse -Force $BinDir
}
New-Item -ItemType Directory -Force -Path $BinDir | Out-Null
Copy-Item -Path (Join-Path $sourceBin "*") -Destination $BinDir -Recurse -Force

if (-not (Test-Path $TargetExe)) {
    throw "Install finished, but $TargetExe was not created."
}
if (-not (Test-Path $TargetProbe)) {
    Write-Step "Warning: ffprobe.exe was not found in the installed bin folder."
}

try {
    & $TargetExe -hide_banner -version | Select-Object -First 1 | ForEach-Object { Write-Step $_ }
} catch {
    Write-Step "Installed, but version check failed: $($_.Exception.Message)"
}

Write-Step "Cleaning temporary download files..."
Remove-Item -Recurse -Force $WorkDir -ErrorAction SilentlyContinue
Write-Step "Done. FFmpeg installed at $TargetExe"
