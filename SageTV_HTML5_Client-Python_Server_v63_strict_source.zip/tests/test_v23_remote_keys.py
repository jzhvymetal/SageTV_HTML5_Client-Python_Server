from app.protocol_constants import SAGE_COMMANDS


def test_v24_media_command_ids():
    assert SAGE_COMMANDS["play"] == 7
    assert SAGE_COMMANDS["pause"] == 6
    assert SAGE_COMMANDS["stop"] == 89
    assert SAGE_COMMANDS["record"] == 25
    assert SAGE_COMMANDS["play_pause"] == 59


def test_v24_navigation_and_overlay_commands_exist():
    assert SAGE_COMMANDS["select"] == 20
    assert SAGE_COMMANDS["options"] == 29
    assert SAGE_COMMANDS["skip_fwd_2"] == 61
    assert SAGE_COMMANDS["skip_back_2"] == 62
    assert SAGE_COMMANDS["live_tv"] == 63
    assert SAGE_COMMANDS["recordings"] == 86
