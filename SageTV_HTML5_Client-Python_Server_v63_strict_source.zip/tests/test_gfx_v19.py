import struct

from app.gfx import GfxParser
from app.protocol_constants import GFXCMD_LOADIMAGECOMPRESSED, GFXCMD_PREPIMAGE


def pkt(cmd, payload=b''):
    return bytes([cmd, 0, 0, 0]) + payload


def i(v):
    return struct.pack('>i', v)


def test_prepimage_returns_allocated_handle():
    parser = GfxParser()
    reply, cmds = parser.execute(pkt(GFXCMD_PREPIMAGE, i(100) + i(50)))
    assert reply == 2
    assert cmds[0]['op'] == 'imageAlloc'
    assert cmds[0]['handle'] == 2


def test_non_advanced_compressed_image_returns_new_handle():
    parser = GfxParser()
    parser.state.advanced_image_caching = False
    fake_png = b'\x89PNG\r\n\x1a\nabc'
    payload = i(99) + i(len(fake_png)) + fake_png
    reply, cmds = parser.execute(pkt(GFXCMD_LOADIMAGECOMPRESSED, payload))
    assert reply == 2
    assert cmds[0]['handle'] == 2
    assert cmds[0]['mime'] == 'image/png'


def test_advanced_compressed_image_uses_server_handle_without_reply():
    parser = GfxParser()
    parser.state.advanced_image_caching = True
    fake_jpg = b'\xff\xd8\xffabc'
    payload = i(123) + i(len(fake_jpg)) + fake_jpg
    reply, cmds = parser.execute(pkt(GFXCMD_LOADIMAGECOMPRESSED, payload))
    assert reply is None
    assert cmds[0]['handle'] == 123
    assert cmds[0]['mime'] == 'image/jpeg'
