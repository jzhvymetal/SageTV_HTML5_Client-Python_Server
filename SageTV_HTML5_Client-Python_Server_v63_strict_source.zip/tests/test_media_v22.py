import struct

from app.media import (
    MediaCommandParser,
    MEDIACMD_INIT,
    MEDIACMD_OPENURL,
    MEDIACMD_PLAY,
    MEDIACMD_PAUSE,
    MEDIACMD_PUSHBUFFER,
    MEDIACMD_SEEK,
    MEDIACMD_SETVIDEORECT,
    PLAY_STATE,
    PAUSE_STATE,
)


def openurl_payload(url: str) -> bytes:
    b = url.encode("utf-8") + b"\x00"
    return struct.pack(">i", len(b)) + b


def test_media_init_and_open_push_url():
    p = MediaCommandParser()
    assert p.execute(MEDIACMD_INIT, b"\x00\x00\x00\x00").reply == struct.pack(">i", 1)
    rv = p.execute(MEDIACMD_OPENURL, openurl_payload("push:foo?bf=vid"))
    assert rv.reply == struct.pack(">i", 1)
    assert p.status.push_mode is True
    assert p.status.url.startswith("push:")


def test_media_play_pause_timeline_advances():
    p = MediaCommandParser()
    p.execute(MEDIACMD_OPENURL, openurl_payload("push:foo"))
    p.execute(MEDIACMD_PLAY, b"")
    assert p.status.state == PLAY_STATE
    p.status.media_time_ms = 1234
    p.status.play_started_media_ms = 1234
    mt = p.execute(17, b"").reply
    assert len(mt) == 5  # int media time + one detailed stats state byte
    p.execute(MEDIACMD_PAUSE, b"")
    assert p.status.state == PAUSE_STATE


def test_pushbuffer_reply_contains_room_time_and_state():
    p = MediaCommandParser()
    p.execute(MEDIACMD_OPENURL, openurl_payload("push:foo?bf=vid"))
    p.execute(MEDIACMD_PLAY, b"")
    data = b"12345678"
    # Detailed buffer stats path has 10 extra bytes before data and mux time at offset 14.
    payload = struct.pack(">iiHHHi", len(data), 0, 100, 200, 300, 4567) + data
    rv = p.execute(MEDIACMD_PUSHBUFFER, payload)
    assert len(rv.reply) == 9
    room = struct.unpack(">i", rv.reply[:4])[0]
    media_time = struct.unpack(">i", rv.reply[4:8])[0]
    assert room > 0
    assert media_time >= 4567
    assert rv.reply[8] == PLAY_STATE
    assert p.status.bytes_pushed == len(data)


def test_video_rect_status():
    p = MediaCommandParser()
    payload = struct.pack(">iiiiiiii", 0, 0, 1920, 1080, 10, 20, 640, 360)
    rv = p.execute(MEDIACMD_SETVIDEORECT, payload)
    assert rv.reply == struct.pack(">i", 0)
    assert rv.video_bounds_changed is True
    assert p.status.dest_rect == (10, 20, 640, 360)


def test_seek_is_64_bit():
    p = MediaCommandParser()
    payload = struct.pack(">iI", 0, 987654)
    rv = p.execute(MEDIACMD_SEEK, payload)
    assert rv.reply == b""
    assert p.status.media_time_ms == 987654
    assert p.status.seeks == 1
