from app.protocol_constants import SAGE_COMMANDS
from app.sagetv_session import SageTVWebSession


def test_real_sage_command_ids():
    assert SAGE_COMMANDS["select"] == 20
    assert SAGE_COMMANDS["ok"] == 20
    assert SAGE_COMMANDS["back"] == 75
    assert SAGE_COMMANDS["home"] == 28
    assert SAGE_COMMANDS["guide"] == 18
    assert SAGE_COMMANDS["info"] == 24
    assert SAGE_COMMANDS["play"] == 7
    assert SAGE_COMMANDS["pause"] == 6


def test_conservative_renderer_properties():
    class DummyWs:
        pass
    s = SageTVWebSession("x", DummyWs())
    assert s.get_property("GFX_TEXTMODE") == "NONE"
    assert s.get_property("GFX_DRAWMODE") == "FULLSCREEN"
    assert s.get_property("GFX_SURFACES") == "FALSE"
    assert s.get_property("GFX_HIRES_SURFACES") == "FALSE"
