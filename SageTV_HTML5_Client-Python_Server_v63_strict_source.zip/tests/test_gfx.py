import struct

from app.gfx import GfxParser, argb_to_css
from app.protocol_constants import GFXCMD_FILLRECT, GFXCMD_FLIPBUFFER, GFXCMD_INIT


def pkt(cmd, *ints):
    # 4 byte GFX header then payload ints.
    return bytes([cmd,0,0,0]) + b''.join(struct.pack('>I', x & 0xFFFFFFFF) for x in ints)


def test_argb_to_css():
    assert argb_to_css(0xFF112233).startswith('rgba(17,34,51,1')


def test_init_reply():
    r, cmds = GfxParser().execute(pkt(GFXCMD_INIT))
    assert r == 1
    assert cmds[0]['op'] == 'init'


def test_fill_rect():
    r, cmds = GfxParser().execute(pkt(GFXCMD_FILLRECT, 1, 2, 3, 4, 0xFF010203, 0, 0, 0))
    assert r is None
    assert cmds[0]['op'] == 'fillRect'
    assert cmds[0]['x'] == 1
    assert cmds[0]['color'].startswith('rgba(1,2,3')


def test_flip_reply():
    r, cmds = GfxParser().execute(pkt(GFXCMD_FLIPBUFFER))
    assert r == 0
    assert cmds[0]['op'] == 'flip'
