# Core message types from OpenSageTV MiniClient MiniClientConnection.java
GET_PROPERTY_CMD_TYPE = 0
SET_PROPERTY_CMD_TYPE = 1
FS_CMD_TYPE = 2
DRAWING_CMD_TYPE = 16

IR_EVENT_REPLY_TYPE = 128
KB_EVENT_REPLY_TYPE = 129
MPRESS_EVENT_REPLY_TYPE = 130
MRELEASE_EVENT_REPLY_TYPE = 131
MCLICK_EVENT_REPLY_TYPE = 132
MMOVE_EVENT_REPLY_TYPE = 133
MDRAG_EVENT_REPLY_TYPE = 134
MWHEEL_EVENT_REPLY_TYPE = 135
SAGECOMMAND_EVENT_REPLY_TYPE = 136
UI_RESIZE_EVENT_REPLY_TYPE = 192
UI_REPAINT_EVENT_REPLY_TYPE = 193
IMAGE_UNLOAD_REPLY_TYPE = 226
OFFLINE_CACHE_CHANGE_REPLY_TYPE = 227

# Graphics commands from GFXCMD2.java
GFXCMD_INIT = 1
GFXCMD_DEINIT = 2
GFXCMD_DRAWRECT = 16
GFXCMD_FILLRECT = 17
GFXCMD_CLEARRECT = 18
GFXCMD_DRAWOVAL = 19
GFXCMD_FILLOVAL = 20
GFXCMD_DRAWROUNDRECT = 21
GFXCMD_FILLROUNDRECT = 22
GFXCMD_DRAWTEXT = 23
GFXCMD_DRAWTEXTURED = 24
GFXCMD_DRAWLINE = 25
GFXCMD_LOADIMAGE = 26
GFXCMD_UNLOADIMAGE = 27
GFXCMD_LOADFONT = 28
GFXCMD_UNLOADFONT = 29
GFXCMD_FLIPBUFFER = 30
GFXCMD_STARTFRAME = 31
GFXCMD_LOADIMAGELINE = 32
GFXCMD_PREPIMAGE = 33
GFXCMD_LOADIMAGECOMPRESSED = 34
GFXCMD_XFMIMAGE = 35
GFXCMD_LOADFONTSTREAM = 36
GFXCMD_CREATESURFACE = 37
GFXCMD_SETTARGETSURFACE = 38
GFXCMD_DRAWTEXTUREDDIFFUSE = 40
GFXCMD_PUSHTRANSFORM = 41
GFXCMD_POPTRANSFORM = 42
GFXCMD_TEXTUREBATCH = 43
GFXCMD_LOADCACHEDIMAGE = 44
GFXCMD_LOADIMAGETARGETED = 45
GFXCMD_PREPIMAGETARGETED = 46
GFXCMD_SETVIDEOPROP = 130
GFXCMD_MEDIA_RECONNECT = 131

# Sage command IDs. These are common user-command IDs used by SageTV clients.
# If a key does not work, browser can still send raw key events instead.
# Sage command IDs copied from OpenSageTV core/src/main/java/sagex/miniclient/SageCommand.java
# These are NOT the same as ordinary keyboard key codes.
SAGE_COMMANDS = {
    "left": 2,
    "right": 3,
    "up": 4,
    "down": 5,
    "pause": 6,
    "play": 7,
    "ff": 8,
    "skip_fwd": 8,
    "rew": 9,
    "skip_back": 9,
    "ch_up": 11,
    "channel_up": 11,
    "page_up_channel": 11,
    "ch_down": 12,
    "channel_down": 12,
    "page_down_channel": 12,
    "vol_up": 13,
    "vol_down": 14,
    "tv": 15,
    "faster": 16,
    "slower": 17,
    "guide": 18,
    "power": 19,
    "select": 20,
    "ok": 20,
    "watched": 21,
    "like": 22,
    "dont_like": 23,
    "info": 24,
    "record": 25,
    "mute": 26,
    "full_screen": 27,
    "home": 28,
    "options": 29,
    "0": 30,
    "1": 31,
    "2": 32,
    "3": 33,
    "4": 34,
    "5": 35,
    "6": 36,
    "7": 37,
    "8": 38,
    "9": 39,
    "search": 40,
    "setup": 41,
    "library": 42,
    "ar_fill": 47,
    "ar_4x3": 48,
    "ar_16x9": 49,
    "ar_source": 50,
    "page_up": 55,
    "page_down": 56,
    "page_right": 57,
    "page_left": 58,
    "play_pause": 59,
    "prev_channel": 60,
    "ff_2": 61,
    "skip_fwd_2": 61,
    "rew_2": 62,
    "skip_back_2": 62,
    "live_tv": 63,
    "dvd_menu": 67,
    "dvd": 74,
    "back": 75,
    "forward": 76,
    "delete": 83,
    "music": 84,
    "schedule": 85,
    "recordings": 86,
    "picture_library": 87,
    "video_library": 88,
    "stop": 89,
    "aspect": 96,
}


GFXCMD_NAMES = {
    1: "INIT", 2: "DEINIT", 16: "DRAWRECT", 17: "FILLRECT", 18: "CLEARRECT",
    19: "DRAWOVAL", 20: "FILLOVAL", 21: "DRAWROUNDRECT", 22: "FILLROUNDRECT",
    23: "DRAWTEXT", 24: "DRAWTEXTURED", 25: "DRAWLINE", 26: "LOADIMAGE",
    27: "UNLOADIMAGE", 28: "LOADFONT", 29: "UNLOADFONT", 30: "FLIPBUFFER",
    31: "STARTFRAME", 32: "LOADIMAGELINE", 33: "PREPIMAGE", 34: "LOADIMAGECOMPRESSED",
    35: "XFMIMAGE", 36: "LOADFONTSTREAM", 37: "CREATESURFACE", 38: "SETTARGETSURFACE",
    40: "DRAWTEXTUREDDIFFUSE", 41: "PUSHTRANSFORM", 42: "POPTRANSFORM",
    43: "TEXTUREBATCH", 44: "LOADCACHEDIMAGE", 45: "LOADIMAGETARGETED",
    46: "PREPIMAGETARGETED", 130: "SETVIDEOPROP", 131: "MEDIA_RECONNECT",
}
