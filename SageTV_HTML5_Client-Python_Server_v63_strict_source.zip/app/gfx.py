import base64
import struct
from dataclasses import dataclass, field
from typing import Any, Dict, Optional, Tuple

from .protocol_constants import *


def i32(buf: bytes, pos: int) -> int:
    # Java GFXCMD2.readInt adds 4 for the command header.
    p = pos + 4
    return struct.unpack_from(">i", buf, p)[0]


def u32(buf: bytes, pos: int) -> int:
    p = pos + 4
    return struct.unpack_from(">I", buf, p)[0]


def s16(buf: bytes, pos: int) -> int:
    p = pos + 4
    return struct.unpack_from(">h", buf, p)[0]


def argb_to_css(argb: int) -> str:
    argb &= 0xFFFFFFFF
    a = (argb >> 24) & 0xFF
    r = (argb >> 16) & 0xFF
    g = (argb >> 8) & 0xFF
    b = argb & 0xFF
    return f"rgba({r},{g},{b},{a / 255.0:.4f})"


def blend_to_alpha(blend: int) -> float:
    blend &= 0xFFFFFFFF
    a = (blend >> 24) & 0xFF
    if a == 0 and blend != 0:
        return 1.0
    return a / 255.0 if a else 1.0


def b64(data: bytes) -> str:
    return base64.b64encode(data).decode("ascii")


def image_mime(data: bytes) -> str:
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        return "image/png"
    if data.startswith(b"\xff\xd8\xff"):
        return "image/jpeg"
    if data.startswith(b"GIF87a") or data.startswith(b"GIF89a"):
        return "image/gif"
    if data.startswith(b"BM"):
        return "image/bmp"
    return "image/png"


@dataclass
class GfxState:
    handle_count: int = 2
    images: Dict[int, Dict[str, Any]] = field(default_factory=dict)
    advanced_image_caching: bool = True
    command_counts: Dict[int, int] = field(default_factory=dict)
    frame_count: int = 0
    draw_count_this_frame: int = 0


class GfxParser:
    def __init__(self, state: Optional[GfxState] = None):
        self.state = state or GfxState()

    def _new_handle(self) -> int:
        h = self.state.handle_count
        self.state.handle_count += 1
        return h

    def execute(self, packet: bytes) -> Tuple[Optional[int], list[dict]]:
        """Parse a SageTV GFX packet payload.

        The packet begins with a 4-byte GFX command header. Byte 0 is the command.
        Java GFXCMD2 then reads args starting at offset +4.
        Returns (reply_int_or_none, canvas_commands).
        """
        if not packet:
            return None, []
        cmd = packet[0]
        self.state.command_counts[cmd] = self.state.command_counts.get(cmd, 0) + 1
        out: list[dict] = []
        reply: Optional[int] = None

        try:
            if cmd == GFXCMD_INIT:
                reply = 1
                out.append({"op": "init"})
            elif cmd == GFXCMD_DEINIT:
                out.append({"op": "deinit"})
            elif cmd == GFXCMD_STARTFRAME:
                self.state.frame_count += 1
                self.state.draw_count_this_frame = 0
                out.append({"op": "start"})
            elif cmd == GFXCMD_FLIPBUFFER:
                reply = 0
                out.append({"op": "flip", "frame": self.state.frame_count, "draws": self.state.draw_count_this_frame})
            elif cmd == GFXCMD_DRAWRECT:
                self.state.draw_count_this_frame += 1
                out.append({"op": "drawRect", "x": i32(packet,0), "y": i32(packet,4), "w": i32(packet,8), "h": i32(packet,12), "thickness": i32(packet,16), "color": argb_to_css(i32(packet,20))})
            elif cmd == GFXCMD_FILLRECT:
                self.state.draw_count_this_frame += 1
                out.append({"op": "fillRect", "x": i32(packet,0), "y": i32(packet,4), "w": i32(packet,8), "h": i32(packet,12), "color": argb_to_css(i32(packet,16))})
            elif cmd == GFXCMD_CLEARRECT:
                self.state.draw_count_this_frame += 1
                out.append({"op": "clearRect", "x": i32(packet,0), "y": i32(packet,4), "w": i32(packet,8), "h": i32(packet,12), "color": argb_to_css(i32(packet,16))})
            elif cmd == GFXCMD_DRAWLINE:
                self.state.draw_count_this_frame += 1
                out.append({"op": "drawLine", "x1": i32(packet,0), "y1": i32(packet,4), "x2": i32(packet,8), "y2": i32(packet,12), "color": argb_to_css(i32(packet,16))})
            elif cmd == GFXCMD_DRAWOVAL:
                self.state.draw_count_this_frame += 1
                out.append({"op": "drawOval", "x": i32(packet,0), "y": i32(packet,4), "w": i32(packet,8), "h": i32(packet,12), "thickness": i32(packet,16), "color": argb_to_css(i32(packet,20)), "clip": [i32(packet,36), i32(packet,40), i32(packet,44), i32(packet,48)]})
            elif cmd == GFXCMD_FILLOVAL:
                self.state.draw_count_this_frame += 1
                out.append({"op": "fillOval", "x": i32(packet,0), "y": i32(packet,4), "w": i32(packet,8), "h": i32(packet,12), "color": argb_to_css(i32(packet,16)), "clip": [i32(packet,32), i32(packet,36), i32(packet,40), i32(packet,44)]})
            elif cmd == GFXCMD_DRAWROUNDRECT:
                self.state.draw_count_this_frame += 1
                out.append({"op": "drawRoundRect", "x": i32(packet,0), "y": i32(packet,4), "w": i32(packet,8), "h": i32(packet,12), "thickness": i32(packet,16), "arc": i32(packet,20) * 2, "color": argb_to_css(i32(packet,24)), "clip": [i32(packet,40), i32(packet,44), i32(packet,48), i32(packet,52)]})
            elif cmd == GFXCMD_FILLROUNDRECT:
                self.state.draw_count_this_frame += 1
                out.append({"op": "fillRoundRect", "x": i32(packet,0), "y": i32(packet,4), "w": i32(packet,8), "h": i32(packet,12), "arc": i32(packet,16) * 2, "color": argb_to_css(i32(packet,20)), "clip": [i32(packet,36), i32(packet,40), i32(packet,44), i32(packet,48)]})
            elif cmd == GFXCMD_DRAWTEXTURED:
                self.state.draw_count_this_frame += 1
                handle = i32(packet,16)
                out.append({"op": "drawTexture", "x": i32(packet,0), "y": i32(packet,4), "w": i32(packet,8), "h": i32(packet,12), "handle": handle, "sx": i32(packet,20), "sy": i32(packet,24), "sw": i32(packet,28), "sh": i32(packet,32), "alpha": blend_to_alpha(i32(packet,36))})
            elif cmd == GFXCMD_DRAWTEXTUREDDIFFUSE:
                self.state.draw_count_this_frame += 1
                handle = i32(packet,16)
                out.append({"op": "drawTexture", "x": i32(packet,0), "y": i32(packet,4), "w": i32(packet,8), "h": i32(packet,12), "handle": handle, "sx": i32(packet,20), "sy": i32(packet,24), "sw": i32(packet,28), "sh": i32(packet,32), "alpha": blend_to_alpha(i32(packet,36))})
            elif cmd == GFXCMD_LOADIMAGE:
                width = i32(packet,0)
                height = i32(packet,4)
                handle = self._new_handle()
                self.state.images[handle] = {"width": width, "height": height, "kind": "raw", "lines": {}}
                reply = handle
                out.append({"op": "imageAlloc", "handle": handle, "w": width, "h": height})
            elif cmd == GFXCMD_LOADIMAGETARGETED:
                handle = i32(packet,0)
                width = i32(packet,4)
                height = i32(packet,8)
                self.state.images[handle] = {"width": width, "height": height, "kind": "targeted"}
                out.append({"op": "imageAlloc", "handle": handle, "w": width, "h": height})
            elif cmd == GFXCMD_PREPIMAGE:
                # Non-advanced path. Return the handle Sage should use for the following compressed image.
                width = i32(packet,0) if len(packet) >= 8 else 1
                height = i32(packet,4) if len(packet) >= 12 else 1
                handle = self._new_handle()
                self.state.images[handle] = {"width": width, "height": height, "kind": "prep"}
                reply = handle
                out.append({"op": "imageAlloc", "handle": handle, "w": width, "h": height})
            elif cmd == GFXCMD_PREPIMAGETARGETED:
                # Advanced image caching path: Sage chooses the handle.
                handle = i32(packet,0)
                width = i32(packet,4) if len(packet) >= 12 else 1
                height = i32(packet,8) if len(packet) >= 16 else 1
                self.state.images[handle] = {"width": width, "height": height, "kind": "prepTargeted"}
                reply = None
                out.append({"op": "imageAlloc", "handle": handle, "w": width, "h": height})
            elif cmd == GFXCMD_LOADIMAGECOMPRESSED:
                incoming_handle = i32(packet,0)
                size = i32(packet,4)
                data = packet[12:12+size]
                if self.state.advanced_image_caching:
                    handle = incoming_handle
                    reply = None
                else:
                    # Match Java MiniClient behavior: non-advanced compressed loads return a new handle.
                    handle = self._new_handle()
                    reply = handle
                self.state.images[handle] = {"kind": "compressed", "size": size}
                out.append({"op": "registerImage", "handle": handle, "mime": image_mime(data), "data": b64(data)})
            elif cmd == GFXCMD_LOADIMAGELINE:
                # Raw line loading is uncommon with PNG/JPG support, but log enough to identify it.
                handle = i32(packet,0)
                line = i32(packet,4)
                size = i32(packet,8)
                out.append({"op": "debug", "message": f"LOADIMAGELINE handle={handle} line={line} bytes={size} not rendered yet"})
            elif cmd == GFXCMD_LOADCACHEDIMAGE:
                # We advertise no offline cache, so this should be rare. Tell the browser/debug log.
                handle = i32(packet,0)
                out.append({"op": "debug", "message": f"LOADCACHEDIMAGE handle={handle} requested but offline cache is disabled"})
            elif cmd == GFXCMD_UNLOADIMAGE:
                handle = i32(packet,0)
                self.state.images.pop(handle, None)
                out.append({"op": "unloadImage", "handle": handle})
            elif cmd == GFXCMD_CREATESURFACE:
                handle = self._new_handle()
                w = i32(packet,0); h = i32(packet,4)
                self.state.images[handle] = {"width": w, "height": h, "kind": "surface"}
                reply = handle
                out.append({"op": "createSurface", "handle": handle, "w": w, "h": h})
            elif cmd == GFXCMD_SETTARGETSURFACE:
                out.append({"op": "setSurface", "handle": i32(packet,0)})
            elif cmd == GFXCMD_SETVIDEOPROP:
                out.append({"op": "videoBounds", "src": [i32(packet,4), i32(packet,8), i32(packet,12), i32(packet,16)], "dst": [i32(packet,20), i32(packet,24), i32(packet,28), i32(packet,32)]})
            elif cmd == GFXCMD_PUSHTRANSFORM:
                # Browser transform stack can be added after basic menus render.
                out.append({"op": "pushTransform", "raw": b64(packet[4:])})
            elif cmd == GFXCMD_POPTRANSFORM:
                out.append({"op": "popTransform"})
            elif cmd == GFXCMD_TEXTUREBATCH:
                num = i32(packet,0) if len(packet) >= 8 else 0
                size = i32(packet,4) if len(packet) >= 12 else 0
                out.append({"op": "debug", "message": f"TEXTUREBATCH count={num} bytes={size} not rendered yet"})
            elif cmd == GFXCMD_LOADFONT:
                # Return 0 to request font-as-image path when Sage uses font server features.
                reply = 0
            elif cmd == GFXCMD_UNLOADFONT:
                pass
            elif cmd == GFXCMD_DRAWTEXT:
                text_len = i32(packet,8)
                chars = []
                for n in range(max(0, text_len)):
                    try:
                        chars.append(chr(s16(packet, 12 + n*2)))
                    except Exception:
                        break
                off = 12 + text_len*2
                font_handle = i32(packet, off) if len(packet) >= off + 4 else 0
                color = i32(packet, off+4) if len(packet) >= off + 8 else 0xFFFFFFFF
                clip = [0, 0, 0, 0]
                if len(packet) >= off + 24:
                    clip = [i32(packet, off+8), i32(packet, off+12), i32(packet, off+16), i32(packet, off+20)]
                self.state.draw_count_this_frame += 1
                out.append({"op": "drawText", "x": i32(packet,0), "y": i32(packet,4), "text": "".join(chars), "font": font_handle, "color": argb_to_css(color), "clip": clip})
            else:
                name = GFXCMD_NAMES.get(cmd, f"Unknown {cmd}") if 'GFXCMD_NAMES' in globals() else f"Unknown {cmd}"
                out.append({"op": "debug", "message": f"Unhandled GFX command {name} ({cmd}) len={len(packet)}"})
        except Exception as e:
            out.append({"op": "debug", "message": f"Error parsing GFX command {cmd}: {e}"})
        return reply, out
