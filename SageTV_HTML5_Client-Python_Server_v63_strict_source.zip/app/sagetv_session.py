import asyncio
import json
import os
import random
import re
import socket
import struct
import time
import urllib.parse
from pathlib import Path
from dataclasses import dataclass
from typing import Optional, Tuple

from fastapi import WebSocket, WebSocketDisconnect
from starlette.websockets import WebSocketState

from .gfx import GfxParser
from .media import (
    MediaCommandParser, MEDIA_CMD_NAMES, MEDIACMD_PUSHBUFFER,
    MEDIACMD_OPENURL, MEDIACMD_FLUSH, MEDIACMD_SEEK, MEDIACMD_STOP, MEDIACMD_DEINIT,
)
from .video_bridge import FfmpegHlsBridge, SagePullStreamPump, parse_stv_url
from .protocol_constants import *


def parse_server(server: str) -> Tuple[str, int]:
    server = server.strip()
    if ":" in server:
        host, port = server.rsplit(":", 1)
        return host.strip(), int(port)
    return server, 31099


def normalize_mac(mac: str | None) -> str:
    if not mac:
        rnd = [0x02, 0x51, 0x56, random.randint(0,255), random.randint(0,255), random.randint(0,255)]
        return ":".join(f"{b:02x}" for b in rnd)
    raw = re.sub(r"[^0-9a-fA-F]", "", mac)
    if len(raw) < 12:
        raw = (raw + "025156000000")[:12]
    return ":".join(raw[i:i+2].lower() for i in range(0, 12, 2))


def mac_to_bytes(mac: str) -> bytes:
    return bytes(int(part, 16) for part in mac.split(":"))


async def open_sagetv_socket(host: str, port: int, conn_type: int, client_id: str, timeout: float = 10.0) -> Tuple[asyncio.StreamReader, asyncio.StreamWriter]:
    reader, writer = await asyncio.wait_for(asyncio.open_connection(host, port), timeout=timeout)
    # Java MiniClient writes 7 bytes: 0x01 + 6 MAC bytes, then one connType byte.
    writer.write(bytes([1]) + mac_to_bytes(client_id) + bytes([conn_type]))
    await writer.drain()
    accepted = await asyncio.wait_for(reader.readexactly(1), timeout=timeout)
    if accepted[0] != 2:
        writer.close()
        try:
            await writer.wait_closed()
        except Exception:
            pass
        raise ConnectionError(f"SageTV rejected conn_type {conn_type}; reply={accepted[0]}")
    return reader, writer


def make_reply_packet(reply_type: int, reply_count: int, payload: bytes) -> bytes:
    if len(payload) > 0xFFFFFF:
        raise ValueError("Payload too large")
    # 1 byte type, 3 byte length, 12 bytes event metadata, then payload.
    return bytes([reply_type]) + len(payload).to_bytes(3, "big") + struct.pack(">III", 0, reply_count, 0) + payload


@dataclass
class ClientSize:
    width: int = 1280
    height: int = 720


def parse_max_height(value, default: int = 480) -> int:
    """Return 0 for source/original height, otherwise a positive scale height."""
    if value is None:
        return int(default or 0)
    text = str(value).strip().lower()
    if text in ("", "source", "src", "original", "native", "0", "none"):
        return 0
    # Accept labels such as "720p" from future UI variants.
    text = text.rstrip("p")
    try:
        return max(0, int(text))
    except Exception:
        return int(default or 0)


def normalize_bitrate_choice(value) -> str:
    """Normalize the browser bitrate dropdown value."""
    text = str(value or "source").strip().lower()
    if text in ("", "default"):
        return "source"
    if text in ("source", "src", "original", "native"):
        return "source"
    if text in ("auto", "adaptive"):
        return "auto"
    if text[-1:] in ("k", "m"):
        return text
    try:
        int(text)
        return text + "k"
    except Exception:
        return "source"



def parse_audio_offset_ms(value, default: int = 0) -> int:
    try:
        text = str(value if value is not None else default).strip().lower().replace("ms", "")
        return max(-2000, min(2000, int(float(text))))
    except Exception:
        return int(default or 0)

def parse_bool(value, default: bool = False) -> bool:
    if value is None:
        return bool(default)
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in ("1", "true", "yes", "on", "checked")

def normalize_player_mode(value) -> str:
    text = str(value or "mseav").strip().lower()
    if text in ("mseav", "mse-av", "mse_sep", "mse-sep", "separate", "separate_av", "split"):
        return "mseav"
    if text in ("mse", "mse-fmp4", "fmp4", "mp4", "direct"):
        return "mse"
    if text in ("hlsfmp4", "hls-fmp4", "hls_fmp4", "cmaf"):
        return "hlsfmp4"
    if text in ("videojsfmp4", "videojs-fmp4", "videojs_fmp4", "vjsfmp4", "vjs-fmp4", "video-js-fmp4"):
        return "videojsfmp4"
    if text in ("videojs", "video-js", "vjs"):
        return "videojs"
    return "hls"

def normalize_playback_source(value) -> str:
    text = str(value or "push").strip().lower()
    aliases = {
        "auto": "auto",
        "auto_direct": "auto",
        "auto-direct": "auto",
        "direct": "direct",
        "file": "direct",
        "smb": "direct",
        "nfs": "direct",
        "pull": "pull",
        "stv": "pull",
        "push": "push",
        "pushbuffer": "push",
    }
    return aliases.get(text, "push")

def _strip_url_to_path(url: str) -> str:
    r"""Normalize file/smb/stv URLs to the path portion used for mapping.

    Important for Direct File/SMB mode: SageTV often sends URLs like
    stv://192.168.10.175//var/media/tv/file.ts, while the Windows share is
    \\192.168.10.175\sagemedia\tv\file.ts.  The stv:// host is only the SageTV
    pull server; the part we need for file mapping is /var/media/tv/file.ts.
    """
    raw = str(url or "").strip()
    if not raw:
        return ""
    low = raw.lower()
    if low.startswith("stv://"):
        try:
            _host, stv_path = parse_stv_url(raw)
            return urllib.parse.unquote(stv_path or "")
        except Exception:
            return urllib.parse.unquote(raw)
    if low.startswith("file://"):
        parsed = urllib.parse.urlparse(raw)
        path = urllib.parse.unquote(parsed.path or "")
        if parsed.netloc:
            # file://server/share/file.ts -> UNC on Windows, //server/share on POSIX.
            return ("\\\\" + parsed.netloc + path.replace("/", "\\")) if os.name == "nt" else ("//" + parsed.netloc + path)
        if os.name == "nt" and path.startswith("/") and len(path) >= 3 and path[2] == ":":
            path = path[1:]
        return path.replace("/", "\\") if os.name == "nt" else path
    if low.startswith("smb://"):
        parsed = urllib.parse.urlparse(raw)
        path = urllib.parse.unquote(parsed.path or "")
        return ("\\\\" + parsed.netloc + path.replace("/", "\\")) if os.name == "nt" else ("//" + parsed.netloc + path)
    return urllib.parse.unquote(raw)

def _norm_compare_path(path: str) -> str:
    p = str(path or "").replace("\\", "/")
    # Collapse repeated slashes except directly after a URL scheme marker.
    marker = ":__SCHEME_SLASHES__"
    p = p.replace("://", marker)
    while "//" in p:
        p = p.replace("//", "/")
    p = p.replace(marker, "://")
    return p.lower() if os.name == "nt" else p

def _join_mapped_path(local_root: str, rest: str) -> str:
    root = str(local_root or "").strip().rstrip("/\\")
    tail = str(rest or "").strip().lstrip("/\\")
    if not tail:
        return root
    # Preserve UNC roots on Windows.  pathlib can reinterpret backslash-heavy
    # strings when the server is running on a different OS, so keep this as a
    # simple string join.
    if "\\" in root or (os.name == "nt" and not root.startswith("/")):
        return root + "\\" + tail.replace("/", "\\")
    return root + "/" + tail.replace("\\", "/")

def map_direct_path(source_path: str, sage_root: str = "", local_root: str = "") -> str:
    src = _strip_url_to_path(source_path)
    if not src:
        return ""
    pairs: list[tuple[str, str]] = []
    if sage_root and local_root:
        pairs.append((_strip_url_to_path(sage_root), _strip_url_to_path(local_root)))
    # Optional env for multiple mappings:
    # SAGEWEB_DIRECT_PATH_MAP=\\SAGE\TV=Z:\TV|/var/media=/mnt/sagetv
    env_map = os.environ.get("SAGEWEB_DIRECT_PATH_MAP", "")
    for part in re.split(r"[|;]", env_map):
        if not part.strip() or "=" not in part:
            continue
        a, b = part.split("=", 1)
        if a.strip() and b.strip():
            pairs.append((_strip_url_to_path(a.strip()), _strip_url_to_path(b.strip())))
    cmp_src = _norm_compare_path(src)
    for sage, local in pairs:
        if not sage or not local:
            continue
        sage_norm = str(sage).rstrip("/\\")
        cmp_sage = _norm_compare_path(sage_norm).rstrip("/")
        if cmp_src == cmp_sage or cmp_src.startswith(cmp_sage + "/"):
            rest = src[len(sage_norm):].lstrip("/\\")
            return _join_mapped_path(local, rest)
    return src



class SageTVWebSession:
    def __init__(self, session_id: str, websocket: WebSocket):
        self.session_id = session_id
        self.ws = websocket
        self.server = os.environ.get("SAGETV_SERVER", "192.168.10.175:31099")
        self.client_id = normalize_mac(os.environ.get("SAGETV_CLIENT_ID"))
        self.size = ClientSize()
        self.gfx_reader: Optional[asyncio.StreamReader] = None
        self.gfx_writer: Optional[asyncio.StreamWriter] = None
        self.media_reader: Optional[asyncio.StreamReader] = None
        self.media_writer: Optional[asyncio.StreamWriter] = None
        self.gfx_task: Optional[asyncio.Task] = None
        self.media_task: Optional[asyncio.Task] = None
        self.reply_count = 0
        self.connected = False
        self.gfx = GfxParser()
        self.media = MediaCommandParser()
        self.media_caps_enabled = os.environ.get("SAGEWEB_MEDIA_CAPS", "0").lower() in ("1", "true", "yes", "on")
        self.video_encoder = os.environ.get("SAGEWEB_VIDEO_ENCODER", "auto")
        self.video_max_height = parse_max_height(os.environ.get("SAGEWEB_VIDEO_MAX_HEIGHT", "source"), default=0)
        self.video_bitrate = normalize_bitrate_choice(os.environ.get("SAGEWEB_VIDEO_BITRATE", "source"))
        self.hls_mode = os.environ.get("SAGEWEB_HLS_MODE", "stable").strip().lower()
        if self.hls_mode not in ("stable", "rolling", "debug"):
            self.hls_mode = "stable"
        self.player_mode = normalize_player_mode(os.environ.get("SAGEWEB_PLAYER_MODE", "mseav"))
        self.audio_offset_ms = parse_audio_offset_ms(os.environ.get("SAGEWEB_AUDIO_OFFSET_MS", "-200"), default=-200)
        self.video = FfmpegHlsBridge(
            session_id=session_id,
            encoder_request=self.video_encoder,
            max_height=self.video_max_height,
            video_bitrate=self.video_bitrate,
            hls_mode=self.hls_mode,
            player_mode=self.player_mode,
            audio_offset_ms=self.audio_offset_ms,
        )
        self.playback_source = normalize_playback_source(os.environ.get("SAGEWEB_PLAYBACK_SOURCE", "direct"))
        # v63: No fallback checkbox was removed. Explicit Source/Player selections are always strict.
        # Use Source=Auto Direct/PULL/PUSH when source fallback is desired.
        self.no_fallback = True
        self.direct_sage_root = os.environ.get("SAGEWEB_DIRECT_SAGE_ROOT", "")
        self.direct_local_root = os.environ.get("SAGEWEB_DIRECT_LOCAL_ROOT", "")
        self.direct_last_path = ""
        self._ignored_pushbuffer_logged = False
        self.pull_pump: Optional[SagePullStreamPump] = None
        self.pull_task: Optional[asyncio.Task] = None
        self.started_at = time.time()
        self.last_error: Optional[str] = None
        self.gfx_packet_count = 0
        self.gfx_reply_count = 0
        self._send_lock = asyncio.Lock()
        # v20: batch all GFX ops between STARTFRAME and FLIPBUFFER into one
        # WebSocket message.  Sending every SageTV draw packet individually caused
        # browser/main-thread lag and delayed arrow-key response.
        self._frame_commands: list[dict] = []
        self._inside_frame = False
        self.gfx_trace = os.environ.get("SAGEWEB_GFX_TRACE", "0").lower() in ("1", "true", "yes", "on")
        self.ws_closed = False

    def snapshot(self):
        return {
            "server": self.server,
            "client_id": self.client_id,
            "connected": self.connected,
            "size": {"width": self.size.width, "height": self.size.height},
            "last_error": self.last_error,
            "gfx_packets": self.gfx_packet_count,
            "gfx_replies": self.gfx_reply_count,
            "media": self.media.status.to_json(),
            "video": self.video.status.to_json(),
            "media_caps_enabled": self.media_caps_enabled,
            "playback_source": self.playback_source,
            "no_fallback": self.no_fallback,
            "direct_sage_root": self.direct_sage_root,
            "direct_local_root": self.direct_local_root,
            "direct_last_path": self.direct_last_path,
            "hls_mode": self.hls_mode,
            "player_mode": self.player_mode,
            "video_encoder": self.video_encoder,
            "video_max_height": self.video_max_height,
            "video_bitrate": self.video_bitrate,
            "age_seconds": round(time.time() - self.started_at, 1),
        }

    async def send(self, payload: dict):
        if self.ws_closed:
            return False
        async with self._send_lock:
            try:
                if self.ws.application_state != WebSocketState.CONNECTED:
                    self.ws_closed = True
                    return False
                await self.ws.send_text(json.dumps(payload, separators=(",", ":")))
                return True
            except (WebSocketDisconnect, RuntimeError):
                self.ws_closed = True
                return False

    async def send_log(self, message: str):
        await self.send({"type": "log", "message": message})

    async def send_gfx(self, commands: list[dict]):
        if commands:
            await self.send({"type": "gfx", "commands": commands})

    async def handle_browser_message(self, data: dict):
        msg_type = data.get("type")
        if msg_type == "connect":
            self.server = data.get("server") or self.server
            self.client_id = normalize_mac(data.get("client_id") or self.client_id)
            self.size.width = int(data.get("width") or self.size.width)
            self.size.height = int(data.get("height") or self.size.height)
            self.media_caps_enabled = bool(data.get("media_caps", self.media_caps_enabled))
            self.playback_source = normalize_playback_source(data.get("playback_source") or self.playback_source)
            self.no_fallback = True
            self.direct_sage_root = str(data.get("direct_sage_root") if data.get("direct_sage_root") is not None else self.direct_sage_root)
            self.direct_local_root = str(data.get("direct_local_root") if data.get("direct_local_root") is not None else self.direct_local_root)
            self.video_encoder = str(data.get("video_encoder") or self.video_encoder or "auto")
            self.video_max_height = parse_max_height(data.get("video_max_height"), default=self.video_max_height)
            self.video_bitrate = normalize_bitrate_choice(data.get("video_bitrate") or self.video_bitrate or "source")
            self.hls_mode = str(data.get("hls_mode") or self.hls_mode or "stable").strip().lower()
            if self.hls_mode not in ("stable", "rolling", "debug"):
                self.hls_mode = "stable"
            self.player_mode = normalize_player_mode(data.get("player_mode") or self.player_mode or "mseav")
            self.audio_offset_ms = parse_audio_offset_ms(data.get("audio_offset_ms"), default=self.audio_offset_ms)
            self._apply_video_settings_to_bridge()
            await self.connect_to_sagetv()
        elif msg_type == "disconnect":
            await self.send_log("Browser requested disconnect")
            await self.close(keep_ws=True)
        elif msg_type == "videoSettings":
            await self.apply_video_settings(data, restart_if_running=True)
        elif msg_type == "videoRestart":
            reason = str(data.get("reason") or "browser requested video restart")
            await self.restart_video_bridge(reason=reason)
        elif msg_type == "resize":
            self.size.width = int(data.get("width") or self.size.width)
            self.size.height = int(data.get("height") or self.size.height)
            await self.post_resize(self.size.width, self.size.height)
        elif msg_type == "key":
            key = data.get("key") or ""
            code = int(data.get("keyCode") or 0)
            await self.post_key(code, key)
        elif msg_type == "command":
            cmd = data.get("command")
            if cmd in SAGE_COMMANDS:
                await self.post_sage_command(SAGE_COMMANDS[cmd])
            else:
                await self.send_log(f"Unknown command: {cmd}")
        elif msg_type == "mouse":
            await self.post_mouse(data)
        else:
            await self.send_log(f"Unhandled browser message: {data}")


    def _read_video_settings_from_message(self, data: dict) -> dict:
        enc = str(data.get("video_encoder") or self.video_encoder or "auto")
        max_h = parse_max_height(data.get("video_max_height"), default=self.video_max_height)
        bitrate = normalize_bitrate_choice(data.get("video_bitrate") or self.video_bitrate or "source")
        hls_mode = str(data.get("hls_mode") or self.hls_mode or "stable").strip().lower()
        if hls_mode not in ("stable", "rolling", "debug"):
            hls_mode = "stable"
        player = normalize_player_mode(data.get("player_mode") or self.player_mode or "mseav")
        audio_offset = parse_audio_offset_ms(data.get("audio_offset_ms"), default=self.audio_offset_ms)
        return {
            "video_encoder": enc,
            "video_max_height": max_h,
            "video_bitrate": bitrate,
            "hls_mode": hls_mode,
            "player_mode": player,
            "audio_offset_ms": audio_offset,
            "playback_source": normalize_playback_source(data.get("playback_source") or self.playback_source),
            "no_fallback": True,
            "direct_sage_root": str(data.get("direct_sage_root") if data.get("direct_sage_root") is not None else self.direct_sage_root),
            "direct_local_root": str(data.get("direct_local_root") if data.get("direct_local_root") is not None else self.direct_local_root),
        }

    def _apply_video_settings_to_bridge(self):
        self.video.encoder_request = self.video_encoder
        self.video.max_height = self.video_max_height
        self.video.video_bitrate = self.video_bitrate
        self.video.hls_mode = self.hls_mode
        self.video.player_mode = self.player_mode
        self.video.audio_offset_ms = self.audio_offset_ms
        self.video.capture_push_stream = self.hls_mode == "debug"
        # Keep explicit encoder/player tests strict too. Encoder fallback can be reintroduced as a separate Auto Encoder option later.
        self.video.allow_internal_fallback = False
        # Show the selected source in debug even before FFmpeg starts.
        # Starters still set direct path / pull URL immediately before start().
        if not self.video.status.running:
            self.video.input_source = self.playback_source if self.playback_source in ("direct", "pull", "push") else "auto"
            self.video.direct_input_path = ""
            self.video.pull_url = ""

    async def apply_video_settings(self, data: dict, restart_if_running: bool = True):
        new_settings = self._read_video_settings_from_message(data)
        old_settings = {
            "video_encoder": self.video_encoder,
            "video_max_height": self.video_max_height,
            "video_bitrate": self.video_bitrate,
            "hls_mode": self.hls_mode,
            "player_mode": self.player_mode,
            "audio_offset_ms": self.audio_offset_ms,
            "playback_source": self.playback_source,
            "no_fallback": self.no_fallback,
            "direct_sage_root": self.direct_sage_root,
            "direct_local_root": self.direct_local_root,
        }
        changed = [k for k, v in new_settings.items() if old_settings.get(k) != v]
        self.video_encoder = new_settings["video_encoder"]
        self.video_max_height = new_settings["video_max_height"]
        self.video_bitrate = new_settings["video_bitrate"]
        self.hls_mode = new_settings["hls_mode"]
        self.player_mode = new_settings["player_mode"]
        self.audio_offset_ms = new_settings["audio_offset_ms"]
        self.playback_source = new_settings["playback_source"]
        self.no_fallback = new_settings["no_fallback"]
        self.direct_sage_root = new_settings["direct_sage_root"]
        self.direct_local_root = new_settings["direct_local_root"]
        self._apply_video_settings_to_bridge()
        if not changed:
            return
        desc = ", ".join(changed)
        await self.send_log(
            f"Video settings updated live: encoder={self.video_encoder}, maxH={'source' if not self.video_max_height else self.video_max_height}, bitrate={self.video_bitrate}, player={self.player_mode}, hls={self.hls_mode}, audioOffset={self.audio_offset_ms}ms, source={self.playback_source}, strict=True"
        )
        source_keys = {"playback_source", "direct_sage_root", "direct_local_root"}
        restart_keys = [k for k in changed if k not in source_keys]
        if source_keys.intersection(changed) and self.connected:
            await self.send_log("Playback Source/path changes usually take effect on reconnect or the next SageTV OPENURL. If video is already running, stop/play or reconnect.")
        if restart_if_running and self.video.status.running and restart_keys:
            await self.restart_video_bridge(reason=f"video settings changed: {desc}")

    async def restart_video_bridge(self, reason: str = "video restart requested"):
        if not self.video.status.running:
            await self.send_log(f"Video restart ignored because FFmpeg is not running ({reason})")
            return
        try:
            playlist = await self.video.restart_with_current_settings(reason=reason)
            await self.send({"type": "videoStream", "url": playlist, "status": self.video.status.to_json()})
            await self.send_log(f"Video bridge restarted live: {playlist} ({reason})")
        except Exception as exc:
            self.video.status.last_error = str(exc)
            await self.send_log(f"Video bridge live restart failed: {exc}")

    async def connect_to_sagetv(self):
        await self.close(keep_ws=True)
        host, port = parse_server(self.server)
        await self.send_log(f"Connecting to SageTV {host}:{port} with client ID {self.client_id}; source={self.playback_source}; strictSource={self.playback_source != 'auto'}; directRoot={self.direct_sage_root or '(none)'} -> {self.direct_local_root or '(none)'}")
        try:
            # conn_type 1 = media, conn_type 0 = gfx/events, matching Java MiniClient.
            self.media_reader, self.media_writer = await open_sagetv_socket(host, port, 1, self.client_id)
            await self.send_log("Media socket accepted")
            self.gfx_reader, self.gfx_writer = await open_sagetv_socket(host, port, 0, self.client_id)
            await self.send_log("GFX socket accepted")
            self.connected = True
            self.media_task = asyncio.create_task(self.media_loop(), name=f"media-{self.session_id}")
            self.gfx_task = asyncio.create_task(self.gfx_loop(), name=f"gfx-{self.session_id}")
            await self.post_resize(self.size.width, self.size.height)
        except Exception as e:
            self.last_error = str(e)
            await self.send_log(f"SageTV connect failed: {e}")
            await self.close(keep_ws=True)

    async def close(self, keep_ws: bool = False):
        self.connected = False
        for task_name in ("gfx_task", "media_task", "pull_task"):
            task = getattr(self, task_name, None)
            if task and not task.done():
                task.cancel()
            setattr(self, task_name, None)
        self.pull_pump = None
        for writer_name in ("gfx_writer", "media_writer"):
            writer = getattr(self, writer_name)
            if writer:
                try:
                    writer.close()
                    await writer.wait_closed()
                except Exception:
                    pass
            setattr(self, writer_name, None)
        self.gfx_reader = None
        self.media_reader = None
        try:
            await self.video.stop(remove_files=True)
        except Exception:
            pass
        if not keep_ws:
            self.ws_closed = True
            try:
                if self.ws.application_state == WebSocketState.CONNECTED:
                    await self.ws.close()
            except Exception:
                pass

    async def reconnect_media_socket(self, reason: str = "MEDIA_RECONNECT"):
        """Reconnect only the SageTV media socket, matching Java MiniClient behavior.

        SageTV can send GFXCMD_MEDIA_RECONNECT on the GFX/event channel when
        playback stops, errors, or changes. The Java MiniClient closes the media
        socket and lets the media thread reconnect. If we ignore it, SageTV can
        show "There was a Playback Error in Playback" and the UI can become
        unresponsive after stopping a video.
        """
        await self.send_log(f"GFX MEDIA_RECONNECT requested; reconnecting media socket ({reason})")
        current = asyncio.current_task()
        if self.media_task and self.media_task is not current and not self.media_task.done():
            self.media_task.cancel()
        self.media_task = None
        await self.stop_pull_pump()
        try:
            await self.video.stop(remove_files=True)
            await self.send({"type": "videoStop", "status": self.video.status.to_json()})
        except Exception:
            pass
        if self.media_writer:
            try:
                self.media_writer.close()
                await self.media_writer.wait_closed()
            except Exception:
                pass
        self.media_reader = None
        self.media_writer = None
        if not self.connected:
            return
        try:
            host, port = parse_server(self.server)
            self.media = MediaCommandParser()
            self.media_reader, self.media_writer = await open_sagetv_socket(host, port, 1, self.client_id)
            await self.send_log("Media socket reconnected")
            self.media_task = asyncio.create_task(self.media_loop(), name=f"media-{self.session_id}")
        except Exception as exc:
            self.last_error = str(exc)
            await self.send_log(f"Media reconnect failed: {exc}")


    async def gfx_loop(self):
        assert self.gfx_reader is not None
        await self.send_log("GFX loop running")
        try:
            while self.connected:
                header = await self.gfx_reader.readexactly(4)
                cmd_type = header[0]
                length = int.from_bytes(header[1:4], "big")
                payload = await self.gfx_reader.readexactly(length) if length else b""
                await self.handle_sagetv_packet(cmd_type, payload)
        except asyncio.CancelledError:
            pass
        except Exception as e:
            self.last_error = str(e)
            await self.send_log(f"GFX loop stopped: {e}")
            self.connected = False

    async def stop_pull_pump(self):
        if self.pull_task and not self.pull_task.done():
            self.pull_task.cancel()
            try:
                await self.pull_task
            except Exception:
                pass
        self.pull_task = None
        self.pull_pump = None

    async def start_pull_stream_fallback(self, url: str):
        """Start SageTV stv:// PULL input.

        Source selection now controls whether SageTV is asked for PULL/file URLs
        or PUSHBUFFER. This pump reads from SageTV's port 7818 file streamer
        and feeds FFmpeg when PULL is selected or Source=Auto selects PULL.
        """
        await self.stop_pull_pump()
        self.video.input_source = "pull"
        self.video.pull_url = url
        self.video.direct_input_path = ""
        self.video.input_seek_seconds = 0.0
        playlist = await self.video.start(reason="SageTV PULL input via stv://")
        await self.send({"type": "videoStream", "url": playlist, "status": self.video.status.to_json()})
        self.pull_pump = SagePullStreamPump(url=url, bridge=self.video)

        async def _runner():
            await self.send_log(f"SageTV PULL input started for {url}")
            try:
                await self.pull_pump.run()
            finally:
                bytes_read = self.pull_pump.bytes_read if self.pull_pump else 0
                err = self.pull_pump.last_error if self.pull_pump else ""
                if err:
                    await self.send_log(f"SageTV PULL input stopped with error: {err}")
                else:
                    await self.send_log(f"SageTV PULL input ended after {bytes_read} bytes")
                await self.send({"type": "videoStatus", "status": self.video.status.to_json()})

        self.pull_task = asyncio.create_task(_runner(), name=f"sage-pull-{self.session_id}")

    def resolve_direct_media_path(self, url: str) -> tuple[str, str]:
        """Resolve a SageTV OPENURL file/stv URL to a local SMB/NFS path.

        Returns (local_path, reason).  Empty local_path means direct mode cannot
        be used for this URL.  Direct mode needs SageTV to provide either a
        file:// path, a plain path, or an stv:// path whose path part can be
        mapped to a local mounted/share path.
        """
        raw = str(url or "").strip()
        if not raw or raw.lower().startswith("push:"):
            return "", "OPENURL is PUSH, no file path available"
        candidate = raw
        if raw.lower().startswith("stv://"):
            try:
                _host, stv_path = parse_stv_url(raw)
                candidate = stv_path
            except Exception as exc:
                return "", f"could not parse stv:// path: {exc}"
        elif re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*:", raw) and not raw.lower().startswith(("file://", "smb://")):
            return "", f"unsupported URL scheme for direct file mode: {raw.split(':',1)[0]}"

        local = map_direct_path(candidate, self.direct_sage_root, self.direct_local_root)
        local = local.strip()
        if not local:
            return "", "direct mapping produced an empty path"

        # If the user supplied a mapping, require the mapped target to exist. If
        # there is no mapping, still allow Windows UNC paths because Python may be
        # running on Windows and Path.exists() can be slow/fail before credentials
        # are available. FFmpeg's error will be shown in the debug box if it fails.
        mapped = bool(self.direct_sage_root and self.direct_local_root) or bool(os.environ.get("SAGEWEB_DIRECT_PATH_MAP", ""))
        if mapped:
            # Do not block Direct File/SMB just because Path.exists() fails.
            # Windows UNC shares can return false until credentials are cached, and
            # FFmpeg may still be able to open the path.  Start the bridge and let
            # the FFmpeg error show in the debug tail if the share is actually bad.
            try:
                if not Path(local).exists():
                    return local, f"direct path resolved, but exists check failed or share is not browsable yet: {local}"
            except Exception as exc:
                return local, f"direct path resolved, but exists check could not be performed: {exc}"
        return local, "direct path resolved"

    async def start_direct_file_stream(self, url: str, reason: str = "direct file playback") -> bool:
        local, why = self.resolve_direct_media_path(url)
        if not local:
            await self.send_log(f"Direct File/SMB not used: {why}")
            return False
        await self.stop_pull_pump()
        await self.video.stop(remove_files=True, keep_prebuffer=False)
        self.direct_last_path = local
        self.video.media_url = url or ""
        self.video.input_source = "direct"
        self.video.direct_input_path = local
        self.video.pull_url = ""
        self.video.input_seek_seconds = max(0.0, self.media.status.current_media_time_ms() / 1000.0)
        playlist = await self.video.start(reason=f"{reason}; {why}; start={self.video.input_seek_seconds:.3f}s")
        await self.send({"type": "videoStream", "url": playlist, "status": self.video.status.to_json()})
        await self.send_log(f"Direct File/SMB bridge started: {local} -> {playlist}")
        return True

    async def start_push_stream(self) -> None:
        await self.stop_pull_pump()
        await self.video.stop(remove_files=True, keep_prebuffer=False)
        self.video.input_source = "push"
        self.video.direct_input_path = ""
        self.video.pull_url = ""
        self.video.input_seek_seconds = 0.0
        playlist = await self.video.start(reason="SageTV PUSHBUFFER input")
        await self.send({"type": "videoStream", "url": playlist, "status": self.video.status.to_json()})
        await self.send_log(f"FFmpeg HLS PUSH bridge started: {playlist} encoder={self.video.status.encoder}")

    async def media_loop(self):
        """Parse the SageTV media command socket.

        v22 does not decode/play video yet.  It implements the same framing as
        OpenSageTV MediaThread: one byte command, three byte big-endian length,
        payload bytes, then a raw media-command reply when required.  This lets
        SageTV believe a MiniClient media player exists and gives us an exact
        trace before FFmpeg/HLS is added.
        """
        assert self.media_reader is not None
        assert self.media_writer is not None
        await self.send_log("Media loop running in v63 video bridge mode")
        last_status_sent = 0.0
        try:
            while self.connected:
                header = await self.media_reader.readexactly(4)
                cmd = header[0]
                length = int.from_bytes(header[1:4], "big")
                payload = await self.media_reader.readexactly(length) if length else b""
                result = self.media.execute(cmd, payload)
                if result.reply:
                    self.media_writer.write(result.reply)
                    await self.media_writer.drain()

                # FFmpeg/HLS bridge.  SageTV still owns timeline/seek/comskip; Python
                # only converts the pushed native stream to a browser-safe HLS stream.
                if cmd == MEDIACMD_OPENURL and self.media_caps_enabled:
                    self.video.media_url = self.media.status.url or ""
                    self._ignored_pushbuffer_logged = False
                    src_mode = self.playback_source
                    open_url = self.media.status.url or ""
                    open_low = open_url.lower()
                    try:
                        if src_mode == "direct":
                            if self.media.status.push_mode:
                                await self.send_log("Source is Direct File/SMB, but SageTV sent PUSHBUFFER. Explicit Direct mode is strict; bridge not started. Reconnect with Source=Direct File/SMB so SageTV sends stv:// or file://.")
                            elif await self.start_direct_file_stream(open_url, reason="Playback Source=direct"):
                                await self.send_log(f"Direct File/SMB mode active for OPENURL: {open_url[:160]}")
                            else:
                                await self.send_log("Source is Direct File/SMB and strict mode is active; bridge not started because the file path could not be mapped/opened. Use Source=Auto to allow PULL/PUSH fallback.")
                        elif src_mode == "pull":
                            if open_low.startswith("stv://"):
                                await self.start_pull_stream_fallback(open_url)
                                await self.send_log("SageTV PULL mode active for stv:// OPENURL.")
                            else:
                                await self.send_log(f"Source is SageTV PULL, but OPENURL is not stv:// ({open_url[:120]}). Explicit PULL mode is strict; bridge not started. Use Source=Auto to allow fallback.")
                        elif src_mode == "push":
                            if self.media.status.push_mode:
                                await self.start_push_stream()
                            else:
                                await self.send_log(f"Source is PUSHBUFFER, but SageTV sent non-PUSH OPENURL ({open_url[:120]}). Explicit PUSHBUFFER mode is strict; bridge not started. Use Source=Auto to allow PULL/direct fallback.")
                        else:  # auto
                            if not self.media.status.push_mode and await self.start_direct_file_stream(open_url, reason="Playback Source=auto"):
                                await self.send_log(f"Auto source selected Direct File/SMB for OPENURL: {open_url[:160]}")
                            elif open_low.startswith("stv://"):
                                await self.start_pull_stream_fallback(open_url)
                                await self.send_log("Auto source selected SageTV PULL stv:// input.")
                            elif self.media.status.push_mode:
                                await self.start_push_stream()
                                await self.send_log("Auto source selected SageTV PUSHBUFFER input.")
                            else:
                                await self.send_log(f"Auto source could not start direct/pull/push for OPENURL: {open_url[:160]}")
                    except Exception as exc:
                        self.video.status.last_error = str(exc)
                        await self.send_log(f"Video source start failed: {exc}")
                elif cmd in (MEDIACMD_FLUSH, MEDIACMD_SEEK) and self.video.status.running:
                    try:
                        # PUSH can simply restart FFmpeg and wait for new PUSHBUFFER data.
                        # PULL input restarts from the beginning because SageTV's seek is a media-time value,
                        # not a byte offset. Direct File/SMB is preferred when a mapped file path is available.
                        if self.video.input_source == "direct" and self.video.direct_input_path:
                            await self.start_direct_file_stream(self.media.status.url, reason="SageTV seek/flush direct restart")
                            await self.send_log(f"Direct File/SMB restarted near {self.media.status.current_media_time_ms()}ms after SageTV seek/flush")
                        elif self.video.input_source == "push":
                            playlist = await self.video.restart()
                            await self.send({"type": "videoStream", "url": playlist, "status": self.video.status.to_json()})
                            await self.send_log(f"FFmpeg HLS PUSH bridge restarted after SageTV FLUSH/seek: {playlist}")
                        elif self.video.input_source == "pull" and self.media.status.url.lower().startswith("stv://"):
                            await self.video.stop(remove_files=True)
                            await self.start_pull_stream_fallback(self.media.status.url)
                            await self.send_log("SageTV PULL restarted after SageTV FLUSH/seek. Byte-accurate seek is not implemented yet for PULL mode.")
                    except Exception as exc:
                        await self.send_log(f"FFmpeg restart failed after FLUSH: {exc}")
                elif cmd in (MEDIACMD_STOP, MEDIACMD_DEINIT):
                    await self.stop_pull_pump()
                    await self.video.stop(remove_files=True)
                    await self.send({"type": "videoStop", "status": self.video.status.to_json()})

                # v31: Some SageTV sessions begin sending PUSHBUFFER data before
                # the OPENURL-triggered FFmpeg bridge is fully started, or the UI
                # checkbox may have been left off while SageTV still selected PUSH.
                # If real TS bytes arrive, auto-start the video bridge and feed them.
                if result.pushbuffer and result.push_data:
                    try:
                        if self.video.status.running and self.video.input_source != "push":
                            # Direct/PULL modes own their own input stream.  Do not mix in
                            # late PUSHBUFFER chunks or the browser HLS segments will jump.
                            if not self._ignored_pushbuffer_logged:
                                self._ignored_pushbuffer_logged = True
                                await self.send_log(f"Ignoring SageTV PUSHBUFFER because active source is {self.video.input_source}; explicit source/player mode is strict.")
                        else:
                            if not self.video.status.running:
                                can_auto_start_push = self.playback_source in ("push", "auto")
                                if not can_auto_start_push:
                                    if not self._ignored_pushbuffer_logged:
                                        self._ignored_pushbuffer_logged = True
                                        await self.send_log(f"Received PUSHBUFFER but Source={self.playback_source}; explicit source mode is strict, so PUSH is not auto-started. Use Source=PUSHBUFFER or Source=Auto.")
                                    continue
                                self.video.input_source = "push"
                                self.video.direct_input_path = ""
                                self.video.pull_url = ""
                                playlist = await self.video.start(refeed_prebuffer=False, reason="auto-started on first non-empty SageTV PUSHBUFFER")
                                await self.send({"type": "videoStream", "url": playlist, "status": self.video.status.to_json()})
                                await self.send_log(f"FFmpeg HLS PUSH bridge auto-started on PUSHBUFFER: {playlist} encoder={self.video.status.encoder}")
                            await self.video.write(result.push_data)
                            if str(self.video.status.last_error or "").startswith("MSE FFmpeg input queue full"):
                                await self.restart_video_bridge(reason="MSE input queue full; clean fMP4 restart")
                            # v44: Do not send websocket videoStatus from the hot PUSHBUFFER
                            # path. SageTV can send many PUSHBUFFERs per second and each status
                            # update forces browser debug text/layout work. The browser polls
                            # /api/hls_ready during startup, and the normal 1.5s sampled status
                            # below is enough during playback.
                            if self.video.status.chunks_in % 20 == 0:
                                self.video.refresh_ready_state()
                    except Exception as exc:
                        self.video.status.last_error = str(exc)
                        await self.send_log(f"FFmpeg write/start failed: {exc}")

                name = MEDIA_CMD_NAMES.get(cmd, str(cmd))
                # PUSHBUFFER can happen many times per second.  Log only useful samples.
                if result.log:
                    await self.send_log(result.log)
                elif cmd != MEDIACMD_PUSHBUFFER:
                    await self.send_log(f"{name} len={length} reply={len(result.reply)}")

                if result.video_bounds_changed:
                    src = self.media.status.source_rect
                    dst = self.media.status.dest_rect
                    await self.send({"type": "videoBounds", "src": list(src), "dst": list(dst)})

                now = time.monotonic()
                # Do not send a WebSocket status update for every PUSHBUFFER.
                # During playback SageTV can push dozens of buffers per second; sending
                # mediaStatus/videoStatus for each one makes the browser renderer and
                # remote keys feel sluggish. Non-PUSH state changes are immediate;
                # PUSH progress is sampled periodically.
                status_due = (result.status_changed and cmd != MEDIACMD_PUSHBUFFER) or (now - last_status_sent > 1.5)
                if status_due:
                    last_status_sent = now
                    await self.send({"type": "mediaStatus", "status": self.media.status.to_json()})
                    await self.send({"type": "videoStatus", "status": self.video.status.to_json()})
        except asyncio.CancelledError:
            pass
        except Exception as e:
            await self.send_log(f"Media loop stopped: {e}")
            try:
                await self.video.stop(remove_files=True)
                await self.send({"type": "videoStop", "status": self.video.status.to_json()})
            except Exception:
                pass

    async def handle_sagetv_packet(self, cmd_type: int, payload: bytes):
        if cmd_type == DRAWING_CMD_TYPE:
            self.gfx_packet_count += 1
            gfx_cmd = payload[0] if payload else -1
            if gfx_cmd == GFXCMD_MEDIA_RECONNECT:
                # Java MiniClient closes/reconnects media socket here. This is
                # important after stop/playback errors; ignoring it leaves SageTV
                # waiting on the old media channel.
                asyncio.create_task(self.reconnect_media_socket("GFXCMD_MEDIA_RECONNECT"))
                return
            reply, commands = self.gfx.execute(payload)

            if self.gfx_trace and self.gfx_packet_count <= 80:
                name = GFXCMD_NAMES.get(gfx_cmd, str(gfx_cmd))
                await self.send_log(f"GFX packet #{self.gfx_packet_count}: {name} len={len(payload)} reply={reply}")

            # Batch per SageTV frame. v21 also handles skins/plugins that disable
            # GFX_FLIP or start a new frame before a FLIPBUFFER arrives. In that case
            # flush the previous pending frame so the browser never sits on stale draw data.
            if gfx_cmd == GFXCMD_STARTFRAME:
                if self._inside_frame and self._frame_commands:
                    await self.send_gfx(self._frame_commands)
                self._inside_frame = True
                self._frame_commands = list(commands)
            elif self._inside_frame:
                self._frame_commands.extend(commands)
                if gfx_cmd == GFXCMD_FLIPBUFFER:
                    await self.send_gfx(self._frame_commands)
                    self._frame_commands = []
                    self._inside_frame = False
            else:
                await self.send_gfx(commands)

            if reply is not None:
                self.gfx_reply_count += 1
                await self.write_reply(DRAWING_CMD_TYPE, struct.pack(">i", int(reply)))
        elif cmd_type == GET_PROPERTY_CMD_TYPE:
            prop_name = payload.decode("latin-1", errors="replace")
            prop_val = self.get_property(prop_name)
            await self.send_log(f"GET_PROPERTY {prop_name} -> {prop_val!r}")
            await self.write_reply(GET_PROPERTY_CMD_TYPE, prop_val.encode("latin-1", errors="replace"))
        elif cmd_type == SET_PROPERTY_CMD_TYPE:
            rc = await self.set_property(payload)
            await self.write_reply(SET_PROPERTY_CMD_TYPE, struct.pack(">i", rc))
        elif cmd_type == FS_CMD_TYPE:
            await self.send_log(f"FS command ignored in GUI-only mode, len={len(payload)}")
        else:
            await self.send_log(f"Unhandled SageTV packet type={cmd_type} len={len(payload)}")

    async def write_reply(self, reply_type: int, payload: bytes):
        if not self.gfx_writer:
            return
        packet = make_reply_packet(reply_type, self.reply_count, payload)
        self.reply_count += 1
        self.gfx_writer.write(packet)
        await self.gfx_writer.drain()

    def _push_container_caps(self) -> str:
        if not self.media_caps_enabled:
            return "NONE"
        src = self.playback_source
        if src in ("pull", "direct"):
            return "NONE"
        return "MPEG2-PS,MPEG2-TS,MPEG1-PS"

    def _pull_container_caps(self) -> str:
        if not self.media_caps_enabled:
            return "NONE"
        src = self.playback_source
        # Source now fully replaces the old Force PUSH option:
        #   PUSHBUFFER advertises push only.
        #   Direct/PULL/Auto advertise PULL/file URLs so SageTV sends stv:// or file://.
        if src == "push":
            return "NONE"
        return "MPEG2-TS,MPEG2-PS,MPEG"

    def get_property(self, name: str) -> str:
        # Conservative web renderer capabilities. Keep zlib/encryption off for first Python port.
        props = {
            # Ask SageTV to render text as images instead of issuing DRAWTEXT.
            # This is important for SageMC and custom STVs because the browser does
            # not yet have SageTV's exact font metrics.
            "GFX_TEXTMODE": "NONE",
            "GFX_DRAWMODE": "FULLSCREEN",
            "GFX_BLENDMODE": "PREMULTIPLY",
            "GFX_SCALING": "HARDWARE",
            "GFX_OFFLINE_IMAGE_CACHE": "FALSE",
            "OFFLINE_CACHE_CONTENTS": "",
            "ADVANCED_IMAGE_CACHING": "TRUE",
            "GFX_BITMAP_FORMAT": "PNG,JPG,GIF,BMP",
            "GFX_COMPOSITE": "BLEND",
            # Keep surfaces disabled for the pure HTML5 renderer until the full
            # surface/transform pipeline is complete. This makes SageTV send simpler
            # full-screen draw frames and avoids stale offscreen-surface artifacts.
            "GFX_SURFACES": "FALSE",
            "GFX_HIRES_SURFACES": "FALSE",
            "GFX_DIFFUSE_TEXTURES": "",
            "GFX_XFORMS": "",
            "GFX_TEXTURE_BATCH_LIMIT": "",
            "GFX_COLORKEY": "080010",
            "STREAMING_PROTOCOLS": "file,stv",
            # v29: use the same media capability names as the OpenSageTV Android
            # MiniClient profile so SageTV is more likely to include the audio stream
            # in the PUSH media URL instead of sending video-only media.
            "VIDEO_CODECS": "MPEG2-VIDEO,MPEG2-VIDEO@HL,MPEG1-VIDEO,MPEG4-VIDEO,DIVX3,MSMPEG4,FLASHVIDEO,H.264,WMV9,VC1,MJPEG" if self.media_caps_enabled else "NONE",
            "AUDIO_CODECS": "MPG1L2,MPG1L3,AC3,AAC,AAC-HE,WMA,FLAC,VORBIS,PCM,DTS,DCA,PCM_S16LE,WMA8,ALAC,WMAPRO,0X0162,DolbyTrueHD,DTS-HD,DTS-MA,EAC3,EC-3" if self.media_caps_enabled else "NONE",
            "PUSH_AV_CONTAINERS": self._push_container_caps(),
            # v58: source mode controls whether we ask SageTV for PUSHBUFFER or allow stv:// PULL.
            # Direct File/SMB mode also needs non-push OPENURL values, so it allows PULL/file URLs.
            "PULL_AV_CONTAINERS": self._pull_container_caps(),
            "INPUT_DEVICES": "IR,KEYBOARD,MOUSE",
            "DISPLAY_OVERSCAN": "0;0;1.0;1.0",
            "FIRMWARE_VERSION": "9.0.0-python-html5-v63",
            "DETAILED_BUFFER_STATS": "TRUE",
            "PUSH_BUFFER_SEEKING": "TRUE",
            "GFX_SUBTITLES": "",
            "FORCED_MEDIA_RECONNECT": "TRUE",
            "AUTH_CACHE": "",
            "GET_CACHED_AUTH": "",
            "REMOTE_FS": "",
            "GFX_VIDEO_UPDATE": "",  # Enable after FFmpeg video path is added.
            "ZLIB_COMM": "",          # Keep off until zlib stream wrapper is ported.
            "MEDIA_PLAYER_BUFFER_DELAY": "100",
            "GFX_RESOLUTION": f"{self.size.width}x{self.size.height}",
            "GFX_ASPECT": str(self.size.width / max(1, self.size.height)),
        }
        return props.get(name, "")

    async def set_property(self, payload: bytes) -> int:
        """Decode SageTV SET_PROPERTY payload.

        Java MiniClientConnection uses:
          uint16 nameLen, uint16 valLen, name bytes, value bytes
        v18 incorrectly treated these as 32-bit lengths, which produced logs like
        SET_PROPERTY GFX_ASPECT1.7777778=''. That also meant SageTV's request to
        disable advanced image caching was ignored, which can stall image loading.
        """
        try:
            if len(payload) < 4:
                await self.send_log(f"SET_PROPERTY too short len={len(payload)} raw={payload.hex()}")
                return 0
            name_len = ((payload[0] & 0xFF) << 8) | (payload[1] & 0xFF)
            val_len = ((payload[2] & 0xFF) << 8) | (payload[3] & 0xFF)
            name_off = 4
            val_off = name_off + name_len
            name = payload[name_off:val_off].decode("latin-1", errors="replace")
            value = payload[val_off:val_off+val_len].decode("latin-1", errors="replace")
            await self.send_log(f"SET_PROPERTY {name}={value!r}")

            if name == "GFX_RESOLUTION" and "x" in value:
                w, h = value.lower().split("x", 1)
                self.size.width = int(w)
                self.size.height = int(h)
                await self.send({"type": "resizeCanvas", "width": self.size.width, "height": self.size.height})
            elif name == "GFX_ASPECT":
                # Browser canvas already uses the requested resolution, but keep this visible for debug.
                pass
            elif name == "MENU_HINT":
                await self.send({"type": "menuHint", "value": value})
            elif name == "ADVANCED_IMAGE_CACHING":
                self.gfx.state.advanced_image_caching = value.upper() == "TRUE"
                await self.send_log(f"Advanced image caching now {self.gfx.state.advanced_image_caching}")
            elif name == "GFX_FLIP":
                await self.send_log(f"GFX_FLIP requested by SageTV: {value!r}")
            elif name == "RECONNECT_SUPPORTED":
                pass
            return 0
        except Exception as e:
            await self.send_log(f"SET_PROPERTY parse error: {e}; raw={payload[:64].hex()}")
            return 0

    async def post_resize(self, width: int, height: int):
        await self.write_reply(UI_RESIZE_EVENT_REPLY_TYPE, struct.pack(">ii", width, height))
        await self.send_log(f"Sent resize {width}x{height}")

    async def post_sage_command(self, command_id: int):
        await self.write_reply(SAGECOMMAND_EVENT_REPLY_TYPE, struct.pack(">i", command_id))
        await self.send_log(f"Sent Sage command {command_id}")

    async def post_key(self, key_code: int, key: str):
        ch = ord(key[0]) if key and len(key) == 1 else 0
        await self.write_reply(KB_EVENT_REPLY_TYPE, struct.pack(">iHi", key_code, ch, 0))

    async def post_mouse(self, data: dict):
        evt = data.get("event", "move")
        event_type = {
            "move": MMOVE_EVENT_REPLY_TYPE,
            "down": MPRESS_EVENT_REPLY_TYPE,
            "up": MRELEASE_EVENT_REPLY_TYPE,
            "click": MCLICK_EVENT_REPLY_TYPE,
            "drag": MDRAG_EVENT_REPLY_TYPE,
            "wheel": MWHEEL_EVENT_REPLY_TYPE,
        }.get(evt, MMOVE_EVENT_REPLY_TYPE)
        x = int(data.get("x") or 0)
        y = int(data.get("y") or 0)
        button = int(data.get("button") or 1)
        clicks_or_wheel = int(data.get("delta") or data.get("clicks") or 1)
        payload = struct.pack(">iiiBB", x, y, 0, clicks_or_wheel & 0xFF, button & 0xFF)
        await self.write_reply(event_type, payload)
        if evt == "click":
            await self.send_log(f"Sent mouse click x={x} y={y} button={button}")
