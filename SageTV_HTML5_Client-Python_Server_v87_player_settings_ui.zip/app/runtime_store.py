import json
import os
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SERVER_SETTINGS_FILE = ROOT / "server_settings" / "settings.json"
DISK_HLS_ROOT = ROOT / "runtime_hls"


def _load_server_settings() -> dict:
    try:
        if not SERVER_SETTINGS_FILE.exists():
            return {}
        data = json.loads(SERVER_SETTINGS_FILE.read_text(encoding="utf-8"))
        settings = data.get("settings", data)
        return settings if isinstance(settings, dict) else {}
    except Exception:
        return {}


def _truthy(v: str) -> bool:
    return str(v or "").strip().lower() in ("1", "true", "yes", "on", "ram", "memory")


def _first_existing_windows_ram_root() -> Path | None:
    # Python cannot create a true RAM disk on Windows by itself.  If the user has
    # one already mounted, these are common choices.  A custom path can also be
    # configured in the UI or with SAGEWEB_HLS_RAM_ROOT.
    for drive in ("R:", "T:", "M:"):
        p = Path(drive + "\\")
        if p.exists():
            return p / "SageTV_HTML5_HLS"
    return None


def hls_storage_config(mode_override: str | None = None, custom_override: str | None = None) -> dict:
    """Return the selected HLS runtime storage location.

    FFmpeg's HLS muxer needs a filesystem path for stream.m3u8 and segment
    files.  True RAM storage therefore means a RAM-backed filesystem/tmpfs/RAM
    disk, not a Python-only bytes buffer.  Linux normally has /dev/shm. Windows
    needs a RAM disk drive or a custom path supplied by the user.
    """
    settings = _load_server_settings()
    mode = str(mode_override or os.environ.get("SAGEWEB_HLS_STORAGE_MODE") or settings.get("hlsStorageMode") or "disk").strip().lower()
    custom = str(custom_override or os.environ.get("SAGEWEB_HLS_RAM_ROOT") or settings.get("hlsRamRoot") or "").strip()
    if mode in ("memory", "tmpfs"):
        mode = "ram"
    if mode not in ("disk", "ram", "temp"):
        mode = "disk"

    note = "disk"
    is_ram = False
    if mode == "ram":
        if custom:
            root = Path(custom).expanduser()
            note = "custom RAM/tmpfs path"
            is_ram = True
        elif os.name != "nt" and Path("/dev/shm").exists():
            root = Path("/dev/shm") / "sagetv_python_proxy" / "runtime_hls"
            note = "Linux /dev/shm tmpfs"
            is_ram = True
        elif os.name == "nt":
            win_ram = _first_existing_windows_ram_root()
            if win_ram:
                root = win_ram
                note = "Windows RAM disk drive"
                is_ram = True
            else:
                root = DISK_HLS_ROOT
                note = "RAM selected but no RAM disk/custom path found; using disk runtime_hls"
                is_ram = False
        else:
            root = DISK_HLS_ROOT
            note = "RAM selected but no tmpfs found; using disk runtime_hls"
            is_ram = False
    elif mode == "temp":
        import tempfile
        root = Path(tempfile.gettempdir()) / "sagetv_python_proxy" / "runtime_hls"
        note = "OS temp folder"
        is_ram = False
    else:
        root = DISK_HLS_ROOT
        note = "app runtime_hls folder"
        is_ram = False

    try:
        root.mkdir(parents=True, exist_ok=True)
    except Exception:
        # Fall back to disk if the requested location cannot be created.
        root = DISK_HLS_ROOT
        root.mkdir(parents=True, exist_ok=True)
        note = "requested HLS storage path was not writable; using disk runtime_hls"
        is_ram = False
        mode = "disk"
    return {
        "mode": mode,
        "root": root,
        "path": str(root),
        "note": note,
        "is_ram": is_ram,
    }


def runtime_hls_root() -> Path:
    return Path(hls_storage_config()["root"])


def cleanup_hls_roots(active_session_ids: set[str] | None = None, max_age_minutes: int = 240, include_active: bool = False) -> dict:
    active_session_ids = active_session_ids or set()
    roots = []
    selected = runtime_hls_root()
    for root in (selected, DISK_HLS_ROOT):
        if root not in roots:
            roots.append(root)
    # Also clean common Linux tmpfs root even if currently using disk, so a mode
    # switch does not leave old RAM segments behind.
    shm = Path("/dev/shm") / "sagetv_python_proxy" / "runtime_hls"
    if shm.exists() and shm not in roots:
        roots.append(shm)

    cutoff = __import__("time").time() - max(1, int(max_age_minutes)) * 60
    removed = []
    kept = []
    for root in roots:
        if not root.exists():
            continue
        for child in root.iterdir():
            if not child.is_dir():
                continue
            label = f"{root}:{child.name}"
            if (not include_active) and child.name in active_session_ids:
                kept.append(label)
                continue
            try:
                newest = max((p.stat().st_mtime for p in child.rglob('*') if p.is_file()), default=child.stat().st_mtime)
            except Exception:
                newest = 0
            if include_active or newest < cutoff:
                shutil.rmtree(child, ignore_errors=True)
                removed.append(label)
            else:
                kept.append(label)
    return {"removed": removed, "kept": kept, "max_age_minutes": max_age_minutes, "storage": hls_storage_config()}
