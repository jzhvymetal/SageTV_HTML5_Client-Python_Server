"""Experimental aiortc WebRTC bridge for SageTV HTML5 Client.

This module is intentionally optional. The rest of the app can run without
aiortc installed; selecting Player=WebRTC aiortc will show a clear error until
`pip install aiortc` is run.
"""

from __future__ import annotations

import asyncio
import inspect
import time
from pathlib import Path
from typing import Awaitable, Callable, Optional

try:  # Optional dependency; do not break normal HLS/MSE startup if missing.
    from aiortc import RTCPeerConnection, RTCSessionDescription, RTCRtpSender, MediaStreamTrack
    from aiortc.contrib.media import MediaPlayer
    AIORTC_AVAILABLE = True
    AIORTC_IMPORT_ERROR = ""
except Exception as exc:  # pragma: no cover - exercised only when dependency missing
    RTCPeerConnection = None  # type: ignore
    RTCSessionDescription = None  # type: ignore
    RTCRtpSender = None  # type: ignore
    MediaStreamTrack = object  # type: ignore
    MediaPlayer = None  # type: ignore
    AIORTC_AVAILABLE = False
    AIORTC_IMPORT_ERROR = str(exc)


LogCallback = Callable[[str], Awaitable[None] | None]


class DelayedMediaTrack(MediaStreamTrack):
    """Delay one aiortc MediaStreamTrack by a fixed amount.

    Positive Audio Sync delays audio. Negative Audio Sync delays video.
    This is intentionally simple and experimental; it shifts wall-clock delivery
    rather than rewriting file timestamps.
    """

    def __init__(self, source, delay_seconds: float = 0.0):
        super().__init__()
        self.source = source
        self.delay_seconds = max(0.0, float(delay_seconds or 0.0))

    @property
    def kind(self):
        return getattr(self.source, "kind", "unknown")

    async def recv(self):
        frame = await self.source.recv()
        if self.delay_seconds > 0:
            await asyncio.sleep(self.delay_seconds)
        return frame

    def stop(self):
        try:
            self.source.stop()
        except Exception:
            pass
        try:
            super().stop()
        except Exception:
            pass


class AiortcWebRtcBridge:
    """Small receive-only WebRTC sender backed by aiortc MediaPlayer.

    First implementation supports Direct File/SMB paths. PULL/PUSH need a
    separate custom MediaStreamTrack or GStreamer path, so they are intentionally
    not hidden behind this class yet.
    """

    def __init__(self, session_id: str, log: Optional[LogCallback] = None):
        self.session_id = session_id
        self.log = log
        self.pc = None
        self.player = None
        self.media_path = ""
        self.started_at = 0.0
        self.last_error = ""
        self.connection_state = "new"
        self.ice_connection_state = "new"
        self.ice_gathering_state = "new"
        self.tracks = []

    async def _log(self, message: str):
        if not self.log:
            return
        try:
            res = self.log(message)
            if inspect.isawaitable(res):
                await res
        except Exception:
            pass

    async def stop(self):
        pc = self.pc
        self.pc = None
        player = self.player
        self.player = None
        self.tracks = []
        if player is not None:
            for name in ("audio", "video"):
                tr = getattr(player, name, None)
                if tr is not None:
                    try:
                        tr.stop()
                    except Exception:
                        pass
        if pc is not None:
            try:
                await pc.close()
            except Exception:
                pass
        self.connection_state = "closed"
        self.ice_connection_state = "closed"
        self.ice_gathering_state = "closed"

    def _codec_preferences(self, kind: str, preferred: list[str]) -> list:
        try:
            caps = RTCRtpSender.getCapabilities(kind)
            codecs = list(getattr(caps, "codecs", []) or [])
            first = []
            rest = []
            preferred_l = [p.lower() for p in preferred]
            for c in codecs:
                mt = str(getattr(c, "mimeType", "") or "").lower()
                if mt in preferred_l:
                    first.append(c)
                else:
                    rest.append(c)
            return first + rest
        except Exception:
            return []

    def _set_last_transceiver_codecs(self, kind: str):
        try:
            transceivers = [t for t in self.pc.getTransceivers() if t.kind == kind]
            if not transceivers:
                return
            transceiver = transceivers[-1]
            if kind == "video":
                codecs = self._codec_preferences("video", ["video/h264"])
            else:
                codecs = self._codec_preferences("audio", ["audio/opus"])
            if codecs:
                transceiver.setCodecPreferences(codecs)
        except Exception:
            # Codec preference is best-effort. aiortc/browser negotiation can still proceed.
            pass

    async def _seek_media_player(self, seek_seconds: float) -> bool:
        """Best-effort seek for aiortc.contrib.media.MediaPlayer.

        MediaPlayer accepts FFmpeg/PyAV demuxer options, but for some formats
        the common "ss" option is ignored when it is passed through av.open().
        The more reliable approach is to seek the underlying PyAV container
        after MediaPlayer opens it and before WebRTC starts consuming tracks.
        This is intentionally best-effort because MPEG-TS files can have
        non-zero timestamps and can only seek to nearby keyframes.
        """
        try:
            ss = float(seek_seconds or 0.0)
        except Exception:
            ss = 0.0
        if ss <= 0.5 or self.player is None:
            return False
        container = getattr(self.player, "_container", None)
        if container is None:
            await self._log("WebRTC aiortc seek warning: MediaPlayer has no exposed PyAV container; starting at beginning.")
            return False

        # Try stream-timebase seeking first. This tends to work better for MPEG-TS.
        streams = []
        try:
            video_streams = list(getattr(getattr(container, "streams", None), "video", []) or [])
            audio_streams = list(getattr(getattr(container, "streams", None), "audio", []) or [])
            streams = video_streams + audio_streams
        except Exception:
            streams = []

        errors = []
        for stream in streams[:2]:
            try:
                tb = getattr(stream, "time_base", None)
                if tb:
                    offset = int(ss / float(tb))
                    start = getattr(stream, "start_time", None)
                    if start is not None:
                        offset += int(start)
                    container.seek(offset, any_frame=False, backward=True, stream=stream)
                    await self._log(f"WebRTC aiortc PyAV seek applied with stream time_base to {ss:.3f}s")
                    return True
            except Exception as exc:
                errors.append(str(exc))

        # Then try global container time in AV_TIME_BASE units (microseconds).
        for offset in (
            int((float(getattr(container, "start_time", 0) or 0) / 1000000.0 + ss) * 1000000),
            int(ss * 1000000),
        ):
            try:
                container.seek(offset, any_frame=False, backward=True)
                await self._log(f"WebRTC aiortc PyAV seek applied with container time to {ss:.3f}s")
                return True
            except Exception as exc:
                errors.append(str(exc))

        await self._log(f"WebRTC aiortc seek warning: could not seek to {ss:.3f}s; starting at beginning. {'; '.join(errors[-2:])}")
        return False

    def _normalize_bitrate_profile(self, profile: Optional[dict]) -> dict:
        profile = profile if isinstance(profile, dict) else {}
        def kbps(name: str) -> int:
            try:
                n = int(float(profile.get(name, 0) or 0))
            except Exception:
                n = 0
            return max(0, min(50000, n))
        mode = str(profile.get("mode") or "auto").strip().lower()
        if mode not in ("auto", "low", "balanced", "high", "manual"):
            mode = "auto"
        lo, start, hi = kbps("min_kbps"), kbps("start_kbps"), kbps("max_kbps")
        if hi and lo and hi < lo:
            hi = lo
        if start:
            if lo and start < lo:
                start = lo
            if hi and start > hi:
                start = hi
        return {"mode": mode, "min_kbps": lo, "start_kbps": start, "max_kbps": hi}

    def _bitrate_summary(self, profile: Optional[dict]) -> str:
        p = self._normalize_bitrate_profile(profile)
        if p["mode"] == "auto" and not (p["min_kbps"] or p["start_kbps"] or p["max_kbps"]):
            return "webrtc/auto"
        return f"webrtc/{p['mode']} min={p['min_kbps']} start={p['start_kbps']} max={p['max_kbps']}kbps"

    async def _apply_sender_bitrate_parameters(self, sender, profile: Optional[dict]) -> str:
        """Best-effort RTCRtpSender maxBitrate control.

        aiortc versions differ on how much RTCRtpSender parameter control is
        exposed.  This function safely tries the standard getParameters /
        setParameters path and reports what happened without making WebRTC fail.
        """
        p = self._normalize_bitrate_profile(profile)
        max_kbps = p["max_kbps"]
        if not max_kbps:
            return "senderParams=auto"
        try:
            if not hasattr(sender, "getParameters") or not hasattr(sender, "setParameters"):
                return "senderParams=unsupported"
            params = sender.getParameters()
            encodings = getattr(params, "encodings", None)
            if not encodings:
                return "senderParams=no-encodings"
            enc = encodings[0]
            # WebRTC uses bits/sec for maxBitrate.
            try:
                setattr(enc, "maxBitrate", int(max_kbps) * 1000)
            except Exception:
                try:
                    enc["maxBitrate"] = int(max_kbps) * 1000
                except Exception:
                    return "senderParams=maxBitrate-set-failed"
            res = sender.setParameters(params)
            if inspect.isawaitable(res):
                await res
            return f"senderParams=maxBitrate:{max_kbps}kbps"
        except Exception as exc:
            return f"senderParams=error:{exc}"

    def _munge_sdp_bitrate(self, sdp: str, profile: Optional[dict]) -> tuple[str, str]:
        """Best-effort SDP bitrate hints for browser/aiortc negotiation.

        This adds b=AS/TIAS to the video m-section and appends common
        x-google-min/start/max-bitrate hints to video fmtp lines.  It is harmless
        if a browser/aiortc version ignores the hints.
        """
        p = self._normalize_bitrate_profile(profile)
        if p["mode"] == "auto" and not (p["min_kbps"] or p["start_kbps"] or p["max_kbps"]):
            return sdp, "sdpBitrate=auto"
        max_kbps = p["max_kbps"] or p["start_kbps"] or p["min_kbps"]
        if not max_kbps:
            return sdp, "sdpBitrate=auto"
        lines = sdp.splitlines()
        out = []
        in_video = False
        inserted_b = False
        video_payloads = set()
        for i, line in enumerate(lines):
            if line.startswith("m="):
                if in_video and not inserted_b:
                    out.append(f"b=AS:{max_kbps}")
                    out.append(f"b=TIAS:{max_kbps * 1000}")
                in_video = line.startswith("m=video")
                inserted_b = False
                if in_video:
                    parts = line.split()
                    video_payloads = set(parts[3:])
            out.append(line)
            if in_video and line.startswith("c=") and not inserted_b:
                out.append(f"b=AS:{max_kbps}")
                out.append(f"b=TIAS:{max_kbps * 1000}")
                inserted_b = True
        if in_video and not inserted_b:
            out.append(f"b=AS:{max_kbps}")
            out.append(f"b=TIAS:{max_kbps * 1000}")

        # Add x-google hints to video fmtp lines when possible. This is common
        # with Chromium and ignored by browsers that do not use it.
        min_kbps = p["min_kbps"]
        start_kbps = p["start_kbps"]
        hint_parts = []
        if min_kbps:
            hint_parts.append(f"x-google-min-bitrate={min_kbps}")
        if start_kbps:
            hint_parts.append(f"x-google-start-bitrate={start_kbps}")
        if max_kbps:
            hint_parts.append(f"x-google-max-bitrate={max_kbps}")
        if not hint_parts:
            return "\r\n".join(out) + "\r\n", f"sdpBitrate=max:{max_kbps}kbps"
        hinted = []
        in_video = False
        for line in out:
            if line.startswith("m="):
                in_video = line.startswith("m=video")
            if in_video and line.startswith("a=fmtp:"):
                try:
                    pt = line.split(":", 1)[1].split(None, 1)[0]
                except Exception:
                    pt = ""
                if not video_payloads or pt in video_payloads:
                    suffix = ";" if ";" in line or " " in line else " "
                    line = line + suffix + ";".join(hint_parts)
            hinted.append(line)
        return "\r\n".join(hinted) + "\r\n", f"sdpBitrate=min:{min_kbps} start:{start_kbps} max:{max_kbps}kbps"

    def _sync_wrapped_tracks(self, audio_track, video_track, audio_offset_ms: int) -> tuple[object, object, str]:
        try:
            offset = int(float(audio_offset_ms or 0))
        except Exception:
            offset = 0
        audio_delay = max(0.0, offset / 1000.0)
        video_delay = max(0.0, -offset / 1000.0)
        note = f"sync=0ms"
        if audio_delay > 0:
            note = f"sync=audioDelay:{offset}ms"
            if audio_track is not None:
                audio_track = DelayedMediaTrack(audio_track, audio_delay)
        elif video_delay > 0:
            note = f"sync=videoDelay:{abs(offset)}ms"
            if video_track is not None:
                video_track = DelayedMediaTrack(video_track, video_delay)
        return audio_track, video_track, note

    async def create_answer(self, offer: dict, media_path: str, seek_seconds: float = 0.0, bitrate_profile: Optional[dict] = None, audio_offset_ms: int = 0) -> dict:
        if not AIORTC_AVAILABLE:
            raise RuntimeError(
                "aiortc is not installed. Install it with: pip install aiortc av. "
                f"Import error: {AIORTC_IMPORT_ERROR}"
            )
        media_path = str(media_path or "").strip()
        if not media_path:
            raise RuntimeError("WebRTC aiortc needs a Direct File/SMB path; no media path is available.")
        # Do not require Path.exists() for UNC paths; Windows credentials may be cached lazily.
        if not (media_path.startswith("\\\\") or media_path.lower().startswith("smb://")):
            try:
                if not Path(media_path).exists():
                    await self._log(f"WebRTC aiortc warning: path does not exist according to Python, trying anyway: {media_path}")
            except Exception as exc:
                await self._log(f"WebRTC aiortc warning: could not check file path: {exc}")

        await self.stop()
        self.media_path = media_path
        self.started_at = time.monotonic()
        self.last_error = ""
        self.connection_state = "new"
        self.ice_connection_state = "new"
        self.ice_gathering_state = "new"

        self.pc = RTCPeerConnection()

        @self.pc.on("connectionstatechange")
        async def on_connectionstatechange():
            self.connection_state = getattr(self.pc, "connectionState", "unknown")
            await self._log(f"WebRTC connection state: {self.connection_state}")

        @self.pc.on("iceconnectionstatechange")
        async def on_iceconnectionstatechange():
            self.ice_connection_state = getattr(self.pc, "iceConnectionState", "unknown")
            await self._log(f"WebRTC ICE connection state: {self.ice_connection_state}")

        @self.pc.on("icegatheringstatechange")
        async def on_icegatheringstatechange():
            self.ice_gathering_state = getattr(self.pc, "iceGatheringState", "unknown")

        options = {}
        try:
            ss = float(seek_seconds or 0.0)
            if ss > 1.0:
                # PyAV passes options to libavformat. For MPEG-TS this should start
                # close to the current SageTV media time, but exact seek depends on
                # keyframes and container timestamps.
                options["ss"] = f"{ss:.3f}"
        except Exception:
            pass

        try:
            self.player = MediaPlayer(media_path, options=options or None)
        except TypeError:
            self.player = MediaPlayer(media_path)

        seek_applied = await self._seek_media_player(float(seek_seconds or 0.0))

        added = []
        bitrate_notes = []
        video_track = getattr(self.player, "video", None)
        audio_track = getattr(self.player, "audio", None)
        audio_track, video_track, sync_note = self._sync_wrapped_tracks(audio_track, video_track, int(audio_offset_ms or 0))
        # Keep m-line order aligned with the browser offer (video, then audio).
        if video_track is not None:
            video_sender = self.pc.addTrack(video_track)
            self._set_last_transceiver_codecs("video")
            bitrate_notes.append(await self._apply_sender_bitrate_parameters(video_sender, bitrate_profile))
            added.append("video")
        if audio_track is not None:
            self.pc.addTrack(audio_track)
            self._set_last_transceiver_codecs("audio")
            added.append("audio")
        if not added:
            await self.stop()
            raise RuntimeError("aiortc MediaPlayer opened the file but did not expose audio or video tracks.")
        self.tracks = added

        offer_sdp = offer.get("sdp") or offer.get("offer_sdp") or ""
        offer_type = offer.get("type") or offer.get("offer_type") or "offer"
        if not offer_sdp:
            raise RuntimeError("Browser WebRTC offer did not include SDP.")
        await self.pc.setRemoteDescription(RTCSessionDescription(sdp=offer_sdp, type=offer_type))
        answer = await self.pc.createAnswer()
        sdp, sdp_note = self._munge_sdp_bitrate(answer.sdp, bitrate_profile)
        if sdp != answer.sdp:
            answer = RTCSessionDescription(sdp=sdp, type=answer.type)
        await self.pc.setLocalDescription(answer)
        local = self.pc.localDescription
        bitrate_summary = self._bitrate_summary(bitrate_profile)
        bitrate_notes.append(sdp_note)
        await self._log(f"WebRTC aiortc answer created for {media_path}; tracks={','.join(added)} seek={float(seek_seconds or 0):.3f}s seekApplied={seek_applied} bitrate={bitrate_summary} {sync_note} {'; '.join(bitrate_notes)}")
        return {
            "type": local.type,
            "sdp": local.sdp,
            "tracks": added,
            "media_path": media_path,
            "seek_seconds": float(seek_seconds or 0.0),
            "seek_applied": bool(seek_applied),
            "bitrate_profile": self._normalize_bitrate_profile(bitrate_profile),
            "bitrate_summary": bitrate_summary,
            "bitrate_notes": bitrate_notes,
            "audio_offset_ms": int(audio_offset_ms or 0),
            "sync_note": sync_note,
        }

    def snapshot(self) -> dict:
        return {
            "available": AIORTC_AVAILABLE,
            "import_error": AIORTC_IMPORT_ERROR,
            "running": bool(self.pc is not None),
            "media_path": self.media_path,
            "tracks": list(self.tracks),
            "connection_state": self.connection_state,
            "ice_connection_state": self.ice_connection_state,
            "ice_gathering_state": self.ice_gathering_state,
            "age_seconds": round(max(0.0, time.monotonic() - self.started_at), 1) if self.started_at else 0.0,
            "last_error": self.last_error,
        }
