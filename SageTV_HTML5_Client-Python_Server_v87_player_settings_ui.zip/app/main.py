import asyncio
import json
import os
import re
import shutil
import subprocess
import hashlib
import ipaddress
import time
import uuid
import traceback
from pathlib import Path
from typing import Dict

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Body, Request
from starlette.websockets import WebSocketState
from fastapi.responses import HTMLResponse, JSONResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles

from .sagetv_session import SageTVWebSession, normalize_mac
from .runtime_store import runtime_hls_root, hls_storage_config, cleanup_hls_roots

ROOT = Path(__file__).resolve().parent.parent
STATIC = ROOT / "static"

CLIENT_SETTINGS = ROOT / "client_settings"
CLIENT_SETTINGS.mkdir(parents=True, exist_ok=True)

SERVER_SETTINGS = ROOT / "server_settings"
SERVER_SETTINGS.mkdir(parents=True, exist_ok=True)
SERVER_SETTINGS_FILE = SERVER_SETTINGS / "settings.json"
SERVER_ERROR_LOG = SERVER_SETTINGS / "server_errors.log"

# Client settings are per device/browser profile. Server settings describe the
# SageTV/server environment and are shared by every client profile.
CLIENT_SETTING_IDS = {
    "clientId", "mediaCaps", "videoEncoder", "videoMaxHeight",
    "videoBitrate", "audioOffset", "videoMuted", "videoDebugOverlay", "hlsMode",
    "bufferPreset", "hlsSegmentSeconds", "hlsStartSegments", "hlsJsMaxBuffer",
    "directReadMode", "ffmpegBufferPreset", "playerMode",
    "webrtcBitrateMode", "webrtcMinKbps", "webrtcStartKbps", "webrtcMaxKbps",
}

SERVER_SETTING_IDS = {
    "server", "playbackSource", "directSageRoot", "directLocalRoot",
    "hlsStorageMode", "hlsRamRoot",
}


MAC_PATTERN = re.compile(r"(?i)(?:[0-9a-f]{2}[:-]){5}[0-9a-f]{2}")


def _normalize_detected_mac(value: str | None) -> str | None:
    if not value:
        return None
    m = MAC_PATTERN.search(str(value))
    if not m:
        return None
    raw = re.sub(r"[^0-9a-fA-F]", "", m.group(0)).lower()
    if len(raw) != 12:
        return None
    # Ignore all-zero/broadcast addresses.
    if raw in ("000000000000", "ffffffffffff"):
        return None
    return ":".join(raw[i:i+2] for i in range(0, 12, 2))


def _mac_from_int(value: int) -> str:
    raw = f"{value & 0xFFFFFFFFFFFF:012x}"
    return ":".join(raw[i:i+2] for i in range(0, 12, 2))


def _local_admin_mac_from_seed(seed: str) -> str:
    digest = hashlib.sha256(seed.encode("utf-8", errors="ignore")).digest()
    b = bytearray(digest[:6])
    # Locally administered, unicast. Keep 02:51:56 prefix to make generated ids easy to spot.
    b[0], b[1], b[2] = 0x02, 0x51, 0x56
    return ":".join(f"{x:02x}" for x in b)


def _run_mac_lookup_command(cmd: list[str]) -> str:
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=1.5)
    except Exception:
        return ""
    return (p.stdout or "") + "\n" + (p.stderr or "")


def detect_client_mac_from_ip(ip: str | None) -> tuple[str | None, str]:
    """Best-effort LAN MAC lookup for the browser host.

    Browsers do not expose the client's MAC address to JavaScript.  On a LAN, the
    server can often read it from the OS ARP/neighbor table after the HTTP
    connection arrives.  Across routed/VPN/reverse-proxy connections this may be
    unavailable or may represent an intermediate router, so callers must fall
    back to a generated id.
    """
    ip = (ip or "").strip()
    if not ip:
        return None, "none"

    # If the browser is running on the same machine as the Python server, use the
    # server host MAC as the best available per-machine identity.
    if ip in {"127.0.0.1", "::1", "localhost"}:
        mac_int = uuid.getnode()
        if (mac_int >> 40) & 0x01 == 0:  # unicast, likely a real adapter MAC
            return _mac_from_int(mac_int), "localhost"
        return None, "localhost-unavailable"

    try:
        parsed = ipaddress.ip_address(ip)
        if parsed.version != 4:
            return None, "ipv6-unavailable"
    except Exception:
        return None, "invalid-ip"

    # Refresh the ARP entry if possible. Timeout is intentionally tiny.
    if os.name == "nt":
        _run_mac_lookup_command(["ping", "-n", "1", "-w", "300", ip])
        commands = [["arp", "-a", ip], ["arp", "-a"]]
    else:
        _run_mac_lookup_command(["ping", "-c", "1", "-W", "1", ip])
        commands = [["ip", "neigh", "show", ip], ["arp", "-n", ip], ["arp", "-a", ip]]

    for cmd in commands:
        out = _run_mac_lookup_command(cmd)
        # Prefer a line containing the target IP so a broad arp table does not
        # accidentally return another device.
        lines = [ln for ln in out.splitlines() if ip in ln] or out.splitlines()
        for line in lines:
            mac = _normalize_detected_mac(line)
            if mac:
                return mac, "arp"
    return None, "arp-unavailable"


app = FastAPI(title="SageTV Pure Python HTML5 MiniClient GUI")
app.mount("/static", StaticFiles(directory=str(STATIC)), name="static")

sessions: Dict[str, SageTVWebSession] = {}


def _mac_to_int(mac: str) -> int:
    clean = re.sub(r"[^0-9a-fA-F]", "", normalize_mac(mac))
    return int(clean, 16)


def _int_to_mac(value: int) -> str:
    value &= 0xFFFFFFFFFFFF
    # keep locally administered/unicast first octet so SageTV treats it like a normal MiniClient id
    value = (value & 0x00FFFFFFFFFF) | (0x02 << 40)
    raw = f"{value:012x}"
    return ":".join(raw[i:i+2] for i in range(0, 12, 2))


def allocate_effective_client_id(requested_client_id: str, current_session_id: str) -> tuple[str, bool]:
    """Return a SageTV client id that is not already connected.

    SageTV uses the MiniClient MAC/client id as the identity for the UI session.
    If two browser clients connect with the same id, SageTV disconnects the older
    one.  Keep the user's requested Client ID for settings, but automatically
    derive a unique effective id for the SageTV socket when there is an active
    conflict.
    """
    requested = normalize_mac(requested_client_id)
    active = {
        normalize_mac(s.client_id)
        for sid, s in sessions.items()
        if sid != current_session_id and not getattr(s, "ws_closed", False)
    }
    if requested not in active:
        return requested, False

    base_int = _mac_to_int(requested)
    # Try deterministic nearby ids first so logs are easy to follow.
    for delta in range(1, 512):
        candidate = _int_to_mac(base_int + delta)
        if candidate not in active:
            return candidate, True

    # Extremely unlikely fallback: fold in the websocket session id.
    salt = int(re.sub(r"[^0-9a-fA-F]", "", current_session_id)[:8] or "0", 16)
    for delta in range(512, 2048):
        candidate = _int_to_mac(base_int ^ salt ^ delta)
        if candidate not in active:
            return candidate, True
    return requested, False



def _now_log_ts() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())


def append_text_log(path: Path, line: str, max_bytes: int = 2_000_000):
    """Append one line to a UTF-8 log and rotate it when it gets large."""
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.exists() and path.stat().st_size > max_bytes:
            bak = path.with_suffix(path.suffix + ".1")
            try:
                if bak.exists():
                    bak.unlink()
                path.replace(bak)
            except Exception:
                path.unlink(missing_ok=True)
        with path.open("a", encoding="utf-8", errors="replace") as f:
            f.write(line.rstrip("\r\n") + "\n")
    except Exception:
        # Logging must never break playback or settings saves.
        pass


def append_server_error(where: str, exc):
    text = str(exc)
    stack = ""
    if isinstance(exc, BaseException):
        stack = traceback.format_exc()
    append_text_log(SERVER_ERROR_LOG, f"[{_now_log_ts()}] {where}: {text}\n{stack}".rstrip(), max_bytes=5_000_000)


def client_log_file(client_id: str) -> Path:
    return client_settings_folder(client_id) / "client.log"


def append_client_log(client_id: str, line: str):
    append_text_log(client_log_file(client_id), line, max_bytes=2_000_000)


def cleanup_runtime_hls(max_age_minutes: int = 240, include_active: bool = False) -> dict:
    """Delete old HLS session folders from the selected storage root.

    The selected root may be the app disk folder, OS temp, or a RAM-backed
    tmpfs/RAM-disk path. Active sessions are skipped unless include_active=True.
    """
    return cleanup_hls_roots(set(sessions.keys()), max_age_minutes=max_age_minutes, include_active=include_active)


@app.on_event("startup")
async def startup_cleanup():
    # Clean abandoned session folders from prior crashes/runs. Active playback uses
    # rolling FFmpeg cleanup in v37; this handles folders left behind by older builds.
    cleanup_runtime_hls(int(os.environ.get("SAGEWEB_HLS_CLEANUP_AGE_MIN", "240")))


@app.middleware("http")
async def no_cache_for_dev(request, call_next):
    try:
        response = await call_next(request)
    except Exception as exc:
        append_server_error(f"HTTP {request.method} {request.url.path}", exc)
        raise
    # Do not run HLS through Starlette StaticFiles. FFmpeg can grow/rename HLS
    # files while the browser is reading them, and StaticFiles may compute a
    # Content-Length before the write is complete. The custom /hls route below
    # returns a byte snapshot with a matching length.
    response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"
    return response



def safe_client_folder_name(client_id: str) -> str:
    """Convert a SageTV Client ID into a safe cross-platform folder name."""
    raw = (client_id or "default").strip() or "default"
    safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", raw).strip("._-")
    return safe[:80] or "default"


def client_settings_folder(client_id: str) -> Path:
    folder = CLIENT_SETTINGS / safe_client_folder_name(client_id)
    folder.mkdir(parents=True, exist_ok=True)
    return folder


def client_settings_file(client_id: str) -> Path:
    return client_settings_folder(client_id) / "settings.json"


def _load_settings_payload(path: Path) -> dict:
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}
    settings = data.get("settings", data)
    return settings if isinstance(settings, dict) else {}


def _clean_settings(settings: dict, allowed_ids: set) -> dict:
    return {k: str(v) for k, v in (settings or {}).items() if k in allowed_ids and v is not None}


def load_client_settings(client_id: str) -> dict:
    return _clean_settings(_load_settings_payload(client_settings_file(client_id)), CLIENT_SETTING_IDS)


def save_client_settings(client_id: str, settings: dict) -> dict:
    clean = _clean_settings(settings, CLIENT_SETTING_IDS)
    clean["clientId"] = (client_id or clean.get("clientId") or "default").strip() or "default"
    path = client_settings_file(client_id)
    payload = {
        "client_id": clean["clientId"],
        "folder": path.parent.name,
        "scope": "client",
        "updated_at": int(time.time()),
        "settings": clean,
    }
    tmp = path.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    tmp.replace(path)
    return payload


def default_server() -> str:
    return os.environ.get("SAGETV_SERVER", "192.168.10.175:31099")


def load_server_settings(client_id_for_legacy: str = "default") -> tuple[dict, bool, bool]:
    """Return (settings, exists, legacy_used).

    v65 stored every UI setting under client_settings/<client>/settings.json.
    If a v66/v67/v70/v71 server_settings file does not exist yet, import the server-wide
    fields from the selected client's old v65 settings as a one-time compatible
    fallback. The first save writes server_settings/settings.json.
    """
    defaults = {
        "server": default_server(),
        "playbackSource": "direct",
        "directSageRoot": "",
        "directLocalRoot": "",
        "hlsStorageMode": "disk",
        "hlsRamRoot": "",
    }
    if SERVER_SETTINGS_FILE.exists():
        return {**defaults, **_clean_settings(_load_settings_payload(SERVER_SETTINGS_FILE), SERVER_SETTING_IDS)}, True, False

    legacy = _clean_settings(_load_settings_payload(client_settings_file(client_id_for_legacy)), SERVER_SETTING_IDS)
    return {**defaults, **legacy}, False, bool(legacy)


def save_server_settings(settings: dict) -> dict:
    current, _, _ = load_server_settings()
    clean = {**current, **_clean_settings(settings, SERVER_SETTING_IDS)}
    payload = {
        "scope": "server",
        "folder": SERVER_SETTINGS.name,
        "updated_at": int(time.time()),
        "settings": clean,
    }
    tmp = SERVER_SETTINGS_FILE.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    tmp.replace(SERVER_SETTINGS_FILE)
    return payload


@app.get("/")
async def index():
    html = (STATIC / "index.html").read_text(encoding="utf-8")
    return HTMLResponse(html)


@app.get("/hls/{session_id}/{filename:path}")
async def hls_file(session_id: str, filename: str):
    # Snapshot HLS files into memory before returning them. This avoids
    # "Response content longer than Content-Length" when FFmpeg is still
    # writing a playlist/segment while the browser requests it.
    # v78: allow safe nested ABR paths such as v0/stream.m3u8 and v1/seg.ts.
    parts = []
    for part in str(filename or "").replace("\\", "/").split("/"):
        if not part or part in (".", ".."):
            continue
        parts.append(part)
    if not parts:
        return Response(status_code=404)
    rel_path = Path(*parts)
    safe_name = rel_path.name
    session = sessions.get(session_id)
    base_dir = None
    if session and session.video.output_dir:
        base_dir = Path(session.video.output_dir)
    elif session and session.video.status.playlist_path:
        base_dir = Path(session.video.status.playlist_path).parent
    else:
        base_dir = runtime_hls_root() / session_id
    path = base_dir / rel_path
    if not path.exists() or not path.is_file():
        # FFmpeg may temporarily write stream_m3u8.tmp/master_m3u8.tmp before the final
        # playlist rename. If the final playlist is not visible yet, serve the
        # temp snapshot from the same folder.
        if safe_name in ("stream.m3u8", "master.m3u8"):
            parent = path.parent
            stem = safe_name.replace(".m3u8", "")
            for tmp_name in (f"{stem}_m3u8.tmp", f"{safe_name}.tmp"):
                tmp_path = parent / tmp_name
                if tmp_path.exists() and tmp_path.is_file():
                    path = tmp_path
                    break
    if not path.exists() or not path.is_file():
        return Response(status_code=404)
    try:
        data = path.read_bytes()
    except Exception:
        return Response(status_code=404)
    if safe_name.endswith(".m3u8"):
        media_type = "application/vnd.apple.mpegurl"
    elif safe_name.endswith(".ts"):
        media_type = "video/mp2t"
    elif safe_name.endswith((".m4s", ".mp4")):
        media_type = "video/mp4"
    else:
        media_type = "application/octet-stream"
    return Response(
        content=data,
        media_type=media_type,
        headers={
            "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
            "Pragma": "no-cache",
            "Expires": "0",
            "Accept-Ranges": "none",
        },
    )



@app.get("/mse/{session_id}/stream.mp4")
async def mse_stream(session_id: str):
    s = sessions.get(session_id)
    if not s:
        return Response(status_code=404)
    headers = {
        "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
        "Pragma": "no-cache",
        "Expires": "0",
        "X-Accel-Buffering": "no",
        "Accept-Ranges": "none",
    }
    return StreamingResponse(
        s.video.stream_mse_chunks(),
        media_type="video/mp4",
        headers=headers,
    )

@app.get("/mseav/{session_id}/video.mp4")
async def mseav_video_stream(session_id: str):
    s = sessions.get(session_id)
    if not s:
        return Response(status_code=404)
    headers = {
        "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
        "Pragma": "no-cache",
        "Expires": "0",
        "X-Accel-Buffering": "no",
        "Accept-Ranges": "none",
    }
    return StreamingResponse(
        s.video.stream_growing_file("video.mp4"),
        media_type="video/mp4",
        headers=headers,
    )

@app.get("/mseav/{session_id}/audio.mp4")
async def mseav_audio_stream(session_id: str):
    s = sessions.get(session_id)
    if not s:
        return Response(status_code=404)
    headers = {
        "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
        "Pragma": "no-cache",
        "Expires": "0",
        "X-Accel-Buffering": "no",
        "Accept-Ranges": "none",
    }
    return StreamingResponse(
        s.video.stream_growing_file("audio.mp4"),
        media_type="audio/mp4",
        headers=headers,
    )


@app.get("/api/default_client_id")
async def default_client_id(request: Request):
    # Kept for backward compatibility with older app.js clients. Newer browsers
    # generate the Client ID locally and store it in a cookie. The value is still
    # MAC-format because SageTV's MiniClient handshake requires six ID bytes, but
    # this is not a hardware MAC address.
    b = bytearray(os.urandom(6))
    b[0] = 0x02  # locally-administered, unicast
    b[1] = 0x51
    b[2] = 0x56
    client_id = ":".join(f"{x:02x}" for x in b)
    return {
        "ok": True,
        "client_id": normalize_mac(client_id),
        "source": "server-generated-private",
        "client_host": request.client.host if request.client else "",
        "note": "Private generated Client ID. It is stored by the browser cookie and is not the device MAC address.",
    }

@app.get("/api/status")
async def status():
    return {
        "default_server": default_server(),
        "sessions": {sid: s.snapshot() for sid, s in sessions.items()},
        "version": "v87",
        "hls_storage": hls_storage_config(),
        "note": "Pure Python/HTML5 GUI bridge. v87 stores a private generated Client ID in each browser cookie instead of using device MAC detection, while still assigning unique effective SageTV IDs for simultaneous duplicate connections."
    }


@app.get("/api/server_settings")
async def get_server_settings(client_id: str = "default"):
    settings, exists, legacy_used = load_server_settings(client_id_for_legacy=client_id)
    return {
        "ok": True,
        "exists": exists,
        "legacy_used": legacy_used,
        "folder": SERVER_SETTINGS.name,
        "path": str(SERVER_SETTINGS_FILE),
        "settings": settings,
        "hls_storage": hls_storage_config(),
    }


@app.post("/api/server_settings")
async def post_server_settings(payload: dict = Body(default_factory=dict)):
    settings = payload.get("settings") or payload
    saved = save_server_settings(settings)
    return {
        "ok": True,
        "folder": saved["folder"],
        "path": str(SERVER_SETTINGS_FILE),
        "updated_at": saved["updated_at"],
        "hls_storage": hls_storage_config(),
    }


@app.get("/api/client_settings")
async def get_client_settings(client_id: str = "default"):
    folder = client_settings_folder(client_id)
    path = folder / "settings.json"
    settings = load_client_settings(client_id)
    return {
        "ok": True,
        "exists": path.exists(),
        "client_id": client_id,
        "folder": folder.name,
        "path": str(path),
        "settings": settings,
    }


@app.post("/api/client_settings")
async def post_client_settings(payload: dict = Body(default_factory=dict)):
    client_id = str(payload.get("client_id") or payload.get("clientId") or "default")
    settings = payload.get("settings") or {}
    saved = save_client_settings(client_id, settings)
    return {
        "ok": True,
        "client_id": saved["client_id"],
        "folder": saved["folder"],
        "path": str(client_settings_file(client_id)),
        "updated_at": saved["updated_at"],
    }



@app.post("/api/client_log")
async def post_client_log(payload: dict = Body(default_factory=dict)):
    client_id = str(payload.get("client_id") or payload.get("clientId") or "default")
    lines = payload.get("lines") or []
    if isinstance(lines, str):
        lines = [lines]
    count = 0
    for line in lines[:200]:
        if line is None:
            continue
        append_client_log(client_id, str(line)[:4000])
        count += 1
    return {
        "ok": True,
        "client_id": client_id,
        "folder": client_settings_folder(client_id).name,
        "path": str(client_log_file(client_id)),
        "lines": count,
    }


@app.get("/api/log_paths")
async def get_log_paths(client_id: str = "default"):
    return {
        "ok": True,
        "client_id": client_id,
        "client_log": str(client_log_file(client_id)),
        "server_error_log": str(SERVER_ERROR_LOG),
    }


@app.get("/api/hls_ready/{session_id}")
async def hls_ready(session_id: str):
    s = sessions.get(session_id)
    if not s:
        return JSONResponse({"ready": False, "exists": False, "error": "session not found"}, status_code=404)
    try:
        ready = s.video.refresh_ready_state()
    except Exception as exc:
        return {"ready": False, "exists": False, "error": str(exc), "video": s.video.status.to_json()}
    playlist_path = Path(s.video.status.playlist_path) if s.video.status.playlist_path else None
    return {
        "ready": bool(ready),
        "exists": bool(playlist_path and playlist_path.exists()),
        "segments": s.video.status.segments,
        "video": s.video.status.to_json(),
    }


@app.post("/api/stop_all")
async def stop_all():
    for s in list(sessions.values()):
        await s.close()
    sessions.clear()
    cleanup_runtime_hls(include_active=True)
    return {"ok": True}


@app.post("/api/cleanup_hls")
async def cleanup_hls(max_age_minutes: int = 60):
    return cleanup_runtime_hls(max_age_minutes=max_age_minutes)


@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    # Browsers can close during page refresh or while the Disconnect button is
    # processing.  Treat those cases as normal disconnects instead of letting
    # Starlette/Uvicorn print an exception stack trace.
    try:
        await ws.accept()
    except Exception:
        return

    sid = uuid.uuid4().hex[:12]
    session = SageTVWebSession(session_id=sid, websocket=ws)
    sessions[sid] = session
    try:
        await session.send_log(f"Session {sid} connected. Default SageTV server {default_server()}")
        while True:
            try:
                msg = await ws.receive_text()
            except WebSocketDisconnect:
                break
            except RuntimeError as exc:
                # Happens if the server/browser side already closed the socket,
                # for example after the Disconnect button intentionally ends the
                # session.  Do not treat it as an application error.
                if "WebSocket is not connected" in str(exc) or ws.application_state != WebSocketState.CONNECTED:
                    break
                raise

            try:
                data = json.loads(msg)
            except Exception:
                await session.send_log(f"Invalid JSON from browser: {msg[:120]}")
                continue

            if data.get("type") == "connect":
                requested_id = normalize_mac(data.get("client_id") or "")
                effective_id, adjusted = allocate_effective_client_id(requested_id, sid)
                data["requested_client_id"] = requested_id
                data["client_id"] = effective_id
                data["auto_client_id_adjusted"] = adjusted

            try:
                await session.handle_browser_message(data)
            except Exception as exc:
                append_server_error(f"websocket message sid={sid} type={data.get('type')}", exc)
                await session.send_log(f"Server error handling browser message: {exc}")
                continue
            if data.get("type") == "disconnect":
                break
    except Exception as exc:
        append_server_error(f"websocket endpoint sid={sid}", exc)
        raise
    finally:
        await session.close()
        sessions.pop(sid, None)
