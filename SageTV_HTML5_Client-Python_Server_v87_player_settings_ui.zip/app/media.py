import struct
import time
from dataclasses import dataclass, field
from typing import Optional


MEDIACMD_INIT = 0
MEDIACMD_DEINIT = 1
MEDIACMD_OPENURL = 16
MEDIACMD_GETMEDIATIME = 17
MEDIACMD_SETMUTE = 18
MEDIACMD_STOP = 19
MEDIACMD_PAUSE = 20
MEDIACMD_PLAY = 21
MEDIACMD_FLUSH = 22
MEDIACMD_PUSHBUFFER = 23
MEDIACMD_GETVIDEORECT = 24
MEDIACMD_SETVIDEORECT = 25
MEDIACMD_GETVOLUME = 26
MEDIACMD_SETVOLUME = 27
MEDIACMD_FRAMESTEP = 28
MEDIACMD_SEEK = 29
MEDIACMD_DVD_STREAMS = 36

MEDIA_CMD_NAMES = {
    MEDIACMD_INIT: "MEDIACMD_INIT",
    MEDIACMD_DEINIT: "MEDIACMD_DEINIT",
    MEDIACMD_OPENURL: "MEDIACMD_OPENURL",
    MEDIACMD_GETMEDIATIME: "MEDIACMD_GETMEDIATIME",
    MEDIACMD_SETMUTE: "MEDIACMD_SETMUTE",
    MEDIACMD_STOP: "MEDIACMD_STOP",
    MEDIACMD_PAUSE: "MEDIACMD_PAUSE",
    MEDIACMD_PLAY: "MEDIACMD_PLAY",
    MEDIACMD_FLUSH: "MEDIACMD_FLUSH",
    MEDIACMD_PUSHBUFFER: "MEDIACMD_PUSHBUFFER",
    MEDIACMD_GETVIDEORECT: "MEDIACMD_GETVIDEORECT",
    MEDIACMD_SETVIDEORECT: "MEDIACMD_SETVIDEORECT",
    MEDIACMD_GETVOLUME: "MEDIACMD_GETVOLUME",
    MEDIACMD_SETVOLUME: "MEDIACMD_SETVOLUME",
    MEDIACMD_FRAMESTEP: "MEDIACMD_FRAMESTEP",
    MEDIACMD_SEEK: "MEDIACMD_SEEK",
    MEDIACMD_DVD_STREAMS: "MEDIACMD_DVD_STREAMS",
}

NO_STATE = 0
LOADED_STATE = 1
PLAY_STATE = 2
PAUSE_STATE = 3
STOPPED_STATE = 4
EOS_STATE = 5

STATE_NAMES = {
    NO_STATE: "none",
    LOADED_STATE: "loaded",
    PLAY_STATE: "playing",
    PAUSE_STATE: "paused",
    STOPPED_STATE: "stopped",
    EOS_STATE: "eos",
}


def read_i32(buf: bytes, offset: int = 0) -> int:
    if len(buf) < offset + 4:
        return 0
    return struct.unpack_from(">i", buf, offset)[0]


def read_u32(buf: bytes, offset: int = 0) -> int:
    if len(buf) < offset + 4:
        return 0
    return struct.unpack_from(">I", buf, offset)[0]


def write_i32(value: int) -> bytes:
    # Java writes signed int bytes. Clamp/wrap like a 32-bit int.
    value = int(value)
    if value > 0x7FFFFFFF:
        value -= 0x100000000
    if value < -0x80000000:
        value = -0x80000000
    return struct.pack(">i", value)


def write_i64(value: int) -> bytes:
    return struct.pack(">q", int(value))


def write_u16_pair(a: int, b: int) -> bytes:
    return struct.pack(">HH", max(0, min(65535, int(a))), max(0, min(65535, int(b))))


@dataclass
class MediaStatus:
    state: int = NO_STATE
    url: str = ""
    push_mode: bool = False
    muted: bool = False
    volume: int = 65535
    media_time_ms: int = 0
    last_server_start_ms: int = -1
    bytes_pushed: int = 0
    push_buffers: int = 0
    flushes: int = 0
    seeks: int = 0
    eos: bool = False
    source_rect: tuple[int, int, int, int] = (0, 0, 0, 0)
    dest_rect: tuple[int, int, int, int] = (0, 0, 0, 0)
    video_size: tuple[int, int] = (0, 0)
    last_command: str = ""
    last_error: str = ""
    opened_at: float = 0.0
    play_started_at: float = 0.0
    play_started_media_ms: int = 0
    last_seek_ms: int = -1
    last_seek_at: float = 0.0

    def to_json(self) -> dict:
        current_time = self.current_media_time_ms()
        return {
            "state": STATE_NAMES.get(self.state, str(self.state)),
            "state_id": self.state,
            "url": self.url,
            "push_mode": self.push_mode,
            "muted": self.muted,
            "volume": self.volume,
            "media_time_ms": current_time,
            "last_server_start_ms": max(0, self.last_server_start_ms),
            "bytes_pushed": self.bytes_pushed,
            "push_buffers": self.push_buffers,
            "flushes": self.flushes,
            "seeks": self.seeks,
            "eos": self.eos,
            "source_rect": list(self.source_rect),
            "dest_rect": list(self.dest_rect),
            "video_size": list(self.video_size),
            "last_command": self.last_command,
            "last_error": self.last_error,
            "last_seek_ms": self.last_seek_ms,
        }

    def current_media_time_ms(self) -> int:
        if self.state == PLAY_STATE and self.play_started_at > 0:
            return int(self.play_started_media_ms + (time.monotonic() - self.play_started_at) * 1000)
        return int(max(0, self.media_time_ms))

    def set_state(self, new_state: int):
        if new_state == PLAY_STATE and self.state != PLAY_STATE:
            self.play_started_media_ms = self.current_media_time_ms()
            self.play_started_at = time.monotonic()
        elif self.state == PLAY_STATE and new_state != PLAY_STATE:
            self.media_time_ms = self.current_media_time_ms()
            self.play_started_at = 0.0
            self.play_started_media_ms = self.media_time_ms
        self.state = new_state


@dataclass
class MediaCommandResult:
    reply: bytes = b""
    log: Optional[str] = None
    status_changed: bool = False
    video_bounds_changed: bool = False
    pushbuffer: bool = False
    push_data: bytes = b""
    push_flags: int = 0


@dataclass
class MediaCommandParser:
    detailed_buffer_stats: bool = True
    max_video_prebuffer: int = 4 * 1024 * 1024
    max_audio_prebuffer: int = 2 * 1024 * 1024
    status: MediaStatus = field(default_factory=MediaStatus)

    def command_name(self, cmd: int) -> str:
        return MEDIA_CMD_NAMES.get(cmd, f"UNKNOWN_{cmd}")

    def execute(self, cmd: int, payload: bytes) -> MediaCommandResult:
        name = self.command_name(cmd)
        self.status.last_command = name
        try:
            method = getattr(self, f"_cmd_{cmd}", None)
            if method:
                return method(payload)
            return MediaCommandResult(reply=b"", log=f"Unhandled media command {cmd} len={len(payload)}", status_changed=True)
        except Exception as exc:
            self.status.last_error = str(exc)
            return MediaCommandResult(reply=b"", log=f"Media command {name} error: {exc}", status_changed=True)

    def _cmd_0(self, payload: bytes) -> MediaCommandResult:
        self.status.set_state(NO_STATE)
        self.status.url = ""
        self.status.push_mode = False
        self.status.bytes_pushed = 0
        self.status.push_buffers = 0
        self.status.eos = False
        return MediaCommandResult(write_i32(1), "MEDIACMD_INIT -> OK", True)

    def _cmd_1(self, payload: bytes) -> MediaCommandResult:
        self.status.set_state(NO_STATE)
        self.status.url = ""
        return MediaCommandResult(write_i32(1), "MEDIACMD_DEINIT -> OK", True)

    def _cmd_16(self, payload: bytes) -> MediaCommandResult:
        # Java MediaCmd: int length, NUL-terminated URL bytes.
        str_len = read_i32(payload, 0)
        raw = payload[4:4 + max(0, str_len - 1)] if str_len > 0 else b""
        url = raw.decode("utf-8", errors="replace")
        self.status.url = url
        self.status.push_mode = url.startswith("push:")
        self.status.set_state(LOADED_STATE)
        self.status.opened_at = time.time()
        self.status.media_time_ms = 0
        self.status.play_started_media_ms = 0
        self.status.play_started_at = 0.0
        self.status.bytes_pushed = 0
        self.status.push_buffers = 0
        self.status.flushes = 0
        self.status.seeks = 0
        self.status.eos = False
        self.status.last_server_start_ms = -1
        kind = "PUSH" if self.status.push_mode else "PULL/FILE"
        return MediaCommandResult(write_i32(1), f"MEDIACMD_OPENURL {kind}: {url[:180]}", True)

    def _cmd_17(self, payload: bytes) -> MediaCommandResult:
        media_time = self.status.current_media_time_ms()
        self.status.media_time_ms = media_time
        if self.detailed_buffer_stats:
            return MediaCommandResult(write_i32(media_time) + bytes([self.status.state & 0xFF]), status_changed=False)
        return MediaCommandResult(write_i32(media_time), status_changed=False)

    def _cmd_18(self, payload: bytes) -> MediaCommandResult:
        self.status.muted = read_i32(payload, 0) != 0
        return MediaCommandResult(write_i32(1), f"MEDIACMD_SETMUTE {self.status.muted}", True)

    def _cmd_19(self, payload: bytes) -> MediaCommandResult:
        self.status.set_state(STOPPED_STATE)
        return MediaCommandResult(write_i32(1), "MEDIACMD_STOP", True)

    def _cmd_20(self, payload: bytes) -> MediaCommandResult:
        self.status.set_state(PAUSE_STATE)
        return MediaCommandResult(write_i32(1), "MEDIACMD_PAUSE", True)

    def _cmd_21(self, payload: bytes) -> MediaCommandResult:
        self.status.set_state(PLAY_STATE)
        return MediaCommandResult(write_i32(1), "MEDIACMD_PLAY", True)

    def _cmd_22(self, payload: bytes) -> MediaCommandResult:
        self.status.flushes += 1
        self.status.bytes_pushed = 0
        self.status.push_buffers = 0
        self.status.last_server_start_ms = -1
        # SageTV commonly sends SEEK followed immediately by FLUSH.  Earlier
        # builds reset media time to zero on FLUSH, which made Direct/WebRTC
        # restarts seek back to the beginning.  Preserve a very recent SEEK
        # target so the local bridge restarts near the user's requested time.
        now = time.monotonic()
        recent_seek = self.status.last_seek_ms >= 0 and (now - self.status.last_seek_at) <= 3.0
        if recent_seek:
            self.status.media_time_ms = int(max(0, self.status.last_seek_ms))
            self.status.play_started_media_ms = self.status.media_time_ms
            log = f"MEDIACMD_FLUSH preserve recent seek {self.status.media_time_ms} ms"
        else:
            # Keep the current play/pause state, but reset timeline until server pushes mux time/data.
            self.status.media_time_ms = 0
            self.status.play_started_media_ms = 0
            log = "MEDIACMD_FLUSH"
        self.status.play_started_at = now if self.status.state == PLAY_STATE else 0.0
        return MediaCommandResult(write_i32(1), log, True)

    def _cmd_23(self, payload: bytes) -> MediaCommandResult:
        buff_size = read_i32(payload, 0)
        flags = read_i32(payload, 4)
        data_off = 8
        server_mux_time = None
        if self.detailed_buffer_stats and buff_size > 0 and len(payload) > buff_size + 13:
            data_off += 10
            server_mux_time = read_i32(payload, 14)
            if self.status.last_server_start_ms < 0 and server_mux_time > 0:
                self.status.last_server_start_ms = server_mux_time
                # Match MiniClient behavior: after a flush, report from SageTV's server mux time.
                self.status.media_time_ms = server_mux_time
                self.status.play_started_media_ms = server_mux_time
                self.status.play_started_at = time.monotonic() if self.status.state == PLAY_STATE else 0.0
        push_data = b""
        if buff_size > 0:
            push_data = payload[data_off:data_off + buff_size]
            if len(push_data) < buff_size:
                self.status.last_error = f"short PUSHBUFFER data: expected {buff_size}, got {len(push_data)}"
            self.status.bytes_pushed += max(0, len(push_data))
            self.status.push_buffers += 1
        if flags == 0x80:
            self.status.eos = True
        # Stub player: keep advertising receive room so SageTV continues to push.
        rv = self.max_audio_prebuffer if "audio" in self.status.url and "bf=vid" not in self.status.url else self.max_video_prebuffer
        if self.detailed_buffer_stats:
            reply = write_i32(rv) + write_i32(self.status.current_media_time_ms()) + bytes([self.status.state & 0xFF])
        else:
            reply = write_i32(rv)
        log = None
        # Avoid spam: caller also throttles, but include useful information when requested.
        if self.status.push_buffers <= 3 or self.status.push_buffers % 100 == 0 or flags == 0x80:
            log = f"PUSHBUFFER size={buff_size} flags=0x{flags:02x} total={self.status.bytes_pushed} mux={server_mux_time}"
        return MediaCommandResult(reply, log, True, pushbuffer=True, push_data=push_data, push_flags=flags)

    def _cmd_24(self, payload: bytes) -> MediaCommandResult:
        w, h = self.status.video_size
        if w <= 0 or h <= 0:
            # Fall back to the last SETVIDEORECT source rectangle. Some SageTV
            # STVs poll this aggressively and reporting 0x0 can leave the HTML5
            # video layer in an unknown state even though the stream is 1920x1080.
            src = self.status.source_rect
            if src and src[2] > 0 and src[3] > 0:
                w, h = src[2], src[3]
                self.status.video_size = (w, h)
            else:
                return MediaCommandResult(write_i32(0), status_changed=False)
        return MediaCommandResult(write_u16_pair(w, h), status_changed=False)

    def _cmd_25(self, payload: bytes) -> MediaCommandResult:
        if len(payload) >= 32:
            src = (read_i32(payload, 0), read_i32(payload, 4), read_i32(payload, 8), read_i32(payload, 12))
            dst = (read_i32(payload, 16), read_i32(payload, 20), read_i32(payload, 24), read_i32(payload, 28))
            self.status.source_rect = src
            self.status.dest_rect = dst
            if src[2] > 0 and src[3] > 0:
                self.status.video_size = (src[2], src[3])
            return MediaCommandResult(write_i32(0), f"MEDIACMD_SETVIDEORECT src={src} dst={dst}", True, True)
        return MediaCommandResult(write_i32(0), "MEDIACMD_SETVIDEORECT short payload", True)

    def _cmd_26(self, payload: bytes) -> MediaCommandResult:
        return MediaCommandResult(write_i32(self.status.volume), status_changed=False)

    def _cmd_27(self, payload: bytes) -> MediaCommandResult:
        self.status.volume = max(0, min(65535, read_i32(payload, 0)))
        return MediaCommandResult(write_i32(self.status.volume), f"MEDIACMD_SETVOLUME {self.status.volume}", True)

    def _cmd_28(self, payload: bytes) -> MediaCommandResult:
        # Frame step in stub mode just advances roughly one 30fps frame.
        self.status.media_time_ms = self.status.current_media_time_ms() + 33
        self.status.play_started_media_ms = self.status.media_time_ms
        self.status.play_started_at = time.monotonic() if self.status.state == PLAY_STATE else 0.0
        return MediaCommandResult(write_i32(1), "MEDIACMD_FRAMESTEP", True)

    def _cmd_29(self, payload: bytes) -> MediaCommandResult:
        # Java MediaCmd combines two signed ints into a long. Use unsigned low part.
        hi = read_i32(payload, 0)
        lo = read_u32(payload, 4)
        seek_ms = (hi << 32) | lo
        self.status.seeks += 1
        self.status.media_time_ms = max(0, int(seek_ms))
        self.status.last_seek_ms = self.status.media_time_ms
        self.status.last_seek_at = time.monotonic()
        self.status.play_started_media_ms = self.status.media_time_ms
        self.status.play_started_at = time.monotonic() if self.status.state == PLAY_STATE else 0.0
        return MediaCommandResult(b"", f"MEDIACMD_SEEK {seek_ms} ms", True)

    def _cmd_36(self, payload: bytes) -> MediaCommandResult:
        stream_type = read_i32(payload, 0)
        stream_pos = read_i32(payload, 4)
        return MediaCommandResult(write_i32(0), f"MEDIACMD_DVD_STREAMS type={stream_type} pos={stream_pos}", True)
