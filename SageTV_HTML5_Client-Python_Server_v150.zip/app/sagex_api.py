"""SageX API helpers for current MediaFile lookup and timeline polling.

The browser UI keeps the old webInterface* setting names for saved-setting
compatibility, but v132 uses the SageX REST endpoint (``/sagex/api``) as the
primary lookup/timeline source instead of parsing the normal SageTV Web
Interface/Webpage HTML pages.
"""
from __future__ import annotations

import base64
import html
import json
import re
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Any, Iterable

from .sagetv_server import normalize_server_host
from .web_interface import mediafile_ids_from_text, _extract_media_paths, MEDIA_PATH_RE

DEFAULT_SAGEX_PORT = 8080


def normalize_sagex_base(value: str | None, fallback_host: str | None = None) -> str:
    """Return a normalized base URL for the SageX REST endpoint host.

    The setting accepts ``SERVER:PORT`` or a full URL.  A full URL that already
    contains ``/sagex/api`` is accepted; callers still append/use the endpoint
    safely.  Blank values default to ``http://<SageTV host>:8080``.
    """
    text = str(value or "").strip()
    if not text:
        host = normalize_server_host(fallback_host) or "127.0.0.1"
        text = f"{host}:{DEFAULT_SAGEX_PORT}"
    if "://" not in text:
        text = "http://" + text
    p = urllib.parse.urlsplit(text)
    scheme = p.scheme or "http"
    netloc = p.netloc or p.path
    path = p.path if p.netloc else ""
    if "/" in netloc:
        netloc, extra = netloc.split("/", 1)
        path = "/" + extra
    # Store only the base path; _api_url handles an already-included /sagex/api.
    return urllib.parse.urlunsplit((scheme, netloc.rstrip("/"), path.rstrip("/"), "", ""))


def sagex_context_variants(client_id: str | None) -> list[str]:
    """Return likely SageTV UI context strings for this MiniClient ID."""
    raw = re.sub(r"[^0-9A-Fa-f]", "", str(client_id or "")).lower()
    out: list[str] = []
    if raw:
        out.append(":".join(raw[i:i + 2] for i in range(0, min(len(raw), 12), 2)))
        out.append(raw)
    # A blank context is useful for single-client testing and older SageX setups.
    out.append("")
    return list(dict.fromkeys(out))


def _api_url(base_url: str) -> str:
    base = normalize_sagex_base(base_url)
    low = base.lower().rstrip("/")
    if low.endswith("/sagex/api"):
        return base.rstrip("/")
    if low.endswith("/sagex"):
        return base.rstrip("/") + "/api"
    return base.rstrip("/") + "/sagex/api"


def _make_request(url: str, username: str = "", password: str = "", timeout: float = 4.0) -> str:
    req = urllib.request.Request(url, headers={"User-Agent": "SageTV-HTML5-Client/130 SageX"})
    if username or password:
        token = base64.b64encode(f"{username}:{password}".encode("utf-8")).decode("ascii")
        req.add_header("Authorization", f"Basic {token}")
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        data = resp.read(2_000_000)
        charset = resp.headers.get_content_charset() or "utf-8"
        return data.decode(charset, errors="replace")


def sagex_call_text(base_url: str, command: str, args: Iterable[Any] | None = None, context: str = "", username: str = "", password: str = "", timeout: float = 4.0) -> str:
    params: list[tuple[str, str]] = [("c", str(command))]
    for idx, arg in enumerate(args or [], 1):
        params.append((str(idx), str(arg)))
    if context:
        params.append(("context", str(context)))
    url = _api_url(base_url) + "?" + urllib.parse.urlencode(params)
    return _make_request(url, username=username, password=password, timeout=timeout)


def _strip_html(value: str) -> str:
    text = re.sub(r"(?is)<br\s*/?>", "\n", str(value or ""))
    text = re.sub(r"(?is)</(p|div|li|tr|td|h\d|span|value|result|item|file|segment|property)>", "\n", text)
    text = re.sub(r"(?is)<script.*?</script>|<style.*?</style>", " ", text)
    text = re.sub(r"(?is)<[^>]+>", " ", text)
    return html.unescape(text).replace("\r", "")


def _walk_json_strings(obj: Any) -> Iterable[str]:
    if obj is None:
        return
    if isinstance(obj, (str, int, float, bool)):
        yield str(obj)
        return
    if isinstance(obj, dict):
        for k, v in obj.items():
            yield str(k)
            yield from _walk_json_strings(v)
        return
    if isinstance(obj, (list, tuple)):
        for item in obj:
            yield from _walk_json_strings(item)


def _all_text_fragments(response_text: str) -> list[str]:
    raw = str(response_text or "")
    items = [raw, html.unescape(raw), _strip_html(raw)]
    try:
        parsed = json.loads(raw)
        items.extend(_walk_json_strings(parsed) or [])
    except Exception:
        pass
    return [x for x in items if x is not None]


def extract_paths_from_sagex_response(response_text: str) -> list[str]:
    paths: list[str] = []
    for text in _all_text_fragments(response_text):
        # JSON responses often contain escaped Windows paths such as
        # C:\Videos\file.mkv. Prefer the unescaped form first so it
        # becomes file_path, then keep the original as a lower-priority
        # candidate. Actual UNC paths are still preserved because the original
        # text is also parsed.
        unescaped = text.replace("\\\\", "\\")
        if unescaped != text:
            paths.extend(_extract_media_paths(unescaped))
        paths.extend(_extract_media_paths(text))
    return list(dict.fromkeys([p for p in paths if p]))


def extract_ids_from_sagex_response(response_text: str) -> list[str]:
    ids: list[str] = []
    for text in _all_text_fragments(response_text):
        ids.extend(mediafile_ids_from_text(text))
        for rx in (
            re.compile(r"(?i)mediafile\s*[:#= ]\s*(\d+)"),
            re.compile(r"(?i)\bMediaFileID\b\s*[:= ]\s*(\d+)"),
            re.compile(r"(?i)\bmediafileid\b[^0-9]{0,16}(\d+)"),
            re.compile(r"(?i)\bid\b\s*[:= ]\s*(\d+)")
        ):
            for m in rx.finditer(text):
                ids.append(m.group(1))
    return list(dict.fromkeys([i for i in ids if i and i.isdigit()]))


def extract_first_int(response_text: str) -> int | None:
    for text in _all_text_fragments(response_text):
        cleaned = _strip_html(text).strip()
        # Prefer a clean scalar result.
        if re.fullmatch(r"-?\d+(?:\.0+)?", cleaned):
            try:
                return int(float(cleaned))
            except Exception:
                pass
        for key in ("RawMediaTime", "MediaTime", "MediaDuration", "value", "result"):
            m = re.search(rf"(?is)\b{re.escape(key)}\b[^0-9-]{{0,32}}(-?\d+)", text)
            if m:
                try:
                    return int(m.group(1))
                except Exception:
                    pass
    # Last resort: first integer in a very short response.
    raw = _strip_html(response_text).strip()
    if len(raw) < 128:
        m = re.search(r"-?\d+", raw)
        if m:
            try:
                return int(m.group(0))
            except Exception:
                return None
    return None


@dataclass
class SageXLookupResult:
    detail: dict
    reason: str


class SageXClient:
    def __init__(self, base_url: str, username: str = "", password: str = "", timeout: float = 4.0):
        self.base_url = normalize_sagex_base(base_url)
        self.username = str(username or "")
        self.password = str(password or "")
        self.timeout = float(timeout or 4.0)

    def call(self, command: str, args: Iterable[Any] | None = None, context: str = "") -> str:
        return sagex_call_text(self.base_url, command, args=args, context=context, username=self.username, password=self.password, timeout=self.timeout)

    def _detail_from_response(self, response_text: str, source: str) -> dict:
        paths = extract_paths_from_sagex_response(response_text)
        ids = extract_ids_from_sagex_response(response_text)
        detail: dict[str, object] = {}
        if paths:
            detail["file_path"] = paths[0]
            detail["file_candidates"] = paths
        if ids:
            detail["media_file_id"] = ids[0]
        if source:
            detail["sagex_source"] = source
        return detail

    def resolve_mediafile_id(self, media_file_id: str, context: str = "") -> SageXLookupResult:
        mfid = str(media_file_id or "").strip()
        if not mfid.isdigit():
            return SageXLookupResult({}, "SageX media file id was not numeric")
        errors: list[str] = []
        # The mediafile:<id> reference form is accepted by SageX APIs in many places.
        ref_variants = [f"mediafile:{mfid}", mfid]
        command_attempts: list[tuple[str, list[str], str]] = []
        for ref in ref_variants:
            command_attempts.extend([
                ("GetFileForSegment", [ref, "0"], f"GetFileForSegment({ref},0)"),
                ("GetSegmentFiles", [ref], f"GetSegmentFiles({ref})"),
                ("GetMediaFileFormatDescription", [ref], f"GetMediaFileFormatDescription({ref})"),
                ("GetMediaFileFormatDesc", [ref], f"GetMediaFileFormatDesc({ref})"),
            ])
        merged: dict[str, object] = {"media_file_id": mfid}
        for command, args, label in command_attempts:
            try:
                text = self.call(command, args=args, context=context)
            except Exception as exc:
                errors.append(f"{label}: {exc}")
                continue
            detail = self._detail_from_response(text, label)
            if detail.get("file_path"):
                merged.update(detail)
                return SageXLookupResult(merged, f"SageX {label} returned MediaFile path for id {mfid}")
            if detail:
                merged.update({k: v for k, v in detail.items() if v})
        return SageXLookupResult(merged if len(merged) > 1 else {}, "; ".join(errors[-3:]) or f"SageX did not return a file path for MediaFileID {mfid}")

    def lookup_current_media(self, client_id: str = "", push_url: str = "") -> SageXLookupResult:
        errors: list[str] = []
        # Exact IDs embedded in push URLs are the most reliable.
        for mfid in mediafile_ids_from_text(push_url):
            result = self.resolve_mediafile_id(mfid, context="")
            if result.detail.get("file_path"):
                return result
            errors.append(result.reason)
        for ctx in sagex_context_variants(client_id):
            try:
                text = self.call("GetCurrentMediaFile", context=ctx)
            except Exception as exc:
                errors.append(f"GetCurrentMediaFile context={ctx or '(default)'}: {exc}")
                continue
            detail = self._detail_from_response(text, f"GetCurrentMediaFile context={ctx or '(default)'}")
            if detail.get("file_path"):
                return SageXLookupResult(detail, f"SageX GetCurrentMediaFile returned a current file path for context {ctx or '(default)'}")
            for mfid in detail.get("media_file_id") and [str(detail.get("media_file_id"))] or extract_ids_from_sagex_response(text):
                result = self.resolve_mediafile_id(mfid, context=ctx)
                if result.detail.get("file_path"):
                    result.detail.setdefault("sagex_context", ctx)
                    return result
                errors.append(result.reason)
            if detail:
                errors.append(f"GetCurrentMediaFile context={ctx or '(default)'} returned no file path: {detail}")
        return SageXLookupResult({}, "; ".join(errors[-4:]) or "SageX lookup did not return current MediaFile detail")

    def get_timeline(self, client_id: str = "") -> tuple[int | None, int | None, str]:
        errors: list[str] = []
        for ctx in sagex_context_variants(client_id):
            raw_ms: int | None = None
            duration_ms: int | None = None
            try:
                raw_text = self.call("GetRawMediaTime", context=ctx)
                raw_ms = extract_first_int(raw_text)
            except Exception as exc:
                errors.append(f"GetRawMediaTime context={ctx or '(default)'}: {exc}")
                continue
            try:
                dur_text = self.call("GetMediaDuration", context=ctx)
                duration_ms = extract_first_int(dur_text)
            except Exception:
                duration_ms = None
            if raw_ms is not None and raw_ms >= 0:
                return raw_ms, duration_ms, f"SageX GetRawMediaTime context={ctx or '(default)'}"
            # Conservative fallback.  Only use GetMediaTime when it looks like a
            # file-relative time; absolute airing times are too large for FFmpeg -ss.
            try:
                media_text = self.call("GetMediaTime", context=ctx)
                media_ms = extract_first_int(media_text)
                max_without_duration = 24 * 60 * 60 * 1000
                if media_ms is not None and media_ms >= 0 and (
                    (duration_ms and media_ms <= max(duration_ms + 30000, duration_ms * 2))
                    or (not duration_ms and media_ms <= max_without_duration)
                ):
                    return media_ms, duration_ms, f"SageX GetMediaTime context={ctx or '(default)'}"
            except Exception as exc:
                errors.append(f"GetMediaTime context={ctx or '(default)'}: {exc}")
        return None, None, "; ".join(errors[-3:]) or "SageX timeline unavailable"


def sagex_lookup_current_media(base_url: str, username: str = "", password: str = "", client_id: str = "", push_url: str = "", timeout: float = 4.0) -> tuple[dict, str]:
    result = SageXClient(base_url, username, password, timeout).lookup_current_media(client_id=client_id, push_url=push_url)
    return result.detail, result.reason


def sagex_get_timeline(base_url: str, username: str = "", password: str = "", client_id: str = "", timeout: float = 3.0) -> tuple[int | None, int | None, str]:
    return SageXClient(base_url, username, password, timeout).get_timeline(client_id=client_id)
