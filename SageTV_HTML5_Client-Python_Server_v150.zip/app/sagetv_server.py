"""Shared SageTV server address helpers.

Only the MiniClient/UI connection is used here.  Native 42024 backend/database
lookup was intentionally removed in v110/v111; Web Interface lookup is used for
MediaFile detail instead.
"""
from __future__ import annotations

SAGETV_MINICLIENT_PORT = 31099


def normalize_server_host(value: str | None) -> str:
    """Return a SageTV host/IP only, stripping legacy ports and schemes."""
    text = str(value or "").strip()
    if not text:
        return ""
    if "://" in text:
        text = text.split("://", 1)[1]
    text = text.split("/", 1)[0].strip()
    # IPv6 bracket form [addr]:port.
    if text.startswith("[") and "]" in text:
        return text[1:text.index("]")].strip()
    # Legacy host:port entry. If the last segment is all digits, drop it.
    if text.count(":") == 1:
        host, port = text.rsplit(":", 1)
        if port.isdigit():
            return host.strip()
    return text


def parse_miniclient_server(value: str | None) -> tuple[str, int]:
    host = normalize_server_host(value) or "127.0.0.1"
    return host, SAGETV_MINICLIENT_PORT
