import asyncio
import os
import shutil
import signal
import subprocess
import time
import re
import urllib.parse
from dataclasses import dataclass, field
from collections import deque
from pathlib import Path
from typing import Optional


ROOT = Path(__file__).resolve().parent.parent
from .runtime_store import runtime_hls_root, hls_storage_config


def find_executable(name: str) -> Optional[str]:
    env_name = "FFMPEG" if name.lower().startswith("ffmpeg") else "FFPROBE"
    env_path = os.environ.get(env_name)
    if env_path and Path(env_path).exists():
        return env_path

    exe = f"{name}.exe" if os.name == "nt" and not name.endswith(".exe") else name
    candidates = [
        ROOT / "tools" / "ffmpeg" / "bin" / exe,
        ROOT / "tools" / "ffmpeg" / exe,
    ]
    for c in candidates:
        if c.exists():
            return str(c)

    # Common extracted gyan.dev layout: tools/ffmpeg/ffmpeg-*-essentials_build/bin/ffmpeg.exe
    for c in (ROOT / "tools" / "ffmpeg").glob("**/bin/" + exe):
        if c.exists():
            return str(c)

    found = shutil.which(name)
    return found




def scrub_ffmpeg_command_for_status(cmd: list[str]) -> str:
    """Return an FFmpeg command line safe enough for the browser debug box."""
    out: list[str] = []
    hide_next = False
    for token in cmd:
        if hide_next:
            out.append("[hidden]")
            hide_next = False
            continue
        if str(token) == "-headers":
            out.append(str(token))
            hide_next = True
            continue
        text = str(token)
        try:
            p = urllib.parse.urlsplit(text)
            if p.scheme in ("http", "https") and (p.username or p.password):
                host = p.hostname or ""
                if p.port:
                    host += f":{p.port}"
                text = urllib.parse.urlunsplit((p.scheme, host, p.path, p.query, p.fragment))
        except Exception:
            pass
        out.append(text)
    return " ".join(out)

def list_ffmpeg_encoders(ffmpeg: str) -> str:
    try:
        p = subprocess.run([ffmpeg, "-hide_banner", "-encoders"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=8)
        return p.stdout or ""
    except Exception:
        return ""


def normalize_encoder_name(requested: str) -> str:
    """Normalize browser/env encoder names.

    FFmpeg encoder names are lowercase.  This also lets users type common aliases
    such as h264_NVenc, nvenc, qsv, or nvidia.
    """
    enc = (requested or "auto").strip().lower().replace("-", "_")
    aliases = {
        "x264": "libx264",
        "software": "libx264",
        "intel": "h264_qsv",
        "qsv": "h264_qsv",
        "quick_sync": "h264_qsv",
        "quicksync": "h264_qsv",
        "nvidia": "h264_nvenc",
        "nvenc": "h264_nvenc",
        "h264_nvenc_safe": "h264_nvenc",
        "h264_nvenc_compat": "h264_nvenc",
        "nvenc_safe": "h264_nvenc",
        "nvenc_compat": "h264_nvenc",
        "nvenc_ll": "h264_nvenc_ll",
        "nvidia_ll": "h264_nvenc_ll",
        "h264_nvenc_bare": "h264_nvenc_bare",
        "nvenc_bare": "h264_nvenc_bare",
        "nvidia_bare": "h264_nvenc_bare",
        "h264_nvenc_cuda": "h264_nvenc_cuda",
        "nvenc_cuda": "h264_nvenc_cuda",
        "nvidia_cuda": "h264_nvenc_cuda",
        "amd": "h264_amf",
        "amf": "h264_amf",
    }
    return aliases.get(enc, enc or "auto")




def normalize_encoder_latency_mode(value: str) -> str:
    """Normalize UI/env encoder latency mode.

    normal keeps the encoder's conservative profile. faststart applies the
    lowest-latency options that are safe/relevant for each encoder family.
    """
    text = str(value or "faststart").strip().lower().replace("-", "_").replace(" ", "_")
    if text in ("fast", "faststart", "fast_start", "low", "lowlatency", "low_latency", "zero", "zerolatency", "zero_latency"):
        return "faststart"
    return "normal"


def normalize_qsv_decode_mode(value: str) -> str:
    """Normalize QSV hardware decode device mode.

    auto chooses a Windows D3D11VA QSV device on Windows, a Linux DRM render
    node when present, and otherwise leaves decode compatible/off.
    """
    text = str(value or "auto").strip().lower().replace("-", "_").replace(" ", "_")
    if text in ("off", "none", "false", "0", "software", "compatible", "compat"):
        return "off"
    if text in ("d3d11", "d3d11va", "windows", "win", "win_d3d11", "windows_d3d11"):
        return "d3d11va"
    if text in ("dxva2", "windows_dxva2", "win_dxva2"):
        return "dxva2"
    if text in ("linux", "linux_drm", "drm", "renderd128", "dev_dri"):
        return "linux_drm"
    return "auto"


def normalize_qsv_filter_mode(value: str) -> str:
    """Normalize Intel QSV filter mode for hardware decode/filter/encode."""
    text = str(value or "auto").strip().lower().replace("-", "_").replace(" ", "_")
    if text in ("off", "none", "software", "cpu", "compatible", "compat"):
        return "software"
    if text in ("scale", "scale_only", "no_deint", "no_deinterlace"):
        return "scale"
    if text in ("deint", "deinterlace", "deinterlace_scale", "deint_scale", "deinterlace_and_scale"):
        return "deint"
    return "auto"


def qsv_hw_device_args(mode: str) -> tuple[list[str], str]:
    """Return (args, effective_mode) for QSV hw decode.

    The Linux MITM script used /dev/dri/renderD128.  Windows needs a DirectX
    child device instead.  Auto is conservative on Linux and only enables DRM
    when the render node exists.
    """
    mode = normalize_qsv_decode_mode(mode)
    if mode == "off":
        return [], "off"
    if mode == "auto":
        if os.name == "nt":
            mode = "d3d11va"
        else:
            drm = os.environ.get("SAGEWEB_QSV_DRM_DEVICE", "/dev/dri/renderD128")
            mode = "linux_drm" if Path(drm).exists() else "off"
    if mode == "d3d11va":
        return [
            "-init_hw_device", "qsv=hw,child_device_type=d3d11va",
            "-hwaccel", "qsv",
            "-hwaccel_device", "hw",
            "-hwaccel_output_format", "qsv",
        ], "d3d11va"
    if mode == "dxva2":
        return [
            "-init_hw_device", "qsv=hw,child_device_type=dxva2",
            "-hwaccel", "qsv",
            "-hwaccel_device", "hw",
            "-hwaccel_output_format", "qsv",
        ], "dxva2"
    if mode == "linux_drm":
        drm = os.environ.get("SAGEWEB_QSV_DRM_DEVICE", "/dev/dri/renderD128")
        return [
            "-init_hw_device", f"qsv=hw:{drm}",
            "-hwaccel", "qsv",
            "-hwaccel_device", "hw",
            "-hwaccel_output_format", "qsv",
        ], "linux_drm"
    return [], "off"


def fps_to_output_arg(choice: str, *, qsv_source_guard: bool = False) -> str:
    """Return an FFmpeg -r value, or empty when source FPS should pass through."""
    choice = normalize_video_fps_choice(choice)
    if choice == "source":
        return "30000/1001" if qsv_source_guard else ""
    if choice == "30":
        # Broadcast MPEG-2 recordings are commonly 30000/1001. This avoids
        # QSV deinterlace accidentally doubling 59.94 to 119.88 fps while still
        # staying close to the user's 30 fps intent.
        return "30000/1001"
    if choice == "60":
        return "60000/1001"
    return choice


def fps_to_gop_value(output_fps: str, default: str = "60") -> str:
    """Use roughly one GOP per second so 1-second HLS startup cuts have keyframes."""
    try:
        if "/" in str(output_fps):
            a, b = str(output_fps).split("/", 1)
            return str(max(1, int(round(float(a) / float(b)))))
        if output_fps:
            return str(max(1, int(round(float(output_fps)))))
    except Exception:
        pass
    return str(default)


def qsv_width_for_height(height: int) -> int:
    """Return an even 16:9 width for QSV scale_qsv.

    scale_qsv is less forgiving than software scale on some FFmpeg builds, so
    avoid relying on scale=-2 style expressions in the hardware filter path.
    """
    h = int(height or 0)
    if h <= 0:
        return 0
    common = {240: 426, 360: 640, 480: 854, 576: 1024, 720: 1280, 1080: 1920}
    if h in common:
        return common[h]
    w = int(round(h * 16 / 9))
    return w if w % 2 == 0 else w + 1


def ffmpeg_encoder_name(encoder: str) -> str:
    enc = normalize_encoder_name(encoder)
    if enc in ("h264_nvenc_ll", "h264_nvenc_bare", "h264_nvenc_cuda"):
        return "h264_nvenc"
    return enc


def choose_encoder(ffmpeg: str, requested: str = "auto") -> str:
    requested_norm = normalize_encoder_name(requested)
    encoders = list_ffmpeg_encoders(ffmpeg)
    if requested_norm and requested_norm != "auto":
        actual = ffmpeg_encoder_name(requested_norm)
        # If the FFmpeg build clearly does not expose the requested hardware
        # encoder, fall back to x264 instead of starting a doomed FFmpeg process.
        if encoders and actual != "libx264" and actual not in encoders:
            return "libx264"
        return requested_norm
    # Keep auto conservative. libx264 is still the most compatible first choice
    # for this MiniClient pipeline. Hardware can be selected explicitly.
    for enc in ("libx264", "h264_qsv", "h264_nvenc", "h264_amf"):
        if not encoders or enc in encoders:
            return enc
    return "libx264"


def encoder_args(encoder: str, latency_mode: str = "faststart") -> list[str]:
    encoder = normalize_encoder_name(encoder)
    latency_mode = normalize_encoder_latency_mode(latency_mode)
    fast = latency_mode == "faststart"

    if encoder == "libx264":
        args = [
            "-c:v", "libx264",
            "-preset", os.environ.get("SAGEWEB_X264_PRESET", "ultrafast"),
            "-tune", os.environ.get("SAGEWEB_X264_TUNE", "zerolatency"),
            "-x264-params", os.environ.get("SAGEWEB_X264_PARAMS", "keyint=60:min-keyint=1:scenecut=0"),
            "-sc_threshold", "0",
        ]
        if fast:
            args += ["-bf", "0"]
        return args

    if encoder == "h264_nvenc":
        # Conservative NVIDIA path for workstation cards such as RTX A2000.
        # Fast Start / Low Latency uses the newer NVENC low-latency options.
        if fast:
            return [
                "-c:v", "h264_nvenc",
                "-preset", os.environ.get("SAGEWEB_NVENC_FAST_PRESET", "p1"),
                "-tune", os.environ.get("SAGEWEB_NVENC_FAST_TUNE", "ull"),
                "-zerolatency", "1",
                "-rc-lookahead", "0",
                "-forced-idr", "1",
                "-bf", "0",
            ]
        return [
            "-c:v", "h264_nvenc",
            "-preset", os.environ.get("SAGEWEB_NVENC_PRESET", "default"),
            "-bf", "0",
        ]

    if encoder == "h264_nvenc_bare":
        # Absolute minimum NVENC path.  Bare stays intentionally minimal even
        # in Fast Start mode so it can be used as a compatibility fallback.
        args = ["-c:v", "h264_nvenc"]
        if fast:
            args += ["-bf", "0"]
        return args

    if encoder == "h264_nvenc_cuda":
        # CPU decode/filter, then explicit CUDA upload before NVENC.  Useful on
        # systems where implicit upload fails with NVIDIA but QSV/x264 work.
        if fast:
            return [
                "-c:v", "h264_nvenc",
                "-preset", os.environ.get("SAGEWEB_NVENC_FAST_PRESET", "p1"),
                "-tune", os.environ.get("SAGEWEB_NVENC_FAST_TUNE", "ull"),
                "-zerolatency", "1",
                "-rc-lookahead", "0",
                "-forced-idr", "1",
                "-bf", "0",
            ]
        return [
            "-c:v", "h264_nvenc",
            "-preset", os.environ.get("SAGEWEB_NVENC_PRESET", "default"),
            "-bf", "0",
        ]

    if encoder == "h264_nvenc_ll":
        # Optional low-latency NVENC path. Fast Start uses the newer p1/ull
        # style; Normal keeps the older llhq path for driver compatibility.
        if fast:
            return [
                "-c:v", "h264_nvenc",
                "-preset", os.environ.get("SAGEWEB_NVENC_FAST_PRESET", "p1"),
                "-tune", os.environ.get("SAGEWEB_NVENC_FAST_TUNE", "ull"),
                "-zerolatency", "1",
                "-rc-lookahead", "0",
                "-forced-idr", "1",
                "-bf", "0",
            ]
        return [
            "-c:v", "h264_nvenc",
            "-preset", os.environ.get("SAGEWEB_NVENC_LL_PRESET", "llhq"),
            "-bf", "0",
        ]

    if encoder == "h264_qsv":
        # QSV low latency: disable lookahead, keep the async queue shallow, and
        # make forced keyframes clean IDR frames for HLS startup segments.
        args = ["-c:v", "h264_qsv", "-preset", os.environ.get("SAGEWEB_QSV_PRESET", "veryfast"), "-bf", "0"]
        if fast:
            args += [
                "-look_ahead", os.environ.get("SAGEWEB_QSV_LOOK_AHEAD", "0"),
                "-async_depth", os.environ.get("SAGEWEB_QSV_ASYNC_DEPTH", "1"),
                "-forced_idr", os.environ.get("SAGEWEB_QSV_FORCED_IDR", "1"),
            ]
        return args

    if encoder == "h264_amf":
        args = ["-c:v", "h264_amf", "-quality", os.environ.get("SAGEWEB_AMF_QUALITY", "speed"), "-bf", "0"]
        if fast:
            args += ["-usage", os.environ.get("SAGEWEB_AMF_USAGE", "ultralowlatency")]
        return args

    return ["-c:v", encoder]


def _bitrate_to_kbps(text: str) -> int:
    t = str(text or "").strip().lower()
    if not t:
        return 0
    try:
        if t.endswith("m"):
            return int(float(t[:-1]) * 1000)
        if t.endswith("k"):
            return int(float(t[:-1]))
        return int(float(t))
    except Exception:
        return 0


def _kbps_to_bitrate(kbps: int) -> str:
    kbps = max(100, int(kbps))
    return f"{kbps}k"




def audio_sync_filter(offset_ms: int) -> str:
    """Return an FFmpeg audio filter that keeps audio/video aligned.

    Positive values delay audio. Negative values advance audio by trimming the
    beginning. The aresample async value lets FFmpeg stretch/drop tiny amounts
    to follow the video clock instead of drifting on long MPEG-TS captures.
    """
    try:
        offset = int(offset_ms or 0)
    except Exception:
        offset = 0
    base = "aresample=async=1000:first_pts=0"
    if offset > 0:
        return f"{base},adelay={offset}|{offset},asetpts=PTS-STARTPTS"
    if offset < 0:
        sec = abs(offset) / 1000.0
        return f"{base},atrim=start={sec:.3f},asetpts=PTS-STARTPTS"
    return base

def source_bitrate_from_url(media_url: str) -> int:
    """Return source bitrate from SageTV push URL as kbps, if present."""
    m = re.search(r"(?:^|;)br=(\d+)", media_url or "", re.IGNORECASE)
    if not m:
        return 0
    # SageTV reports br in bits/second. FFmpeg wants kbits/second when using k suffix.
    return max(100, int(int(m.group(1)) / 1000))


def auto_bitrate_for_height(max_height: int, media_url: str = "") -> str:
    src = source_bitrate_from_url(media_url)
    h = int(max_height or 0)
    if h <= 0:
        return _kbps_to_bitrate(src or 3500)
    if h <= 240:
        return "500k"
    if h <= 360:
        return "900k"
    if h <= 480:
        return "1600k"
    if h <= 576:
        return "2200k"
    if h <= 720:
        return "3000k"
    if h <= 1080:
        # Do not exceed source bitrate by much when known.
        return _kbps_to_bitrate(min(max(src, 4500), 6500) if src else 6000)
    return _kbps_to_bitrate(src or 8000)


def resolve_video_bitrate(choice: str, max_height: int, media_url: str = "") -> str:
    c = str(choice or "source").strip().lower()
    if c in ("source", "src", "original", "native"):
        src = source_bitrate_from_url(media_url)
        return _kbps_to_bitrate(src) if src else auto_bitrate_for_height(max_height, media_url)
    if c in ("auto", "adaptive"):
        return auto_bitrate_for_height(max_height, media_url)
    if c.endswith(("k", "m")):
        return c
    try:
        int(c)
        return c + "k"
    except Exception:
        return auto_bitrate_for_height(max_height, media_url)




def normalize_video_fps_choice(value) -> str:
    """Normalize FPS setting. Return 'source' or an integer fps string."""
    text = str(value or "source").strip().lower()
    if text in ("", "source", "src", "original", "native", "0", "none", "auto"):
        return "source"
    text = text.rstrip("fps")
    try:
        n = int(float(text))
        # Keep the UI practical. Very high frame rates increase encode cost and
        # make fast-start keyframes more expensive.
        if n in (15, 20, 24, 25, 30, 50, 60):
            return str(n)
    except Exception:
        pass
    return "source"


def normalize_audio_bitrate_choice(value) -> str:
    text = str(value or "128k").strip().lower()
    if text in ("", "default", "auto"):
        return "128k"
    if text.endswith(("k", "m")):
        return text
    try:
        return f"{max(32, min(320, int(float(text))))}k"
    except Exception:
        return "128k"

def normalize_quality_ramp_mode(value: str) -> str:
    text = str(value or "off").strip().lower().replace("-", "_")
    if text in ("low", "startup_low", "start_low", "low_start", "ramp", "on", "true", "1"):
        return "low"
    if text in ("verylow", "very_low", "lowest", "start_verylow", "very_low_start"):
        return "verylow"
    return "off"


def quality_ramp_start_profile(mode: str) -> tuple[int, str]:
    mode = normalize_quality_ramp_mode(mode)
    if mode == "verylow":
        return 360, "900k"
    if mode == "low":
        return 480, "1600k"
    return 0, ""


def normalize_ffmpeg_buffer_preset(value: str) -> str:
    text = str(value or "faststart").strip().lower().replace("-", "_")
    if text in ("fast", "faststart", "fast_start", "startup", "low_latency", "lowlatency", "mitm"):
        return "faststart"
    if text in ("huge", "max", "maximum", "diagnostic"):
        return "huge"
    if text in ("large", "big", "more", "high"):
        return "large"
    return "normal"


def ffmpeg_buffer_profile(preset: str) -> dict:
    """Return FFmpeg queue/probe/VBV settings for visible RAM-buffer presets.

    These are not the browser buffer. They let FFmpeg allocate larger packet,
    probe, muxing, and encoder VBV queues so transient input/output hiccups are
    less likely to stall segment creation. Higher settings use more RAM and can
    add startup delay, especially with unknown inputs.
    """
    p = normalize_ffmpeg_buffer_preset(preset)
    if p == "faststart":
        vals = {
            "preset": "faststart",
            "thread_queue_size": 4096,
            "analyzeduration": 300000,
            "probesize": 300000,
            "mux_queue_size": 2048,
            "vbv_multiplier": 2.0,
            "fflags": "+genpts+nobuffer+flush_packets",
            "max_delay": 0,
        }
    elif p == "huge":
        vals = {
            "preset": "huge",
            "thread_queue_size": 32768,
            "analyzeduration": 30000000,
            "probesize": 67108864,
            "mux_queue_size": 8192,
            "vbv_multiplier": 8.0,
            "fflags": "+genpts+discardcorrupt",
            "max_delay": None,
        }
    elif p == "large":
        vals = {
            "preset": "large",
            "thread_queue_size": 16384,
            "analyzeduration": 10000000,
            "probesize": 16777216,
            "mux_queue_size": 4096,
            "vbv_multiplier": 4.0,
            "fflags": "+genpts+discardcorrupt",
            "max_delay": None,
        }
    else:
        vals = {
            "preset": "normal",
            "thread_queue_size": 4096,
            "analyzeduration": 2000000,
            "probesize": 2000000,
            "mux_queue_size": 2048,
            "vbv_multiplier": 2.0,
            "fflags": "+genpts+discardcorrupt",
            "max_delay": None,
        }

    # Env overrides are useful for testing without changing the UI.
    def env_int(name: str, default: int) -> int:
        try:
            return max(1, int(float(os.environ.get(name, default))))
        except Exception:
            return int(default)
    def env_float(name: str, default: float) -> float:
        try:
            return max(0.1, float(os.environ.get(name, default)))
        except Exception:
            return float(default)
    vals["thread_queue_size"] = env_int("SAGEWEB_FFMPEG_THREAD_QUEUE_SIZE", vals["thread_queue_size"])
    vals["analyzeduration"] = env_int("SAGEWEB_ANALYZE_DURATION", vals["analyzeduration"])
    vals["probesize"] = env_int("SAGEWEB_PROBE_SIZE", vals["probesize"])
    vals["mux_queue_size"] = env_int("SAGEWEB_MAX_MUXING_QUEUE_SIZE", vals["mux_queue_size"])
    vals["vbv_multiplier"] = env_float("SAGEWEB_VIDEO_BUFSIZE_MULT", vals["vbv_multiplier"])
    return vals


@dataclass
class VideoBridgeStatus:
    running: bool = False
    encoder: str = ""
    playlist_url: str = ""
    playlist_path: str = ""
    bytes_in: int = 0
    chunks_in: int = 0
    restarts: int = 0
    last_error: str = ""
    ffmpeg_log_tail: str = ""
    playlist_ready: bool = False
    segments: int = 0
    command_line: str = ""
    capture_path: str = ""
    exited_returncode: str = ""
    audio_enabled: bool = True
    audio_offset_ms: int = 0
    pts_mode: str = ""
    queued_chunks: int = 0
    queued_bytes_est: int = 0
    fallback_reason: str = ""
    ts_sync_state: str = ""
    ts_sync_bytes: int = 0
    requested_max_height: str = ""
    requested_bitrate: str = "source"
    effective_bitrate: str = ""
    video_fps: str = "source"
    audio_bitrate: str = "128k"
    encoder_latency_mode: str = "faststart"
    qsv_decode_mode: str = "auto"
    qsv_filter_mode: str = "auto"
    qsv_effective_decode_mode: str = "off"
    qsv_effective_filter_mode: str = "software"
    effective_output_fps: str = ""
    effective_gop: str = ""
    ffmpeg_input_flags: str = ""
    ffmpeg_max_delay: str = ""
    hls_mode: str = "stable"
    hls_delete_threshold: int = 24
    hls_time: float = 3.0
    hls_init_time: float = 1.0
    hls_start_segments: int = 0
    hlsjs_max_buffer_seconds: int = 180
    buffer_preset: str = "normal"
    capture_enabled: bool = False
    player_mode: str = "hls"
    backpressure_events: int = 0
    dropped_input_chunks: int = 0
    ffmpeg_elapsed_seconds: float = 0.0
    hls_seconds_produced: float = 0.0
    hls_fill_rate: float = 0.0
    latest_segment_age: float = 0.0
    latest_segment_name: str = ""
    hls_endlist: bool = False
    input_source: str = "push"
    direct_input_path: str = ""
    pull_url: str = ""
    direct_read_mode: str = "fast"
    input_seek_seconds: float = 0.0
    hls_storage_mode: str = "disk"
    hls_storage_path: str = ""
    hls_storage_note: str = ""
    hls_storage_is_ram: bool = False
    ffmpeg_buffer_preset: str = "normal"
    ffmpeg_thread_queue_size: int = 0
    ffmpeg_analyzeduration: int = 0
    ffmpeg_probesize: int = 0
    ffmpeg_mux_queue_size: int = 0
    video_bufsize: str = ""
    quality_ramp_mode: str = "off"
    quality_ramp_phase: str = "off"
    quality_ramp_threshold_seconds: int = 30
    quality_ramp_start_max_height: str = ""
    quality_ramp_start_bitrate: str = ""
    quality_ramp_target_max_height: str = ""
    quality_ramp_target_bitrate: str = ""

    def to_json(self) -> dict:
        return {
            "running": self.running,
            "encoder": self.encoder,
            "playlist_url": self.playlist_url,
            "playlist_path": self.playlist_path,
            "bytes_in": self.bytes_in,
            "chunks_in": self.chunks_in,
            "restarts": self.restarts,
            "last_error": self.last_error,
            "ffmpeg_log_tail": self.ffmpeg_log_tail[-2400:],
            "playlist_ready": self.playlist_ready,
            "segments": self.segments,
            "command_line": self.command_line[-2400:],
            "capture_path": self.capture_path,
            "exited_returncode": self.exited_returncode,
            "audio_enabled": self.audio_enabled,
            "audio_offset_ms": self.audio_offset_ms,
            "pts_mode": self.pts_mode,
            "queued_chunks": self.queued_chunks,
            "queued_bytes_est": self.queued_bytes_est,
            "fallback_reason": self.fallback_reason,
            "ts_sync_state": self.ts_sync_state,
            "ts_sync_bytes": self.ts_sync_bytes,
            "requested_max_height": self.requested_max_height,
            "requested_bitrate": self.requested_bitrate,
            "effective_bitrate": self.effective_bitrate,
            "video_fps": self.video_fps,
            "audio_bitrate": self.audio_bitrate,
            "encoder_latency_mode": self.encoder_latency_mode,
            "qsv_decode_mode": self.qsv_decode_mode,
            "qsv_filter_mode": self.qsv_filter_mode,
            "qsv_effective_decode_mode": self.qsv_effective_decode_mode,
            "qsv_effective_filter_mode": self.qsv_effective_filter_mode,
            "effective_output_fps": self.effective_output_fps,
            "effective_gop": self.effective_gop,
            "ffmpeg_input_flags": self.ffmpeg_input_flags,
            "ffmpeg_max_delay": self.ffmpeg_max_delay,
            "hls_mode": self.hls_mode,
            "hls_delete_threshold": self.hls_delete_threshold,
            "hls_time": self.hls_time,
            "hls_init_time": self.hls_init_time,
            "hls_start_segments": self.hls_start_segments,
            "hlsjs_max_buffer_seconds": self.hlsjs_max_buffer_seconds,
            "buffer_preset": self.buffer_preset,
            "capture_enabled": self.capture_enabled,
            "player_mode": self.player_mode,
            "backpressure_events": self.backpressure_events,
            "dropped_input_chunks": self.dropped_input_chunks,
            "ffmpeg_elapsed_seconds": self.ffmpeg_elapsed_seconds,
            "hls_seconds_produced": self.hls_seconds_produced,
            "hls_fill_rate": self.hls_fill_rate,
            "latest_segment_age": self.latest_segment_age,
            "latest_segment_name": self.latest_segment_name,
            "hls_endlist": self.hls_endlist,
            "input_source": self.input_source,
            "direct_input_path": self.direct_input_path,
            "pull_url": self.pull_url,
            "direct_read_mode": self.direct_read_mode,
            "input_seek_seconds": self.input_seek_seconds,
            "hls_storage_mode": self.hls_storage_mode,
            "hls_storage_path": self.hls_storage_path,
            "hls_storage_note": self.hls_storage_note,
            "hls_storage_is_ram": self.hls_storage_is_ram,
            "ffmpeg_buffer_preset": self.ffmpeg_buffer_preset,
            "ffmpeg_thread_queue_size": self.ffmpeg_thread_queue_size,
            "ffmpeg_analyzeduration": self.ffmpeg_analyzeduration,
            "ffmpeg_probesize": self.ffmpeg_probesize,
            "ffmpeg_mux_queue_size": self.ffmpeg_mux_queue_size,
            "video_bufsize": self.video_bufsize,
            "quality_ramp_mode": self.quality_ramp_mode,
            "quality_ramp_phase": self.quality_ramp_phase,
            "quality_ramp_threshold_seconds": self.quality_ramp_threshold_seconds,
            "quality_ramp_start_max_height": self.quality_ramp_start_max_height,
            "quality_ramp_start_bitrate": self.quality_ramp_start_bitrate,
            "quality_ramp_target_max_height": self.quality_ramp_target_max_height,
            "quality_ramp_target_bitrate": self.quality_ramp_target_bitrate,
        }


@dataclass
class FfmpegHlsBridge:
    session_id: str
    encoder_request: str = "libx264"
    max_height: int = 0
    video_bitrate: str = "source"
    video_fps: str = "source"
    audio_bitrate: str = "128k"
    encoder_latency_mode: str = "faststart"
    qsv_decode_mode: str = "auto"
    qsv_filter_mode: str = "auto"
    audio_offset_ms: int = 0
    hls_time: float = 3.0
    hls_init_time: float = 1.0
    hls_start_segments: int = 0
    hlsjs_max_buffer_seconds: int = 180
    buffer_preset: str = "normal"
    hls_list_size: int = 36
    hls_mode: str = "stable"
    hls_delete_threshold: int = 36
    capture_push_stream: bool = False
    player_mode: str = "hls"
    queue_size: int = 768
    # HLS cannot tolerate missing TS chunks.  By default v62 waits/backpressures
    # instead of dropping data when FFmpeg falls behind.
    hls_drop_on_full: bool = False
    startup_fallback_seconds: float = 16.0
    prebuffer_limit: int = 10 * 1024 * 1024
    video_only_mode: bool = False
    media_url: str = ""
    input_source: str = "push"  # push, pull, direct
    direct_input_path: str = ""
    http_input_headers: str = ""
    pull_url: str = ""
    direct_read_mode: str = "fast"
    input_seek_seconds: float = 0.0
    hls_storage_mode: str = "disk"
    hls_storage_path: str = ""
    hls_storage_note: str = ""
    hls_storage_is_ram: bool = False
    direct_read_realtime: bool = False
    segment_token: str = ""
    ffmpeg_started_monotonic: float = 0.0
    allow_internal_fallback: bool = True
    hls_storage_mode: str = "disk"
    hls_ram_root: str = ""
    ffmpeg_buffer_preset: str = "normal"
    quality_ramp_mode: str = "off"
    quality_ramp_threshold_seconds: int = 30
    quality_ramp_upgraded: bool = False
    status: VideoBridgeStatus = field(default_factory=VideoBridgeStatus)

    process: Optional[asyncio.subprocess.Process] = None
    writer_task: Optional[asyncio.Task] = None
    stderr_task: Optional[asyncio.Task] = None
    stdout_task: Optional[asyncio.Task] = None
    monitor_task: Optional[asyncio.Task] = None
    queue: Optional[asyncio.Queue] = None
    output_dir: Optional[Path] = None
    log_lines: list[str] = field(default_factory=list)
    prebuffer_chunks: deque = field(default_factory=deque)
    prebuffer_bytes: int = 0
    ts_started: bool = False
    ts_sync_buffer: bytes = b""
    restart_lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    capture_file = None

    @property
    def ffmpeg_path(self) -> str:
        ffmpeg = find_executable("ffmpeg")
        if not ffmpeg:
            raise FileNotFoundError("ffmpeg was not found. Put ffmpeg.exe in tools/ffmpeg/bin or set FFMPEG.")
        return ffmpeg



    def normalize_hls_mode(self) -> str:
        mode = str(self.hls_mode or os.environ.get("SAGEWEB_HLS_MODE", "rolling")).strip().lower()
        if mode in ("debug", "keep", "keep_all", "keepall"):
            return "debug"
        if mode in ("rolling", "delete", "delete_segments"):
            return "rolling"
        # v45 default: keep segments for the current playback session so hls.js
        # never has the active segment deleted underneath it. The whole session
        # folder is still removed on STOP/DEINIT/disconnect/new video.
        return "stable"


    def normalize_player_mode(self) -> str:
        mode = str(self.player_mode or os.environ.get("SAGEWEB_PLAYER_MODE", "hls")).strip().lower()
        # Removed ABR mode falls back to fixed HLS TS.
        if mode in ("hlsabr", "hls-abr", "hls_abr", "abr", "adaptive_hls", "adaptive"):
            return "hls"
        if mode in ("hlsfmp4", "hls-fmp4", "hls_fmp4", "cmaf"):
            return "hlsfmp4"
        if mode in ("videojsfmp4", "videojs-fmp4", "videojs_fmp4", "vjsfmp4", "vjs-fmp4", "video-js-fmp4"):
            return "videojsfmp4"
        if mode in ("videojs", "video-js", "vjs"):
            return "videojs"
        return "hls"

    def hls_uses_fmp4(self) -> bool:
        return self.normalize_player_mode() in ("hlsfmp4", "videojsfmp4")

    def hls_segment_ext(self) -> str:
        return ".m4s" if self.hls_uses_fmp4() else ".ts"

    def _update_hls_fill_metrics(self, segs: list[Path], playlist_text: str = ""):
        """Update visible buffer/fill metrics used by the browser debug panel."""
        now_wall = time.time()
        elapsed = 0.0
        if self.ffmpeg_started_monotonic:
            elapsed = max(0.0, time.monotonic() - self.ffmpeg_started_monotonic)
        try:
            seg_len = float(self.hls_time or self.status.hls_time or 0.0)
        except Exception:
            seg_len = 0.0
        durations: list[float] = []
        if playlist_text:
            for m in re.finditer(r"#EXTINF:([0-9.]+)", playlist_text):
                try:
                    durations.append(max(0.0, float(m.group(1))))
                except Exception:
                    pass
        # hls_init_time makes the first segments shorter than hls_time. Parse
        # EXTINF when available so the displayed fill rate reflects actual
        # playable seconds instead of assuming every segment is max length.
        produced = max(0.0, sum(durations) if durations else len(segs) * seg_len)
        latest_age = 0.0
        latest_name = ""
        if segs:
            try:
                latest = max(segs, key=lambda p: p.stat().st_mtime)
                latest_name = latest.name
                latest_age = max(0.0, now_wall - latest.stat().st_mtime)
            except Exception:
                latest_age = 0.0
                latest_name = segs[-1].name
        self.status.ffmpeg_elapsed_seconds = round(elapsed, 2)
        self.status.hls_seconds_produced = round(produced, 2)
        self.status.hls_fill_rate = round((produced / elapsed), 2) if elapsed > 0.5 and produced > 0 else 0.0
        self.status.latest_segment_age = round(latest_age, 2)
        self.status.latest_segment_name = latest_name
        if playlist_text:
            self.status.hls_endlist = "#EXT-X-ENDLIST" in playlist_text

    def refresh_ready_state(self) -> bool:
        if not self.output_dir:
            self.status.playlist_ready = False
            self.status.segments = 0
            return False
        playlist = self.output_dir / "stream.m3u8"
        # FFmpeg normally writes stream_m3u8.tmp and then renames it to
        # stream.m3u8.  On some Windows builds the final rename can lag or fail
        # while the app is polling the playlist.  Treat the temp playlist as a
        # readable snapshot so the browser does not wait forever even though
        # completed segments already exist.
        playlist_candidates = [
            playlist,
            self.output_dir / "stream_m3u8.tmp",
            self.output_dir / "stream.m3u8.tmp",
        ]
        segs = sorted(self.output_dir.glob("seg_*" + self.hls_segment_ext()))
        self.status.segments = len(segs)
        self._update_hls_fill_metrics(segs)
        ready = False
        for candidate in playlist_candidates:
            try:
                if not candidate.exists():
                    continue
                txt = candidate.read_text(encoding="utf-8", errors="replace")
                self._update_hls_fill_metrics(segs, txt)
                candidate_ready = "#EXTM3U" in txt and len(segs) > 0
                if self.hls_uses_fmp4():
                    # fMP4 HLS needs an init segment referenced by EXT-X-MAP.
                    candidate_ready = candidate_ready and "#EXT-X-MAP" in txt and (self.output_dir / "init.mp4").exists()
                if candidate_ready:
                    ready = True
                    # If FFmpeg has only left the temp playlist visible, publish
                    # a snapshot under the normal name used by the browser.
                    if candidate != playlist and not playlist.exists():
                        try:
                            playlist.write_text(txt, encoding="utf-8")
                        except Exception:
                            pass
                    break
            except Exception:
                continue
        self.status.playlist_ready = ready
        return ready

    def normalize_input_source(self) -> str:
        src = str(self.input_source or "push").strip().lower()
        if src in ("web", "webui", "web_interface", "webui_http", "http", "https"):
            return "web"
        if src in ("direct", "file", "smb", "nfs", "local"):
            return "direct"
        if src in ("pull", "stv"):
            return "pull"
        return "push"

    def input_target(self) -> str:
        if self.normalize_input_source() in ("direct", "web") and self.direct_input_path:
            return str(self.direct_input_path)
        return "pipe:0"

    def input_http_args(self) -> list[str]:
        target = self.input_target().lower()
        if self.normalize_input_source() == "web" and target.startswith(("http://", "https://")):
            hdrs = str(self.http_input_headers or "")
            return ["-headers", hdrs] if hdrs else []
        return []

    def input_seek_args(self) -> list[str]:
        if self.normalize_input_source() not in ("direct", "web"):
            return []
        args: list[str] = []
        try:
            ss = max(0.0, float(self.input_seek_seconds or 0.0))
        except Exception:
            ss = 0.0
        if ss > 0.050:
            args += ["-ss", f"{ss:.3f}"]
        # Direct File/SMB can either read at real time (-re) or fill the HLS
        # buffer as fast as FFmpeg can transcode. Fast fill is useful for normal
        # recordings because playback can start after a small Start Buffer while
        # FFmpeg continues creating future HLS segments ahead of the viewer.
        # Use realtime for live/in-progress recordings so FFmpeg does not race
        # to the current end of a growing file and stop.
        mode = os.environ.get("SAGEWEB_SOURCE_FILL_MODE", self.direct_read_mode or ("realtime" if self.direct_read_realtime else "fast")).strip().lower().replace("-", "_")
        if mode in ("realtime", "real_time", "live", "1x", "safe"):
            args += ["-re"]
        elif mode in ("auto", "adaptive", "live_auto", "auto_live", "burst", "fast_then_live", "catchup"):
            # Read quickly for an initial burst to build client/HLS buffer, then
            # pace the file input at real time so a growing Live TV file does not
            # get read to EOF and stop.  This is the FFmpeg equivalent of
            # "fast fill until close to live, then live fill" for Direct File/SMB.
            burst = os.environ.get("SAGEWEB_SOURCE_FILL_BURST_SECONDS", "60")
            args += ["-readrate", "1", "-readrate_initial_burst", str(burst)]
        return args

    def input_format_args(self) -> list[str]:
        forced = os.environ.get("SAGEWEB_INPUT_FORMAT", "").strip()
        if forced:
            return ["-f", forced]
        if self.normalize_input_source() == "direct":
            return []
        u = (self.media_url or "").upper()
        if "F=MPEG2-TS" in u or "F=MPEGTS" in u:
            return ["-f", "mpegts"]
        if "F=MPEG2-PS" in u or "F=MPEG1-PS" in u:
            return ["-f", "mpeg"]
        # Unknown or non-TS stream. Let FFmpeg probe instead of forcing MPEG-TS.
        return []

    def current_ffmpeg_buffer_profile(self) -> dict:
        return ffmpeg_buffer_profile(self.ffmpeg_buffer_preset)

    def ffmpeg_input_buffer_args(self, profile: Optional[dict] = None) -> list[str]:
        p = profile or self.current_ffmpeg_buffer_profile()
        return [
            "-thread_queue_size", str(int(p.get("thread_queue_size", 4096))),
            "-analyzeduration", str(int(p.get("analyzeduration", 2000000))),
            "-probesize", str(int(p.get("probesize", 2000000))),
        ]

    def ffmpeg_low_delay_input_args(self, profile: Optional[dict] = None) -> list[str]:
        p = profile or self.current_ffmpeg_buffer_profile()
        flags = str(os.environ.get("SAGEWEB_FFMPEG_FFLAGS", p.get("fflags", "+genpts+discardcorrupt")))
        args = ["-fflags", flags]
        max_delay = os.environ.get("SAGEWEB_MAX_DELAY")
        if max_delay is None:
            max_delay = p.get("max_delay", None)
        if max_delay is not None and str(max_delay) != "":
            args += ["-max_delay", str(max_delay)]
        return args


    def quality_ramp_enabled(self) -> bool:
        return normalize_quality_ramp_mode(self.quality_ramp_mode) != "off"

    def reset_quality_ramp(self):
        self.quality_ramp_upgraded = False

    def mark_quality_ramp_upgraded(self):
        self.quality_ramp_upgraded = True

    def active_quality_settings(self) -> tuple[int, str, str]:
        """Return (max_height, bitrate_choice, phase) for current FFmpeg start.

        HLS/FFmpeg cannot change bitrate inside a single one-variant stream.
        The practical ramp method is to start the local bridge at a lower encode
        profile, let the browser fill, then restart the local bridge at the
        selected quality without reconnecting SageTV.
        """
        mode = normalize_quality_ramp_mode(self.quality_ramp_mode)
        if mode == "off" or self.quality_ramp_upgraded:
            return int(self.max_height or 0), str(self.video_bitrate or "source"), ("target" if mode != "off" else "off")
        start_h, start_br = quality_ramp_start_profile(mode)
        target_h = int(self.max_height or 0)
        # Only scale down while ramping. If the user's target is already lower
        # than the ramp profile, keep the user's lower target but use the ramp
        # bitrate so startup is still light.
        active_h = start_h if target_h <= 0 else min(start_h, target_h)
        return int(active_h or 0), start_br, "startup-low"


    def build_command(self, ffmpeg: str, out_dir: Path, encoder: str) -> list[str]:
        player_mode = self.normalize_player_mode()
        playlist = out_dir / "stream.m3u8"
        hls_fmp4 = player_mode in ("hlsfmp4", "videojsfmp4")
        token = re.sub(r"[^A-Za-z0-9_-]", "", str(getattr(self, "segment_token", "") or int(time.time())))
        seg_pattern = out_dir / ((f"seg_{token}_%05d.m4s") if hls_fmp4 else (f"seg_{token}_%05d.ts"))
        active_max_height, active_bitrate_choice, ramp_phase = self.active_quality_settings()
        effective_bitrate = resolve_video_bitrate(active_bitrate_choice, active_max_height, self.media_url)
        br_kbps = _bitrate_to_kbps(effective_bitrate)
        ffbuf = self.current_ffmpeg_buffer_profile()
        input_buffer_args = self.ffmpeg_input_buffer_args(ffbuf)
        low_delay_input_args = self.ffmpeg_low_delay_input_args(ffbuf)
        mux_queue_size = str(int(ffbuf.get("mux_queue_size", 2048)))
        vbv_mult = float(ffbuf.get("vbv_multiplier", 2.0))
        maxrate = os.environ.get("SAGEWEB_VIDEO_MAXRATE") or _kbps_to_bitrate(int(br_kbps * 1.25) if br_kbps else 3600)
        bufsize = os.environ.get("SAGEWEB_VIDEO_BUFSIZE") or _kbps_to_bitrate(int(br_kbps * vbv_mult) if br_kbps else int(3000 * vbv_mult))
        self.status.requested_max_height = "source" if not active_max_height else str(active_max_height)
        self.status.requested_bitrate = str(active_bitrate_choice)
        self.status.effective_bitrate = effective_bitrate
        self.status.video_fps = normalize_video_fps_choice(self.video_fps)
        self.status.audio_bitrate = normalize_audio_bitrate_choice(self.audio_bitrate)
        self.status.encoder_latency_mode = normalize_encoder_latency_mode(self.encoder_latency_mode)
        self.status.qsv_decode_mode = normalize_qsv_decode_mode(self.qsv_decode_mode)
        self.status.qsv_filter_mode = normalize_qsv_filter_mode(self.qsv_filter_mode)
        self.status.ffmpeg_input_flags = str(ffbuf.get("fflags", ""))
        self.status.ffmpeg_max_delay = "" if ffbuf.get("max_delay", None) is None else str(ffbuf.get("max_delay"))
        self.status.quality_ramp_mode = normalize_quality_ramp_mode(self.quality_ramp_mode)
        self.status.quality_ramp_phase = ramp_phase
        self.status.quality_ramp_threshold_seconds = int(self.quality_ramp_threshold_seconds or 30)
        st_h, st_br = quality_ramp_start_profile(self.quality_ramp_mode)
        self.status.quality_ramp_start_max_height = str(st_h or "")
        self.status.quality_ramp_start_bitrate = st_br
        self.status.quality_ramp_target_max_height = "source" if not self.max_height else str(self.max_height)
        self.status.quality_ramp_target_bitrate = str(self.video_bitrate)
        self.status.audio_offset_ms = int(self.audio_offset_ms or 0)
        self.status.pts_mode = ""
        self.status.ffmpeg_buffer_preset = str(ffbuf.get("preset", "normal"))
        self.status.ffmpeg_thread_queue_size = int(ffbuf.get("thread_queue_size", 0))
        self.status.ffmpeg_analyzeduration = int(ffbuf.get("analyzeduration", 0))
        self.status.ffmpeg_probesize = int(ffbuf.get("probesize", 0))
        self.status.ffmpeg_mux_queue_size = int(ffbuf.get("mux_queue_size", 0))
        self.status.video_bufsize = bufsize

        filters: list[str] = []
        enc_norm = normalize_encoder_name(encoder)
        fps_choice = normalize_video_fps_choice(self.video_fps)

        qsv_decode_requested = normalize_qsv_decode_mode(self.qsv_decode_mode)
        qsv_filter_requested = normalize_qsv_filter_mode(self.qsv_filter_mode)
        qsv_decode_args: list[str] = []
        qsv_effective_decode = "off"
        qsv_effective_filter = "software"
        qsv_hw_filter = False
        # Software filter mode intentionally disables QSV hw decode because QSV
        # surfaces cannot pass through normal CPU filters without hwdownload.
        if enc_norm == "h264_qsv" and qsv_filter_requested != "software":
            qsv_decode_args, qsv_effective_decode = qsv_hw_device_args(qsv_decode_requested)
            qsv_hw_filter = bool(qsv_decode_args)

        output_r = ""
        if qsv_hw_filter:
            # Auto follows the successful Windows test path: keep frames in QSV,
            # deinterlace/scale on the GPU, then cap Source FPS to ~29.97 so
            # deinterlace_qsv does not double 59.94i to 119.88 fps.
            use_deint = qsv_filter_requested in ("auto", "deint")
            if use_deint:
                filters.append(os.environ.get("SAGEWEB_QSV_DEINTERLACE_FILTER", "deinterlace_qsv"))
                qsv_effective_filter = "deint"
            else:
                qsv_effective_filter = "scale"
            if active_max_height and active_max_height > 0:
                filters.append(f"scale_qsv=w={qsv_width_for_height(int(active_max_height))}:h={int(active_max_height)}")
            output_r = fps_to_output_arg(fps_choice, qsv_source_guard=use_deint)
        else:
            deint = os.environ.get("SAGEWEB_DEINTERLACE", "yadif=0:-1:0")
            if deint:
                filters.append(deint)
            # Source = preserve source frame rate. A fixed FPS drops frames before
            # encoding, reducing bandwidth/CPU and often improving startup on mobile.
            if fps_choice != "source":
                filters.append(f"fps={fps_choice}")
            if active_max_height and active_max_height > 0:
                filters.append(f"scale=-2:{int(active_max_height)}")
            if enc_norm == "h264_nvenc_cuda":
                filters.append("format=nv12")
                filters.append("hwupload_cuda")
            elif enc_norm.startswith("h264_nvenc") or enc_norm == "h264_qsv":
                filters.append("format=nv12")
            else:
                filters.append("format=yuv420p")
            output_r = fps_to_output_arg(fps_choice)

        vf = ["-vf", ",".join(f for f in filters if f)] if filters else []
        gop_default = fps_to_gop_value(output_r, os.environ.get("SAGEWEB_GOP", "60"))
        self.status.qsv_effective_decode_mode = qsv_effective_decode
        self.status.qsv_effective_filter_mode = qsv_effective_filter
        self.status.effective_output_fps = output_r or "source"
        self.status.effective_gop = str(os.environ.get("SAGEWEB_GOP", gop_default))

        audio_enabled = not self.video_only_mode
        cmd = [
            ffmpeg,
            "-hide_banner",
            "-loglevel", os.environ.get("SAGEWEB_FFMPEG_LOGLEVEL", "info"),
            "-nostats",
            "-y",
            *qsv_decode_args,
            *low_delay_input_args,
            "-err_detect", "ignore_err",
            *input_buffer_args,
            *self.input_seek_args(),
            *self.input_format_args(),
            *self.input_http_args(),
            "-i", self.input_target(),
            "-map", "0:v:0",
        ]
        if audio_enabled:
            cmd += ["-map", "0:a:0?"]
        cmd += ["-sn", "-dn", *vf]
        if output_r:
            cmd += ["-fps_mode", os.environ.get("SAGEWEB_HLS_FPS_MODE", "cfr"), "-r", output_r]
        cmd += [*encoder_args(encoder, self.encoder_latency_mode)]

        cmd += [
            "-g", os.environ.get("SAGEWEB_GOP", gop_default),
            "-keyint_min", os.environ.get("SAGEWEB_KEYINT_MIN", "1"),
            "-sc_threshold", "0",
            "-b:v", effective_bitrate,
            "-maxrate", maxrate,
            "-bufsize", bufsize,
        ]
        if audio_enabled:
            cmd += [
                "-af", audio_sync_filter(self.audio_offset_ms),
                "-c:a", "aac",
                "-ar", "48000",
                "-b:a", normalize_audio_bitrate_choice(self.audio_bitrate),
                "-ac", "2",
            ]
        else:
            cmd += ["-an"]

        cmd += [
            "-max_muxing_queue_size", mux_queue_size,
            "-muxdelay", "0",
            "-muxpreload", "0",
            "-flush_packets", "1",
        ]

        hls_time = str(os.environ.get("SAGEWEB_HLS_TIME", str(self.hls_time)))
        try:
            hls_time_float = max(0.25, float(hls_time))
        except Exception:
            hls_time_float = max(0.25, float(self.hls_time or 3.0))
        try:
            hls_init_time_float = max(0.0, float(os.environ.get("SAGEWEB_HLS_INIT_TIME", str(self.hls_init_time))))
        except Exception:
            hls_init_time_float = 1.0
        hls_init_time_float = min(hls_time_float, hls_init_time_float) if hls_init_time_float > 0 else 0.0
        self.status.hls_time = hls_time_float
        self.status.hls_init_time = hls_init_time_float
        cmd += [
            "-avoid_negative_ts", "make_zero",
        ]
        # Fast start: cut the initial HLS playlist at 1-second segments, then
        # let FFmpeg grow to the selected max segment length. Segments still need
        # keyframes, so force keyframes at the startup segment cadence.
        if os.environ.get("SAGEWEB_HLS_FORCE_KEYFRAMES", "1").lower() in ("1", "true", "yes", "on"):
            try:
                keyframe_time = hls_init_time_float if hls_init_time_float > 0 else hls_time_float
                cmd += ["-force_key_frames", f"expr:gte(t,n_forced*{keyframe_time:g})"]
            except Exception:
                pass
        cmd += [
            "-f", "hls",
            "-hls_time", f"{hls_time_float:g}",
        ]
        if hls_init_time_float > 0 and hls_init_time_float < hls_time_float:
            cmd += ["-hls_init_time", f"{hls_init_time_float:g}"]
        cmd += [
            "-hls_segment_type", "fmp4" if hls_fmp4 else "mpegts",
        ]
        if hls_fmp4:
            cmd += [
                "-hls_fmp4_init_filename", os.environ.get("SAGEWEB_HLS_FMP4_INIT", "init.mp4"),
                "-hls_fmp4_init_resend", os.environ.get("SAGEWEB_HLS_FMP4_INIT_RESEND", "1"),
            ]

        mode = self.normalize_hls_mode()
        # temp_file makes FFmpeg publish segments atomically so the browser does
        # not fetch a half-written .ts/.m4s file.  Direct file playback is finite,
        # so let FFmpeg write #EXT-X-ENDLIST at EOF. PUSH/PULL are live-like and
        # keep omit_endlist.
        live_like = self.normalize_input_source() != "direct"
        base_flags = "append_list+independent_segments+temp_file"
        if live_like:
            base_flags += "+omit_endlist"
        if mode == "debug":
            cmd += [
                "-hls_list_size", "0",
                "-hls_playlist_type", "event",
                "-hls_flags", os.environ.get("SAGEWEB_HLS_FLAGS", base_flags),
            ]
        elif mode == "stable":
            cmd += [
                "-hls_list_size", "0",
                "-hls_playlist_type", "event",
                "-hls_flags", os.environ.get("SAGEWEB_HLS_FLAGS", base_flags),
            ]
        else:
            list_size = int(os.environ.get("SAGEWEB_HLS_LIST_SIZE", str(self.hls_list_size or 36)))
            delete_threshold = int(os.environ.get("SAGEWEB_HLS_DELETE_THRESHOLD", str(self.hls_delete_threshold or 36)))
            rolling_flags = "delete_segments+independent_segments+temp_file"
            if live_like:
                rolling_flags += "+omit_endlist"
            cmd += [
                "-hls_list_size", str(max(12, list_size)),
                "-hls_delete_threshold", str(max(6, delete_threshold)),
                "-hls_flags", os.environ.get("SAGEWEB_HLS_FLAGS", rolling_flags),
            ]

        cmd += [
            "-hls_segment_filename", str(seg_pattern),
            str(playlist),
        ]
        return cmd

    def _append_prebuffer(self, data: bytes):
        if not data:
            return
        self.prebuffer_chunks.append(data)
        self.prebuffer_bytes += len(data)
        while self.prebuffer_bytes > self.prebuffer_limit and self.prebuffer_chunks:
            old = self.prebuffer_chunks.popleft()
            self.prebuffer_bytes -= len(old)

    def _prebuffer_blob(self) -> bytes:
        if not self.prebuffer_chunks:
            return b""
        return b"".join(self.prebuffer_chunks)

    async def start(self, encoder_override: Optional[str] = None, refeed_prebuffer: bool = False, reason: str = "") -> str:
        async with self.restart_lock:
            await self.stop(remove_files=True, keep_prebuffer=True)
            storage = hls_storage_config(self.hls_storage_mode, self.hls_ram_root)
            self.output_dir = Path(storage["root"]) / self.session_id
            self.output_dir.mkdir(parents=True, exist_ok=True)
            ffmpeg = self.ffmpeg_path
            encoder = encoder_override or choose_encoder(ffmpeg, self.encoder_request)
            # Unique segment names prevent the browser from requesting stale
            # seg_00000 files after a seek/restart/recovery cycle.
            self.segment_token = str(int(time.time() * 1000))
            self.ffmpeg_started_monotonic = time.monotonic()
            cmd = self.build_command(ffmpeg, self.output_dir, encoder)
            self.log_lines.clear()
            self.ts_started = False
            self.ts_sync_buffer = b""
            player_mode = self.normalize_player_mode()
            input_source = self.normalize_input_source()
            use_stdin = input_source != "direct"
            # HLS TS/fMP4 is damaged by dropped input chunks. Give FFmpeg a large
            # queue and then use TCP backpressure instead of intentionally skipping
            # SageTV PUSHBUFFER data.
            q_size = max(self.queue_size, int(os.environ.get("SAGEWEB_HLS_INPUT_QUEUE_SIZE", "8192")))
            self.hls_drop_on_full = os.environ.get("SAGEWEB_HLS_DROP_ON_FULL", "1" if self.hls_drop_on_full else "0").lower() in ("1", "true", "yes", "on")
            self.queue = asyncio.Queue(maxsize=q_size) if use_stdin else None
            rev = int(time.time() * 1000)
            stream_url = f"/hls/{self.session_id}/stream.m3u8?rev={rev}"
            ffbuf = self.current_ffmpeg_buffer_profile()
            active_max_height_for_status, active_bitrate_choice_for_status, ramp_phase_for_status = self.active_quality_settings()
            effective_bitrate_for_status = resolve_video_bitrate(active_bitrate_choice_for_status, active_max_height_for_status, self.media_url)
            br_kbps_for_status = _bitrate_to_kbps(effective_bitrate_for_status)
            vbv_mult_for_status = float(ffbuf.get("vbv_multiplier", 2.0))
            bufsize = os.environ.get("SAGEWEB_VIDEO_BUFSIZE") or _kbps_to_bitrate(int(br_kbps_for_status * vbv_mult_for_status) if br_kbps_for_status else int(3000 * vbv_mult_for_status))
            self.status = VideoBridgeStatus(
                running=True,
                encoder=encoder,
                playlist_url=stream_url,
                playlist_path=str(self.output_dir / "stream.m3u8"),
                restarts=self.status.restarts + 1,
                command_line=scrub_ffmpeg_command_for_status(cmd),
                fallback_reason=reason,
                capture_path=str(self.output_dir / "push_capture.ts"),
                audio_enabled=not self.video_only_mode,
                audio_offset_ms=int(self.audio_offset_ms or 0),
                pts_mode="",
                requested_max_height="source" if not active_max_height_for_status else str(active_max_height_for_status),
                requested_bitrate=str(active_bitrate_choice_for_status),
                effective_bitrate=effective_bitrate_for_status,
                video_fps=normalize_video_fps_choice(self.video_fps),
                audio_bitrate=normalize_audio_bitrate_choice(self.audio_bitrate),
                quality_ramp_mode=normalize_quality_ramp_mode(self.quality_ramp_mode),
                quality_ramp_phase=ramp_phase_for_status,
                quality_ramp_threshold_seconds=int(self.quality_ramp_threshold_seconds or 30),
                quality_ramp_start_max_height=str(quality_ramp_start_profile(self.quality_ramp_mode)[0] or ""),
                quality_ramp_start_bitrate=quality_ramp_start_profile(self.quality_ramp_mode)[1],
                quality_ramp_target_max_height="source" if not self.max_height else str(self.max_height),
                quality_ramp_target_bitrate=str(self.video_bitrate),
                hls_mode=self.normalize_hls_mode(),
                hls_delete_threshold=int(os.environ.get("SAGEWEB_HLS_DELETE_THRESHOLD", str(self.hls_delete_threshold or 24))),
                hls_time=float(self.hls_time or 3.0),
                hls_init_time=float(self.hls_init_time or 0.0),
                hls_start_segments=int(self.hls_start_segments or 0),
                hlsjs_max_buffer_seconds=int(self.hlsjs_max_buffer_seconds or 180),
                buffer_preset=str(self.buffer_preset or "normal"),
                capture_enabled=bool(self.capture_push_stream or self.normalize_hls_mode() == "debug" or os.environ.get("SAGEWEB_CAPTURE_PUSH", "0").lower() in ("1", "true", "yes", "on")),
                player_mode=player_mode,
                playlist_ready=False,
                backpressure_events=self.status.backpressure_events,
                dropped_input_chunks=self.status.dropped_input_chunks,
                ffmpeg_elapsed_seconds=0.0,
                hls_seconds_produced=0.0,
                hls_fill_rate=0.0,
                latest_segment_age=0.0,
                latest_segment_name="",
                hls_endlist=False,
                input_source=input_source,
                direct_input_path=str(self.direct_input_path or ""),
                pull_url=str(self.pull_url or ""),
                direct_read_mode=("push-live" if input_source == "push" else str(self.direct_read_mode or ("realtime" if self.direct_read_realtime else "fast"))),
                input_seek_seconds=float(self.input_seek_seconds or 0.0),
                hls_storage_mode=str(storage.get("mode") or "disk"),
                hls_storage_path=str(storage.get("path") or self.output_dir.parent),
                hls_storage_note=str(storage.get("note") or ""),
                hls_storage_is_ram=bool(storage.get("is_ram")),
                ffmpeg_buffer_preset=str(ffbuf.get("preset", "normal")),
                ffmpeg_thread_queue_size=int(ffbuf.get("thread_queue_size", 0)),
                ffmpeg_analyzeduration=int(ffbuf.get("analyzeduration", 0)),
                ffmpeg_probesize=int(ffbuf.get("probesize", 0)),
                ffmpeg_mux_queue_size=int(ffbuf.get("mux_queue_size", 0)),
                video_bufsize=bufsize,
            )
            creationflags = 0
            if os.name == "nt":
                creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            # Run FFmpeg from the per-session HLS folder.  This matters for
            # fMP4 HLS because FFmpeg treats -hls_fmp4_init_filename as a
            # relative output name.  Without this, init.mp4 is written to the
            # app working directory while the browser requests
            # /hls/<session>/init.mp4, so readiness never becomes true.
            self.process = await asyncio.create_subprocess_exec(
                *cmd,
                stdin=(asyncio.subprocess.PIPE if use_stdin else asyncio.subprocess.DEVNULL),
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.PIPE,
                creationflags=creationflags,
                cwd=str(self.output_dir),
            )
            self.writer_task = asyncio.create_task(self._writer_loop(), name=f"ffmpeg-writer-{self.session_id}") if use_stdin else None
            self.stderr_task = asyncio.create_task(self._stderr_loop(), name=f"ffmpeg-stderr-{self.session_id}")
            self.stdout_task = None
            self.monitor_task = asyncio.create_task(self._startup_monitor_loop(), name=f"ffmpeg-monitor-{self.session_id}")
            if refeed_prebuffer:
                blob = self._prebuffer_blob()
                if blob:
                    try:
                        # Schedule the aligned prebuffer feed outside the lock so startup cannot deadlock.
                        asyncio.create_task(self.write(blob), name=f"ffmpeg-refeed-{self.session_id}")
                        self.status.fallback_reason = (reason + f"; queued {len(blob)} bytes of SageTV TS prebuffer for aligned re-feed").strip("; ")
                    except Exception as exc:
                        self.status.last_error = f"could not queue prebuffer after restart: {exc}"
            return self.status.playlist_url

    async def stop(self, remove_files: bool = False, keep_prebuffer: bool = False):
        if self.queue:
            try:
                self.queue.put_nowait(None)
            except Exception:
                pass
        current = asyncio.current_task()
        for task in (self.writer_task, self.stderr_task, self.stdout_task, self.monitor_task):
            # Important: startup monitor can call start()->stop() to fall back from
            # a stalled hardware encoder.  Do not cancel the task that is currently
            # performing the fallback or the fallback never completes.
            if task and task is not current and not task.done():
                task.cancel()
        self.writer_task = None
        self.stderr_task = None
        self.stdout_task = None
        self.monitor_task = None
        if self.process:
            try:
                if self.process.stdin:
                    self.process.stdin.close()
            except Exception:
                pass
            if self.process.returncode is None:
                try:
                    self.process.terminate()
                    await asyncio.wait_for(self.process.wait(), timeout=2.5)
                except Exception:
                    try:
                        self.process.kill()
                        await self.process.wait()
                    except Exception:
                        pass
            if self.process and self.process.returncode is not None:
                self.status.exited_returncode = str(self.process.returncode)
            self.process = None
        self.queue = None
        self.status.running = False
        self.status.queued_chunks = 0
        self.status.queued_bytes_est = 0
        if remove_files and self.output_dir and self.output_dir.exists():
            shutil.rmtree(self.output_dir, ignore_errors=True)
            self.status.playlist_ready = False
            self.status.segments = 0
            self.status.playlist_url = ""
            self.status.playlist_path = ""
        if not keep_prebuffer:
            self.prebuffer_chunks.clear()
            self.prebuffer_bytes = 0
            self.ts_started = False
            self.ts_sync_buffer = b""
            self.status.ts_sync_state = ""
            self.status.ts_sync_bytes = 0

    async def restart(self) -> str:
        # A SageTV FLUSH/seek means the transport stream continuity changes. Keep a
        # short prebuffer until new data arrives, but restart FFmpeg from clean HLS files.
        return await self.start()

    async def restart_with_current_settings(self, reason: str = "settings changed") -> str:
        """Restart the current FFmpeg/browser stream without asking SageTV to stop playback."""
        return await self.start(refeed_prebuffer=True, reason=reason)

    async def _restart_with_fallback(self, reason: str):
        """Always fall back to libx264 when a hardware encoder stalls.

        v30-v32 only fell back when Encoder was set to auto.  In real testing the
        browser dropdown can still be on h264_nvenc from a prior run, so FFmpeg
        kept reading SageTV data but never produced HLS segments.  For now the
        safe behavior is: any non-libx264 encoder that fails to create the first
        segment gets restarted with libx264 and the rolling TS prebuffer is
        re-fed.  Once the software path is stable we can re-enable optional
        hardware-only testing.
        """
        if not self.allow_internal_fallback:
            self.status.last_error = reason + "; strict mode is active, keeping current FFmpeg process for diagnostics"
            return
        if self.status.encoder == "libx264":
            self.status.last_error = reason + "; already using libx264, keeping current process for diagnostics"
            return
        await self.start(encoder_override="libx264", refeed_prebuffer=True, reason=reason + "; automatic safe fallback to libx264")

    def _find_mpegts_sync(self, data: bytes) -> int:
        """Return offset of a likely 188-byte MPEG-TS sync pattern, or -1."""
        max_scan = min(len(data), 188 * 12)
        for off in range(max_scan):
            good = 0
            pos = off
            while pos < len(data) and good < 5:
                if data[pos] != 0x47:
                    break
                good += 1
                pos += 188
            if good >= 3:
                return off
        return -1

    def _align_to_mpegts_sync(self, data: bytes) -> bytes:
        """Drop leading bytes until a TS packet sync boundary is found.

        SageTV PUSHBUFFER can begin in the middle of a TS packet after a seek or
        client reconnect. FFmpeg can usually recover, but starting FFmpeg on a
        clean 0x47/188-byte boundary makes first segment creation much more
        reliable and reduces the repeated 'Invalid frame dimensions 0x0' startup
        noise.
        """
        if self.ts_started:
            return data
        if not data:
            return b""
        self.ts_sync_buffer += data
        # Keep a bounded startup buffer while looking for sync.
        if len(self.ts_sync_buffer) > 2 * 1024 * 1024:
            self.ts_sync_buffer = self.ts_sync_buffer[-1024 * 1024:]
        self.status.ts_sync_bytes = len(self.ts_sync_buffer)
        off = self._find_mpegts_sync(self.ts_sync_buffer)
        if off < 0:
            self.status.ts_sync_state = f"waiting for MPEG-TS sync ({len(self.ts_sync_buffer)} bytes)"
            return b""
        out = self.ts_sync_buffer[off:]
        self.ts_started = True
        self.status.ts_sync_state = f"MPEG-TS sync found at offset {off}; feeding aligned stream"
        self.ts_sync_buffer = b""
        return out

    async def write(self, data: bytes):
        if not data:
            return
        self._append_prebuffer(data)

        aligned = self._align_to_mpegts_sync(data)
        if not aligned:
            return

        # v37: raw SageTV PUSH capture is useful for diagnostics but it grows
        # very quickly. Keep it only in Debug/keep-all mode or when explicitly
        # enabled by SAGEWEB_CAPTURE_PUSH=1.
        capture_enabled = bool(self.capture_push_stream or self.normalize_hls_mode() == "debug" or os.environ.get("SAGEWEB_CAPTURE_PUSH", "0").lower() in ("1", "true", "yes", "on"))
        self.status.capture_enabled = capture_enabled
        if capture_enabled:
            try:
                if self.output_dir:
                    self.output_dir.mkdir(parents=True, exist_ok=True)
                    with open(self.output_dir / "push_capture.ts", "ab") as f:
                        f.write(aligned)
                    self.status.capture_path = str(self.output_dir / "push_capture.ts")
            except Exception as exc:
                self.status.last_error = f"could not write push_capture.ts: {exc}"
        else:
            self.status.capture_path = ""

        if not self.process or self.process.returncode is not None:
            await self.start(refeed_prebuffer=False, reason="FFmpeg was not running; started after MPEG-TS sync")
        if not self.queue:
            return
        self.status.bytes_in += len(aligned)
        self.status.chunks_in += 1
        if self.status.chunks_in % 10 == 0:
            self.refresh_ready_state()
        self.status.queued_chunks = self.queue.qsize()
        self.status.queued_bytes_est = self.queue.qsize() * 32768
        try:
            self.queue.put_nowait(aligned)
        except asyncio.QueueFull:
            # HLS cannot tolerate skipped MPEG-TS/PULL chunks.  v62 waits by
            # default instead of dropping; dropping even one input chunk can create
            # the corrupt HLS segments that Video.js reports as "media could not be loaded".
            if not self.hls_drop_on_full:
                self.status.backpressure_events += 1
                self.status.last_error = "HLS backpressure: FFmpeg input queue full; waiting instead of dropping video data"
                await self.queue.put(aligned)
                if self.queue:
                    self.status.queued_chunks = self.queue.qsize()
                    self.status.queued_bytes_est = self.queue.qsize() * 32768
                return
            # Optional old behavior, only if SAGEWEB_HLS_DROP_ON_FULL is enabled later.
            self.status.dropped_input_chunks += 1
            self.status.last_error = "FFmpeg input queue full; dropped oldest chunk to keep SageTV responsive"
            try:
                _ = self.queue.get_nowait()
            except Exception:
                pass
            try:
                self.queue.put_nowait(aligned)
            except Exception:
                pass
            if not self.status.playlist_ready:
                asyncio.create_task(self._restart_with_fallback("FFmpeg input queue filled before HLS was ready"))

    async def _writer_loop(self):
        assert self.process is not None
        try:
            while True:
                item = await self.queue.get()
                if item is None:
                    break
                if not self.process or not self.process.stdin or self.process.returncode is not None:
                    break
                self.process.stdin.write(item)
                await self.process.stdin.drain()
                if self.queue:
                    self.status.queued_chunks = self.queue.qsize()
                    self.status.queued_bytes_est = self.queue.qsize() * 32768
        except asyncio.CancelledError:
            pass
        except Exception as exc:
            self.status.last_error = f"FFmpeg stdin error: {exc}"
        finally:
            try:
                if self.process and self.process.stdin:
                    self.process.stdin.close()
            except Exception:
                pass

    async def _stderr_loop(self):
        assert self.process is not None
        try:
            while self.process and self.process.stderr:
                line = await self.process.stderr.readline()
                if not line:
                    break
                text = line.decode("utf-8", errors="replace").rstrip()
                if text:
                    self.log_lines.append(text)
                    if len(self.log_lines) > 90:
                        self.log_lines = self.log_lines[-90:]
                    self.status.ffmpeg_log_tail = "\n".join(self.log_lines[-45:])
                    self.refresh_ready_state()
            if self.process:
                rc = await self.process.wait()
                self.status.running = False
                if rc not in (0, None):
                    self.status.last_error = f"FFmpeg exited with code {rc}"
                    if not self.status.playlist_ready:
                        await self._restart_with_fallback(f"FFmpeg exited before HLS was ready, rc={rc}")
        except asyncio.CancelledError:
            pass
        except Exception as exc:
            self.status.last_error = f"FFmpeg stderr error: {exc}"

    async def _startup_monitor_loop(self):
        try:
            started = time.monotonic()
            while True:
                await asyncio.sleep(1.0)
                self.refresh_ready_state()
                if self.status.playlist_ready:
                    return
                if not self.process or self.process.returncode is not None:
                    return
                age = time.monotonic() - started
                # If hardware encoder initialization/drain stalls, FFmpeg can read a
                # little input, print stream mapping, but never produce a segment. In
                # auto mode restart with libx264 using the rolling SageTV TS prebuffer.
                if age >= self.startup_fallback_seconds and self.status.encoder != "libx264":
                    await self._restart_with_fallback(
                        f"No HLS segment after {int(age)}s with {self.status.encoder}"
                    )
                    return
                if age >= (self.startup_fallback_seconds + 8) and self.status.encoder == "libx264" and not self.video_only_mode and self.status.bytes_in > 1024 * 1024 and self.allow_internal_fallback:
                    # If video+audio does not segment, try video-only. This isolates
                    # AC3/AAC interleave issues and at least proves the MPEG-2 video
                    # decode/encode/HLS path. Audio can be re-enabled after video is stable.
                    self.video_only_mode = True
                    await self.start(encoder_override="libx264", refeed_prebuffer=True, reason=f"No HLS segment after {int(age)}s with audio; retrying video-only")
                    return
        except asyncio.CancelledError:
            pass
        except Exception as exc:
            self.status.last_error = f"startup monitor error: {exc}"

def parse_stv_url(url: str) -> tuple[str, str]:
    """Return (host, path) for SageTV stv://host/path URLs.

    The Java MiniClient SimplePullDataSource connects to host:7818 and sends
    OPEN <path>.  For URLs like stv://server//var/media/file.ts the path sent
    to SageTV intentionally begins with /var/...
    """
    if not url.lower().startswith("stv://"):
        raise ValueError(f"not an stv:// URL: {url}")
    rest = url[6:]
    slash = rest.find("/")
    if slash < 0:
        raise ValueError(f"stv:// URL is missing path: {url}")
    host = rest[:slash]
    path = rest[slash + 1:]
    if not host:
        raise ValueError(f"stv:// URL is missing host: {url}")
    return host, path


async def _read_sage_line(reader: asyncio.StreamReader, timeout: float = 8.0) -> str:
    data = await asyncio.wait_for(reader.readline(), timeout=timeout)
    return data.decode("latin-1", errors="replace").strip()


async def _send_sage_line(writer: asyncio.StreamWriter, line: str):
    writer.write((line + "\r\n").encode("latin-1", errors="replace"))
    await writer.drain()


@dataclass
class SagePullStreamPump:
    """Small Python port of SimplePullDataSource for stv:// input.

    Fast mode lets the Python side READ ahead as quickly as FFmpeg can accept
    data, which can build HLS segments ahead of playback for already-recorded
    files. Realtime mode lightly paces READ requests for live/in-progress files
    so we do not race to the current end of SageTV's growing file.
    """

    url: str
    bridge: FfmpegHlsBridge
    chunk_size: int = 256 * 1024
    start_offset: int = 0
    mode: str = "fast"
    realtime_bytes_per_sec: int = int(os.environ.get("SAGEWEB_PULL_REALTIME_BYTES_PER_SEC", "2500000"))
    burst_seconds: float = float(os.environ.get("SAGEWEB_SOURCE_FILL_BURST_SECONDS", "60"))
    live_no_growth_timeout: float = float(os.environ.get("SAGEWEB_PULL_AUTO_NO_GROWTH_TIMEOUT", "12"))
    task: Optional[asyncio.Task] = None
    bytes_read: int = 0
    last_error: str = ""

    async def run(self):
        reader: Optional[asyncio.StreamReader] = None
        writer: Optional[asyncio.StreamWriter] = None
        try:
            host, path = parse_stv_url(self.url)
            reader, writer = await asyncio.wait_for(asyncio.open_connection(host, 7818), timeout=8.0)
            await _send_sage_line(writer, "OPEN " + path)
            open_reply = await _read_sage_line(reader)
            await _send_sage_line(writer, "SIZE")
            size_reply = await _read_sage_line(reader)
            try:
                size = int((size_reply.split() or ["-1"])[0])
            except Exception:
                size = -1

            offset = max(0, int(self.start_offset))
            started = time.monotonic()
            mode = str(self.mode or "fast").strip().lower().replace("-", "_")
            burst_bytes = max(0, int(float(self.burst_seconds) * max(1, int(self.realtime_bytes_per_sec))))
            no_growth_since: Optional[float] = None
            if mode == "realtime":
                self.bridge.status.last_error = f"SageTV PULL realtime input pacing enabled at about {int(self.realtime_bytes_per_sec)} B/s"
            elif mode == "auto":
                self.bridge.status.last_error = f"SageTV PULL auto fill enabled; fast burst for about {int(self.burst_seconds)}s, then live pacing"
            else:
                self.bridge.status.last_error = "SageTV PULL fast fill enabled; reading ahead as fast as FFmpeg accepts data"
            while True:
                if size >= 0 and offset >= size:
                    if mode in ("auto", "realtime"):
                        await _send_sage_line(writer, "SIZE")
                        new_size_reply = await _read_sage_line(reader)
                        try:
                            new_size = int((new_size_reply.split() or [str(size)])[0])
                        except Exception:
                            new_size = size
                        if new_size > offset:
                            size = new_size
                            no_growth_since = None
                        else:
                            now = time.monotonic()
                            if no_growth_since is None:
                                no_growth_since = now
                                if mode == "auto":
                                    self.bridge.status.last_error = "SageTV PULL auto fill reached current file end; waiting for Live TV growth"
                            if mode == "auto" and (now - no_growth_since) >= float(self.live_no_growth_timeout):
                                self.bridge.status.last_error = "SageTV PULL auto fill saw no file growth; treating as completed recording"
                                break
                            await asyncio.sleep(0.50)
                            continue
                    else:
                        break
                want = self.chunk_size if size < 0 else min(self.chunk_size, max(0, size - offset))
                if want <= 0:
                    if mode in ("auto", "realtime"):
                        await asyncio.sleep(0.50)
                        continue
                    break
                await _send_sage_line(writer, f"READ {offset} {want}")
                try:
                    data = await reader.readexactly(want)
                except asyncio.IncompleteReadError as e:
                    data = e.partial or b""
                    if data:
                        await self.bridge.write(data)
                        self.bytes_read += len(data)
                    break
                if not data:
                    break
                await self.bridge.write(data)
                self.bytes_read += len(data)
                offset += len(data)
                if mode in ("realtime", "auto"):
                    # Approximate live-safe pacing for SageTV PULL. Auto mode
                    # allows an initial fast burst and then uses the same pacing
                    # so it can build a buffer without racing forever to EOF.
                    try:
                        paced_bytes = self.bytes_read if mode == "realtime" else max(0, self.bytes_read - burst_bytes)
                        expected = paced_bytes / max(1, int(self.realtime_bytes_per_sec))
                        actual = time.monotonic() - started
                        delay = min(0.50, max(0.0, expected - actual))
                        if delay > 0:
                            await asyncio.sleep(delay)
                        else:
                            await asyncio.sleep(0)
                    except Exception:
                        await asyncio.sleep(0)
                else:
                    await asyncio.sleep(0)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            self.last_error = str(exc)
            self.bridge.status.last_error = f"Sage pull stream error: {exc}"
        finally:
            if writer:
                try:
                    await _send_sage_line(writer, "CLOSE")
                except Exception:
                    pass
                try:
                    writer.close()
                    await writer.wait_closed()
                except Exception:
                    pass
