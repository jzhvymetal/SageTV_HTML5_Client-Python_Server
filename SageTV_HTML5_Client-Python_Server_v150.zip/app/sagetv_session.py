import asyncio
import base64
import json
import os
import random
import re
import socket
import struct
import time
import urllib.parse
from pathlib import Path
from dataclasses import dataclass
from typing import Optional, Tuple

from fastapi import WebSocket, WebSocketDisconnect
from starlette.websockets import WebSocketState

from .gfx import GfxParser
from .media import (
    MediaCommandParser, MEDIA_CMD_NAMES, MEDIACMD_PUSHBUFFER,
    MEDIACMD_OPENURL, MEDIACMD_FLUSH, MEDIACMD_SEEK, MEDIACMD_STOP, MEDIACMD_DEINIT, MEDIACMD_GETMEDIATIME,
    PLAY_STATE, PAUSE_STATE, STOPPED_STATE,
)
from .video_bridge import (
    FfmpegHlsBridge, SagePullStreamPump, parse_stv_url,
    normalize_video_fps_choice, normalize_audio_bitrate_choice, normalize_encoder_latency_mode,
    normalize_qsv_decode_mode, normalize_qsv_filter_mode,
)
from .protocol_constants import *
from .sagetv_server import normalize_server_host, parse_miniclient_server, SAGETV_MINICLIENT_PORT
from .sagex_api import normalize_sagex_base, sagex_lookup_current_media, sagex_get_timeline


def parse_server(server: str) -> Tuple[str, int]:
    """Return the MiniClient host and standard SageTV MiniClient port.

    The GUI now stores only the SageTV server host/IP.  Legacy host:port
    values are accepted for migration, but the port is ignored so the app always
    uses SageTV's standard MiniClient port internally.
    """
    return parse_miniclient_server(server)


def normalize_server_setting(value: str | None) -> str:
    return normalize_server_host(value) or "192.168.10.175"


def normalize_mac(mac: str | None) -> str:
    if not mac:
        rnd = [0x02, 0x51, 0x56, random.randint(0,255), random.randint(0,255), random.randint(0,255)]
        return ":".join(f"{b:02x}" for b in rnd)
    raw = re.sub(r"[^0-9a-fA-F]", "", mac)
    if len(raw) < 12:
        raw = (raw + "025156000000")[:12]
    return ":".join(raw[i:i+2].lower() for i in range(0, 12, 2))


def mac_to_bytes(mac: str) -> bytes:
    return bytes(int(part, 16) for part in mac.split(":"))


async def open_sagetv_socket(host: str, port: int, conn_type: int, client_id: str, timeout: float = 10.0) -> Tuple[asyncio.StreamReader, asyncio.StreamWriter]:
    reader, writer = await asyncio.wait_for(asyncio.open_connection(host, port), timeout=timeout)
    # Java MiniClient writes 7 bytes: 0x01 + 6 MAC bytes, then one connType byte.
    writer.write(bytes([1]) + mac_to_bytes(client_id) + bytes([conn_type]))
    await writer.drain()
    accepted = await asyncio.wait_for(reader.readexactly(1), timeout=timeout)
    if accepted[0] != 2:
        writer.close()
        try:
            await writer.wait_closed()
        except Exception:
            pass
        raise ConnectionError(f"SageTV rejected conn_type {conn_type}; reply={accepted[0]}")
    return reader, writer


def make_reply_packet(reply_type: int, reply_count: int, payload: bytes) -> bytes:
    if len(payload) > 0xFFFFFF:
        raise ValueError("Payload too large")
    # 1 byte type, 3 byte length, 12 bytes event metadata, then payload.
    return bytes([reply_type]) + len(payload).to_bytes(3, "big") + struct.pack(">III", 0, reply_count, 0) + payload


@dataclass
class ClientSize:
    width: int = 1280
    height: int = 720


def parse_max_height(value, default: int = 480) -> int:
    """Return 0 for source/original height, otherwise a positive scale height."""
    if value is None:
        return int(default or 0)
    text = str(value).strip().lower()
    if text in ("", "source", "src", "original", "native", "0", "none"):
        return 0
    # Accept labels such as "720p" from future UI variants.
    text = text.rstrip("p")
    try:
        return max(0, int(text))
    except Exception:
        return int(default or 0)


def normalize_bitrate_choice(value) -> str:
    """Normalize the browser bitrate dropdown value."""
    text = str(value or "source").strip().lower()
    if text in ("", "default"):
        return "source"
    if text in ("source", "src", "original", "native"):
        return "source"
    if text in ("auto", "adaptive"):
        return "auto"
    if text[-1:] in ("k", "m"):
        return text
    try:
        int(text)
        return text + "k"
    except Exception:
        return "source"



def parse_audio_offset_ms(value, default: int = 0) -> int:
    try:
        text = str(value if value is not None else default).strip().lower().replace("ms", "")
        return max(-2000, min(2000, int(float(text))))
    except Exception:
        return int(default or 0)


def parse_float_range(value, default: float, lo: float, hi: float) -> float:
    try:
        n = float(str(value if value is not None else default).strip())
        return max(lo, min(hi, n))
    except Exception:
        return float(default)

def parse_int_range(value, default: int, lo: int, hi: int) -> int:
    try:
        n = int(float(str(value if value is not None else default).strip()))
        return max(lo, min(hi, n))
    except Exception:
        return int(default)

def normalize_direct_read_mode(value) -> str:
    v = str(value or "fast").strip().lower().replace("-", "_")
    if v in ("auto", "adaptive", "live_auto", "auto_live", "burst", "fast_then_live", "catchup"):
        return "auto"
    if v in ("realtime", "real_time", "live", "1x", "safe"):
        return "realtime"
    return "fast"


def normalize_buffer_preset(value) -> str:
    text = str(value or "ios").strip().lower().replace("-", "_")
    if text in ("ios", "ios_safe", "iphone", "ipad"):
        return "ios"
    if text in ("max", "maximum", "max_stability", "maximum_stability"):
        return "maximum"
    if text in ("low", "lowdelay", "low_delay", "fast"):
        return "lowdelay"
    return "normal"

def normalize_ffmpeg_buffer_preset(value) -> str:
    text = str(value or "faststart").strip().lower().replace("-", "_")
    if text in ("fast", "faststart", "fast_start", "startup", "low_latency", "lowlatency", "mitm"):
        return "faststart"
    if text in ("huge", "max", "maximum", "diagnostic"):
        return "huge"
    if text in ("large", "big", "more", "high"):
        return "large"
    return "normal"

def parse_bool(value, default: bool = False) -> bool:
    if value is None:
        return bool(default)
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in ("1", "true", "yes", "on", "checked")

def normalize_player_mode(value) -> str:
    text = str(value or "hls").strip().lower()
    # Removed ABR mode falls back to fixed HLS TS so old cookies/settings do not select a missing player.
    if text in ("hlsabr", "hls-abr", "hls_abr", "abr", "adaptive_hls", "adaptive"):
        return "hls"
    if text in ("hlsfmp4", "hls-fmp4", "hls_fmp4", "cmaf"):
        return "hlsfmp4"
    if text in ("videojsfmp4", "videojs-fmp4", "videojs_fmp4", "vjsfmp4", "vjs-fmp4", "video-js-fmp4"):
        return "videojsfmp4"
    if text in ("videojs", "video-js", "vjs"):
        return "videojs"
    return "hls"

def normalize_playback_source(value) -> str:
    text = str(value or "push").strip().lower()
    aliases = {
        "auto": "auto",
        "auto_direct": "auto",
        "auto-direct": "auto",
        "direct": "direct",
        "file": "direct",
        "smb": "direct",
        "nfs": "direct",
        "pull": "pull",
        "stv": "pull",
        "push": "push",
        "pushbuffer": "push",
        # Legacy v113/v114 Web source settings are no longer a playback
        # source.  Keep using the SageX API plugin only to find
        # MediaFile paths, then play through Direct File/SMB.
        "web": "direct",
        "webui": "direct",
        "sagex_api": "direct",
        "web-interface": "direct",
        "sagetv_web": "direct",
    }
    return aliases.get(text, "push")



DETAIL_LABEL_RE = re.compile(r"^(File|Format|File Size|Language|Date / Duration|Date|Duration|Title|Airing|Channel)\s*:", re.I)


def parse_sagetv_detail_text_lines(lines: list[str]) -> dict:
    """Extract useful Video Detail metadata from SageTV GUI text lines.

    This is intentionally tolerant because SageTV wraps long paths over several
    drawText commands.  It returns both spaced and compact file-path candidates;
    the spaced value matches typical SageTV detail wrapping, while the compact
    candidate helps if the UI wrapped in the middle of a filename.
    """
    cleaned = [re.sub(r"\s+", " ", str(x or "")).strip() for x in (lines or [])]
    cleaned = [x for x in cleaned if x]
    if not cleaned:
        return {}

    def capture_parts_after(label: str, stop_labels: tuple[str, ...]) -> list[str]:
        parts = []
        active = False
        label_re = re.compile(rf"^{re.escape(label)}\s*:\s*(.*)$", re.I)
        stop_re = re.compile(r"^(" + "|".join(re.escape(x) for x in stop_labels) + r")\s*:", re.I)
        for line in cleaned:
            if not active:
                m = label_re.match(line)
                if m:
                    active = True
                    first = m.group(1).strip()
                    if first:
                        parts.append(first)
                continue
            if stop_re.match(line):
                break
            # Continuation lines in SageTV detail screens are usually indented on
            # the UI but not in the captured text.  Keep them as value parts.
            parts.append(line.strip())
        return [p for p in parts if p]

    def smart_join_path_parts(parts: list[str]) -> str:
        if not parts:
            return ""
        out = parts[0].strip()
        for part in parts[1:]:
            part = part.strip()
            if not part:
                continue
            if out.endswith(("/", "\\", "-", "_", ".")) or part.startswith(("/", "\\", "-", "_", ".")):
                out += part
            else:
                out += " " + part
        return out.strip()

    file_parts = capture_parts_after("File", ("Format", "File Size", "Language", "Date / Duration", "Date", "Duration"))
    fmt_parts = capture_parts_after("Format", ("File Size", "File", "Language", "Date / Duration", "Date", "Duration"))

    file_value = smart_join_path_parts(file_parts)
    fmt_value = " ".join(fmt_parts).strip()

    def clean_bracket_value(v: str) -> str:
        v = str(v or "").strip()
        if v.startswith("[") and v.endswith("]"):
            v = v[1:-1].strip()
        elif v.startswith("["):
            v = v[1:].strip()
        elif v.endswith("]"):
            v = v[:-1].strip()
        return v

    file_spaced = clean_bracket_value(file_value)
    # Alternate candidate used when SageTV wraps a path in the middle of a token.
    # Keep normal spaces in known paths like "Season 01" in the primary value.
    file_compact = re.sub(r"\s+", "", file_spaced)
    candidates = []
    for c in (file_spaced, file_compact):
        if c and c not in candidates:
            candidates.append(c)

    out = {}
    if candidates:
        out["file_path"] = candidates[0]
        out["file_candidates"] = candidates
    if fmt_value:
        out["format"] = clean_bracket_value(fmt_value)
        hints = parse_sagetv_format_hint(out["format"])
        if hints:
            out["format_hint"] = hints
    if out:
        out["lines"] = cleaned[-40:]
        out["captured_at"] = time.time()
    return out


def parse_sagetv_format_hint(fmt: str) -> dict:
    """Parse the human-readable SageTV Format line into lightweight hints."""
    text = str(fmt or "").strip().strip("[]")
    if not text:
        return {}
    hints: dict[str, object] = {"raw": text}
    container = text.split("[", 1)[0].strip()
    if container:
        hints["container"] = container
    m = re.search(r"(\d{2,5})x(\d{2,5})(?:@([0-9.]+)fps)?", text, re.I)
    if m:
        hints["width"] = int(m.group(1))
        hints["height"] = int(m.group(2))
        if m.group(3):
            try:
                hints["fps"] = float(m.group(3))
            except Exception:
                pass
    m = re.search(r"\b(H\.264|H264|MPEG2|MPEG-2|HEVC|H\.265|AVC)\b", text, re.I)
    if m:
        v = m.group(1).upper().replace("H264", "H.264").replace("H265", "H.265")
        hints["video_codec"] = v
    m = re.search(r"\b(AAC|AC3|AC-3|MP3|MPEG Audio|EAC3|E-AC-3)\b", text, re.I)
    if m:
        hints["audio_codec"] = m.group(1).upper()
    m = re.search(r"(\d+(?:\.\d+)?)\s*Kbps", text, re.I)
    if m:
        try:
            hints["bitrate_kbps"] = float(m.group(1))
        except Exception:
            pass
    return hints




def _looks_like_media_path(value: str) -> bool:
    text = str(value or "").strip()
    if not text:
        return False
    low = text.lower()
    if low.startswith(("http://", "https://", "push:")):
        return False
    if low.startswith(("file:/", "stv://")):
        return True
    if text.startswith(("/", "\\", "//")):
        return True
    if re.match(r"^[A-Za-z]:[\\/]", text):
        return True
    return bool(re.search(r"\.(ts|mpg|mpeg|mp4|mkv|avi|mov|m4v|wmv|flv|webm)(?:$|[?#])", low))



def _recursive_values(obj):
    if isinstance(obj, dict):
        for k, v in obj.items():
            yield k, v
            yield from _recursive_values(v)
    elif isinstance(obj, list):
        for v in obj:
            yield "", v
            yield from _recursive_values(v)

def _normalize_media_detail_result(data):
    if isinstance(data, dict) and "Result" in data:
        return data.get("Result")
    return data


def parse_media_detail_current_file(data) -> dict:
    """Extract file/format hints from a SageX API MediaFile result."""
    result = _normalize_media_detail_result(data)
    if not result:
        return {}
    if isinstance(result, dict) and len(result) == 1 and isinstance(next(iter(result.values())), dict):
        # Some encoders wrap the object as {"MediaFile": {...}}.
        only_key = next(iter(result.keys()))
        if str(only_key).lower() in ("mediafile", "media_file"):
            result = next(iter(result.values()))
    candidates: list[str] = []

    def add_candidate(v):
        text = str(v or "").strip()
        if not text:
            return
        text = _strip_url_to_path(text)
        if _looks_like_media_path(text) and text not in candidates:
            candidates.append(text)

    if isinstance(result, dict):
        segs = result.get("SegmentFiles") or result.get("segmentFiles") or result.get("Files") or result.get("files")
        if isinstance(segs, list):
            for x in segs:
                add_candidate(x)
        for key_name in ("File", "file", "FilePath", "filePath", "Path", "path", "MediaFilePath", "mediaFilePath"):
            if key_name in result:
                add_candidate(result.get(key_name))

    for key, val in _recursive_values(result):
        kl = str(key or "").lower()
        if isinstance(val, str) and ("file" in kl or "path" in kl or "segment" in kl):
            add_candidate(val)
        elif isinstance(val, list) and ("segment" in kl or "file" in kl):
            for x in val:
                add_candidate(x)

    fmt = ""
    encoding = ""
    media_id = ""
    if isinstance(result, dict):
        for k in ("MediaFileFormatDescription", "FormatDescription", "formatDescription", "MediaFormat", "Format", "format"):
            if result.get(k):
                fmt = str(result.get(k)).strip()
                break
        for k in ("MediaFileEncoding", "Encoding", "encoding"):
            if result.get(k):
                encoding = str(result.get(k)).strip()
                break
        for k in ("MediaFileID", "MediaFileId", "mediaFileID", "mediaFileId", "ID", "id"):
            if result.get(k) is not None:
                media_id = str(result.get(k)).strip()
                break
    if not fmt:
        for key, val in _recursive_values(result):
            kl = str(key or "").lower()
            if isinstance(val, str) and ("formatdescription" in kl or kl == "format"):
                fmt = val.strip()
                break
    if not encoding:
        for key, val in _recursive_values(result):
            if isinstance(val, str) and "encoding" in str(key or "").lower():
                encoding = val.strip()
                break

    out: dict[str, object] = {}
    if candidates:
        out["file_path"] = candidates[0]
        out["file_candidates"] = candidates
    if fmt:
        out["format"] = fmt
        hints = parse_sagetv_format_hint(fmt)
        if hints:
            out["format_hint"] = hints
    if encoding:
        out["encoding"] = encoding
    if media_id:
        out["media_file_id"] = media_id
    if out:
        out["source"] = "webui"
        out["captured_at"] = time.time()
    return out



def guess_sage_storage_root(path: str) -> str:
    """Guess the editable Sage root for an auto-discovered media path.

    SageTV commonly displays imported media under roots like /var/media/videos
    or recordings under /var/media/tv.  If we can identify /var/media/<library>,
    add that root instead of an overly specific Season/Movie folder.
    """
    src = _strip_url_to_path(path).strip().rstrip("/\\")
    if not src:
        return ""
    norm = src.replace("\\", "/")
    lower = norm.lower()
    m = re.match(r"^(/var/media/[^/]+)(?:/|$)", norm, re.I)
    if m:
        return m.group(1)
    m = re.match(r"^(/media/[^/]+)(?:/|$)", norm, re.I)
    if m:
        return m.group(1)
    if norm.startswith("//"):
        parts = [p for p in norm.split("/") if p]
        if len(parts) >= 2:
            return "//" + "/".join(parts[:2])
    if src.startswith("\\\\"):
        parts = [p for p in src.split("\\") if p]
        if len(parts) >= 2:
            return "\\\\" + "\\".join(parts[:2])
    m = re.match(r"^([A-Za-z]:[\\/][^\\/]+)", src)
    if m:
        return m.group(1)
    return _split_direct_path_parent(src)


def _clean_push_direct_path(candidate: str) -> str:
    candidate = str(candidate or "").strip().strip('"')
    # SageTV push URLs often append MiniClient stream flags such as ?bf=vid.
    # Those are not part of the filesystem path.
    if "?" in candidate:
        candidate = candidate.split("?", 1)[0]
    return candidate


def _extract_path_from_push_url(url: str) -> str:
    r"""Return a Direct File candidate from SageTV push-style URLs.

    Some SageTV library items advertise PUSHBUFFER mode but still include the
    backing file path after the ``push:`` prefix. Direct File/SMB should use
    that embedded path instead of refusing the stream immediately. When the
    PUSH URL truly has no path, return an empty string so strict Direct mode
    still refuses PUSHBUFFER.
    """
    raw = str(url or "").strip()
    if not raw.lower().startswith("push:"):
        return raw
    rest = urllib.parse.unquote(raw[5:].strip())
    if not rest:
        return ""

    # If SageTV embeds a normal URL after push:, normalize that URL directly.
    low_rest = rest.lower()
    for marker in ("stv://", "file://", "smb://"):
        idx = low_rest.find(marker)
        if idx >= 0:
            return _strip_url_to_path(rest[idx:])

    # Direct path forms. Keep the full rest when it already starts as a path.
    if rest.startswith(("/", "\\")) or re.match(r"^[A-Za-z]:[\\/]", rest):
        return _clean_push_direct_path(rest)

    # Metadata may precede the path, for example push:<flags>:/var/media/file.ts.
    # Look for Windows drive, UNC, then POSIX path candidates in that order.
    m = re.search(r"[A-Za-z]:[\\/][^\r\n]+", rest)
    if m:
        return _clean_push_direct_path(m.group(0))
    m = re.search(r"(?:\\\\|//)[^\s]+", rest)
    if m:
        return _clean_push_direct_path(m.group(0))
    m = re.search(r"(?:^|[:\s])(/[^\s]+)", rest)
    if m:
        return _clean_push_direct_path(m.group(1))
    return ""


def _strip_url_to_path(url: str) -> str:
    r"""Normalize file/smb/stv/push URLs to the path portion used for mapping.

    Important for Direct File/SMB mode: SageTV often sends URLs like
    stv://192.168.10.175//var/media/tv/file.ts, while the Windows share is
    \\192.168.10.175\sagemedia\tv\file.ts. The stv:// host is only the SageTV
    pull server; the part we need for file mapping is /var/media/tv/file.ts.

    Some SageTV video-library items advertise PUSHBUFFER but still include the
    real file path after push:. For Direct File/SMB mapping, extract that path
    when available.
    """
    raw = str(url or "").strip()
    if not raw:
        return ""
    low = raw.lower()
    if low.startswith("push:"):
        return _extract_path_from_push_url(raw)
    if low.startswith("stv://"):
        try:
            _host, stv_path = parse_stv_url(raw)
            return urllib.parse.unquote(stv_path or "")
        except Exception:
            return urllib.parse.unquote(raw)
    if low.startswith("file://"):
        parsed = urllib.parse.urlparse(raw)
        path = urllib.parse.unquote(parsed.path or "")
        if parsed.netloc:
            # file://server/share/file.ts -> UNC on Windows, //server/share on POSIX.
            return ("\\\\" + parsed.netloc + path.replace("/", "\\")) if os.name == "nt" else ("//" + parsed.netloc + path)
        if os.name == "nt" and path.startswith("/") and len(path) >= 3 and path[2] == ":":
            path = path[1:]
        return path.replace("/", "\\") if os.name == "nt" else path
    if low.startswith("smb://"):
        parsed = urllib.parse.urlparse(raw)
        path = urllib.parse.unquote(parsed.path or "")
        return ("\\\\" + parsed.netloc + path.replace("/", "\\")) if os.name == "nt" else ("//" + parsed.netloc + path)
    return urllib.parse.unquote(raw)

def _norm_compare_path(path: str) -> str:
    p = str(path or "").replace("\\", "/")
    # Collapse repeated slashes except directly after a URL scheme marker.
    marker = ":__SCHEME_SLASHES__"
    p = p.replace("://", marker)
    while "//" in p:
        p = p.replace("//", "/")
    p = p.replace(marker, "://")
    return p.lower() if os.name == "nt" else p

def _join_mapped_path(local_root: str, rest: str) -> str:
    root = str(local_root or "").strip().rstrip("/\\")
    tail = str(rest or "").strip().lstrip("/\\")
    if not tail:
        return root
    # Preserve UNC roots on Windows.  pathlib can reinterpret backslash-heavy
    # strings when the server is running on a different OS, so keep this as a
    # simple string join.
    if "\\" in root or (os.name == "nt" and not root.startswith("/")):
        return root + "\\" + tail.replace("/", "\\")
    return root + "/" + tail.replace("\\", "/")

def map_direct_path(source_path: str, sage_root: str = "", local_root: str = "", path_map="") -> str:
    local, _matched, had_local = find_direct_path_mapping(source_path, sage_root, local_root, path_map)
    if local:
        return local
    return "" if _matched and not had_local else _strip_url_to_path(source_path)


def parse_direct_path_map(value) -> list[dict]:
    """Parse the shared Direct File/SMB mapping list.

    Stored as JSON in server_settings/settings.json because the existing settings
    store is string-based.  Each row is {"sage": "...", "local": "..."}.
    Blank local values are kept so the GUI can show newly discovered Sage roots
    that still need to be mapped by the user.
    """
    if value is None:
        return []
    data = value
    if isinstance(value, str):
        raw = value.strip()
        if not raw:
            return []
        try:
            data = json.loads(raw)
        except Exception:
            # Backward-compatible text format: one mapping per line, sage=local.
            rows = []
            for line in raw.splitlines():
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if "=" in line:
                    a, b = line.split("=", 1)
                else:
                    a, b = line, ""
                if a.strip():
                    rows.append({"sage": a.strip(), "local": b.strip()})
            return dedupe_direct_path_map(rows)
    if not isinstance(data, list):
        return []
    rows = []
    for item in data:
        if isinstance(item, dict):
            sage = str(item.get("sage") or item.get("sage_root") or "").strip()
            local = str(item.get("local") or item.get("local_root") or "").strip()
        elif isinstance(item, (list, tuple)) and item:
            sage = str(item[0] or "").strip()
            local = str(item[1] if len(item) > 1 and item[1] is not None else "").strip()
        else:
            continue
        if sage:
            rows.append({"sage": sage, "local": local})
    return dedupe_direct_path_map(rows)


def encode_direct_path_map(rows: list[dict]) -> str:
    return json.dumps(dedupe_direct_path_map(rows), separators=(",", ":"))


def dedupe_direct_path_map(rows: list[dict]) -> list[dict]:
    out = []
    seen = set()
    for row in rows or []:
        sage = str(row.get("sage") or "").strip()
        local = str(row.get("local") or "").strip()
        if not sage:
            continue
        key = _norm_compare_path(_strip_url_to_path(sage)).rstrip("/")
        if not key or key in seen:
            # Keep the first entry because it is the one the user most likely edited.
            continue
        seen.add(key)
        out.append({"sage": sage, "local": local})
    # Prefer longer/specific roots first during matching, but keep display stable by
    # not sorting here. Matching sorts a copy.
    return out


def direct_path_map_pairs(value) -> list[tuple[str, str]]:
    rows = parse_direct_path_map(value)
    pairs = []
    for row in rows:
        sage = _strip_url_to_path(row.get("sage", "")).strip().rstrip("/\\")
        local = _strip_url_to_path(row.get("local", "")).strip().rstrip("/\\")
        if sage:
            pairs.append((sage, local))
    pairs.sort(key=lambda p: len(_norm_compare_path(p[0])), reverse=True)
    return pairs


def _split_direct_path_parent(path: str) -> str:
    src = _strip_url_to_path(path).strip().rstrip("/\\")
    if not src:
        return ""
    # UNC/share style. Preserve both backslash and slash UNC forms.
    if src.startswith("\\\\"):
        parts = [p for p in src.split("\\") if p]
        if len(parts) <= 2:
            return src
        return "\\\\" + "\\".join(parts[:-1])
    if src.startswith("//"):
        parts = [p for p in src.split("/") if p]
        if len(parts) <= 2:
            return src
        return "//" + "/".join(parts[:-1])
    sep = "\\" if "\\" in src and (os.name == "nt" or not src.startswith("/")) else "/"
    idx = src.rfind(sep)
    if idx <= 0:
        return src
    # For Windows C:\foo\bar.ts, parent is C:\foo. For /x/y.ts, parent is /x.
    return src[:idx]


def _path_needs_mapping_for_platform(path: str) -> bool:
    src = _strip_url_to_path(path).strip()
    if not src:
        return False
    # Windows can read UNC and drive-letter paths directly. A POSIX Sage path needs mapping.
    if os.name == "nt":
        if src.startswith(("\\\\", "//")):
            return False
        if re.match(r"^[A-Za-z]:[\\/]", src):
            return False
        return src.startswith("/")
    # POSIX can read POSIX paths directly. Windows drive/UNC Sage paths need mapping.
    if re.match(r"^[A-Za-z]:[\\/]", src) or src.startswith("\\\\"):
        return True
    return False


def find_direct_path_mapping(source_path: str, sage_root: str = "", local_root: str = "", path_map="") -> tuple[str, str, bool]:
    """Return (mapped_local_path_or_source, matched_sage_root, matched_had_local)."""
    src = _strip_url_to_path(source_path)
    if not src:
        return "", "", False
    pairs: list[tuple[str, str]] = []
    pairs.extend(direct_path_map_pairs(path_map))
    if sage_root:
        pairs.append((_strip_url_to_path(sage_root).strip().rstrip("/\\"), _strip_url_to_path(local_root or "").strip().rstrip("/\\")))
    env_map = os.environ.get("SAGEWEB_DIRECT_PATH_MAP", "")
    for part in re.split(r"[|;]", env_map):
        if not part.strip() or "=" not in part:
            continue
        a, b = part.split("=", 1)
        if a.strip():
            pairs.append((_strip_url_to_path(a.strip()).rstrip("/\\"), _strip_url_to_path(b.strip()).rstrip("/\\")))
    # Longest/specific roots first.
    pairs = [(a, b) for a, b in pairs if a]
    pairs.sort(key=lambda p: len(_norm_compare_path(p[0])), reverse=True)
    cmp_src = _norm_compare_path(src).rstrip("/")
    for sage, local in pairs:
        sage_norm = str(sage).rstrip("/\\")
        cmp_sage = _norm_compare_path(sage_norm).rstrip("/")
        if cmp_src == cmp_sage or cmp_src.startswith(cmp_sage + "/"):
            if not local:
                return "", sage_norm, False
            rest = src[len(sage_norm):].lstrip("/\\")
            return _join_mapped_path(local, rest), sage_norm, True
    return src, "", False


def load_shared_direct_path_map_value() -> str:
    path = Path(__file__).resolve().parent.parent / "server_settings" / "settings.json"
    if not path.exists():
        return "[]"
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        settings = data.get("settings", data)
        return str(settings.get("directPathMap") or "[]") if isinstance(settings, dict) else "[]"
    except Exception:
        return "[]"


def save_shared_direct_path_map_value(path_map_value: str):
    path = Path(__file__).resolve().parent.parent / "server_settings" / "settings.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {}
    if path.exists():
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            payload = {}
    if not isinstance(payload, dict):
        payload = {}
    settings = payload.get("settings")
    if not isinstance(settings, dict):
        settings = {}
    settings["directPathMap"] = path_map_value
    payload.update({
        "scope": "server",
        "folder": "server_settings",
        "updated_at": int(time.time()),
        "settings": settings,
    })
    tmp = path.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    tmp.replace(path)



class SageTVWebSession:
    def __init__(self, session_id: str, websocket: WebSocket):
        self.session_id = session_id
        self.ws = websocket
        self.server = normalize_server_setting(os.environ.get("SAGETV_SERVER", "192.168.10.175"))
        self.requested_client_id = normalize_mac(os.environ.get("SAGETV_CLIENT_ID"))
        self.client_id = self.requested_client_id
        self.size = ClientSize()
        self.gfx_reader: Optional[asyncio.StreamReader] = None
        self.gfx_writer: Optional[asyncio.StreamWriter] = None
        self.media_reader: Optional[asyncio.StreamReader] = None
        self.media_writer: Optional[asyncio.StreamWriter] = None
        self.gfx_task: Optional[asyncio.Task] = None
        self.media_task: Optional[asyncio.Task] = None
        self.reply_count = 0
        self.connected = False
        self.gfx = GfxParser()
        self.media = MediaCommandParser()
        self.media_caps_enabled = os.environ.get("SAGEWEB_MEDIA_CAPS", "0").lower() in ("1", "true", "yes", "on")
        self.video_encoder = os.environ.get("SAGEWEB_VIDEO_ENCODER", "auto")
        self.video_max_height = parse_max_height(os.environ.get("SAGEWEB_VIDEO_MAX_HEIGHT", "source"), default=0)
        self.video_bitrate = normalize_bitrate_choice(os.environ.get("SAGEWEB_VIDEO_BITRATE", "source"))
        self.video_fps = normalize_video_fps_choice(os.environ.get("SAGEWEB_VIDEO_FPS", "source"))
        self.audio_bitrate = normalize_audio_bitrate_choice(os.environ.get("SAGEWEB_AUDIO_BITRATE", "128k"))
        self.encoder_latency_mode = normalize_encoder_latency_mode(os.environ.get("SAGEWEB_ENCODER_LATENCY_MODE", "faststart"))
        self.qsv_decode_mode = normalize_qsv_decode_mode(os.environ.get("SAGEWEB_QSV_DECODE_MODE", "auto"))
        self.qsv_filter_mode = normalize_qsv_filter_mode(os.environ.get("SAGEWEB_QSV_FILTER_MODE", "auto"))
        self.hls_mode = os.environ.get("SAGEWEB_HLS_MODE", "stable").strip().lower()
        self.buffer_preset = normalize_buffer_preset(os.environ.get("SAGEWEB_BUFFER_PRESET", "ios"))
        self.hls_segment_seconds = parse_float_range(os.environ.get("SAGEWEB_HLS_TIME", "4"), 4.0, 1.0, 12.0)
        self.hls_init_seconds = parse_float_range(os.environ.get("SAGEWEB_HLS_INIT_TIME", "1"), 1.0, 0.0, 4.0)
        self.hls_start_segments = parse_int_range(os.environ.get("SAGEWEB_HLS_START_SEGMENTS", "0"), 0, 0, 10)
        self.hlsjs_max_buffer_seconds = parse_int_range(os.environ.get("SAGEWEB_HLSJS_MAX_BUFFER_SECONDS", "180"), 180, 30, 600)
        self.direct_read_mode = normalize_direct_read_mode(os.environ.get("SAGEWEB_DIRECT_READ_MODE", "fast"))
        self.ffmpeg_buffer_preset = normalize_ffmpeg_buffer_preset(os.environ.get("SAGEWEB_FFMPEG_BUFFER_PRESET", "faststart"))
        if self.hls_mode not in ("stable", "rolling", "debug"):
            self.hls_mode = "stable"
        self.player_mode = normalize_player_mode(os.environ.get("SAGEWEB_PLAYER_MODE", "hls"))
        self.audio_offset_ms = parse_audio_offset_ms(os.environ.get("SAGEWEB_AUDIO_OFFSET_MS", "-200"), default=-200)
        self.video = FfmpegHlsBridge(
            session_id=session_id,
            encoder_request=self.video_encoder,
            max_height=self.video_max_height,
            video_bitrate=self.video_bitrate,
            video_fps=self.video_fps,
            audio_bitrate=self.audio_bitrate,
            encoder_latency_mode=self.encoder_latency_mode,
            qsv_decode_mode=self.qsv_decode_mode,
            qsv_filter_mode=self.qsv_filter_mode,
            hls_mode=self.hls_mode,
            hls_time=self.hls_segment_seconds,
            hls_init_time=self.hls_init_seconds,
            hls_start_segments=self.hls_start_segments,
            hlsjs_max_buffer_seconds=self.hlsjs_max_buffer_seconds,
            buffer_preset=self.buffer_preset,
            player_mode=self.player_mode,
            audio_offset_ms=self.audio_offset_ms,
            direct_read_realtime=(self.direct_read_mode == "realtime"),
            direct_read_mode=self.direct_read_mode,
            ffmpeg_buffer_preset=self.ffmpeg_buffer_preset,
        )
        self.playback_source = normalize_playback_source(os.environ.get("SAGEWEB_PLAYBACK_SOURCE", "direct"))
        # v66: No fallback checkbox was removed. Explicit Source/Player selections are always strict.
        # Use Source=Auto Direct/PULL/PUSH when source fallback is desired.
        self.no_fallback = True
        self.direct_sage_root = os.environ.get("SAGEWEB_DIRECT_SAGE_ROOT", "")
        self.direct_local_root = os.environ.get("SAGEWEB_DIRECT_LOCAL_ROOT", "")
        self.direct_path_map = os.environ.get("SAGEWEB_DIRECT_PATH_MAP_JSON", load_shared_direct_path_map_value())
        self._pending_direct_path_map_update = False
        self.hls_storage_mode = os.environ.get("SAGEWEB_HLS_STORAGE_MODE", "disk").strip().lower()
        self.hls_ram_root = os.environ.get("SAGEWEB_HLS_RAM_ROOT", "")
        self.web_interface_server = normalize_sagex_base(os.environ.get("SAGEWEB_WEB_INTERFACE_SERVER", ""), self.server)
        self.web_interface_username = os.environ.get("SAGEWEB_WEB_INTERFACE_USERNAME", "")
        self.web_interface_password = os.environ.get("SAGEWEB_WEB_INTERFACE_PASSWORD", "")
        self.sage_detail_cache: dict = {}
        self._last_detail_send_ts = 0.0
        self.direct_last_path = ""
        self.direct_last_url = ""
        self._ignored_pushbuffer_logged = False
        # v129: Direct File/SMB can use the SageX API only to
        # resolve the real file path while keeping SageTV PUSHBUFFER alive as
        # the timing/control channel.  In that hybrid mode we ignore pushed
        # bytes but read SageTV's PUSHBUFFER mux/request times and mirror them
        # into local FFmpeg seeks/restarts.
        self.direct_push_timing_control = False
        self._await_push_timing_seek = False
        self._last_push_timing_log_at = 0.0
        self._last_direct_seek_restart_target_ms = -1
        self._last_direct_seek_restart_at = 0.0
        # v132: When Direct File/SMB plays a SageX-resolved file but SageTV
        # keeps a PUSHBUFFER media session, PUSHBUFFER may not include useful
        # seek/mux timing. Poll SageX GetRawMediaTime as the control timeline.
        self._sagex_timeline_last_poll_at = 0.0
        self._sagex_timeline_last_error_at = 0.0
        self._sagex_timeline_last_seek_ms = -1
        self._sagex_timeline_last_seek_at = 0.0
        self.pull_pump: Optional[SagePullStreamPump] = None
        self.pull_task: Optional[asyncio.Task] = None
        self.started_at = time.time()
        self.last_error: Optional[str] = None
        self.gfx_packet_count = 0
        self.gfx_reply_count = 0
        self._send_lock = asyncio.Lock()
        # v20: batch all GFX ops between STARTFRAME and FLIPBUFFER into one
        # WebSocket message.  Sending every SageTV draw packet individually caused
        # browser/main-thread lag and delayed arrow-key response.
        self._frame_commands: list[dict] = []
        self._inside_frame = False
        self.gfx_trace = os.environ.get("SAGEWEB_GFX_TRACE", "0").lower() in ("1", "true", "yes", "on")
        self.ws_closed = False

    def snapshot(self):
        return {
            "server": self.server,
            "client_id": self.client_id,
            "requested_client_id": self.requested_client_id,
            "connected": self.connected,
            "size": {"width": self.size.width, "height": self.size.height},
            "last_error": self.last_error,
            "gfx_packets": self.gfx_packet_count,
            "gfx_replies": self.gfx_reply_count,
            "media": self.media.status.to_json(),
            "video": self.video.status.to_json(),
            "media_caps_enabled": self.media_caps_enabled,
            "playback_source": self.playback_source,
            "no_fallback": self.no_fallback,
            "direct_sage_root": self.direct_sage_root,
            "direct_local_root": self.direct_local_root,
            "direct_path_map": self.direct_path_map,
            "hls_storage_mode": self.hls_storage_mode,
            "hls_ram_root": self.hls_ram_root,
            "web_interface_server": self.web_interface_server,
            "web_interface_username": self.web_interface_username,
            "web_interface_password_set": bool(self.web_interface_password),
            "direct_last_path": self.direct_last_path,
            "direct_push_timing_control": self.direct_push_timing_control,
            "direct_last_url": self.direct_last_url,
            "sage_detail_cache": self.sage_detail_cache,
            "hls_mode": self.hls_mode,
            "player_mode": self.player_mode,
            "video_encoder": self.video_encoder,
            "video_max_height": self.video_max_height,
            "video_bitrate": self.video_bitrate,
            "video_fps": self.video_fps,
            "audio_bitrate": self.audio_bitrate,
            "qsv_decode_mode": self.qsv_decode_mode,
            "qsv_filter_mode": self.qsv_filter_mode,
            "direct_read_mode": self.direct_read_mode,
            "age_seconds": round(time.time() - self.started_at, 1),
        }

    async def send(self, payload: dict):
        if self.ws_closed:
            return False
        async with self._send_lock:
            try:
                if self.ws.application_state != WebSocketState.CONNECTED:
                    self.ws_closed = True
                    return False
                await self.ws.send_text(json.dumps(payload, separators=(",", ":")))
                return True
            except (WebSocketDisconnect, RuntimeError):
                self.ws_closed = True
                return False

    async def send_log(self, message: str):
        await self.send({"type": "log", "message": message})

    async def send_gfx(self, commands: list[dict]):
        if commands:
            await self.send({"type": "gfx", "commands": commands})

    async def handle_browser_message(self, data: dict):
        msg_type = data.get("type")
        if msg_type == "connect":
            self.server = normalize_server_setting(data.get("server") or self.server)
            self.requested_client_id = normalize_mac(data.get("requested_client_id") or data.get("client_id") or self.requested_client_id)
            self.client_id = normalize_mac(data.get("client_id") or self.client_id)
            if data.get("auto_client_id_adjusted") and self.client_id != self.requested_client_id:
                await self.send_log(f"Requested Client ID {self.requested_client_id} is already connected; using effective SageTV Client ID {self.client_id} for this session.")
            self.size.width = int(data.get("width") or self.size.width)
            self.size.height = int(data.get("height") or self.size.height)
            self.media_caps_enabled = bool(data.get("media_caps", self.media_caps_enabled))
            self.playback_source = normalize_playback_source(data.get("playback_source") or self.playback_source)
            self.no_fallback = True
            self.direct_sage_root = str(data.get("direct_sage_root") if data.get("direct_sage_root") is not None else self.direct_sage_root)
            self.direct_local_root = str(data.get("direct_local_root") if data.get("direct_local_root") is not None else self.direct_local_root)
            self.direct_path_map = encode_direct_path_map(parse_direct_path_map(data.get("direct_path_map") if data.get("direct_path_map") is not None else self.direct_path_map))
            self.hls_storage_mode = str(data.get("hls_storage_mode") or self.hls_storage_mode or "disk").strip().lower()
            if self.hls_storage_mode not in ("disk", "temp", "ram"):
                self.hls_storage_mode = "disk"
            self.hls_ram_root = str(data.get("hls_ram_root") if data.get("hls_ram_root") is not None else self.hls_ram_root)
            self.web_interface_server = normalize_sagex_base(data.get("web_interface_server") if data.get("web_interface_server") is not None else self.web_interface_server, self.server)
            self.web_interface_username = str(data.get("web_interface_username") if data.get("web_interface_username") is not None else self.web_interface_username)
            self.web_interface_password = str(data.get("web_interface_password") if data.get("web_interface_password") is not None else self.web_interface_password)
            self.video_encoder = str(data.get("video_encoder") or self.video_encoder or "auto")
            self.video_max_height = parse_max_height(data.get("video_max_height"), default=self.video_max_height)
            self.video_bitrate = normalize_bitrate_choice(data.get("video_bitrate") or self.video_bitrate or "source")
            self.video_fps = normalize_video_fps_choice(data.get("video_fps") or self.video_fps or "source")
            self.audio_bitrate = normalize_audio_bitrate_choice(data.get("audio_bitrate") or self.audio_bitrate or "128k")
            self.encoder_latency_mode = normalize_encoder_latency_mode(data.get("encoder_latency_mode") or self.encoder_latency_mode or "faststart")
            self.qsv_decode_mode = normalize_qsv_decode_mode(data.get("qsv_decode_mode") or self.qsv_decode_mode or "auto")
            self.qsv_filter_mode = normalize_qsv_filter_mode(data.get("qsv_filter_mode") or self.qsv_filter_mode or "auto")
            self.hls_mode = str(data.get("hls_mode") or self.hls_mode or "stable").strip().lower()
            if self.hls_mode not in ("stable", "rolling", "debug"):
                self.hls_mode = "stable"
            self.player_mode = normalize_player_mode(data.get("player_mode") or self.player_mode or "hls")
            self.buffer_preset = normalize_buffer_preset(data.get("buffer_preset") or self.buffer_preset)
            self.hls_segment_seconds = parse_float_range(data.get("hls_segment_seconds"), self.hls_segment_seconds, 1.0, 12.0)
            self.hls_init_seconds = parse_float_range(data.get("hls_init_seconds"), self.hls_init_seconds, 0.0, min(4.0, self.hls_segment_seconds))
            self.hls_start_segments = parse_int_range(data.get("hls_start_segments"), self.hls_start_segments, 0, 10)
            self.hlsjs_max_buffer_seconds = parse_int_range(data.get("hlsjs_max_buffer_seconds"), self.hlsjs_max_buffer_seconds, 30, 600)
            self.direct_read_mode = normalize_direct_read_mode(data.get("direct_read_mode") or self.direct_read_mode)
            self.ffmpeg_buffer_preset = normalize_ffmpeg_buffer_preset(data.get("ffmpeg_buffer_preset") or self.ffmpeg_buffer_preset)
            self.audio_offset_ms = parse_audio_offset_ms(data.get("audio_offset_ms"), default=self.audio_offset_ms)
            self._apply_video_settings_to_bridge()
            await self.connect_to_sagetv()
        elif msg_type == "disconnect":
            await self.send_log("Browser requested disconnect")
            await self.close(keep_ws=True)
        elif msg_type == "videoSettings":
            await self.apply_video_settings(data, restart_if_running=True)
        elif msg_type == "videoRestart":
            reason = str(data.get("reason") or "browser requested video restart")
            await self.restart_video_bridge(reason=reason)
        elif msg_type == "localMediaControl":
            await self.handle_local_media_control(str(data.get("action") or ""))
        elif msg_type == "resize":
            self.size.width = int(data.get("width") or self.size.width)
            self.size.height = int(data.get("height") or self.size.height)
            await self.post_resize(self.size.width, self.size.height)
        elif msg_type == "key":
            key = data.get("key") or ""
            code = int(data.get("keyCode") or 0)
            await self.post_key(code, key)
        elif msg_type == "command":
            cmd = str(data.get("command") or "").lower()
            if cmd in SAGE_COMMANDS:
                await self.post_sage_command(SAGE_COMMANDS[cmd])
                try:
                    await self.maybe_apply_local_seek_command(str(cmd))
                except Exception as exc:
                    await self.send_log(f"Local Direct/Web seek mirror failed for {cmd}: {exc}")
            else:
                await self.send_log(f"Unknown command: {cmd}")
        elif msg_type == "remoteCommand":
            # v137: Android/Web-Remote style buttons prefer the raw IR code when
            # SageCommand.java defines one.  This matches SageTV's green Web
            # Remote behavior better for STVs that listen for remote IR events.
            # Commands without an IR mapping still use the normal Sage command.
            cmd = str(data.get("command") or "").lower()
            sent = False
            if cmd in SAGE_IR_CODES:
                await self.post_ir(SAGE_IR_CODES[cmd], label=cmd)
                sent = True
            elif cmd in SAGE_COMMANDS:
                await self.post_sage_command(SAGE_COMMANDS[cmd])
                sent = True
            if sent:
                try:
                    await self.maybe_apply_local_seek_command(str(cmd))
                except Exception as exc:
                    await self.send_log(f"Local Direct/Web seek mirror failed for remote {cmd}: {exc}")
            else:
                await self.send_log(f"Unknown remote command: {cmd}")
        elif msg_type == "ir":
            try:
                await self.post_ir(int(data.get("code")), label=str(data.get("label") or ""))
            except Exception as exc:
                await self.send_log(f"Invalid IR event from browser: {data} ({exc})")
        elif msg_type == "mouse":
            await self.post_mouse(data)
        else:
            await self.send_log(f"Unhandled browser message: {data}")


    def _read_video_settings_from_message(self, data: dict) -> dict:
        enc = str(data.get("video_encoder") or self.video_encoder or "auto")
        max_h = parse_max_height(data.get("video_max_height"), default=self.video_max_height)
        bitrate = normalize_bitrate_choice(data.get("video_bitrate") or self.video_bitrate or "source")
        fps = normalize_video_fps_choice(data.get("video_fps") or self.video_fps or "source")
        audio_bitrate = normalize_audio_bitrate_choice(data.get("audio_bitrate") or self.audio_bitrate or "128k")
        encoder_latency_mode = normalize_encoder_latency_mode(data.get("encoder_latency_mode") or self.encoder_latency_mode or "faststart")
        qsv_decode_mode = normalize_qsv_decode_mode(data.get("qsv_decode_mode") or self.qsv_decode_mode or "auto")
        qsv_filter_mode = normalize_qsv_filter_mode(data.get("qsv_filter_mode") or self.qsv_filter_mode or "auto")
        hls_mode = str(data.get("hls_mode") or self.hls_mode or "stable").strip().lower()
        if hls_mode not in ("stable", "rolling", "debug"):
            hls_mode = "stable"
        player = normalize_player_mode(data.get("player_mode") or self.player_mode or "hls")
        buffer_preset = normalize_buffer_preset(data.get("buffer_preset") or self.buffer_preset)
        hls_segment_seconds = parse_float_range(data.get("hls_segment_seconds"), self.hls_segment_seconds, 1.0, 12.0)
        hls_init_seconds = parse_float_range(data.get("hls_init_seconds"), self.hls_init_seconds, 0.0, min(4.0, hls_segment_seconds))
        hls_start_segments = parse_int_range(data.get("hls_start_segments"), self.hls_start_segments, 0, 10)
        hlsjs_max_buffer_seconds = parse_int_range(data.get("hlsjs_max_buffer_seconds"), self.hlsjs_max_buffer_seconds, 30, 600)
        direct_read_mode = normalize_direct_read_mode(data.get("direct_read_mode") or self.direct_read_mode)
        ffmpeg_buffer_preset = normalize_ffmpeg_buffer_preset(data.get("ffmpeg_buffer_preset") or self.ffmpeg_buffer_preset)
        audio_offset = parse_audio_offset_ms(data.get("audio_offset_ms"), default=self.audio_offset_ms)
        return {
            "video_encoder": enc,
            "video_max_height": max_h,
            "video_bitrate": bitrate,
            "video_fps": fps,
            "audio_bitrate": audio_bitrate,
            "encoder_latency_mode": encoder_latency_mode,
            "qsv_decode_mode": qsv_decode_mode,
            "qsv_filter_mode": qsv_filter_mode,
            "hls_mode": hls_mode,
            "player_mode": player,
            "buffer_preset": buffer_preset,
            "hls_segment_seconds": hls_segment_seconds,
            "hls_init_seconds": hls_init_seconds,
            "hls_start_segments": hls_start_segments,
            "hlsjs_max_buffer_seconds": hlsjs_max_buffer_seconds,
            "direct_read_mode": direct_read_mode,
            "ffmpeg_buffer_preset": ffmpeg_buffer_preset,
            "audio_offset_ms": audio_offset,
            "playback_source": normalize_playback_source(data.get("playback_source") or self.playback_source),
            "no_fallback": True,
            "direct_sage_root": str(data.get("direct_sage_root") if data.get("direct_sage_root") is not None else self.direct_sage_root),
            "direct_local_root": str(data.get("direct_local_root") if data.get("direct_local_root") is not None else self.direct_local_root),
            "direct_path_map": encode_direct_path_map(parse_direct_path_map(data.get("direct_path_map") if data.get("direct_path_map") is not None else self.direct_path_map)),
            "hls_storage_mode": (str(data.get("hls_storage_mode") or self.hls_storage_mode or "disk").strip().lower() if str(data.get("hls_storage_mode") or self.hls_storage_mode or "disk").strip().lower() in ("disk", "temp", "ram") else "disk"),
            "hls_ram_root": str(data.get("hls_ram_root") if data.get("hls_ram_root") is not None else self.hls_ram_root),
            "web_interface_server": normalize_sagex_base(data.get("web_interface_server") if data.get("web_interface_server") is not None else self.web_interface_server, self.server),
            "web_interface_username": str(data.get("web_interface_username") if data.get("web_interface_username") is not None else self.web_interface_username),
            "web_interface_password": str(data.get("web_interface_password") if data.get("web_interface_password") is not None else self.web_interface_password),
        }

    def _apply_video_settings_to_bridge(self):
        self.video.encoder_request = self.video_encoder
        self.video.max_height = self.video_max_height
        self.video.video_bitrate = self.video_bitrate
        self.video.video_fps = self.video_fps
        self.video.audio_bitrate = self.audio_bitrate
        self.video.encoder_latency_mode = self.encoder_latency_mode
        self.video.qsv_decode_mode = self.qsv_decode_mode
        self.video.qsv_filter_mode = self.qsv_filter_mode
        self.video.hls_mode = self.hls_mode
        self.video.hls_time = self.hls_segment_seconds
        self.video.hls_init_time = self.hls_init_seconds
        self.video.hls_start_segments = self.hls_start_segments
        self.video.hlsjs_max_buffer_seconds = self.hlsjs_max_buffer_seconds
        self.video.direct_read_realtime = (self.direct_read_mode == "realtime")
        self.video.direct_read_mode = self.direct_read_mode
        self.video.ffmpeg_buffer_preset = self.ffmpeg_buffer_preset
        self.video.hls_storage_mode = self.hls_storage_mode
        self.video.hls_ram_root = self.hls_ram_root
        self.video.buffer_preset = self.buffer_preset
        self.video.player_mode = self.player_mode
        self.video.audio_offset_ms = self.audio_offset_ms
        self.video.capture_push_stream = self.hls_mode == "debug"
        # Keep playback resilient: if the selected hardware encoder starts but never
        # produces the first HLS segment, automatically retry with libx264. This
        # matters for imported AVI/MPEG4 videos where QSV can stall before HLS is ready.
        # Set SAGEWEB_STRICT_ENCODER=1 only when intentionally debugging hardware.
        self.video.allow_internal_fallback = os.environ.get("SAGEWEB_STRICT_ENCODER", "0").lower() not in ("1", "true", "yes", "on")
        # Show the selected source in debug even before FFmpeg starts.
        # Starters still set direct path / pull URL immediately before start().
        if not self.video.status.running:
            self.video.input_source = self.playback_source if self.playback_source in ("direct", "pull", "push") else "auto"
            self.video.direct_input_path = ""
            self.video.pull_url = ""

    async def apply_video_settings(self, data: dict, restart_if_running: bool = True):
        new_settings = self._read_video_settings_from_message(data)
        old_settings = {
            "video_encoder": self.video_encoder,
            "video_max_height": self.video_max_height,
            "video_bitrate": self.video_bitrate,
            "video_fps": self.video_fps,
            "audio_bitrate": self.audio_bitrate,
            "qsv_decode_mode": self.qsv_decode_mode,
            "qsv_filter_mode": self.qsv_filter_mode,
            "encoder_latency_mode": self.encoder_latency_mode,
            "qsv_decode_mode": self.qsv_decode_mode,
            "qsv_filter_mode": self.qsv_filter_mode,
            "hls_mode": self.hls_mode,
            "player_mode": self.player_mode,
            "buffer_preset": self.buffer_preset,
            "hls_segment_seconds": self.hls_segment_seconds,
            "hls_init_seconds": self.hls_init_seconds,
            "hls_start_segments": self.hls_start_segments,
            "hlsjs_max_buffer_seconds": self.hlsjs_max_buffer_seconds,
            "direct_read_mode": self.direct_read_mode,
            "ffmpeg_buffer_preset": self.ffmpeg_buffer_preset,
            "audio_offset_ms": self.audio_offset_ms,
            "playback_source": self.playback_source,
            "no_fallback": self.no_fallback,
            "direct_sage_root": self.direct_sage_root,
            "direct_local_root": self.direct_local_root,
            "direct_path_map": self.direct_path_map,
            "hls_storage_mode": self.hls_storage_mode,
            "hls_ram_root": self.hls_ram_root,
            "web_interface_server": self.web_interface_server,
            "web_interface_username": self.web_interface_username,
            "web_interface_password": self.web_interface_password,
        }
        changed = [k for k, v in new_settings.items() if old_settings.get(k) != v]
        self.video_encoder = new_settings["video_encoder"]
        self.video_max_height = new_settings["video_max_height"]
        self.video_bitrate = new_settings["video_bitrate"]
        self.video_fps = new_settings["video_fps"]
        self.audio_bitrate = new_settings["audio_bitrate"]
        self.encoder_latency_mode = new_settings["encoder_latency_mode"]
        self.qsv_decode_mode = new_settings["qsv_decode_mode"]
        self.qsv_filter_mode = new_settings["qsv_filter_mode"]
        self.hls_mode = new_settings["hls_mode"]
        self.player_mode = new_settings["player_mode"]
        self.buffer_preset = new_settings["buffer_preset"]
        self.hls_segment_seconds = new_settings["hls_segment_seconds"]
        self.hls_init_seconds = new_settings["hls_init_seconds"]
        self.hls_start_segments = new_settings["hls_start_segments"]
        self.hlsjs_max_buffer_seconds = new_settings["hlsjs_max_buffer_seconds"]
        self.direct_read_mode = new_settings["direct_read_mode"]
        self.ffmpeg_buffer_preset = new_settings["ffmpeg_buffer_preset"]
        self.audio_offset_ms = new_settings["audio_offset_ms"]
        self.playback_source = new_settings["playback_source"]
        self.no_fallback = new_settings["no_fallback"]
        self.direct_sage_root = new_settings["direct_sage_root"]
        self.direct_local_root = new_settings["direct_local_root"]
        self.direct_path_map = new_settings["direct_path_map"]
        self.hls_storage_mode = new_settings["hls_storage_mode"]
        self.hls_ram_root = new_settings["hls_ram_root"]
        self.web_interface_server = new_settings["web_interface_server"]
        self.web_interface_username = new_settings["web_interface_username"]
        self.web_interface_password = new_settings["web_interface_password"]
        self._apply_video_settings_to_bridge()
        if not changed:
            return
        desc = ", ".join(changed)
        await self.send_log(
            f"Video settings updated live: encoder={self.video_encoder}, latency={self.encoder_latency_mode}, qsvDecode={self.qsv_decode_mode}, qsvFilter={self.qsv_filter_mode}, maxH={'source' if not self.video_max_height else self.video_max_height}, bitrate={self.video_bitrate}, fps={self.video_fps}, audio={self.audio_bitrate}, player={self.player_mode}, hls={self.hls_mode}, buffer={self.buffer_preset}/{self.hls_init_seconds:g}s-init/{self.hls_segment_seconds:g}s-max/{self.hls_start_segments}seg/sourceFill={self.direct_read_mode}, ffmpegBuffer={self.ffmpeg_buffer_preset}, audioOffset={self.audio_offset_ms}ms, source={self.playback_source}, web={self.web_interface_server}, storage={self.hls_storage_mode}, strict=True"
        )
        source_keys = {"playback_source", "direct_sage_root", "direct_local_root", "direct_path_map", "web_interface_server", "web_interface_username", "web_interface_password"}
        source_changed = bool(source_keys.intersection(changed))
        restart_keys = [k for k in changed if k not in source_keys]

        # v74: Source changes should not tear down the whole SageTV GUI/media
        # session.  Stop only the local FFmpeg/PULL bridge, keep the MiniClient
        # sockets connected, then try to restart video from the current OPENURL
        # using the newly selected source.  Source=Auto remains the only fallback
        # mode; explicit Direct/PULL/PUSH choices stay strict.
        if restart_if_running and source_changed:
            await self.restart_current_source(reason=f"source/path changed: {desc}")
            return

        if source_changed and self.connected:
            await self.send_log("Playback Source/path changed; it will take effect on the next SageTV OPENURL.")
        if restart_if_running and self.video.status.running and restart_keys:
            await self.restart_video_bridge(reason=f"video settings changed: {desc}")

    async def restart_current_source(self, reason: str = "source changed", reset_quality: bool = True):
        """Stop local playback and restart with the selected Source without reconnecting SageTV.

        This keeps the GUI/media sockets alive.  It reuses the current MEDIACMD_OPENURL
        when Direct/PULL can be started from the existing file/stv URL.  PUSHBUFFER can
        only resume without a reconnect if SageTV is already sending PUSHBUFFER data;
        otherwise the user must select Auto or change media so SageTV sends a new OPENURL.
        """
        open_url = self.media.status.url or self.video.media_url or ""
        open_low = open_url.lower()
        was_running = bool(self.video.status.running or self.pull_task)
        await self.send_log(f"Playback Source/path changed; stopping local video only and restarting from current OPENURL ({reason}).")
        try:
            await self.stop_pull_pump()
            await self.video.stop(remove_files=True, keep_prebuffer=False)
            await self.send({"type": "videoStop", "status": self.video.status.to_json()})
        except Exception as exc:
            await self.send_log(f"Could not fully stop current video before source restart: {exc}")

        # Refresh the selected-source text in Video Debug while stopped.
        self._apply_video_settings_to_bridge()
        await self.send({"type": "videoStatus", "status": self.video.status.to_json()})

        if not open_url:
            await self.send_log("Source restart skipped: SageTV has not sent a media URL yet. The new Source will be used on the next OPENURL.")
            return

        try:
            src_mode = self.playback_source
            if src_mode == "direct":
                cached_direct = self.video.direct_input_path or self.direct_last_path
                if self.media.status.push_mode or open_low.startswith("push:"):
                    if cached_direct:
                        if await self.start_direct_path_stream(cached_direct, url=(self.direct_last_url or self.video.media_url or ""), reason=f"Source restart direct using cached path because current OPENURL is PUSHBUFFER-only ({reason})", reset_quality=reset_quality):
                            await self.send_log(f"Direct File/SMB restarted from cached path without SageTV reconnect: {cached_direct}")
                    else:
                        if self.media.status.push_mode:
                            await self.start_push_stream(reset_quality=reset_quality)
                            await self.send_log("Source restart Direct File/SMB fallback: current OPENURL is PUSHBUFFER-only and no cached Direct path is available, so PUSHBUFFER was started.")
                        else:
                            await self.send_log("Source restart could not use Direct File/SMB because the current OPENURL is PUSHBUFFER only and no cached Direct path is available.")
                    return
                if await self.start_direct_file_stream(open_url, reason=f"Source restart direct ({reason})", reset_quality=reset_quality):
                    await self.send_log(f"Direct File/SMB restarted without SageTV reconnect for OPENURL: {open_url[:160]}")
                elif cached_direct:
                    if await self.start_direct_path_stream(cached_direct, url=(self.direct_last_url or open_url), reason=f"Source restart direct using cached path after mapping failed ({reason})", reset_quality=reset_quality):
                        await self.send_log(f"Direct File/SMB restarted from cached path after OPENURL remap failed: {cached_direct}")
                else:
                    await self.send_log("Source restart Direct File/SMB failed. Explicit source mode is strict; no fallback was used. Use Source=Auto to allow fallback.")
            elif src_mode == "pull":
                if open_low.startswith("stv://"):
                    await self.start_pull_stream_fallback(open_url, reset_quality=reset_quality)
                    await self.send_log("SageTV PULL restarted without SageTV reconnect for current stv:// OPENURL.")
                else:
                    await self.send_log(f"Source restart could not use SageTV PULL because the current OPENURL is not stv:// ({open_url[:120]}). Explicit PULL mode is strict; no fallback was used.")
            elif src_mode == "push":
                if self.media.status.push_mode or open_low.startswith("push:"):
                    await self.start_push_stream(reset_quality=reset_quality)
                    await self.send_log("PUSHBUFFER bridge restarted without SageTV reconnect and is waiting for SageTV PUSHBUFFER data.")
                else:
                    await self.send_log("Source restart could not switch to PUSHBUFFER because the current OPENURL is a file/stv URL. A full reconnect or new media OPENURL is required for SageTV to change advertised media mode to PUSH.")
            else:  # auto
                cached_direct = self.video.direct_input_path or self.direct_last_path
                if not self.media.status.push_mode and await self.start_direct_file_stream(open_url, reason=f"Source restart auto/direct ({reason})", reset_quality=reset_quality):
                    await self.send_log(f"Auto source restart selected Direct File/SMB for current OPENURL: {open_url[:160]}")
                elif cached_direct and (self.video.input_source == "direct" or self.direct_last_path):
                    await self.start_direct_path_stream(cached_direct, url=(self.direct_last_url or self.video.media_url or ""), reason=f"Source restart auto/direct cached path ({reason})", reset_quality=reset_quality)
                    await self.send_log(f"Auto source restart kept Direct File/SMB using cached path: {cached_direct}")
                elif open_low.startswith("stv://"):
                    await self.start_pull_stream_fallback(open_url, reset_quality=reset_quality)
                    await self.send_log("Auto source restart selected SageTV PULL for current stv:// OPENURL.")
                elif self.media.status.push_mode or open_low.startswith("push:"):
                    await self.start_push_stream(reset_quality=reset_quality)
                    await self.send_log("Auto source restart selected PUSHBUFFER and is waiting for SageTV PUSHBUFFER data.")
                else:
                    await self.send_log(f"Auto source restart could not start direct/pull/push for current OPENURL: {open_url[:160]}")
        except Exception as exc:
            self.video.status.last_error = str(exc)
            await self.send_log(f"Source restart failed: {exc}")
            if was_running:
                await self.send({"type": "videoStatus", "status": self.video.status.to_json()})

    async def restart_video_bridge(self, reason: str = "video restart requested"):
        if not self.video.status.running:
            await self.send_log(f"Video restart ignored because FFmpeg is not running ({reason})")
            return
        try:
            playlist = await self.video.restart_with_current_settings(reason=reason)
            await self.send({"type": "videoStream", "url": playlist, "status": self.video.status.to_json()})
            await self.send_log(f"Video bridge restarted live: {playlist} ({reason})")
        except Exception as exc:
            self.video.status.last_error = str(exc)
            await self.send_log(f"Video bridge live restart failed: {exc}")

    def _local_seek_delta_for_command(self, cmd: str) -> int:
        """Return a local seek delta for SageTV skip commands.

        When Direct File/SMB was resolved by the SageX API while the active
        SageTV OPENURL is still PUSHBUFFER, SageTV can update its OSD/timeline
        but may not send MEDIACMD_SEEK to the MiniClient media socket.  PUSHBUFFER
        mode works because SageTV sends new stream bytes.  Direct mode must seek
        FFmpeg locally, so mirror the common skip/rew commands here.
        """
        c = str(cmd or "").strip().lower()
        def env_ms(name: str, default: int) -> int:
            try:
                return int(float(os.environ.get(name, str(default))))
            except Exception:
                return default
        if c in ("ff", "skip_fwd"):
            return env_ms("SAGEWEB_LOCAL_FF_MS", 10000)
        if c in ("rew", "skip_back"):
            return -env_ms("SAGEWEB_LOCAL_REW_MS", 10000)
        if c in ("ff_2", "skip_fwd_2", "forward"):
            return env_ms("SAGEWEB_LOCAL_SKIP_FORWARD_MS", 30000)
        if c in ("rew_2", "skip_back_2"):
            return -env_ms("SAGEWEB_LOCAL_SKIP_BACK_MS", 10000)
        return 0

    def _set_media_time_for_local_seek(self, target_ms: int):
        target_ms = max(0, int(target_ms))
        self.media.status.media_time_ms = target_ms
        self.media.status.play_started_media_ms = target_ms
        self.media.status.last_seek_ms = target_ms
        self.media.status.last_seek_at = time.monotonic()
        self.media.status.play_started_at = time.monotonic() if self.media.status.state == PLAY_STATE else 0.0

    async def _restart_current_direct_like_stream_at(self, target_ms: int, reason: str) -> bool:
        """Restart the local FFmpeg stream at a SageTV media time.

        This is for Direct File/SMB or internal SageX API HTTP fallback only.
        PUSHBUFFER is intentionally left alone because SageTV controls seek there.
        """
        if not self.video.status.running:
            return False
        src = str(self.video.input_source or "").lower()
        if src not in ("direct", "web"):
            return False
        now = time.monotonic()
        target_ms = max(0, int(target_ms))
        if self._last_direct_seek_restart_target_ms >= 0:
            if abs(target_ms - self._last_direct_seek_restart_target_ms) < 750 and (now - self._last_direct_seek_restart_at) < 1.25:
                return False
        self._last_direct_seek_restart_target_ms = target_ms
        self._last_direct_seek_restart_at = now
        self._set_media_time_for_local_seek(target_ms)
        if src == "direct":
            cached_direct = self.video.direct_input_path or self.direct_last_path
            if not cached_direct:
                return False
            await self.start_direct_path_stream(
                cached_direct,
                url=(self.direct_last_url or self.video.media_url or self.media.status.url or ""),
                reason=f"{reason}; local direct seek target={target_ms}ms",
            )
            await self.send_log(f"Direct File/SMB local seek restart at {target_ms}ms ({reason})")
            return True
        if src == "web" and self.video.direct_input_path:
            await self.start_web_http_stream(
                self.video.direct_input_path,
                url=self.direct_last_url or self.video.media_url or self.media.status.url,
                reason=f"{reason}; local web seek target={target_ms}ms",
            )
            await self.send_log(f"SageX API HTTP fallback local seek restart at {target_ms}ms ({reason})")
            return True
        return False

    async def maybe_restart_direct_from_push_mux(self, result) -> bool:
        """Use PUSHBUFFER mux/request timestamps as seek hints for Direct mode.

        Source=Direct can still receive PUSHBUFFER commands when SageTV opened a
        push: URL and the SageX API was used only to find the backing file.
        In this hybrid mode we intentionally play the resolved file locally but
        keep the PUSHBUFFER control channel alive. SageTV may send zero-byte
        PUSHBUFFER timing packets after skip/seek; those request times are used
        to restart FFmpeg at the same media time.
        """
        if not (self.video.status.running and self.video.input_source in ("direct", "web")):
            return False
        if not self.media.status.push_mode:
            return False
        if self.video.input_source == "direct" and not self.direct_push_timing_control:
            return False
        mux = getattr(result, "push_mux_time_ms", None)
        if mux is None or int(mux) < 0:
            return False
        mux = int(mux)
        cur = self.media.status.current_media_time_ms()
        # Normal PUSHBUFFER timing packets track the current play time. A larger
        # jump, or a pending FLUSH with no explicit MEDIACMD_SEEK, means SageTV
        # changed position and expects the PUSH pipeline to carry the seek.
        if not self._await_push_timing_seek and not getattr(result, "push_seek_hint", False) and abs(mux - int(cur)) <= 4000:
            return False
        self._await_push_timing_seek = False
        return await self._restart_current_direct_like_stream_at(mux, "PUSHBUFFER request/mux time seek hint")

    async def maybe_poll_sagex_timeline_seek(self) -> bool:
        """Use SageX GetRawMediaTime as a seek/timeline fallback.

        Some imported/video-library files opened as PUSHBUFFER update the SageTV
        OSD timeline but do not send a useful MEDIACMD_SEEK or PUSHBUFFER mux
        time to the MiniClient media socket.  When Direct File/SMB is using a
        SageX-resolved file path, keep FFmpeg on the resolved file and poll
        SageX for the current RawMediaTime.  A jump larger than the normal
        drift threshold is treated as SageTV's requested seek target.
        """
        if not (self.video.status.running and self.video.input_source in ("direct", "web")):
            return False
        detail_source = str((self.sage_detail_cache or {}).get("source") or "").lower()
        if not (self.direct_push_timing_control or detail_source == "sagex"):
            return False
        now = time.monotonic()
        poll_interval = float(os.environ.get("SAGEWEB_SAGEX_TIMELINE_POLL_SECONDS", "0.50") or "0.50")
        poll_interval = max(0.20, min(2.0, poll_interval))
        if now - self._sagex_timeline_last_poll_at < poll_interval:
            return False
        self._sagex_timeline_last_poll_at = now
        base = normalize_sagex_base(self.web_interface_server, self.server)
        try:
            raw_ms, duration_ms, why = await asyncio.to_thread(
                sagex_get_timeline,
                base,
                self.web_interface_username,
                self.web_interface_password,
                self.client_id,
                3.0,
            )
        except Exception as exc:
            if now - self._sagex_timeline_last_error_at > 10.0:
                self._sagex_timeline_last_error_at = now
                await self.send_log(f"SageX timeline poll failed: {exc}")
            return False
        if raw_ms is None or int(raw_ms) < 0:
            if now - self._sagex_timeline_last_error_at > 10.0:
                self._sagex_timeline_last_error_at = now
                await self.send_log(f"SageX timeline poll did not return RawMediaTime: {why}")
            return False
        raw_ms = int(raw_ms)
        if duration_ms and duration_ms > 0:
            # Clamp to a sane seek position for FFmpeg.
            raw_ms = max(0, min(raw_ms, int(duration_ms) + 30000))
        local_ms = int(self.media.status.current_media_time_ms())
        drift_ms = abs(raw_ms - local_ms)
        threshold_ms = int(float(os.environ.get("SAGEWEB_SAGEX_SEEK_DRIFT_MS", "2500") or "2500"))
        threshold_ms = max(500, min(15000, threshold_ms))
        if drift_ms < threshold_ms:
            return False
        # Do not keep restarting for the same SageX value while FFmpeg is catching up.
        if self._sagex_timeline_last_seek_ms >= 0:
            if abs(raw_ms - self._sagex_timeline_last_seek_ms) < 750 and (now - self._sagex_timeline_last_seek_at) < 3.0:
                return False
        self._sagex_timeline_last_seek_ms = raw_ms
        self._sagex_timeline_last_seek_at = now
        ok = await self._restart_current_direct_like_stream_at(raw_ms, f"SageX RawMediaTime seek/timeline poll ({why}; local={local_ms}ms drift={drift_ms}ms)")
        if ok:
            await self.send_log(f"SageX timeline jump mirrored to Direct File/SMB: {raw_ms}ms (local was {local_ms}ms, drift {drift_ms}ms)")
        return ok

    async def maybe_apply_local_seek_command(self, cmd: str) -> bool:
        delta = self._local_seek_delta_for_command(cmd)
        if not delta:
            return False
        if not (self.video.status.running and self.video.input_source in ("direct", "web")):
            return False
        # Only mirror SageTV skip locally for PUSH-backed Direct/Web playback. If
        # SageTV gave us a normal file/stv URL it should send MEDIACMD_SEEK and
        # the regular seek handler will restart FFmpeg.
        if not self.media.status.push_mode:
            return False
        target = max(0, self.media.status.current_media_time_ms() + delta)
        return await self._restart_current_direct_like_stream_at(target, f"browser SageTV command {cmd}")

    async def handle_local_media_control(self, action: str):
        """Apply browser-side media keys to the local HLS bridge immediately.

        SageTV sometimes treats the first Stop/Play/Pause key as an OSD/menu key
        while video continues.  The HTML5 client owns the real browser video/HLS
        element, so mirror those keys locally instead of waiting for SageTV to
        send MEDIACMD_STOP/PAUSE/PLAY.
        """
        action = (action or "").strip().lower()
        if action == "stop":
            self.media.status.set_state(STOPPED_STATE)
            try:
                await self.stop_pull_pump()
            except BaseException:
                pass
            try:
                await self.video.stop(remove_files=True)
            except Exception as exc:
                self.video.status.last_error = str(exc)
                await self.send_log(f"Local media stop could not fully stop FFmpeg: {exc}")
            await self.send({"type": "videoStop", "status": self.video.status.to_json()})
            await self.send({"type": "mediaStatus", "status": self.media.status.to_json()})
            await self.send({"type": "videoStatus", "status": self.video.status.to_json()})
            await self.send_log("Local media stop applied from browser command")
            return
        if action == "pause":
            self.media.status.set_state(PAUSE_STATE)
            await self.send({"type": "mediaStatus", "status": self.media.status.to_json()})
            await self.send({"type": "videoStatus", "status": self.video.status.to_json()})
            await self.send_log("Local media pause applied from browser command")
            return
        if action == "play":
            self.media.status.set_state(PLAY_STATE)
            await self.send({"type": "mediaStatus", "status": self.media.status.to_json()})
            await self.send({"type": "videoStatus", "status": self.video.status.to_json()})
            await self.send_log("Local media play applied from browser command")
            return
        await self.send_log(f"Unknown local media control: {action}")

    async def connect_to_sagetv(self):
        await self.close(keep_ws=True)
        host, port = parse_server(self.server)
        await self.send_log(f"Connecting to SageTV {host}:{port} with client ID {self.client_id} (requested {self.requested_client_id}); source={self.playback_source}; strictSource={self.playback_source != 'auto'}; directRoot={self.direct_sage_root or '(none)'} -> {self.direct_local_root or '(none)'}; directMaps={len(parse_direct_path_map(self.direct_path_map))}")
        try:
            # conn_type 1 = media, conn_type 0 = gfx/events, matching Java MiniClient.
            self.media_reader, self.media_writer = await open_sagetv_socket(host, port, 1, self.client_id)
            await self.send_log("Media socket accepted")
            self.gfx_reader, self.gfx_writer = await open_sagetv_socket(host, port, 0, self.client_id)
            await self.send_log("GFX socket accepted")
            self.connected = True
            self.media_task = asyncio.create_task(self.media_loop(), name=f"media-{self.session_id}")
            self.gfx_task = asyncio.create_task(self.gfx_loop(), name=f"gfx-{self.session_id}")
            await self.post_resize(self.size.width, self.size.height)
        except Exception as e:
            self.last_error = str(e)
            await self.send_log(f"SageTV connect failed: {e}")
            await self.close(keep_ws=True)

    async def close(self, keep_ws: bool = False):
        self.connected = False
        for task_name in ("gfx_task", "media_task", "pull_task"):
            task = getattr(self, task_name, None)
            if task and not task.done():
                task.cancel()
            setattr(self, task_name, None)
        self.pull_pump = None
        for writer_name in ("gfx_writer", "media_writer"):
            writer = getattr(self, writer_name)
            if writer:
                try:
                    writer.close()
                    await writer.wait_closed()
                except Exception:
                    pass
            setattr(self, writer_name, None)
        self.gfx_reader = None
        self.media_reader = None
        try:
            await self.video.stop(remove_files=True)
        except Exception:
            pass
        if not keep_ws:
            self.ws_closed = True
            try:
                if self.ws.application_state == WebSocketState.CONNECTED:
                    await self.ws.close()
            except Exception:
                pass

    async def reconnect_media_socket(self, reason: str = "MEDIA_RECONNECT"):
        """Reconnect only the SageTV media socket, matching Java MiniClient behavior.

        SageTV can send GFXCMD_MEDIA_RECONNECT on the GFX/event channel when
        playback stops, errors, or changes. The Java MiniClient closes the media
        socket and lets the media thread reconnect. If we ignore it, SageTV can
        show "There was a Playback Error in Playback" and the UI can become
        unresponsive after stopping a video.
        """
        await self.send_log(f"GFX MEDIA_RECONNECT requested; reconnecting media socket ({reason})")
        current = asyncio.current_task()
        if self.media_task and self.media_task is not current and not self.media_task.done():
            self.media_task.cancel()
        self.media_task = None
        await self.stop_pull_pump()
        try:
            await self.video.stop(remove_files=True)
            await self.send({"type": "videoStop", "status": self.video.status.to_json()})
        except Exception:
            pass
        if self.media_writer:
            try:
                self.media_writer.close()
                await self.media_writer.wait_closed()
            except Exception:
                pass
        self.media_reader = None
        self.media_writer = None
        if not self.connected:
            return
        try:
            host, port = parse_server(self.server)
            self.media = MediaCommandParser()
            self.media_reader, self.media_writer = await open_sagetv_socket(host, port, 1, self.client_id)
            await self.send_log("Media socket reconnected")
            self.media_task = asyncio.create_task(self.media_loop(), name=f"media-{self.session_id}")
        except Exception as exc:
            self.last_error = str(exc)
            await self.send_log(f"Media reconnect failed: {exc}")


    async def gfx_loop(self):
        assert self.gfx_reader is not None
        await self.send_log("GFX loop running")
        try:
            while self.connected:
                header = await self.gfx_reader.readexactly(4)
                cmd_type = header[0]
                length = int.from_bytes(header[1:4], "big")
                payload = await self.gfx_reader.readexactly(length) if length else b""
                await self.handle_sagetv_packet(cmd_type, payload)
        except asyncio.CancelledError:
            pass
        except Exception as e:
            self.last_error = str(e)
            await self.send_log(f"GFX loop stopped: {e}")
            self.connected = False

    async def stop_pull_pump(self):
        if self.pull_task and not self.pull_task.done():
            self.pull_task.cancel()
            try:
                await self.pull_task
            except Exception:
                pass
        self.pull_task = None
        self.pull_pump = None

    async def start_pull_stream_fallback(self, url: str, reset_quality: bool = True):
        """Start SageTV stv:// PULL input.

        Source selection now controls whether SageTV is asked for PULL/file URLs
        or PUSHBUFFER. This pump reads from SageTV's port 7818 file streamer
        and feeds FFmpeg when PULL is selected or Source=Auto selects PULL.
        """
        await self.stop_pull_pump()
        self.video.input_source = "pull"
        self.video.pull_url = url
        self.video.direct_input_path = ""
        self.video.http_input_headers = ""
        self.video.input_seek_seconds = 0.0
        playlist = await self.video.start(reason="SageTV PULL input via stv://")
        await self.send({"type": "videoStream", "url": playlist, "status": self.video.status.to_json()})
        self.pull_pump = SagePullStreamPump(url=url, bridge=self.video, mode=self.direct_read_mode)

        async def _runner():
            await self.send_log(f"SageTV PULL input started for {url} (sourceFill={self.direct_read_mode})")
            try:
                await self.pull_pump.run()
            finally:
                bytes_read = self.pull_pump.bytes_read if self.pull_pump else 0
                err = self.pull_pump.last_error if self.pull_pump else ""
                if err:
                    await self.send_log(f"SageTV PULL input stopped with error: {err}")
                else:
                    await self.send_log(f"SageTV PULL input ended after {bytes_read} bytes")
                await self.send({"type": "videoStatus", "status": self.video.status.to_json()})

        self.pull_task = asyncio.create_task(_runner(), name=f"sage-pull-{self.session_id}")

    def _discover_direct_root(self, candidate: str) -> str:
        root = guess_sage_storage_root(candidate)
        if not root:
            return ""
        key = _norm_compare_path(_strip_url_to_path(root)).rstrip("/")
        # Do not add a blank discovered row if the legacy single-root fields
        # already cover this Sage root. v111 could show a duplicate blank
        # /var/media/videos entry even though Direct File/SMB was already mapped.
        if self.direct_sage_root and _norm_compare_path(_strip_url_to_path(self.direct_sage_root)).rstrip("/") == key:
            return root
        rows = parse_direct_path_map(self.direct_path_map)
        for row in rows:
            if _norm_compare_path(_strip_url_to_path(row.get("sage", ""))).rstrip("/") == key:
                return root
        rows.append({"sage": root, "local": ""})
        self.direct_path_map = encode_direct_path_map(rows)
        try:
            save_shared_direct_path_map_value(self.direct_path_map)
        except Exception:
            pass
        self._pending_direct_path_map_update = True
        return root

    async def _send_direct_path_map_update_if_needed(self, discovered_root: str = ""):
        if not self._pending_direct_path_map_update and not discovered_root:
            return
        self._pending_direct_path_map_update = False
        await self.send({
            "type": "directPathMapUpdate",
            "direct_path_map": self.direct_path_map,
            "discovered_sage_root": discovered_root,
        })

    def resolve_direct_media_path(self, url: str) -> tuple[str, str]:
        """Resolve a SageTV OPENURL file/stv URL to a local SMB/NFS path.

        Returns (local_path, reason).  Empty local_path means direct mode cannot
        be used for this URL.  Direct mode needs SageTV to provide either a
        file:// path, a plain path, or an stv:// path whose path part can be
        mapped to a local mounted/share path.
        """
        raw = str(url or "").strip()
        if not raw:
            return "", "OPENURL is empty"
        candidate = raw
        if raw.lower().startswith("push:"):
            candidate = _strip_url_to_path(raw)
            if not candidate:
                return "", "OPENURL is PUSHBUFFER and does not include a file path"
        elif raw.lower().startswith("stv://"):
            try:
                _host, stv_path = parse_stv_url(raw)
                candidate = stv_path
            except Exception as exc:
                return "", f"could not parse stv:// path: {exc}"
        elif re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*:", raw) and not raw.lower().startswith(("file://", "smb://")):
            return "", f"unsupported URL scheme for direct file mode: {raw.split(':',1)[0]}"

        local, matched_root, matched_had_local = find_direct_path_mapping(
            candidate,
            self.direct_sage_root,
            self.direct_local_root,
            self.direct_path_map,
        )
        if matched_root and not matched_had_local:
            return "", f"Direct Sage Root discovered but Local Root is blank: {matched_root}. Select it in Source / Server Paths and enter the matching SMB/local path."

        discovered_root = ""
        if not matched_root and _path_needs_mapping_for_platform(candidate):
            discovered_root = self._discover_direct_root(candidate)
            return "", f"New Sage Root discovered and added to the mapping list: {discovered_root} = . Enter the matching Local Root and click Save Root Mapping."

        local = (local or "").strip()
        if not local:
            return "", "direct mapping produced an empty path"

        # If the user supplied a mapping, require the mapped target to exist. If
        # there is no mapping, still allow Windows UNC paths because Python may be
        # running on Windows and Path.exists() can be slow/fail before credentials
        # are available. FFmpeg's error will be shown in the debug box if it fails.
        mapped = bool(matched_root and matched_had_local) or bool(self.direct_sage_root and self.direct_local_root) or bool(os.environ.get("SAGEWEB_DIRECT_PATH_MAP", ""))
        if mapped:
            # Do not block Direct File/SMB just because Path.exists() fails.
            # Windows UNC shares can return false until credentials are cached, and
            # FFmpeg may still be able to open the path.  Start the bridge and let
            # the FFmpeg error show in the debug tail if the share is actually bad.
            try:
                if not Path(local).exists():
                    return local, f"direct path resolved, but exists check failed or share is not browsable yet: {local}"
            except Exception as exc:
                return local, f"direct path resolved, but exists check could not be performed: {exc}"
        return local, "direct path resolved"

    async def start_direct_path_stream(self, local: str, url: str = "", reason: str = "direct file playback", reset_quality: bool = True, push_timing_control: bool = False) -> bool:
        """Start Direct File/SMB from an already-resolved local path.

        This is used both for normal Direct playback and for local-only restarts.
        It is important because SageTV can later report the active media URL as
        PUSHBUFFER-only even though we already resolved the matching SMB path.
        For encoder/player/buffer changes we should restart FFmpeg from the cached
        Direct path instead of forcing the user to leave/re-open the SageTV video.
        """
        local = str(local or "").strip()
        if not local:
            await self.send_log("Direct File/SMB not used: cached direct path is empty")
            return False
        await self.stop_pull_pump()
        await self.video.stop(remove_files=True, keep_prebuffer=False)
        self.direct_last_path = local
        if url:
            self.direct_last_url = url
        media_url = url or self.direct_last_url or self.video.media_url or self.media.status.url or ""
        self.video.media_url = media_url
        self.video.input_source = "direct"
        self.video.direct_input_path = local
        self.video.http_input_headers = ""
        self.video.pull_url = ""
        self.direct_push_timing_control = bool(push_timing_control)
        if not self.direct_push_timing_control:
            self._await_push_timing_seek = False
        self.video.input_seek_seconds = max(0.0, self.media.status.current_media_time_ms() / 1000.0)
        playlist = await self.video.start(reason=f"{reason}; start={self.video.input_seek_seconds:.3f}s")
        await self.send({"type": "videoStream", "url": playlist, "status": self.video.status.to_json()})
        ctl = " with PUSHBUFFER timing control" if self.direct_push_timing_control else ""
        await self.send_log(f"Direct File/SMB bridge started{ctl}: {local} -> {playlist}")
        return True

    async def start_direct_file_stream(self, url: str, reason: str = "direct file playback", reset_quality: bool = True) -> bool:
        local, why = self.resolve_direct_media_path(url)
        if self._pending_direct_path_map_update:
            await self._send_direct_path_map_update_if_needed()

        # SageX API is lookup-only now.  If SageTV gives Python a
        # PUSHBUFFER-only URL, an stv:// URL that cannot be mapped, or any other
        # unusable direct path, ask the SageX API for the current MediaFile
        # path and then play that path through Direct File/SMB.  Do not start
        # FFmpeg from Web HTTP/playlist URLs.
        if not local:
            detail, api_why = await self.fetch_web_or_detail_current_media("Direct File/SMB SageX API path lookup", open_url=url)
            detail_local, detail_why, detail_source = self.resolve_detail_cached_direct_path()
            if self._pending_direct_path_map_update:
                await self._send_direct_path_map_update_if_needed()

            # v129: If SageTV opened this session as PUSHBUFFER and Direct can
            # only find the file by asking the SageX API plugin, keep
            # using the resolved Direct File/SMB path as FFmpeg input, but keep
            # PUSHBUFFER alive as a timing/control channel. SageTV may not send
            # MEDIACMD_SEEK for this case; it updates the PUSHBUFFER request/mux
            # time instead. We mirror those request times into local Direct seeks.
            push_open = self.media.status.push_mode or str(url or "").lower().startswith("push:")

            if detail_local:
                self.direct_last_url = detail_source or url or self.direct_last_url
                if push_open:
                    self._await_push_timing_seek = False
                    await self.send_log(
                        "Direct File/SMB SageX API path lookup found a file for a SageTV PUSHBUFFER item; "
                        "using the resolved file as FFmpeg input and PUSHBUFFER only for timeline/seek timing."
                    )
                return await self.start_direct_path_stream(
                    detail_local,
                    url=detail_source or url,
                    reason=f"{reason}; SageX API path lookup; {detail_why}",
                    reset_quality=reset_quality,
                    push_timing_control=push_open,
                )
            web_url, web_why, web_source = self.resolve_detail_cached_web_url()
            if web_url:
                self.direct_last_url = web_source or url or self.direct_last_url
                return await self.start_web_http_stream(
                    web_url,
                    url=web_source or url,
                    reason=f"{reason}; SageX API HTTP fallback because Direct path was not mapped; {web_why}",
                    reset_quality=reset_quality,
                )
            why = f"{why}; SageX API path lookup not usable: {api_why}; {detail_why}; {web_why}"

        if not local:
            await self.send_log(f"Direct File/SMB not used: {why}")
            return False
        self.direct_last_url = url or self.direct_last_url
        return await self.start_direct_path_stream(local, url=url, reason=f"{reason}; {why}", reset_quality=reset_quality)

    async def start_push_stream(self, reset_quality: bool = True) -> None:
        await self.stop_pull_pump()
        await self.video.stop(remove_files=True, keep_prebuffer=False)
        self.direct_push_timing_control = False
        self._await_push_timing_seek = False
        self.video.input_source = "push"
        self.video.direct_input_path = ""
        self.video.http_input_headers = ""
        self.video.pull_url = ""
        self.video.input_seek_seconds = 0.0
        playlist = await self.video.start(reason="SageTV PUSHBUFFER input")
        await self.send({"type": "videoStream", "url": playlist, "status": self.video.status.to_json()})
        await self.send_log(f"FFmpeg HLS PUSH bridge started: {playlist} encoder={self.video.status.encoder}")

    async def media_loop(self):
        """Parse the SageTV media command socket.

        v22 does not decode/play video yet.  It implements the same framing as
        OpenSageTV MediaThread: one byte command, three byte big-endian length,
        payload bytes, then a raw media-command reply when required.  This lets
        SageTV believe a MiniClient media player exists and gives us an exact
        trace before FFmpeg/HLS is added.
        """
        assert self.media_reader is not None
        assert self.media_writer is not None
        await self.send_log("Media loop running in v132 SageX timeline video bridge mode")
        last_status_sent = 0.0
        try:
            while self.connected:
                header = await self.media_reader.readexactly(4)
                cmd = header[0]
                length = int.from_bytes(header[1:4], "big")
                payload = await self.media_reader.readexactly(length) if length else b""
                result = self.media.execute(cmd, payload)
                if result.reply:
                    self.media_writer.write(result.reply)
                    await self.media_writer.drain()

                # FFmpeg/HLS bridge.  SageTV still owns timeline/seek/comskip; Python
                # only converts the pushed native stream to a browser-safe HLS stream.
                if cmd == MEDIACMD_OPENURL and self.media_caps_enabled:
                    self.video.media_url = self.media.status.url or ""
                    self._ignored_pushbuffer_logged = False
                    self.direct_push_timing_control = False
                    self._await_push_timing_seek = False
                    src_mode = self.playback_source
                    open_url = self.media.status.url or ""
                    open_low = open_url.lower()
                    try:
                        if src_mode == "direct":
                            # Direct File/SMB is now direct-preferred instead of hard-strict.
                            # SageTV video-library items can advertise pure PUSHBUFFER with
                            # no file path at all.  Direct playback is impossible in that
                            # case, so fall back to the pushed stream while logging why.
                            if await self.start_direct_file_stream(open_url, reason="Playback Source=direct"):
                                await self.send_log(f"Direct File/SMB mode active for OPENURL: {open_url[:160]}")
                            elif self.media.status.push_mode:
                                await self.start_push_stream(reset_quality=True)
                                await self.send_log("Direct File/SMB fallback: SageTV sent PUSHBUFFER with no usable direct file path, so the PUSHBUFFER bridge was started. Direct File will be used automatically when SageTV provides a mapped file/stv path.")
                            else:
                                await self.send_log("Direct File/SMB could not start because the file path could not be mapped/opened and SageTV did not advertise PUSHBUFFER fallback. Use Source=Auto if SageTV may provide PULL.")
                        elif src_mode == "pull":
                            if open_low.startswith("stv://"):
                                await self.start_pull_stream_fallback(open_url, reset_quality=True)
                                await self.send_log("SageTV PULL mode active for stv:// OPENURL.")
                            else:
                                await self.send_log(f"Source is SageTV PULL, but OPENURL is not stv:// ({open_url[:120]}). Explicit PULL mode is strict; bridge not started. Use Source=Auto to allow fallback.")
                        elif src_mode == "push":
                            if self.media.status.push_mode:
                                await self.start_push_stream(reset_quality=True)
                            else:
                                await self.send_log(f"Source is PUSHBUFFER, but SageTV sent non-PUSH OPENURL ({open_url[:120]}). Explicit PUSHBUFFER mode is strict; bridge not started. Use Source=Auto to allow PULL/direct fallback.")
                        else:  # auto
                            # Try Direct first even for push: URLs because some SageTV
                            # PUSHBUFFER announcements include the backing file path.
                            if await self.start_direct_file_stream(open_url, reason="Playback Source=auto"):
                                await self.send_log(f"Auto source selected Direct File/SMB for OPENURL: {open_url[:160]}")
                            elif open_low.startswith("stv://"):
                                await self.start_pull_stream_fallback(open_url, reset_quality=True)
                                await self.send_log("Auto source selected SageTV PULL stv:// input.")
                            elif self.media.status.push_mode:
                                await self.start_push_stream(reset_quality=True)
                                await self.send_log("Auto source selected SageTV PUSHBUFFER input.")
                            else:
                                await self.send_log(f"Auto source could not start direct/pull/push for OPENURL: {open_url[:160]}")
                    except Exception as exc:
                        self.video.status.last_error = str(exc)
                        await self.send_log(f"Video source start failed: {exc}")
                elif cmd in (MEDIACMD_FLUSH, MEDIACMD_SEEK) and self.video.status.running:
                    try:
                        # PUSH can simply restart FFmpeg and wait for new PUSHBUFFER data.
                        # PULL input restarts from the beginning because SageTV's seek is a media-time value,
                        # not a byte offset. Direct File/SMB is preferred when a mapped file path is available.
                        if self.video.input_source == "direct" and (self.video.direct_input_path or self.direct_last_path):
                            cached_direct = self.video.direct_input_path or self.direct_last_path
                            current_url = self.media.status.url or self.direct_last_url or self.video.media_url
                            if self.direct_push_timing_control and cmd == MEDIACMD_FLUSH:
                                # In SageX-resolved Direct mode SageTV often sends only FLUSH
                                # and then updates the PUSHBUFFER request/mux time. Do not restart
                                # Direct at 0 from the FLUSH alone; wait for the next PUSHBUFFER
                                # timing packet and mirror that time into FFmpeg. If a real SEEK
                                # arrived immediately before FLUSH, the parser preserved it and
                                # we can restart immediately below.
                                recent_seek = self.media.status.last_seek_ms >= 0 and (time.monotonic() - self.media.status.last_seek_at) <= 3.0
                                if not recent_seek:
                                    self._await_push_timing_seek = True
                                    await self.send_log("Direct File/SMB PUSH-timing FLUSH received; waiting for SageTV PUSHBUFFER request time before restarting FFmpeg.")
                                    current_url = ""
                            if current_url:
                                if current_url and not str(current_url).lower().startswith("push:") and not self.direct_push_timing_control:
                                    await self.start_direct_file_stream(current_url, reason="SageTV seek/flush direct restart")
                                    await self.send_log(f"Direct File/SMB restarted near {self.media.status.current_media_time_ms()}ms after SageTV seek/flush")
                                else:
                                    await self.start_direct_path_stream(cached_direct, url=current_url, reason="SageTV seek/flush direct cached restart", push_timing_control=self.direct_push_timing_control)
                                    await self.send_log(f"Direct File/SMB restarted from cached path near {self.media.status.current_media_time_ms()}ms after SageTV seek/flush")
                        elif self.video.input_source == "web" and self.video.direct_input_path:
                            await self.start_web_http_stream(
                                self.video.direct_input_path,
                                url=self.direct_last_url or self.video.media_url or self.media.status.url,
                                reason="SageTV seek/flush SageX API HTTP fallback restart",
                            )
                            await self.send_log(f"SageX API HTTP fallback restarted near {self.media.status.current_media_time_ms()}ms after SageTV seek/flush")
                        elif self.video.input_source == "push":
                            playlist = await self.video.restart()
                            await self.send({"type": "videoStream", "url": playlist, "status": self.video.status.to_json()})
                            await self.send_log(f"FFmpeg HLS PUSH bridge restarted after SageTV FLUSH/seek: {playlist}")
                        elif self.video.input_source == "pull" and self.media.status.url.lower().startswith("stv://"):
                            await self.video.stop(remove_files=True)
                            await self.start_pull_stream_fallback(self.media.status.url)
                            await self.send_log("SageTV PULL restarted after SageTV FLUSH/seek. Byte-accurate seek is not implemented yet for PULL mode.")
                    except Exception as exc:
                        await self.send_log(f"FFmpeg restart failed after FLUSH: {exc}")
                elif cmd in (MEDIACMD_STOP, MEDIACMD_DEINIT):
                    await self.stop_pull_pump()
                    await self.video.stop(remove_files=True)
                    await self.send({"type": "videoStop", "status": self.video.status.to_json()})

                # v31: Some SageTV sessions begin sending PUSHBUFFER data before
                # the OPENURL-triggered FFmpeg bridge is fully started, or the UI
                # checkbox may have been left off while SageTV still selected PUSH.
                # If real TS bytes arrive, auto-start the video bridge and feed them.
                if result.pushbuffer:
                    try:
                        if self.video.status.running and self.video.input_source != "push":
                            # Direct/PULL modes own their own input stream.  Do not mix in
                            # late PUSHBUFFER chunks or the browser HLS segments will jump.
                            # v129: For SageX-resolved Direct playback, still consume the
                            # zero-byte/full PUSHBUFFER timing packets and mirror their mux
                            # times into the local FFmpeg Direct stream.
                            try:
                                await self.maybe_restart_direct_from_push_mux(result)
                            except Exception as exc:
                                await self.send_log(f"Direct/Web seek from PUSHBUFFER timing failed: {exc}")
                            if result.push_data and not self._ignored_pushbuffer_logged:
                                self._ignored_pushbuffer_logged = True
                                await self.send_log(f"Ignoring SageTV PUSHBUFFER bytes because active source is {self.video.input_source}; using PUSH only for timing/control.")
                        elif result.push_data:
                            if not self.video.status.running:
                                can_auto_start_push = self.playback_source in ("push", "auto", "direct")
                                if not can_auto_start_push:
                                    if not self._ignored_pushbuffer_logged:
                                        self._ignored_pushbuffer_logged = True
                                        await self.send_log(f"Received PUSHBUFFER but Source={self.playback_source}; explicit source mode is strict, so PUSH is not auto-started.")
                                    continue
                                if self.playback_source in ("direct", "auto"):
                                    # SageTV can send a few real PUSHBUFFER chunks before the
                                    # OPENURL command arrives. In v111 this auto-started the
                                    # PUSH bridge first, then the SageX API Direct path
                                    # replaced it a moment later. Keep those bytes as prebuffer
                                    # and wait for OPENURL so Direct/Web-Interface path lookup gets first chance.
                                    direct_url = self.media.status.url or self.direct_last_url or self.video.media_url or ""
                                    if direct_url and await self.start_direct_file_stream(direct_url, reason="Direct Source received PUSHBUFFER with known OPENURL"):
                                        await self.send_log("Direct File/SMB resolved a file path before starting PUSHBUFFER; incoming PUSHBUFFER data ignored.")
                                        continue
                                    try:
                                        self.video._append_prebuffer(result.push_data)
                                    except Exception:
                                        pass
                                    if not self._ignored_pushbuffer_logged:
                                        self._ignored_pushbuffer_logged = True
                                        await self.send_log("Received early PUSHBUFFER before Direct/Web-Interface path lookup completed; buffering briefly and waiting for OPENURL instead of starting PUSH first.")
                                    continue
                                self.video.input_source = "push"
                                self.video.direct_input_path = ""
                                self.video.pull_url = ""
                                playlist = await self.video.start(refeed_prebuffer=False, reason="auto-started on first non-empty SageTV PUSHBUFFER")
                                await self.send({"type": "videoStream", "url": playlist, "status": self.video.status.to_json()})
                                await self.send_log(f"FFmpeg HLS PUSH bridge auto-started on PUSHBUFFER: {playlist} encoder={self.video.status.encoder}")
                            await self.video.write(result.push_data)
                            # v44: Do not send websocket videoStatus from the hot PUSHBUFFER
                            # path. SageTV can send many PUSHBUFFERs per second and each status
                            # update forces browser debug text/layout work. The browser polls
                            # /api/hls_ready during startup, and the normal 1.5s sampled status
                            # below is enough during playback.
                            if self.video.status.chunks_in % 20 == 0:
                                self.video.refresh_ready_state()
                    except Exception as exc:
                        self.video.status.last_error = str(exc)
                        await self.send_log(f"FFmpeg write/start failed: {exc}")

                # v132: For SageX-resolved Direct File/SMB playback, SageTV may
                # update its OSD timeline without sending a real PUSHBUFFER mux
                # seek. Poll SageX RawMediaTime and mirror large jumps locally.
                try:
                    await self.maybe_poll_sagex_timeline_seek()
                except Exception as exc:
                    await self.send_log(f"SageX timeline seek poll failed: {exc}")

                name = MEDIA_CMD_NAMES.get(cmd, str(cmd))
                # PUSHBUFFER can happen many times per second.  Log only useful samples.
                if result.log:
                    await self.send_log(result.log)
                elif cmd not in (MEDIACMD_PUSHBUFFER, MEDIACMD_GETMEDIATIME):
                    await self.send_log(f"{name} len={length} reply={len(result.reply)}")

                if result.video_bounds_changed:
                    src = self.media.status.source_rect
                    dst = self.media.status.dest_rect
                    await self.send({"type": "videoBounds", "src": list(src), "dst": list(dst)})

                now = time.monotonic()
                # Do not send a WebSocket status update for every PUSHBUFFER.
                # During playback SageTV can push dozens of buffers per second; sending
                # mediaStatus/videoStatus for each one makes the browser renderer and
                # remote keys feel sluggish. Non-PUSH state changes are immediate;
                # PUSH progress is sampled periodically.
                status_due = (result.status_changed and cmd != MEDIACMD_PUSHBUFFER) or (now - last_status_sent > 1.5)
                if status_due:
                    last_status_sent = now
                    await self.send({"type": "mediaStatus", "status": self.media.status.to_json()})
                    await self.send({"type": "videoStatus", "status": self.video.status.to_json()})
        except asyncio.CancelledError:
            pass
        except Exception as e:
            await self.send_log(f"Media loop stopped: {e}")
            try:
                await self.video.stop(remove_files=True)
                await self.send({"type": "videoStop", "status": self.video.status.to_json()})
            except Exception:
                pass

    def _commands_to_text_lines(self, commands: list[dict]) -> list[str]:
        """Build approximate readable lines from current-frame drawText commands."""
        items = []
        for cmd in commands or []:
            if cmd.get("op") == "drawText" or ("text" in cmd and "op" not in cmd):
                text = str(cmd.get("text") or "").strip()
                if text:
                    items.append({"x": int(cmd.get("x") or 0), "y": int(cmd.get("y") or 0), "text": text})
        if not items:
            return []
        items.sort(key=lambda t: (t["y"], t["x"]))
        rows: list[list[dict]] = []
        for item in items:
            if not rows or abs(rows[-1][0]["y"] - item["y"]) > 6:
                rows.append([item])
            else:
                rows[-1].append(item)
        lines = []
        for row in rows:
            row.sort(key=lambda t: t["x"])
            parts = [r["text"] for r in row]
            line = " ".join(parts)
            line = re.sub(r"\s+", " ", line).strip()
            if line:
                lines.append(line)
        return lines


    async def fetch_sagex_current_media_detail(self, reason: str = "current media", open_url: str = "") -> tuple[dict, str]:
        """Ask SageX /sagex/api for current MediaFile detail.

        v132 replaces the normal SageX API HTML parser as the
        primary lookup source. SageX is used to resolve the current MediaFile
        path for Direct File/SMB and to provide RawMediaTime timeline polling
        when SageTV's PUSHBUFFER path does not send useful seek timing.
        """
        base = normalize_sagex_base(self.web_interface_server, self.server)
        last_reason = ""
        for attempt in range(3):
            if attempt:
                await asyncio.sleep(0.20 * attempt)
            try:
                detail, why = await asyncio.to_thread(
                    sagex_lookup_current_media,
                    base,
                    self.web_interface_username,
                    self.web_interface_password,
                    self.client_id,
                    open_url or self.media.status.url or self.video.media_url or "",
                    4.0,
                )
            except Exception as exc:
                detail, why = {}, f"SageX API lookup failed: {exc}"
            last_reason = why
            if detail.get("file_path") or detail.get("web_media_urls"):
                detail = parse_media_detail_current_file(detail) or detail
                detail["source"] = "sagex"
                detail["captured_at"] = time.time()
                self.sage_detail_cache = detail
                discovered_root = ""
                fp = str(detail.get("file_path") or "")
                if fp and _path_needs_mapping_for_platform(fp):
                    discovered_root = self._discover_direct_root(fp)
                if self._pending_direct_path_map_update or discovered_root:
                    await self._send_direct_path_map_update_if_needed(discovered_root)
                await self._send_media_detail_update_if_needed(detail, discovered_root, source_label="SageX API")
                return detail, f"SageX API {base}/sagex/api returned current MediaFile detail"
        return {}, last_reason or f"SageX API lookup did not return a MediaFile path from {base}/sagex/api"

    async def fetch_sagex_api_current_media_detail(self, reason: str = "current media", open_url: str = "") -> tuple[dict, str]:
        """Compatibility wrapper: v132 uses SageX instead of SageX API HTML."""
        return await self.fetch_sagex_current_media_detail(reason, open_url=open_url)

    async def fetch_web_or_detail_current_media(self, reason: str = "current media", open_url: str = "") -> tuple[dict, str]:
        """Resolve current MediaFile detail using only the SageX API plugin.

        v117 keeps the v110 removal of the native 42024 backend/database lookup.
        Direct/Auto use the SageX API lookup only to find the current
        MediaFile path when MiniClient OPENURL/PUSHBUFFER does not include a
        usable direct path, then fall back to PUSHBUFFER when needed.
        """
        return await self.fetch_sagex_api_current_media_detail(reason, open_url=open_url)

    def resolve_detail_cached_web_url(self) -> tuple[str, str, str]:
        """Return an HTTP media URL discovered by the SageX API, if present.

        The SageX API remains lookup-only in the UI. This is only used as a
        last-resort playback fallback when the real file path cannot be mapped.
        Keeping it internal lets Direct/Auto still seek by restarting FFmpeg at
        SageTV's requested media time instead of leaving the browser video at the
        old position.
        """
        detail = self.sage_detail_cache or {}
        captured_at = float(detail.get("captured_at") or 0.0)
        if not detail or not captured_at or (time.time() - captured_at) > 1800:
            return "", "no recent SageX API detail is cached", ""
        for candidate in detail.get("web_media_urls") or []:
            candidate = str(candidate or "").strip()
            if candidate.lower().startswith(("http://", "https://")):
                return candidate, f"using SageX API media URL: {candidate}", candidate
        return "", "SageX API detail did not include an HTTP media URL/playlist target", ""

    def sagex_api_ffmpeg_headers(self) -> str:
        """Return optional HTTP headers for FFmpeg SageX API input."""
        headers = ["User-Agent: SageTV-HTML5-Client/129"]
        if self.web_interface_username or self.web_interface_password:
            token = base64.b64encode(f"{self.web_interface_username}:{self.web_interface_password}".encode("utf-8")).decode("ascii")
            headers.append(f"Authorization: Basic {token}")
        return "\r\n".join(headers) + "\r\n"

    async def start_web_http_stream(self, web_url: str, url: str = "", reason: str = "SageX API HTTP fallback", reset_quality: bool = True) -> bool:
        """Start FFmpeg from an HTTP URL served by the SageX API.

        This is not exposed as a Source option. It is only a last-resort fallback
        after Direct File/SMB path lookup fails. It still honors SageTV SEEK by
        restarting FFmpeg with -ss at the current MiniClient media time.
        """
        web_url = str(web_url or "").strip()
        if not web_url.lower().startswith(("http://", "https://")):
            await self.send_log(f"SageX API HTTP fallback not used: URL is not HTTP: {web_url[:160]}")
            return False
        await self.stop_pull_pump()
        await self.video.stop(remove_files=True, keep_prebuffer=False)
        self.direct_last_path = ""
        self.direct_last_url = web_url
        media_url = url or web_url or self.media.status.url or self.video.media_url or ""
        self.video.media_url = media_url
        self.video.input_source = "web"
        self.video.direct_input_path = web_url
        self.video.http_input_headers = self.sagex_api_ffmpeg_headers()
        self.video.pull_url = ""
        self.video.input_seek_seconds = max(0.0, self.media.status.current_media_time_ms() / 1000.0)
        playlist = await self.video.start(reason=f"{reason}; start={self.video.input_seek_seconds:.3f}s")
        await self.send({"type": "videoStream", "url": playlist, "status": self.video.status.to_json()})
        await self.send_log(f"SageX API HTTP fallback bridge started at {self.video.input_seek_seconds:.3f}s: {web_url} -> {playlist}")
        return True

    async def _send_media_detail_update_if_needed(self, detail: dict, discovered_root: str = "", source_label: str = "SageX API"):
        new_path = str(detail.get("file_path") or "")
        new_fmt = str(detail.get("format") or "")
        now = time.time()
        if now - self._last_detail_send_ts < 1.0:
            return
        self._last_detail_send_ts = now
        await self.send({"type": "sageDetailUpdate", "detail": detail, "discovered_sage_root": discovered_root})
        fmt_note = f" format={new_fmt}" if new_fmt else ""
        await self.send_log(f"{source_label} current MediaFile: {new_path}{fmt_note}")

    def resolve_detail_cached_direct_path(self) -> tuple[str, str, str]:
        """Resolve the last SageX API MediaFile path to a local Direct path."""
        detail = self.sage_detail_cache or {}
        captured_at = float(detail.get("captured_at") or 0.0)
        if not detail or not captured_at or (time.time() - captured_at) > 1800:
            return "", "no recent SageX API MediaFile path is cached", ""
        candidates = detail.get("file_candidates") or [detail.get("file_path")]
        for candidate in candidates:
            candidate = str(candidate or "").strip()
            if not candidate:
                continue
            local, matched_root, matched_had_local = find_direct_path_mapping(
                candidate,
                self.direct_sage_root,
                self.direct_local_root,
                self.direct_path_map,
            )
            if matched_root and not matched_had_local:
                return "", f"SageX API path matched Sage Root but Local Root is blank: {matched_root}", candidate
            if not matched_root and _path_needs_mapping_for_platform(candidate):
                discovered_root = self._discover_direct_root(candidate)
                return "", f"SageX API path discovered new Sage Root: {discovered_root} = . Enter the matching Local Root and click Save Root Mapping.", candidate
            if local:
                return local, f"using SageX API MediaFile path: {candidate}", candidate
        return "", "SageX API MediaFile path did not resolve through Direct root mappings", ""

    async def handle_sagetv_packet(self, cmd_type: int, payload: bytes):
        if cmd_type == DRAWING_CMD_TYPE:
            self.gfx_packet_count += 1
            gfx_cmd = payload[0] if payload else -1
            if gfx_cmd == GFXCMD_MEDIA_RECONNECT:
                # Java MiniClient closes/reconnects media socket here. This is
                # important after stop/playback errors; ignoring it leaves SageTV
                # waiting on the old media channel.
                asyncio.create_task(self.reconnect_media_socket("GFXCMD_MEDIA_RECONNECT"))
                return
            reply, commands = self.gfx.execute(payload)

            if self.gfx_trace and self.gfx_packet_count <= 80:
                name = GFXCMD_NAMES.get(gfx_cmd, str(gfx_cmd))
                await self.send_log(f"GFX packet #{self.gfx_packet_count}: {name} len={len(payload)} reply={reply}")

            # Batch per SageTV frame. v21 also handles skins/plugins that disable
            # GFX_FLIP or start a new frame before a FLIPBUFFER arrives. In that case
            # flush the previous pending frame so the browser never sits on stale draw data.
            if gfx_cmd == GFXCMD_STARTFRAME:
                if self._inside_frame and self._frame_commands:
                    await self.send_gfx(self._frame_commands)
                self._inside_frame = True
                self._frame_commands = list(commands)
            elif self._inside_frame:
                self._frame_commands.extend(commands)
                if gfx_cmd == GFXCMD_FLIPBUFFER:
                    await self.send_gfx(self._frame_commands)
                    self._frame_commands = []
                    self._inside_frame = False
            else:
                await self.send_gfx(commands)

            if reply is not None:
                self.gfx_reply_count += 1
                await self.write_reply(DRAWING_CMD_TYPE, struct.pack(">i", int(reply)))
        elif cmd_type == GET_PROPERTY_CMD_TYPE:
            prop_name = payload.decode("latin-1", errors="replace")
            prop_val = self.get_property(prop_name)
            await self.send_log(f"GET_PROPERTY {prop_name} -> {prop_val!r}")
            await self.write_reply(GET_PROPERTY_CMD_TYPE, prop_val.encode("latin-1", errors="replace"))
        elif cmd_type == SET_PROPERTY_CMD_TYPE:
            rc = await self.set_property(payload)
            await self.write_reply(SET_PROPERTY_CMD_TYPE, struct.pack(">i", rc))
        elif cmd_type == FS_CMD_TYPE:
            await self.send_log(f"FS command ignored in GUI-only mode, len={len(payload)}")
        else:
            await self.send_log(f"Unhandled SageTV packet type={cmd_type} len={len(payload)}")

    async def write_reply(self, reply_type: int, payload: bytes):
        if not self.gfx_writer:
            return
        packet = make_reply_packet(reply_type, self.reply_count, payload)
        self.reply_count += 1
        self.gfx_writer.write(packet)
        await self.gfx_writer.drain()

    def _push_container_caps(self) -> str:
        if not self.media_caps_enabled:
            return "NONE"
        src = self.playback_source
        if src in ("pull", "direct"):
            return "NONE"
        return "MPEG2-PS,MPEG2-TS,MPEG1-PS"

    def _pull_container_caps(self) -> str:
        if not self.media_caps_enabled:
            return "NONE"
        src = self.playback_source
        # Source now fully replaces the old Force PUSH option:
        #   PUSHBUFFER advertises push only.
        #   Direct/PULL/Auto advertise PULL/file URLs so SageTV sends stv:// or file://.
        if src == "push":
            return "NONE"
        return "MPEG2-TS,MPEG2-PS,MPEG"

    def get_property(self, name: str) -> str:
        # Conservative web renderer capabilities. Keep zlib/encryption off for first Python port.
        props = {
            # Keep normal SageTV text rendering. Direct File/SMB recovery now uses
            # the SageX API instead of scraping Video Detail screens.
            "GFX_TEXTMODE": "NONE",
            "GFX_DRAWMODE": "FULLSCREEN",
            "GFX_BLENDMODE": "PREMULTIPLY",
            "GFX_SCALING": "HARDWARE",
            "GFX_OFFLINE_IMAGE_CACHE": "FALSE",
            "OFFLINE_CACHE_CONTENTS": "",
            "ADVANCED_IMAGE_CACHING": "TRUE",
            "GFX_BITMAP_FORMAT": "PNG,JPG,GIF,BMP",
            "GFX_COMPOSITE": "BLEND",
            # Keep surfaces disabled for the pure HTML5 renderer until the full
            # surface/transform pipeline is complete. This makes SageTV send simpler
            # full-screen draw frames and avoids stale offscreen-surface artifacts.
            "GFX_SURFACES": "FALSE",
            "GFX_HIRES_SURFACES": "FALSE",
            "GFX_DIFFUSE_TEXTURES": "",
            "GFX_XFORMS": "",
            "GFX_TEXTURE_BATCH_LIMIT": "",
            "GFX_COLORKEY": "080010",
            "STREAMING_PROTOCOLS": "file,stv",
            # v29: use the same media capability names as the OpenSageTV Android
            # MiniClient profile so SageTV is more likely to include the audio stream
            # in the PUSH media URL instead of sending video-only media.
            "VIDEO_CODECS": "MPEG2-VIDEO,MPEG2-VIDEO@HL,MPEG1-VIDEO,MPEG4-VIDEO,DIVX3,MSMPEG4,FLASHVIDEO,H.264,WMV9,VC1,MJPEG" if self.media_caps_enabled else "NONE",
            "AUDIO_CODECS": "MPG1L2,MPG1L3,AC3,AAC,AAC-HE,WMA,FLAC,VORBIS,PCM,DTS,DCA,PCM_S16LE,WMA8,ALAC,WMAPRO,0X0162,DolbyTrueHD,DTS-HD,DTS-MA,EAC3,EC-3" if self.media_caps_enabled else "NONE",
            "PUSH_AV_CONTAINERS": self._push_container_caps(),
            # v58: source mode controls whether we ask SageTV for PUSHBUFFER or allow stv:// PULL.
            # Direct File/SMB mode also needs non-push OPENURL values, so it allows PULL/file URLs.
            "PULL_AV_CONTAINERS": self._pull_container_caps(),
            "INPUT_DEVICES": "IR,KEYBOARD,MOUSE",
            "DISPLAY_OVERSCAN": "0;0;1.0;1.0",
            "FIRMWARE_VERSION": "9.0.0-python-html5-v137",
            "DETAILED_BUFFER_STATS": "TRUE",
            "PUSH_BUFFER_SEEKING": "TRUE",
            "GFX_SUBTITLES": "",
            "FORCED_MEDIA_RECONNECT": "TRUE",
            "AUTH_CACHE": "",
            "GET_CACHED_AUTH": "",
            "REMOTE_FS": "",
            "GFX_VIDEO_UPDATE": "",  # Enable after FFmpeg video path is added.
            "ZLIB_COMM": "",          # Keep off until zlib stream wrapper is ported.
            "MEDIA_PLAYER_BUFFER_DELAY": "100",
            "GFX_RESOLUTION": f"{self.size.width}x{self.size.height}",
            "GFX_ASPECT": str(self.size.width / max(1, self.size.height)),
        }
        return props.get(name, "")

    async def set_property(self, payload: bytes) -> int:
        """Decode SageTV SET_PROPERTY payload.

        Java MiniClientConnection uses:
          uint16 nameLen, uint16 valLen, name bytes, value bytes
        v18 incorrectly treated these as 32-bit lengths, which produced logs like
        SET_PROPERTY GFX_ASPECT1.7777778=''. That also meant SageTV's request to
        disable advanced image caching was ignored, which can stall image loading.
        """
        try:
            if len(payload) < 4:
                await self.send_log(f"SET_PROPERTY too short len={len(payload)} raw={payload.hex()}")
                return 0
            name_len = ((payload[0] & 0xFF) << 8) | (payload[1] & 0xFF)
            val_len = ((payload[2] & 0xFF) << 8) | (payload[3] & 0xFF)
            name_off = 4
            val_off = name_off + name_len
            name = payload[name_off:val_off].decode("latin-1", errors="replace")
            value = payload[val_off:val_off+val_len].decode("latin-1", errors="replace")
            await self.send_log(f"SET_PROPERTY {name}={value!r}")

            if name == "GFX_RESOLUTION" and "x" in value:
                w, h = value.lower().split("x", 1)
                self.size.width = int(w)
                self.size.height = int(h)
                await self.send({"type": "resizeCanvas", "width": self.size.width, "height": self.size.height})
            elif name == "GFX_ASPECT":
                # Browser canvas already uses the requested resolution, but keep this visible for debug.
                pass
            elif name == "MENU_HINT":
                await self.send({"type": "menuHint", "value": value})
            elif name == "ADVANCED_IMAGE_CACHING":
                self.gfx.state.advanced_image_caching = value.upper() == "TRUE"
                await self.send_log(f"Advanced image caching now {self.gfx.state.advanced_image_caching}")
            elif name == "GFX_FLIP":
                await self.send_log(f"GFX_FLIP requested by SageTV: {value!r}")
            elif name == "RECONNECT_SUPPORTED":
                pass
            return 0
        except Exception as e:
            await self.send_log(f"SET_PROPERTY parse error: {e}; raw={payload[:64].hex()}")
            return 0

    async def post_resize(self, width: int, height: int):
        await self.write_reply(UI_RESIZE_EVENT_REPLY_TYPE, struct.pack(">ii", width, height))
        await self.send_log(f"Sent resize {width}x{height}")

    async def post_sage_command(self, command_id: int):
        await self.write_reply(SAGECOMMAND_EVENT_REPLY_TYPE, struct.pack(">i", command_id))
        await self.send_log(f"Sent Sage command {command_id}")

    async def post_ir(self, ir_code: int, label: str = ""):
        await self.write_reply(IR_EVENT_REPLY_TYPE, struct.pack(">i", int(ir_code)))
        if label:
            await self.send_log(f"Sent remote IR {ir_code} ({label})")
        else:
            await self.send_log(f"Sent remote IR {ir_code}")

    async def post_key(self, key_code: int, key: str):
        ch = ord(key[0]) if key and len(key) == 1 else 0
        await self.write_reply(KB_EVENT_REPLY_TYPE, struct.pack(">iHi", key_code, ch, 0))

    async def post_mouse(self, data: dict):
        evt = data.get("event", "move")
        event_type = {
            "move": MMOVE_EVENT_REPLY_TYPE,
            "down": MPRESS_EVENT_REPLY_TYPE,
            "up": MRELEASE_EVENT_REPLY_TYPE,
            "click": MCLICK_EVENT_REPLY_TYPE,
            "drag": MDRAG_EVENT_REPLY_TYPE,
            "wheel": MWHEEL_EVENT_REPLY_TYPE,
        }.get(evt, MMOVE_EVENT_REPLY_TYPE)
        x = int(data.get("x") or 0)
        y = int(data.get("y") or 0)
        button = int(data.get("button") or 1)
        clicks_or_wheel = int(data.get("delta") or data.get("clicks") or 1)
        # MiniClient mouse payload is x, y, modifiers, clicks/wheel, button.
        # Earlier versions sent modifiers=0. That works in the stock STV, but
        # SageMC's Guide code can ignore mouse clicks unless the AWT-style
        # button modifier is present. Use the legacy Java InputEvent masks that
        # SageTV/old STVs are most likely to test.
        old_button_masks = {1: 16, 2: 8, 3: 4}  # BUTTON1/2/3_MASK
        modifiers = 0 if evt in ("move", "wheel") else old_button_masks.get(button, 0)
        payload = struct.pack(">iiiBB", x, y, modifiers, clicks_or_wheel & 0xFF, button & 0xFF)
        await self.write_reply(event_type, payload)
        if evt == "click":
            await self.send_log(f"Sent mouse click x={x} y={y} button={button}")
