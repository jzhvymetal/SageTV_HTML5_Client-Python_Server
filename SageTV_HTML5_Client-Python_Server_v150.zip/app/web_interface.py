"""SageTV Web Interface lookup helpers.

This uses the normal SageTV Web Interface/Webpage plugin, not the SageX
``/sagex/api`` REST endpoint.  It is intentionally conservative: it uses exact
MediaFileID links when available and parses the Web Interface Detailed
Information/playlist pages for file path, format, and HTTP media URLs.
"""
from __future__ import annotations

import base64
import html
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Iterable

from .sagetv_server import normalize_server_host

DEFAULT_WEB_PORT = 8080
MEDIA_EXTENSIONS = "ts|mpg|mpeg|mp4|mkv|avi|mov|m4v|wmv|flv|webm|vob"
MEDIA_EXT_RE = re.compile(rf"\.({MEDIA_EXTENSIONS})(?:$|[?#])", re.I)
# Files from the SageTV Web Interface can contain spaces. Do not split the
# Files: field on whitespace; capture from the root/UNC/drive prefix through
# the media extension. This fixes paths such as:
#   /var/media/videos/Reksio/03. Reksio wychowawca.avi
MEDIA_PATH_RE = re.compile(
    r"(?is)(?P<path>(?:[A-Za-z]:[\\/]|\\\\|//|/)[^\r\n<>\"']*?\.(?:" + MEDIA_EXTENSIONS + r"))(?=$|[\s\"'<>])"
)
MFID_RE = re.compile(r"(?i)(?:mediafileid|mediafile|mfid|fileid)[_\- ]*(?:=|:|/)(\d+)")
AID_RE = re.compile(r"(?i)(?:airingid|airing)[_\- ]*(?:=|:|/)(\d+)")
HTTP_RE = re.compile(r"https?://[^\s'\"<>]+", re.I)
HREF_RE = re.compile(r'''(?is)href\s*=\s*(?:\"([^\"]*)\"|'([^']*)'|([^>\s]+))''')
ANCHOR_RE = re.compile(r'''(?is)<a\b[^>]*?href\s*=\s*(?:\"([^\"]*)\"|'([^']*)'|([^>\s]+))[^>]*>(.*?)</a>''')
DETAIL_HINT_RE = re.compile(r"(?i)(detail|detailed|mediafile|airing|sage/DetailedInfo|DetailedInfo)")
PLAYLIST_HINT_RE = re.compile(r"(?i)\.(m3u8?|pls|wmx|wvx|asx)(?:$|[?#])|playlist|type\s*=\s*(?:m3u8?|pls|wmx|wvx|asx)|format\s*=\s*(?:m3u8?|pls|wmx|wvx|asx)")


def normalize_web_base(value: str | None, fallback_host: str | None = None) -> str:
    """Return a normalized SageTV Web Interface base URL.

    The UI setting is allowed to be ``server:port`` or a full URL.  Blank values
    default to ``http://<SageTV host>:8080``.
    """
    text = str(value or "").strip()
    if not text:
        host = normalize_server_host(fallback_host) or "127.0.0.1"
        text = f"{host}:{DEFAULT_WEB_PORT}"
    if "://" not in text:
        text = "http://" + text
    p = urllib.parse.urlsplit(text)
    scheme = p.scheme or "http"
    netloc = p.netloc or p.path
    path = p.path if p.netloc else ""
    if "/" in netloc:
        netloc, extra = netloc.split("/", 1)
        path = "/" + extra
    return urllib.parse.urlunsplit((scheme, netloc.rstrip("/"), path.rstrip("/"), "", ""))


def context_variants(client_id: str | None) -> list[str]:
    raw = re.sub(r"[^0-9A-Fa-f]", "", str(client_id or "")).lower()
    out = []
    if raw:
        out.append(raw)
        out.append(":".join(raw[i:i + 2] for i in range(0, min(len(raw), 12), 2)))
    return list(dict.fromkeys([x for x in out if x]))


def mediafile_ids_from_text(text: str) -> list[str]:
    ids = []
    for rx in (MFID_RE, re.compile(r"(?i)Internal details:\s*MediaFileID\s*=\s*(\d+)")):
        for m in rx.finditer(str(text or "")):
            ids.append(m.group(1))
    return list(dict.fromkeys(ids))


def _clean_html_text(text: str) -> str:
    text = re.sub(r"(?is)<br\s*/?>", "\n", str(text or ""))
    text = re.sub(r"(?is)</(p|div|li|tr|td|h\d)>", "\n", text)
    text = re.sub(r"(?is)<script.*?</script>|<style.*?</style>", " ", text)
    text = re.sub(r"(?is)<[^>]+>", " ", text)
    return html.unescape(text).replace("\r", "")


def _extract_label_value(text: str, label: str) -> str:
    plain = _clean_html_text(text)
    # Capture the current line and continuation lines up to the next common label.
    labels = "Aired|Episode|Description|Run Time|File Format|Files?|File Playlists|Size|Internal details|Encoded by|Rating|Rated|Channel"
    rx = re.compile(rf"(?ims)^\s*{re.escape(label)}\s*:\s*(.*?)(?=^\s*(?:{labels})\s*:|\Z)")
    m = rx.search(plain)
    if not m:
        return ""
    val = re.sub(r"\s+", " ", m.group(1)).strip()
    return val


def _unescape_path_text(value: str) -> str:
    return urllib.parse.unquote(html.unescape(str(value or ""))).strip().strip('"\'')


def _extract_media_paths(value: str) -> list[str]:
    """Extract local/UNC/Sage paths from text while preserving spaces."""
    text = _unescape_path_text(value).replace("\r", "")
    paths = []
    for m in MEDIA_PATH_RE.finditer(text):
        path = m.group("path").strip()
        if path:
            paths.append(path)
    return list(dict.fromkeys(paths))


def _looks_like_media_path(value: str) -> bool:
    v = _unescape_path_text(value)
    if not v:
        return False
    if v.lower().startswith(("http://", "https://")):
        return bool(MEDIA_EXT_RE.search(urllib.parse.urlsplit(v).path))
    if v.startswith(("/", "\\", "//")) or re.match(r"^[A-Za-z]:[\\/]", v):
        return bool(MEDIA_EXT_RE.search(v)) or bool(_extract_media_paths(v))
    return False

def parse_playlist_urls(text: str, base_url: str = "") -> list[str]:
    urls: list[str] = []
    raw = html.unescape(str(text or ""))
    for line in raw.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or line.upper().startswith(("[PLAYLIST]", "NUMBEROFENTRIES", "VERSION")):
            continue
        if line.lower().startswith("file") and "=" in line:
            line = line.split("=", 1)[1].strip()
        lower = line.lower()
        if lower.startswith(("http://", "https://")):
            urls.append(line)
        elif base_url and (lower.startswith(("/sage/", "sage/", "/stream", "stream")) or "mediafile" in lower or "airing" in lower):
            urls.append(urllib.parse.urljoin(base_url, line))
        # Do not turn local filesystem paths such as /var/media/... into fake
        # HTTP URLs.  Those belong to Direct File/SMB mode, not Web HTTP mode.
    return list(dict.fromkeys(urls))


def parse_detail_html(text: str, base_url: str = "") -> dict:
    raw = str(text or "")
    plain = _clean_html_text(raw)
    detail: dict[str, object] = {}
    file_val = _extract_label_value(raw, "Files") or _extract_label_value(raw, "File")
    if file_val:
        # The Web UI usually puts the path on the line after "Files:".
        # Preserve spaces inside filenames.
        candidates = _extract_media_paths(file_val)
        if not candidates and _looks_like_media_path(file_val):
            candidates.append(_unescape_path_text(file_val))
        if candidates:
            detail["file_path"] = candidates[0]
            detail["file_candidates"] = candidates
    fmt = _extract_label_value(raw, "File Format") or _extract_label_value(raw, "Format")
    if fmt:
        detail["format"] = fmt
    ids = mediafile_ids_from_text(plain + "\n" + raw)
    if ids:
        detail["media_file_id"] = ids[0]
    ma = AID_RE.search(plain + "\n" + raw)
    if ma:
        detail["airing_id"] = ma.group(1)
    hrefs = []
    playlist_links = []
    media_urls = []
    anchor_items = []
    for m in ANCHOR_RE.finditer(raw):
        href = html.unescape(next((g for g in m.groups()[:3] if g), "")).strip()
        if not href:
            continue
        url = urllib.parse.urljoin(base_url, href)
        text = _clean_html_text(m.group(4)).strip().lower()
        ctx = _clean_html_text(raw[max(0, m.start() - 160): min(len(raw), m.end() + 160)]).strip().lower()
        anchor_items.append((url, text, ctx))
        hrefs.append(url)
    # Keep the older href-only parser as a safety net for malformed/unquoted HTML.
    for m in HREF_RE.finditer(raw):
        href = html.unescape(next((g for g in m.groups()[:3] if g), "")).strip()
        if href:
            hrefs.append(urllib.parse.urljoin(base_url, href))
    hrefs = list(dict.fromkeys(hrefs))
    for url, text, ctx in anchor_items:
        cleaned_text = re.sub(r"[^a-z0-9]+", "", text)
        is_playlist_text = cleaned_text in ("m3u", "m3u8", "pls", "wmx", "wvx", "asx")
        is_playlist_ctx = "file playlists" in ctx or "streaming playlists" in ctx or "playlist" in ctx
        is_streamed_watch = "watch" in text and "stream" in text
        if PLAYLIST_HINT_RE.search(url) or is_playlist_text or is_playlist_ctx:
            playlist_links.append(url)
        # Watch(Streamed) links are already media/stream URLs; do not fetch them
        # as playlists.  FFmpeg should open them directly.
        if is_streamed_watch:
            media_urls.append(url)
    for u in hrefs:
        if PLAYLIST_HINT_RE.search(u):
            playlist_links.append(u)
    detail["playlist_links"] = list(dict.fromkeys(playlist_links))
    for u in HTTP_RE.findall(raw):
        u = html.unescape(u).strip()
        if _looks_like_media_path(u):
            media_urls.append(u)
    # Some links are relative direct media links.
    for u in hrefs:
        if _looks_like_media_path(u):
            media_urls.append(u)
    if media_urls:
        detail["web_media_urls"] = list(dict.fromkeys(media_urls))
    return detail


@dataclass
class WebInterfaceLookupResult:
    detail: dict
    reason: str


class SageTVWebInterfaceClient:
    def __init__(self, base_url: str, username: str = "", password: str = "", timeout: float = 4.0):
        self.base_url = normalize_web_base(base_url)
        self.username = str(username or "")
        self.password = str(password or "")
        self.timeout = float(timeout or 4.0)

    def _request(self, url: str) -> str:
        req = urllib.request.Request(url, headers={"User-Agent": "SageTV-HTML5-Client/115"})
        if self.username or self.password:
            token = base64.b64encode(f"{self.username}:{self.password}".encode("utf-8")).decode("ascii")
            req.add_header("Authorization", f"Basic {token}")
        with urllib.request.urlopen(req, timeout=self.timeout) as resp:
            data = resp.read(3_000_000)
            charset = resp.headers.get_content_charset() or "utf-8"
            return data.decode(charset, errors="replace")

    def fetch(self, path_or_url: str) -> str:
        url = path_or_url if str(path_or_url).lower().startswith(("http://", "https://")) else urllib.parse.urljoin(self.base_url + "/", str(path_or_url).lstrip("/"))
        return self._request(url)

    def candidate_detail_paths(self, media_file_id: str = "", airing_id: str = "") -> list[str]:
        paths: list[str] = []
        if media_file_id:
            mid = urllib.parse.quote(str(media_file_id))
            paths.extend([
                f"/sage/DetailedInfo?MediaFileID={mid}",
                f"/sage/DetailedInfo?MediaFileId={mid}",
                f"/sage/DetailedInfo?MediaFile={mid}",
                f"/DetailedInfo?MediaFileID={mid}",
                f"/DetailedInfo?MediaFileId={mid}",
                f"/sage/MediaFile?MediaFileID={mid}",
                f"/sage/Detail?MediaFileID={mid}",
                f"/sage/MediaFileDetails?MediaFileID={mid}",
            ])
        if airing_id:
            aid = urllib.parse.quote(str(airing_id))
            paths.extend([
                f"/sage/DetailedInfo?AiringID={aid}",
                f"/sage/DetailedInfo?AiringId={aid}",
                f"/DetailedInfo?AiringID={aid}",
                f"/DetailedInfo?AiringId={aid}",
                f"/sage/Airing?AiringID={aid}",
                f"/sage/Detail?AiringID={aid}",
            ])
        return list(dict.fromkeys(paths))

    def lookup_by_media_file_id(self, media_file_id: str = "", airing_id: str = "") -> WebInterfaceLookupResult:
        errors = []
        for path in self.candidate_detail_paths(media_file_id=media_file_id, airing_id=airing_id):
            try:
                url = urllib.parse.urljoin(self.base_url + "/", path.lstrip("/"))
                body = self.fetch(path)
                detail = parse_detail_html(body, url)
                if detail.get("file_path") or detail.get("web_media_urls") or detail.get("playlist_links"):
                    detail["source"] = "webui"
                    if media_file_id:
                        detail["media_file_id"] = str(media_file_id)
                    if airing_id:
                        detail["airing_id"] = str(airing_id)
                    detail["captured_at"] = time.time()
                    id_note = f"MediaFileID={media_file_id}" if media_file_id else f"AiringID={airing_id}"
                    return WebInterfaceLookupResult(detail, f"SageTV Web Interface detail page matched {id_note}")
            except Exception as exc:
                errors.append(f"{path}: {exc}")
        id_note = f"MediaFileID={media_file_id}" if media_file_id else f"AiringID={airing_id}"
        return WebInterfaceLookupResult({}, "; ".join(errors[-3:]) or f"{id_note} did not resolve in the Web Interface")

    def enrich_with_playlist_url(self, detail: dict) -> dict:
        detail = dict(detail or {})
        urls = list(detail.get("web_media_urls") or [])
        for plist in list(detail.get("playlist_links") or [])[:4]:
            try:
                body = self.fetch(plist)
                urls.extend(parse_playlist_urls(body, plist))
            except Exception:
                continue
        if urls:
            detail["web_media_urls"] = list(dict.fromkeys(urls))
        return detail

    def lookup_current_media(self, client_id: str = "", push_url: str = "") -> WebInterfaceLookupResult:
        # Exact path: if SageTV ever embeds mfid/mediafileid in a PUSH string or URL.
        ids = mediafile_ids_from_text(str(push_url or ""))
        if ids:
            res = self.lookup_by_media_file_id(media_file_id=ids[0])
            if res.detail:
                res.detail = self.enrich_with_playlist_url(res.detail)
                return res
            return res

        # Best-effort Web Interface pages. Some custom Web UI installs expose a
        # current/now-playing page.  Parse it only if it directly contains a file
        # path or a MediaFileID that can then be followed to a detail page.
        errors = []
        contexts = context_variants(client_id)
        paths = ["/sage/Home", "/sage/Status", "/sage/SystemInfo", "/"]
        for ctx in contexts:
            q = urllib.parse.quote(ctx)
            paths[:0] = [
                f"/sage/Status?context={q}",
                f"/sage/NowPlaying?context={q}",
                f"/sage/CurrentMediaFile?context={q}",
                f"/sage/ExtenderStatus?context={q}",
            ]
        for path in list(dict.fromkeys(paths)):
            try:
                url = urllib.parse.urljoin(self.base_url + "/", path.lstrip("/"))
                body = self.fetch(path)
                detail = parse_detail_html(body, url)
                ids = mediafile_ids_from_text(body)
                detail_id = str(detail.get("media_file_id") or (ids[0] if ids else "")).strip()
                detail_airing_id = str(detail.get("airing_id") or "").strip()
                if detail.get("file_path"):
                    detail["source"] = "webui"
                    detail["captured_at"] = time.time()
                    # If the current/status page includes a MediaFileID, follow
                    # the real DetailedInfo page.  That page normally has the
                    # File Playlists and Streaming Playlists links that the
                    # status page does not expose.
                    if detail_id or detail_airing_id:
                        res = self.lookup_by_media_file_id(media_file_id=detail_id, airing_id=detail_airing_id)
                        if res.detail:
                            merged = dict(detail)
                            merged.update(res.detail)
                            merged.setdefault("file_path", detail.get("file_path"))
                            merged.setdefault("file_candidates", detail.get("file_candidates") or [detail.get("file_path")])
                            merged["source"] = "webui"
                            merged["captured_at"] = time.time()
                            id_note = f"MediaFileID={detail_id}" if detail_id else f"AiringID={detail_airing_id}"
                            return WebInterfaceLookupResult(self.enrich_with_playlist_url(merged), f"SageTV Web Interface current/status page returned {id_note} and DetailedInfo playlist links")
                    return WebInterfaceLookupResult(self.enrich_with_playlist_url(detail), f"SageTV Web Interface current/status page returned a file path: {path}")
                if detail_id or detail_airing_id:
                    res = self.lookup_by_media_file_id(media_file_id=detail_id, airing_id=detail_airing_id)
                    if res.detail:
                        res.detail = self.enrich_with_playlist_url(res.detail)
                        return res
            except urllib.error.HTTPError as exc:
                errors.append(f"{path}: HTTP {exc.code}")
            except Exception as exc:
                errors.append(f"{path}: {exc}")
        return WebInterfaceLookupResult({}, "; ".join(errors[-5:]) or "SageTV Web Interface did not expose current MediaFile/path")


def web_interface_lookup_current_media(base_url: str, username: str = "", password: str = "", client_id: str = "", push_url: str = "", timeout: float = 4.0) -> tuple[dict, str]:
    client = SageTVWebInterfaceClient(base_url, username, password, timeout)
    res = client.lookup_current_media(client_id=client_id, push_url=push_url)
    return res.detail, res.reason
