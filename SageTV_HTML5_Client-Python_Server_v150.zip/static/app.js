(() => {
  const serverEl = document.getElementById('server');
  const clientIdEl = document.getElementById('clientId');
  const connectBtn = document.getElementById('connectBtn');
  const disconnectBtn = document.getElementById('disconnectBtn');
  const mediaCapsEl = document.getElementById('mediaCaps');
  const mouseClickModeEl = document.getElementById('mouseClickMode');
  const guideMouseOkAssistEl = document.getElementById('guideMouseOkAssist');
  const mouseBackButtonSageBackEl = document.getElementById('mouseBackButtonSageBack');
  const osdTriggerModeEl = document.getElementById('osdTriggerMode');
  const fullscreenOnConnectEl = document.getElementById('fullscreenOnConnect');
  let renderOnlyMode = false;
  const videoEncoderEl = document.getElementById('videoEncoder');
  const encoderLatencyModeEl = document.getElementById('encoderLatencyMode');
  const qsvDecodeModeEl = document.getElementById('qsvDecodeMode');
  const qsvFilterModeEl = document.getElementById('qsvFilterMode');
  const videoMaxHeightEl = document.getElementById('videoMaxHeight');
  const videoBitrateEl = document.getElementById('videoBitrate');
  const videoFpsEl = document.getElementById('videoFps');
  const audioBitrateEl = document.getElementById('audioBitrate');
  const audioOffsetEl = document.getElementById('audioOffset');
  const videoMutedEl = document.getElementById('videoMuted');
  const videoDebugOverlayEl = document.getElementById('videoDebugOverlay');
  const hlsModeEl = document.getElementById('hlsMode');
  const bufferPresetEl = document.getElementById('bufferPreset');
  const hlsSegmentSecondsEl = document.getElementById('hlsSegmentSeconds');
  const hlsInitSecondsEl = document.getElementById('hlsInitSeconds');
  const hlsStartSegmentsEl = document.getElementById('hlsStartSegments');
  const hlsJsMaxBufferEl = document.getElementById('hlsJsMaxBuffer');
  const directReadModeEl = document.getElementById('directReadMode');
  const ffmpegBufferPresetEl = document.getElementById('ffmpegBufferPreset');
  const playerModeEl = document.getElementById('playerMode');
  const playbackSourceEl = document.getElementById('playbackSource');
  const directSageRootEl = document.getElementById('directSageRoot');
  const directLocalRootEl = document.getElementById('directLocalRoot');
  const directPathMapEl = document.getElementById('directPathMap');
  const directPathMapListEl = document.getElementById('directPathMapList');
  const directPathMapSaveBtn = document.getElementById('directPathMapSaveBtn');
  const directPathMapAddBtn = document.getElementById('directPathMapAddBtn');
  const directPathMapDeleteBtn = document.getElementById('directPathMapDeleteBtn');
  const hlsStorageModeEl = document.getElementById('hlsStorageMode');
  const webInterfaceServerEl = document.getElementById('webInterfaceServer');
  const webInterfaceUsernameEl = document.getElementById('webInterfaceUsername');
  const webInterfacePasswordEl = document.getElementById('webInterfacePassword');
  const sageDetailFileEl = document.getElementById('sageDetailFile');
  const sageDetailFormatEl = document.getElementById('sageDetailFormat');
  const hlsRamRootEl = document.getElementById('hlsRamRoot');
  const logEl = document.getElementById('log');
  const statusEl = document.getElementById('status');
  const mediaStatusEl = document.getElementById('mediaStatus');
  const sageVideo = document.getElementById('sageVideo');
  const sageVideoJs = document.getElementById('sageVideoJs');
  const videoLayer = document.getElementById('videoLayer');
  const videoBox = document.getElementById('videoBox');
  const navOverlay = document.getElementById('navOverlay');
  const showOverlayBtn = document.getElementById('showOverlayBtn');
  const navKeyboardPanel = document.getElementById('navKeyboardPanel');
  const navKeyboardInput = document.getElementById('navKeyboardInput');
  const screen = document.getElementById('screen');
  const stageWrap = document.getElementById('stageWrap');
  const dstCtx = screen.getContext('2d', { alpha: true });

  let ws = null;
  let curSurface = screen;
  let curCtx = dstCtx;
  let surfaces = {0: screen};
  let images = {};
  let firstFrame = true;
  let hls = null;
  let videoJsPlayer = null;
  let videoJsLastRecoverMs = 0;
  let videoJsErrorWindowStartMs = 0;
  let videoJsErrorCount = 0;
  let videoJsFallbackToHlsJs = false;
  let videoJsLastUrl = "";
  let videoJsLastSerial = 0;
  let videoJsSourceApplyCount = 0;
  let settingsDebounce = null;
  let currentVideoDst = [0,0,0,0];
  let currentVideoDstTrusted = false;
  let lastTrustedVideoDst = [0,0,0,0];
  let videoStatus = {};
  let videoSerial = 0;
  let videoLayerActive = false;
  // v119: keep track of the HLS/FFmpeg stream separately from whether the
  // browser should currently composite video under the SageTV GUI.  When Back
  // returns to a menu, SageTV may keep the media session alive for a moment;
  // the GUI must stop punching transparent video holes until playback is
  // actually shown again.
  let videoStreamActive = false;
  let videoPresentationSuspended = false;
  // v124: clear the browser GUI canvas at STARTFRAME, but clear it to
  // transparent instead of an opaque color.  The HTML5 client has the video as
  // a separate DOM layer underneath the SageTV canvas; an opaque clear covers
  // the subwindow video and makes menus look black.  A transparent clear resets
  // stale menu pixels while SageTV redraws the current frame on top.
  const CLEAR_EACH_FRAME = true;
  let frameHadClearRect = false;
  let frameHadVideoMask = false;
  let frameDrawOps = 0;
  let lastMenuSnapshot = null;
  let restoreMenuSnapshotOnNextFrame = false;
  let forcedOpaqueMenuClearFrames = 0;
  // v117: SageTV should be sending most menu/title text as texture images because
  // we request GFX_TEXTMODE=NONE.  Rendering fallback DRAWTEXT in the browser can
  // double-draw labels during video playback on some STVs, causing the white text
  // overlap seen over the Media Browser. Keep the commands available server-side
  // for detail capture, but do not paint them in the browser by default.
  const RENDER_FALLBACK_DRAWTEXT = false;
  const VIDEO_DEBUG_MAX_LOG_TAIL = 240;
  // v124: log throttling only. Do not change HLS playback/recovery behavior from
  // v122 because v123's extra non-fatal HLS recovery could break audio on some
  // browsers/devices.
  let lastCompositorLogKey = '';
  let lastCompositorLogMs = 0;
  const hlsErrorLogState = {};
  // v39: keep repainting the SageTV GUI even during playback. The video layer is
  // under the canvas; SageTV video-mask/color-key commands punch only the actual
  // video rectangle transparent so OSD/timeline/menu elements can draw on top.
  const VIDEO_COLORKEY_RGB = [8, 0, 16];

  const logLines = [];
  const MAX_LOG_LINES = 160;
  const clientLogPending = [];
  let clientLogFlushTimer = null;

  function queueClientLogLine(line) {
    try {
      clientLogPending.push(line);
      if (clientLogPending.length >= 20) flushClientLog();
      else if (!clientLogFlushTimer) clientLogFlushTimer = setTimeout(flushClientLog, 1500);
    } catch (e) {}
  }

  function flushClientLog() {
    if (clientLogFlushTimer) {
      clearTimeout(clientLogFlushTimer);
      clientLogFlushTimer = null;
    }
    if (!clientLogPending.length) return;
    const lines = clientLogPending.splice(0, clientLogPending.length);
    fetch('/api/client_log', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({client_id: currentClientId(), lines})
    }).catch(e => {
      // Avoid recursive log() calls if the log endpoint itself is down.
      try { console.warn('Could not save client log', e); } catch (_) {}
    });
  }

  function log(msg) {
    const ts = new Date().toLocaleTimeString();
    const line = `[${ts}] ${msg}`;
    logLines.unshift(line);
    if (logLines.length > MAX_LOG_LINES) logLines.length = MAX_LOG_LINES;
    // Rebuilding a very large <pre> on every render log was a major source of UI lag.
    logEl.textContent = logLines.join('\n');
    queueClientLogLine(line);
  }

  function logCompositorEvent(action, reason, force) {
    const now = performance.now();
    const key = `${action}:${reason || ''}`;
    if (force || key !== lastCompositorLogKey || (now - lastCompositorLogMs) > 15000) {
      lastCompositorLogKey = key;
      lastCompositorLogMs = now;
      log(`GUI video compositing ${action}: ${reason || 'video mask'}`);
    }
  }

  function shouldLogHlsEvent(key, intervalMs) {
    const now = performance.now();
    const rec = hlsErrorLogState[key] || {count: 0, last: 0};
    rec.count += 1;
    const allowed = rec.count <= 2 || (now - rec.last) >= intervalMs;
    if (allowed) rec.last = now;
    hlsErrorLogState[key] = rec;
    return allowed;
  }



  const CLIENT_SETTING_IDS = [
    'clientId','mediaCaps','videoEncoder','encoderLatencyMode','qsvDecodeMode','qsvFilterMode','videoMaxHeight',
    'videoBitrate','videoFps','audioBitrate','audioOffset','videoMuted','videoDebugOverlay','hlsMode',
    'bufferPreset','hlsSegmentSeconds','hlsInitSeconds','hlsStartSegments','hlsJsMaxBuffer','directReadMode','ffmpegBufferPreset','playerMode','mouseClickMode','guideMouseOkAssist','mouseBackButtonSageBack','osdTriggerMode','fullscreenOnConnect'
  ];

  const SERVER_SETTING_IDS = [
    'server','playbackSource','directSageRoot','directLocalRoot','directPathMap','hlsStorageMode','hlsRamRoot',
    'webInterfaceServer','webInterfaceUsername','webInterfacePassword'
  ];

  let settingsDebounceSave = null;
  let serverSettingsDebounceSave = null;
  let settingsDebounceLoad = null;
  let settingsApplying = false;

  function getSettingElement(id) { return document.getElementById(id); }

  const CLIENT_ID_COOKIE = 'sage_html5_client_id';

  function normalizeClientIdValue(value) {
    const raw = String(value || '').replace(/[^0-9a-fA-F]/g, '').toLowerCase();
    if (raw.length >= 12) {
      const r = raw.slice(0, 12);
      return r.match(/../g).join(':');
    }
    return String(value || '').trim();
  }

  function currentClientId() {
    return (clientIdEl && clientIdEl.value ? normalizeClientIdValue(clientIdEl.value) : '') || 'default';
  }

  function getCookieValue(name) {
    try {
      const prefix = encodeURIComponent(name) + '=';
      const parts = document.cookie ? document.cookie.split(';') : [];
      for (const part of parts) {
        const t = part.trim();
        if (t.startsWith(prefix)) return decodeURIComponent(t.slice(prefix.length));
      }
    } catch (e) {}
    return '';
  }

  function setCookieValue(name, value, maxAgeSeconds = 31536000) {
    try {
      document.cookie = `${encodeURIComponent(name)}=${encodeURIComponent(value)}; Max-Age=${maxAgeSeconds}; Path=/; SameSite=Lax`;
    } catch (e) {}
  }

  function persistClientIdCookie() {
    if (!clientIdEl) return;
    const id = currentClientId();
    if (!id || id === 'default') return;
    clientIdEl.value = id;
    setCookieValue(CLIENT_ID_COOKIE, id);
  }

  function makeRandomClientId() {
    const b = new Uint8Array(6);
    try { crypto.getRandomValues(b); } catch (e) {
      for (let i = 0; i < b.length; i++) b[i] = Math.floor(Math.random() * 256);
    }
    // Locally administered, unicast, and easy to recognize in logs.
    b[0] = 0x02; b[1] = 0x51; b[2] = 0x56;
    return Array.from(b).map(x => x.toString(16).padStart(2, '0')).join(':');
  }

  async function initializeClientIdFromCookieOrServer() {
    if (!clientIdEl) return;
    const cookieId = normalizeClientIdValue(getCookieValue(CLIENT_ID_COOKIE));
    if (cookieId && cookieId !== 'default') {
      clientIdEl.value = cookieId;
      log(`Client ID loaded from cookie: ${cookieId}`);
      return;
    }

    // Browsers do not expose the real device MAC address, and using ARP from the
    // server is unreliable across Wi-Fi isolation, VPNs, routers, and proxies.
    // Generate a private locally-administered ID in MAC format because SageTV's
    // MiniClient handshake still requires six MAC-style bytes. This is not the
    // hardware MAC; it is just a stable browser/client identity saved in a cookie.
    const id = makeRandomClientId();
    clientIdEl.value = id;
    setCookieValue(CLIENT_ID_COOKIE, id);
    log(`First-run Client ID generated as ${id} and saved in cookie. This is a private generated ID, not the device MAC.`);
  }

  function getUiSettingsObject(ids) {
    const settings = {};
    for (const id of ids) {
      const el = getSettingElement(id);
      if (!el) continue;
      settings[id] = el.type === 'checkbox' ? (el.checked ? '1' : '0') : el.value;
    }
    return settings;
  }

  function getClientSettingsObject() {
    const settings = getUiSettingsObject(CLIENT_SETTING_IDS);
    settings.clientId = currentClientId();
    return settings;
  }


  function getServerSettingsObject() {
    const settings = getUiSettingsObject(SERVER_SETTING_IDS);
    settings.directPathMap = directPathMapValue();
    return settings;
  }

  function normalizeDirectPathMapRows(value) {
    let data = value || [];
    if (typeof data === 'string') {
      const raw = data.trim();
      if (!raw) return [];
      try { data = JSON.parse(raw); }
      catch (e) {
        data = raw.split(/\r?\n/).map(line => {
          const t = line.trim();
          if (!t || t.startsWith('#')) return null;
          const idx = t.indexOf('=');
          if (idx >= 0) return {sage: t.slice(0, idx).trim(), local: t.slice(idx + 1).trim()};
          return {sage: t, local: ''};
        }).filter(Boolean);
      }
    }
    if (!Array.isArray(data)) return [];
    const rows = [];
    const seen = new Set();
    for (const item of data) {
      let sage = '', local = '';
      if (Array.isArray(item)) {
        sage = String(item[0] || '').trim();
        local = String(item[1] || '').trim();
      } else if (item && typeof item === 'object') {
        sage = String(item.sage || item.sage_root || '').trim();
        local = String(item.local || item.local_root || '').trim();
      }
      if (!sage) continue;
      const key = sage.replace(/\\/g, '/').replace(/\/+$/g, '').toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      rows.push({sage, local});
    }
    return rows;
  }

  function directPathMapValue() {
    return JSON.stringify(normalizeDirectPathMapRows(directPathMapEl ? directPathMapEl.value : '[]'));
  }

  function setDirectPathMapValue(value) {
    if (directPathMapEl) directPathMapEl.value = JSON.stringify(normalizeDirectPathMapRows(value));
    renderDirectPathMapList();
  }

  function directPathMapDisplay(row) {
    const local = String(row.local || '').trim();
    return `${row.sage || ''} = ${local}`;
  }

  function renderDirectPathMapList(preferredSage = '') {
    if (!directPathMapListEl) return;
    const rows = normalizeDirectPathMapRows(directPathMapEl ? directPathMapEl.value : '[]');
    const oldValue = preferredSage || directPathMapListEl.value || (directSageRootEl ? directSageRootEl.value : '');
    directPathMapListEl.innerHTML = '';
    rows.forEach((row, idx) => {
      const opt = document.createElement('option');
      opt.value = row.sage;
      opt.textContent = directPathMapDisplay(row);
      opt.dataset.index = String(idx);
      if (row.sage === oldValue) opt.selected = true;
      directPathMapListEl.appendChild(opt);
    });
    if (directPathMapListEl.selectedIndex < 0 && rows.length) directPathMapListEl.selectedIndex = 0;
    if (directPathMapListEl.selectedIndex >= 0) fillDirectPathMapTextboxesFromSelection();
  }

  function selectedDirectPathMapIndex() {
    if (!directPathMapListEl || directPathMapListEl.selectedIndex < 0) return -1;
    const opt = directPathMapListEl.options[directPathMapListEl.selectedIndex];
    const n = opt ? Number(opt.dataset.index) : -1;
    return Number.isFinite(n) ? n : -1;
  }

  function fillDirectPathMapTextboxesFromSelection() {
    const rows = normalizeDirectPathMapRows(directPathMapEl ? directPathMapEl.value : '[]');
    const idx = selectedDirectPathMapIndex();
    if (idx < 0 || !rows[idx]) return;
    if (directSageRootEl) directSageRootEl.value = rows[idx].sage || '';
    if (directLocalRootEl) directLocalRootEl.value = rows[idx].local || '';
  }

  function saveDirectPathMapRow(addNew = false) {
    const sage = String(directSageRootEl ? directSageRootEl.value : '').trim();
    const local = String(directLocalRootEl ? directLocalRootEl.value : '').trim();
    if (!sage) {
      log('Root Mapping not saved: Sage Root is blank.');
      return;
    }
    const rows = normalizeDirectPathMapRows(directPathMapEl ? directPathMapEl.value : '[]');
    let idx = addNew ? -1 : selectedDirectPathMapIndex();
    if (idx < 0 || !rows[idx]) {
      idx = rows.findIndex(r => String(r.sage || '').trim().toLowerCase() === sage.toLowerCase());
    }
    if (idx >= 0 && rows[idx]) rows[idx] = {sage, local};
    else rows.push({sage, local});
    if (directPathMapEl) directPathMapEl.value = JSON.stringify(normalizeDirectPathMapRows(rows));
    renderDirectPathMapList(sage);
    saveServerSettings();
    sendLiveVideoSettings();
    log(`Saved Direct Root Mapping: ${sage} = ${local}`);
  }

  function deleteDirectPathMapRow() {
    const idx = selectedDirectPathMapIndex();
    if (idx < 0) return;
    const rows = normalizeDirectPathMapRows(directPathMapEl ? directPathMapEl.value : '[]');
    const removed = rows.splice(idx, 1)[0];
    if (directPathMapEl) directPathMapEl.value = JSON.stringify(rows);
    renderDirectPathMapList();
    saveServerSettings();
    sendLiveVideoSettings();
    log(`Deleted Direct Root Mapping: ${removed ? removed.sage : ''}`);
  }


  function applyUiSettingsObject(settings, ids) {
    if (!settings || typeof settings !== 'object') return;
    settingsApplying = true;
    try {
      for (const id of ids) {
        // Do not let a saved setting from one folder change the profile key that
        // was just typed. The Client ID selects the per-client settings folder.
        if (id === 'clientId') continue;
        const el = getSettingElement(id);
        if (!el || settings[id] == null) continue;
        const value = String(settings[id]);
        if (el.type === 'checkbox') el.checked = value === '1' || value === 'true' || value === 'yes';
        else {
          const hasOption = !el.options || Array.from(el.options).some(o => o.value === value);
          if (hasOption) el.value = value;
        }
      }
    } finally {
      settingsApplying = false;
    }
  }

  async function loadServerSettings() {
    const clientId = currentClientId();
    try {
      const r = await fetch(`/api/server_settings?client_id=${encodeURIComponent(clientId)}`, {cache: 'no-store'});
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      const data = await r.json();
      if (data && data.settings) {
        applyUiSettingsObject(data.settings, SERVER_SETTING_IDS);
        setDirectPathMapValue(data.settings.directPathMap || directPathMapValue());
        sanitizeRemovedPlayerModeSetting();
        const migrated = data.legacy_used ? ' using legacy v65 values until saved' : '';
        log(`Loaded shared server settings from server_settings/settings.json${migrated}`);
        updatePlayerSpecificSettingAvailability();
        sendLiveVideoSettings();
      }
    } catch (e) {
      log(`Could not load shared server settings: ${e.message || e}`);
    }
  }

  async function loadClientSettings() {
    const clientId = currentClientId();
    try {
      const r = await fetch(`/api/client_settings?client_id=${encodeURIComponent(clientId)}`, {cache: 'no-store'});
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      const data = await r.json();
      if (data && data.exists && data.settings) {
        applyUiSettingsObject(data.settings, CLIENT_SETTING_IDS);
        sanitizeRemovedPlayerModeSetting();
        log(`Loaded client settings for Client ID ${clientId} from client_settings/${data.folder}/settings.json`);
        updatePlayerSpecificSettingAvailability();
        sendLiveVideoSettings();
      } else {
        updatePlayerSpecificSettingAvailability();
        log(`No client settings saved yet for Client ID ${clientId}; using current/default client values.`);
      }
    } catch (e) {
      log(`Could not load client settings: ${e.message || e}`);
    }
  }

  async function loadAllSettings() {
    await loadServerSettings();
    await loadClientSettings();
    try {
      const r = await fetch(`/api/log_paths?client_id=${encodeURIComponent(currentClientId())}`, {cache:'no-store'});
      if (r.ok) {
        const data = await r.json();
        if (data && data.client_log) log(`Client log: ${data.client_log}`);
        if (data && data.server_error_log) log(`Server error log: ${data.server_error_log}`);
      }
    } catch (e) {}
  }

  function saveClientSettings() {
    if (settingsApplying) return;
    const clientId = currentClientId();
    const settings = getClientSettingsObject();
    fetch('/api/client_settings', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({client_id: clientId, settings})
    }).then(r => {
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      return r.json();
    }).catch(e => log(`Could not save client settings: ${e.message || e}`));
  }

  function saveServerSettings() {
    if (settingsApplying) return;
    const settings = getServerSettingsObject();
    fetch('/api/server_settings', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({settings})
    }).then(r => {
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      return r.json();
    }).catch(e => log(`Could not save shared server settings: ${e.message || e}`));
  }

  function saveClientSettingsDebounced() {
    if (settingsDebounceSave) clearTimeout(settingsDebounceSave);
    settingsDebounceSave = setTimeout(saveClientSettings, 300);
  }

  function saveServerSettingsDebounced() {
    if (serverSettingsDebounceSave) clearTimeout(serverSettingsDebounceSave);
    serverSettingsDebounceSave = setTimeout(saveServerSettings, 300);
  }

  function loadClientSettingsDebounced() {
    if (settingsDebounceLoad) clearTimeout(settingsDebounceLoad);
    settingsDebounceLoad = setTimeout(loadClientSettings, 350);
  }

  function attachSettingsPersistence() {
    for (const id of CLIENT_SETTING_IDS) {
      const el = getSettingElement(id);
      if (!el) continue;
      if (id === 'clientId') {
        el.addEventListener('change', () => { persistClientIdCookie(); loadClientSettingsDebounced(); });
        if (el.tagName === 'INPUT') el.addEventListener('input', loadClientSettingsDebounced);
        continue;
      }
      el.addEventListener('change', () => { saveClientSettingsDebounced(); sendLiveVideoSettings(); });
      if (el.tagName === 'INPUT' && el.type !== 'checkbox') el.addEventListener('input', saveClientSettingsDebounced);
    }
    for (const id of SERVER_SETTING_IDS) {
      const el = getSettingElement(id);
      if (!el) continue;
      el.addEventListener('change', () => { saveServerSettingsDebounced(); sendLiveVideoSettings(); });
      if (el.tagName === 'INPUT' && el.type !== 'checkbox') el.addEventListener('input', saveServerSettingsDebounced);
    }
  }

  function videoDebugOverlayEnabled() {
    return !!(videoDebugOverlayEl && videoDebugOverlayEl.checked);
  }

  function strictModeEnabled() {
    // v66: explicit Source/Player selections are always strict.
    // Use Source=Auto Direct/PULL/PUSH when source fallback is desired. SageX API is lookup-only for MediaFile paths and timeline polling.
    return true;
  }

  function noFallbackEnabled() {
    return strictModeEnabled();
  }

  function setVideoBox(text) {
    if (!videoBox) return;
    if (!videoDebugOverlayEnabled()) {
      videoBox.classList.add('hidden');
      return;
    }
    if (text != null) videoBox.textContent = text;
    videoBox.classList.remove('hidden');
  }

  function hideVideoBox() {
    if (!videoBox) return;
    videoBox.classList.add('hidden');
  }

  function hideVideoLayer() {
    if (videoLayer) videoLayer.classList.add('hidden');
    if (sageVideo) sageVideo.classList.add('hidden');
    if (sageVideoJs) sageVideoJs.classList.add('hidden');
    if (videoJsPlayer && videoJsPlayer.el()) videoJsPlayer.el().classList.add('hidden');
  }

  function usingVideoJsPlayer() {
    const pm = String((videoStatus && videoStatus.player_mode) || (playerModeEl && playerModeEl.value) || '').toLowerCase();
    return pm === 'videojs' || pm === 'videojsfmp4';
  }

  function showActiveVideoLayer(force) {
    if (!force && (videoPresentationSuspended || !videoLayerActive)) return;
    if (videoLayer) videoLayer.classList.remove('hidden');
    if (usingVideoJsPlayer()) {
      if (sageVideo) sageVideo.classList.add('hidden');
      if (sageVideoJs) sageVideoJs.classList.remove('hidden');
      if (videoJsPlayer && videoJsPlayer.el()) videoJsPlayer.el().classList.remove('hidden');
    } else {
      if (sageVideo) sageVideo.classList.remove('hidden');
      if (sageVideoJs) sageVideoJs.classList.add('hidden');
      if (videoJsPlayer && videoJsPlayer.el()) videoJsPlayer.el().classList.add('hidden');
    }
  }

  function showRawVideoLayer() {
    if (!videoLayerActive && !videoStreamActive) return;
    if (videoLayer) videoLayer.classList.remove('hidden');
    if (sageVideo) sageVideo.classList.remove('hidden');
    if (sageVideoJs) sageVideoJs.classList.add('hidden');
    if (videoJsPlayer && videoJsPlayer.el()) videoJsPlayer.el().classList.add('hidden');
  }

  function showVideoJsLayer() {
    if (!videoLayerActive && !videoStreamActive) return;
    if (videoLayer) videoLayer.classList.remove('hidden');
    if (sageVideo) sageVideo.classList.add('hidden');
    if (sageVideoJs) sageVideoJs.classList.remove('hidden');
    if (videoJsPlayer && videoJsPlayer.el()) videoJsPlayer.el().classList.remove('hidden');
  }

  function pauseAndClearRawVideo() {
    if (!sageVideo) return;
    try { sageVideo.pause(); } catch (e) {}
    try { sageVideo.srcObject = null; } catch (e) {}
    try { sageVideo.removeAttribute('src'); sageVideo.load(); } catch (e) {}
    sageVideo.classList.add('hidden');
  }

  function isIOSLikeBrowser() {
    const ua = navigator.userAgent || '';
    return /iPad|iPhone|iPod/.test(ua) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  }

  function absoluteMediaUrl(url) {
    try { return new URL(url, window.location.href).href; } catch (e) { return url; }
  }

  function videoJsSourceList(url) {
    const abs = absoluteMediaUrl(url);
    // v62: give Video.js/VHS both standard HLS MIME spellings.  Some Video.js
    // builds reject application/x-mpegURL with "no supported sources" even
    // though hls.js can play the same playlist.
    return [
      {src: abs, type: 'application/vnd.apple.mpegurl'},
      {src: abs, type: 'application/x-mpegURL'},
      {src: abs, type: 'application/mpegurl'},
      {src: abs}
    ];
  }

  function applyVideoJsSource(player, url) {
    videoJsLastUrl = url || '';
    videoJsSourceApplyCount += 1;
    const sources = videoJsSourceList(url);
    try { player.error(null); } catch (e) {}
    player.src(sources);
    log(`Video.js source set: ${sources[0].src}`);
  }

  function ensureVideoJsPlayer() {
    if (!sageVideoJs || !window.videojs) return null;
    if (videoJsPlayer) return videoJsPlayer;
    const useNative = isIOSLikeBrowser();
    videoJsPlayer = window.videojs(sageVideoJs, {
      controls: false,
      autoplay: false,
      muted: !!(videoMutedEl && videoMutedEl.checked),
      preload: 'auto',
      liveui: false,
      fluid: false,
      fill: true,
      sources: [],
      html5: {
        nativeAudioTracks: useNative,
        nativeVideoTracks: useNative,
        vhs: {
          // v62: on desktop browsers force VHS instead of relying on native
          // canPlayType.  This fixes Video.js "element has no supported sources"
          // while the same playlist works in hls.js.
          overrideNative: !useNative,
          lowLatencyMode: false,
          liveRangeSafeTimeDelta: 2,
          useNetworkInformationApi: false
        }
      }
    });
    if (!window.videojs.Vhs && !window.videojs.Hls) {
      log('Video.js VHS/HLS plugin was not detected. If Video.js still says no supported sources, check internet/CDN access or use hls.js mode.');
    }
    videoJsPlayer.on('error', () => {
      const err = videoJsPlayer.error && videoJsPlayer.error();
      const msg = err ? (err.message || `code ${err.code || '?'}`) : 'unknown error';
      log(`Video.js error: ${msg}`);
      recoverVideoJsStream(`Video.js ${msg}`);
    });
    return videoJsPlayer;
  }

  function cleanupVideoJsSource(options = {}) {
    if (!videoJsPlayer) return;
    try { videoJsPlayer.pause(); } catch (e) {}
    if (options.clearSource !== false) {
      try { videoJsPlayer.reset(); } catch (e) {
        try { videoJsPlayer.src([]); } catch (_) {}
      }
      videoJsLastUrl = '';
    }
    if (videoJsPlayer.el()) videoJsPlayer.el().classList.add('hidden');
    if (sageVideoJs) sageVideoJs.classList.add('hidden');
  }

  async function recoverVideoJsStream(reason) {
    const now = performance.now();
    if (!videoStatus || !videoStatus.playlist_url) return;
    if (now - videoJsErrorWindowStartMs > 45000) {
      videoJsErrorWindowStartMs = now;
      videoJsErrorCount = 0;
      videoJsFallbackToHlsJs = false;
    }
    videoJsErrorCount += 1;

    // v62: repeated hard Video.js reloads were causing visible segment jumps.
    // Let Video.js/VHS retry once, then fall back to hls.js/native HLS for the
    // same playlist instead of resetting the player every few seconds.
    if (!noFallbackEnabled() && videoJsErrorCount >= 2 && !videoJsFallbackToHlsJs) {
      videoJsFallbackToHlsJs = true;
      log(`Video.js recovery: ${reason}; switching to hls.js/native HLS after repeated Video.js media errors`);
      setVideoBox('Switching from Video.js to hls.js HLS…');
      try { cleanupVideoJsSource(); } catch (e) {}
      try { await startHlsJsOrNativeStream(videoStatus.playlist_url, videoSerial); } catch (e) { log(`hls.js fallback failed: ${e.message || e}`); }
      return;
    }

    if (noFallbackEnabled() && videoJsErrorCount === 2) {
      log(`Video.js recovery: ${reason}; strict mode is enabled, staying on selected Video.js player`);
    }

    if (now - videoJsLastRecoverMs < 12000) return;
    videoJsLastRecoverMs = now;
    const player = ensureVideoJsPlayer();
    if (!player) return;
    log(`Video.js recovery: ${reason}; soft retry without hard playlist reset`);
    setVideoBox('Recovering Video.js HLS stream…');
    try {
      // Clear the error and try to continue. Avoid replacing src for normal
      // recovery because replacing src restarts VHS and usually jumps to a new
      // segment.  However, if Video.js lost the source list entirely, re-apply
      // the same playlist once so it can start.
      try { player.error(null); } catch (_) {}
      const cur = (player.currentSources && player.currentSources()) || [];
      if ((!cur || cur.length === 0) && videoJsLastUrl) {
        log('Video.js source list is empty during recovery; re-applying the selected playlist.');
        applyVideoJsSource(player, videoJsLastUrl);
      }
      const p = player.play();
      if (p && p.catch) {
        p.catch(err => {
          const m = err.message || String(err);
          log(`Video.js soft recovery play blocked: ${m}`);
          if (/no supported sources/i.test(m) && videoJsLastUrl) {
            log('Video.js reported no supported sources; re-applying HLS source with alternate MIME types.');
            try { applyVideoJsSource(player, videoJsLastUrl); } catch (_) {}
          }
        });
      }
    } catch (e) {
      log(`Video.js recovery failed: ${e.message || e}`);
    }
  }

  function send(obj) {
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(obj));
    }
  }

  function getVideoSettingsPayload() {
    return {
      video_encoder: videoEncoderEl ? videoEncoderEl.value : 'libx264',
      encoder_latency_mode: encoderLatencyModeEl ? encoderLatencyModeEl.value : 'faststart',
      qsv_decode_mode: qsvDecodeModeEl ? qsvDecodeModeEl.value : 'auto',
      qsv_filter_mode: qsvFilterModeEl ? qsvFilterModeEl.value : 'auto',
      video_max_height: videoMaxHeightEl ? videoMaxHeightEl.value : 'source',
      video_bitrate: videoBitrateEl ? videoBitrateEl.value : 'source',
      video_fps: videoFpsEl ? videoFpsEl.value : 'source',
      audio_bitrate: audioBitrateEl ? audioBitrateEl.value : '128k',
      audio_offset_ms: audioOffsetEl ? audioOffsetEl.value : '0',
      hls_mode: hlsModeEl ? hlsModeEl.value : 'stable',
      buffer_preset: selectedBufferPreset(),
      hls_segment_seconds: selectedHlsSegmentSeconds(),
      hls_init_seconds: selectedHlsInitSeconds(),
      hls_start_segments: selectedHlsStartSegments(),
      hlsjs_max_buffer_seconds: selectedHlsJsMaxBufferSeconds(),
      direct_read_mode: selectedDirectReadMode(),
      ffmpeg_buffer_preset: selectedFfmpegBufferPreset(),
      player_mode: playerModeEl ? playerModeEl.value : 'hls',
      playback_source: selectedPlaybackSource(),
      // v66: Strict mode checkbox removed. Explicit source/player choices are always strict.
      no_fallback: true,
      direct_sage_root: directSageRootEl ? directSageRootEl.value : '',
      direct_local_root: directLocalRootEl ? directLocalRootEl.value : '',
      direct_path_map: directPathMapValue(),
      hls_storage_mode: hlsStorageModeEl ? hlsStorageModeEl.value : 'disk',
      hls_ram_root: hlsRamRootEl ? hlsRamRootEl.value : '',
      web_interface_server: webInterfaceServerEl ? webInterfaceServerEl.value : '',
      web_interface_username: webInterfaceUsernameEl ? webInterfaceUsernameEl.value : '',
      web_interface_password: webInterfacePasswordEl ? webInterfacePasswordEl.value : ''
    };
  }

  function sendLiveVideoSettings() {
    if (!ws || ws.readyState !== WebSocket.OPEN) return;
    if (settingsDebounce) clearTimeout(settingsDebounce);
    settingsDebounce = setTimeout(() => {
      send(Object.assign({type: 'videoSettings'}, getVideoSettingsPayload()));
    }, 150);
  }

  function setStatus(s) { statusEl.textContent = s; }

  function updateSageDetail(detail) {
    const file = detail && detail.file_path ? String(detail.file_path) : '';
    const fmt = detail && detail.format ? String(detail.format) : '';
    if (sageDetailFileEl) sageDetailFileEl.textContent = file ? `SageX File: ${file}` : 'SageX File: none';
    if (sageDetailFormatEl) sageDetailFormatEl.textContent = fmt ? `SageX Format: ${fmt}` : 'SageX Format: none';
    if (file) log(`SageX API File: ${file}`);
    if (fmt) log(`SageX API Format: ${fmt}`);
  }


  function parseRgba(css) {
    const m = String(css || '').match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([0-9.]+))?\)/i);
    if (!m) return null;
    return {r: Number(m[1]), g: Number(m[2]), b: Number(m[3]), a: m[4] == null ? 1 : Number(m[4])};
  }

  function isVideoColorKey(css) {
    const c = parseRgba(css);
    if (!c) return false;
    return Math.abs(c.r - VIDEO_COLORKEY_RGB[0]) <= 2 && Math.abs(c.g - VIDEO_COLORKEY_RGB[1]) <= 2 && Math.abs(c.b - VIDEO_COLORKEY_RGB[2]) <= 2 && c.a > 0.5;
  }

  function isDarkMaskColor(css) {
    const c = parseRgba(css);
    if (!c) return false;
    return c.a < 0.05 || (c.a > 0.5 && c.r <= 12 && c.g <= 12 && c.b <= 18);
  }

  function rectIntersection(a, b) {
    const ax1 = Number(a[0] || 0), ay1 = Number(a[1] || 0), ax2 = ax1 + Number(a[2] || 0), ay2 = ay1 + Number(a[3] || 0);
    const bx1 = Number(b[0] || 0), by1 = Number(b[1] || 0), bx2 = bx1 + Number(b[2] || 0), by2 = by1 + Number(b[3] || 0);
    const x1 = Math.max(ax1, bx1), y1 = Math.max(ay1, by1), x2 = Math.min(ax2, bx2), y2 = Math.min(ay2, by2);
    if (x2 <= x1 || y2 <= y1) return null;
    return [x1, y1, x2 - x1, y2 - y1];
  }

  function clearTransparentRect(ctx, x, y, w, h) {
    if (!ctx || w <= 0 || h <= 0) return;
    ctx.save();
    ctx.globalCompositeOperation = 'destination-out';
    ctx.globalAlpha = 1;
    ctx.fillStyle = 'rgba(0,0,0,1)';
    ctx.fillRect(x, y, w, h);
    ctx.restore();
  }

  function currentVideoRect() {
    const v = currentVideoDst || [0,0,0,0];
    return [Number(v[0] || 0), Number(v[1] || 0), Number(v[2] || 0), Number(v[3] || 0)];
  }

  function rectHasArea(r) {
    return Array.isArray(r) && Number(r[2] || 0) > 0 && Number(r[3] || 0) > 0;
  }

  function ensureMenuSnapshotCanvas() {
    if (!screen || !screen.width || !screen.height) return null;
    if (!lastMenuSnapshot || lastMenuSnapshot.width !== screen.width || lastMenuSnapshot.height !== screen.height) {
      lastMenuSnapshot = document.createElement('canvas');
      lastMenuSnapshot.width = screen.width;
      lastMenuSnapshot.height = screen.height;
    }
    return lastMenuSnapshot;
  }

  function saveMenuSnapshot(reason) {
    try {
      const c = ensureMenuSnapshotCanvas();
      if (!c || !screen) return;
      const ctx = c.getContext('2d', {alpha: true});
      ctx.save();
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.globalAlpha = 1;
      ctx.globalCompositeOperation = 'copy';
      ctx.drawImage(screen, 0, 0);
      ctx.restore();
    } catch (e) {}
  }

  function clearCanvasOpaque(ctx, reason) {
    // Historical name kept so older call sites stay simple.  In the browser this
    // must be a transparent UI-layer clear, not a blue/black fill, because the
    // video is a separate DOM element below the canvas.
    try {
      const c = ctx || dstCtx;
      if (!c || !screen) return;
      c.save();
      c.setTransform(1, 0, 0, 1, 0, 0);
      c.globalAlpha = 1;
      c.globalCompositeOperation = 'copy';
      c.fillStyle = 'rgba(0,0,0,0)';
      c.fillRect(0, 0, screen.width, screen.height);
      c.restore();
    } catch (e) {}
  }

  function restoreMenuSnapshot(reason) {
    // v124: never restore a pre-video snapshot.  The current SageTV menu may be
    // different from the one that started playback.  Just clear the UI layer and
    // let SageTV draw the current frame.
    restoreMenuSnapshotOnNextFrame = false;
    clearCanvasOpaque(dstCtx, reason || 'menu restore clear');
  }

  function markMenuModeFromSage(reason) {
    if (!activeVideoStreamLikely() && !videoPresentationSuspended && !videoLayerActive) return;
    // Menu mode only disables the automatic STARTFRAME video punch-through.
    // Do not hide the real video element.  SageTV can still show live video in a
    // preview/subwindow while audio continues, and the next video-mask CLEAR_RECT
    // will decide where the player should be visible.
    videoPresentationSuspended = true;
    if (videoStreamActive) videoLayerActive = true;
    if (stageWrap) stageWrap.classList.remove('video-active');
    hideVideoBox();
    forcedOpaqueMenuClearFrames = 0;
    restoreMenuSnapshotOnNextFrame = false;
    if (videoStreamActive) showActiveVideoLayer(true);
    if (reason) log(`GUI renderer switched to menu mode: ${reason}`);
  }

  function clearVideoHole(ctx) {
    if (!videoLayerActive || videoPresentationSuspended || !currentVideoDstTrusted) return;
    const v = currentVideoRect();
    if (v[2] <= 0 || v[3] <= 0) return;
    // Expand by one pixel to avoid a thin color-key edge around the video.
    clearTransparentRect(ctx || dstCtx, v[0] - 1, v[1] - 1, v[2] + 2, v[3] + 2);
  }

  function activeVideoStreamLikely() {
    return !!(videoStreamActive || videoLayerActive || (videoStatus && (videoStatus.running || videoStatus.playlist_url)));
  }

  const VIDEO_MENU_NAV_COMMANDS = new Set([
    'back', 'home', 'guide', 'tv', 'library', 'video_library', 'recordings',
    'music', 'schedule', 'setup', 'options', 'search', 'dvd_menu', 'dvd', 'stop'
  ]);

  function requestSageFullRepaint(reason) {
    const sendResize = () => {
      if (!ws || ws.readyState !== WebSocket.OPEN || !screen) return;
      send({type:'resize', width: screen.width, height: screen.height, reason: reason || 'repaint'});
    };
    sendResize();
    setTimeout(sendResize, 150);
    setTimeout(sendResize, 500);
  }

  function forceMenuCompositingMode(reason) {
    if (!activeVideoStreamLikely()) return;
    // Back/Home/etc. should not tear down or hide the HTML5 video player.  It
    // only tells the UI compositor to stop using the last video rectangle as an
    // automatic full-frame hole.  The live subwindow will reappear from SageTV's
    // next explicit video-mask/CLEAR_RECT command.
    videoPresentationSuspended = true;
    if (videoStreamActive) videoLayerActive = true;
    if (stageWrap) stageWrap.classList.remove('video-active');
    hideVideoBox();
    forcedOpaqueMenuClearFrames = 0;
    restoreMenuSnapshotOnNextFrame = false;
    clearCanvasOpaque(dstCtx, reason || 'video menu navigation');
    if (videoStreamActive) showActiveVideoLayer(true);
    requestSageFullRepaint(reason || 'video menu navigation');
    logCompositorEvent('suspended', reason || 'menu navigation', true);
  }

  function resumeVideoCompositingMode(reason) {
    if (!activeVideoStreamLikely()) return;
    videoPresentationSuspended = false;
    videoLayerActive = true;
    if (!currentVideoDstTrusted && rectHasArea(lastTrustedVideoDst)) {
      currentVideoDst = lastTrustedVideoDst.slice();
      currentVideoDstTrusted = true;
    }
    if (stageWrap) stageWrap.classList.add('video-active');
    if (rectHasArea(currentVideoDst)) applyVideoBoundsStyles(currentVideoDst);
    // v121: hideVideoLayer() hides the actual <video>/Video.js element.  Resuming
    // by only unhiding #videoLayer leaves a black rectangle while audio continues.
    showActiveVideoLayer(true);
    clearVideoHole(dstCtx);
    logCompositorEvent('resumed', reason || 'video mask', false);
  }

  function maybeUpdateVideoBoundsFromMask(cmd, reason) {
    if (!screen || !activeVideoStreamLikely()) return false;
    const r = [Number(cmd.x || 0), Number(cmd.y || 0), Number(cmd.w || 0), Number(cmd.h || 0)];
    const hit = rectIntersection(r, [0, 0, screen.width, screen.height]);
    if (!hit) return false;
    const area = hit[2] * hit[3];
    const screenArea = Math.max(1, screen.width * screen.height);
    if (area < Math.max(64, screenArea * 0.01)) return false;
    // Treat SageTV's color-key/CLEAR_RECT mask as the authoritative video
    // rectangle.  This is what makes video previews/subwindows work after Back
    // without relying on stale full-screen bounds.
    updateVideoBounds(hit, {trusted:true, allowPlaybackFallback:false});
    return true;
  }

  function commandLooksLikeVideoMask(cmd) {
    if (!activeVideoStreamLikely()) return false;
    const r = [Number(cmd.x || 0), Number(cmd.y || 0), Number(cmd.w || 0), Number(cmd.h || 0)];
    const rectArea = Math.max(1, Math.abs((cmd.w || 0) * (cmd.h || 0)));
    const screenArea = Math.max(1, screen.width * screen.height);
    const explicitColorKey = isVideoColorKey(cmd.color);
    const darkClearMask = cmd.op === 'clearRect' && isDarkMaskColor(cmd.color);

    if (explicitColorKey) {
      maybeUpdateVideoBoundsFromMask(cmd, 'color-key video mask');
      resumeVideoCompositingMode('color-key video mask');
      return true;
    }

    if (darkClearMask) {
      const v = currentVideoRect();
      const hit = currentVideoDstTrusted ? rectIntersection(r, v) : null;
      const hitArea = hit ? hit[2] * hit[3] : 0;
      const videoArea = currentVideoDstTrusted ? Math.max(1, v[2] * v[3]) : 1;
      const lastHit = rectHasArea(lastTrustedVideoDst) ? rectIntersection(r, lastTrustedVideoDst) : null;
      const lastHitArea = lastHit ? lastHit[2] * lastHit[3] : 0;
      const lastArea = rectHasArea(lastTrustedVideoDst) ? Math.max(1, lastTrustedVideoDst[2] * lastTrustedVideoDst[3]) : 1;
      const largeEnough = rectArea >= screenArea * 0.35;
      const coversMostCurrentVideo = hitArea >= videoArea * 0.70;
      const coversMostLastVideo = lastHitArea >= lastArea * 0.70;
      if (largeEnough || coversMostCurrentVideo || coversMostLastVideo) {
        maybeUpdateVideoBoundsFromMask(cmd, 'dark CLEAR_RECT video mask');
        resumeVideoCompositingMode('dark CLEAR_RECT video mask');
        return true;
      }
    }

    if (!videoLayerActive || videoPresentationSuspended || !currentVideoDstTrusted) return false;
    const v = currentVideoRect();
    if (v[2] <= 0 || v[3] <= 0) return false;
    const hit = rectIntersection(r, v);
    if (!hit) return false;
    const hitArea = hit[2] * hit[3];
    const videoArea = Math.max(1, v[2] * v[3]);
    const coversMostVideo = hitArea >= videoArea * 0.70;
    const coversMostScreen = rectArea >= screenArea * 0.75;
    return isDarkMaskColor(cmd.color) && (coversMostVideo || coversMostScreen);
  }

  function clearMaskedVideoIntersection(cmd) {
    const r = [Number(cmd.x || 0), Number(cmd.y || 0), Number(cmd.w || 0), Number(cmd.h || 0)];
    const screenHit = rectIntersection(r, [0, 0, screen.width, screen.height]);
    if (!screenHit) return;

    if (isVideoColorKey(cmd.color) || (cmd.op === 'clearRect' && isDarkMaskColor(cmd.color))) {
      // Update the DOM video layer to the current SageTV mask before clearing
      // the canvas.  This allows the live video preview/subwindow to move from
      // full-screen playback back into the menu/video OSD without needing Stop.
      maybeUpdateVideoBoundsFromMask(cmd, 'mask clear');
    }

    const v = currentVideoRect();
    const hit = rectIntersection(screenHit, v) || (isVideoColorKey(cmd.color) ? screenHit : null);
    if (hit) clearTransparentRect(curCtx, hit[0] - 1, hit[1] - 1, hit[2] + 2, hit[3] + 2);
  }

  function connect() {
    persistClientIdCookie();
    if (ws) ws.close();
    const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
    ws = new WebSocket(`${proto}//${location.host}/ws`);
    ws.onopen = () => {
      log('WebSocket opened');
      try {
        resetRenderer();
        send({
          type: 'connect',
          server: serverEl.value.trim(),
          client_id: currentClientId(),
          width: screen.width,
          height: screen.height,
          media_caps: mediaCapsEl.checked,
          ...getVideoSettingsPayload()
        });
        if (fullscreenOnConnectEnabled()) {
          setTimeout(() => toggleRenderOnlyMode(true), 250);
        }
        screen.focus();
      } catch (e) {
        log(`Connect startup error: ${e && e.stack ? e.stack : e}`);
        setStatus('Browser connect error');
      }
    };
    ws.onmessage = (ev) => {
      const data = JSON.parse(ev.data);
      if (data.type === 'log') log(data.message);
      else if (data.type === 'gfx') renderCommands(data.commands || []);
      else if (data.type === 'resizeCanvas') resizeCanvas(data.width, data.height);
      else if (data.type === 'menuHint') {
        currentMenuHint = String(data.value || '');
        setStatus(`Menu: ${data.value}`);
      }
      else if (data.type === 'mediaStatus') { updateMediaStatus(data.status || {}); updateVideoBoundsFromMediaStatus(data.status || {}); }
      else if (data.type === 'videoBounds') updateVideoBounds(data.dst || [0,0,0,0], {trusted:true});
      else if (data.type === 'videoStream') startVideoStream(data.url, data.status || {});
      else if (data.type === 'videoStatus') { videoStatus = data.status || {}; updateMediaStatus(lastMediaStatus || {}); }
      else if (data.type === 'videoStop') stopVideoStream(data.status || {});
      else if (data.type === 'directPathMapUpdate') {
        setDirectPathMapValue(data.direct_path_map || '[]');
        const root = data.discovered_sage_root || '';
        if (root) {
          renderDirectPathMapList(root);
          log(`Auto-discovered Sage Root and added blank mapping: ${root} = `);
        }
        saveServerSettings();
      }
      else if (data.type === 'sageDetailUpdate') {
        updateSageDetail(data.detail || {});
        const root = data.discovered_sage_root || '';
        if (root) log(`SageX API discovered Sage Root: ${root} = `);
      }
      else log(`Unknown message ${ev.data}`);
    };
    ws.onclose = () => { log('WebSocket closed'); flushClientLog(); setStatus('Disconnected'); stopVideoStream({}); };
    ws.onerror = () => log('WebSocket error');
  }

  function resetRenderer() {
    dstCtx.clearRect(0, 0, screen.width, screen.height);
    surfaces = {0: screen};
    images = {};
    curSurface = screen;
    curCtx = dstCtx;
    firstFrame = true;
    frameHadClearRect = false;
    frameHadVideoMask = false;
    frameDrawOps = 0;
    restoreMenuSnapshotOnNextFrame = false;
    forcedOpaqueMenuClearFrames = 0;
    lastMenuSnapshot = null;
    setStatus('Connecting...');
    updateMediaStatus({state:'not connected'});
    stopVideoStream({});
    updateVideoBounds([0,0,0,0], {allowPlaybackFallback:false});
  }


  function activeVideoElementForMetrics() {
    const pm = String((videoStatus && videoStatus.player_mode) || (playerModeEl && playerModeEl.value) || '').toLowerCase();
    if ((pm === 'videojs' || pm === 'videojsfmp4') && sageVideoJs) return sageVideoJs;
    return sageVideo || sageVideoJs;
  }

  function videoReadyStateLabel(n) {
    const labels = ['HAVE_NOTHING','HAVE_METADATA','HAVE_CURRENT_DATA','HAVE_FUTURE_DATA','HAVE_ENOUGH_DATA'];
    n = Number(n || 0);
    return `${n}:${labels[n] || '?'}`;
  }

  function videoNetworkStateLabel(n) {
    const labels = ['EMPTY','IDLE','LOADING','NO_SOURCE'];
    n = Number(n || 0);
    return `${n}:${labels[n] || '?'}`;
  }

  function bufferedAheadSecondsFor(v) {
    try {
      if (!v || !v.buffered || v.buffered.length === 0) return 0;
      const t = Number(v.currentTime || 0);
      let bestEnd = 0;
      for (let i = 0; i < v.buffered.length; i++) {
        const start = v.buffered.start(i);
        const end = v.buffered.end(i);
        if (t >= start - 0.25 && t <= end + 0.25) bestEnd = Math.max(bestEnd, end);
        else if (start > t && bestEnd === 0) bestEnd = Math.max(bestEnd, end);
      }
      return Math.max(0, bestEnd - t);
    } catch (e) { return 0; }
  }

  function bufferedBehindSecondsFor(v) {
    try {
      if (!v || !v.buffered || v.buffered.length === 0) return 0;
      const t = Number(v.currentTime || 0);
      for (let i = 0; i < v.buffered.length; i++) {
        const start = v.buffered.start(i);
        const end = v.buffered.end(i);
        if (t >= start - 0.25 && t <= end + 0.25) return Math.max(0, t - start);
      }
    } catch (e) {}
    return 0;
  }

  function bufferedRangesText(v) {
    try {
      if (!v || !v.buffered || v.buffered.length === 0) return 'none';
      const out = [];
      for (let i = 0; i < Math.min(v.buffered.length, 4); i++) {
        out.push(`${v.buffered.start(i).toFixed(1)}-${v.buffered.end(i).toFixed(1)}`);
      }
      if (v.buffered.length > 4) out.push('…');
      return out.join(',');
    } catch (e) { return 'err'; }
  }

  function formatSec(n) {
    n = Number(n || 0);
    if (!Number.isFinite(n)) n = 0;
    return `${n.toFixed(1)}s`;
  }

  function bufferDebugLine() {
    const v = activeVideoElementForMetrics();
    const ahead = bufferedAheadSecondsFor(v);
    const behind = bufferedBehindSecondsFor(v);
    const cur = v ? Number(v.currentTime || 0) : 0;
    const dur = v && Number.isFinite(Number(v.duration)) ? Number(v.duration) : 0;
    const paused = v ? !!v.paused : true;
    const rs = v ? videoReadyStateLabel(v.readyState) : 'n/a';
    const ns = v ? videoNetworkStateLabel(v.networkState) : 'n/a';
    const segLen = Number(videoStatus.hls_time || selectedHlsSegmentSeconds() || 0);
    const made = Number(videoStatus.hls_seconds_produced || ((videoStatus.segments || 0) * segLen) || 0);
    const elapsed = Number(videoStatus.ffmpeg_elapsed_seconds || 0);
    const rate = Number(videoStatus.hls_fill_rate || 0);
    const latestAge = Number(videoStatus.latest_segment_age || 0);
    const target = Number(videoStatus.hlsjs_max_buffer_seconds || selectedHlsJsMaxBufferSeconds() || 0);
    let hlsDetails = '';
    try {
      if (hls) {
        const bw = hls.bandwidthEstimate ? `${Math.round(hls.bandwidthEstimate / 1000)}kbps` : '';
        const latency = Number.isFinite(hls.latency) ? ` latency=${hls.latency.toFixed(1)}s` : '';
        const level = Number.isFinite(hls.currentLevel) ? hls.currentLevel : -1;
        const autoLevel = Number.isFinite(hls.nextAutoLevel) ? hls.nextAutoLevel : -1;
        const levels = Array.isArray(hls.levels) ? hls.levels.map((l, i) => `${i}:${l.height || '?'}p/${Math.round((l.bitrate || 0) / 1000)}k`).join(',') : '';
        hlsDetails = ` hls.js bw=${bw}${latency} level=${level} next=${autoLevel} levels=[${levels}]`;
      }
    } catch (e) {}
    return `buffer: browserAhead=${formatSec(ahead)} behind=${formatSec(behind)} current=${formatSec(cur)} duration=${dur ? formatSec(dur) : 'live/unknown'} paused=${paused} ready=${rs} net=${ns} ranges=${bufferedRangesText(v)}\n` +
      `fill: serverMade=${formatSec(made)} elapsed=${formatSec(elapsed)} rate=${rate ? rate.toFixed(2) + 'x' : '0.00x'} latestSegAge=${formatSec(latestAge)} latest=${videoStatus.latest_segment_name || ''} endlist=${!!videoStatus.hls_endlist} maxBrowserBuffer=${formatSec(target)}${hlsDetails}`;
  }

  function formatMs(ms) {
    ms = Math.max(0, Math.floor(Number(ms || 0)));
    const s = Math.floor(ms / 1000);
    const hh = Math.floor(s / 3600);
    const mm = Math.floor((s % 3600) / 60);
    const ss = s % 60;
    if (hh > 0) return `${hh}:${String(mm).padStart(2,'0')}:${String(ss).padStart(2,'0')}`;
    return `${mm}:${String(ss).padStart(2,'0')}`;
  }

  let lastMediaStatus = null;

  function updateMediaStatus(st) {
    lastMediaStatus = st || lastMediaStatus || {};
    st = lastMediaStatus;
    if (!mediaStatusEl) return;
    const url = st.url || '';
    const shortUrl = url.length > 140 ? url.slice(0, 140) + '…' : url;
    mediaStatusEl.textContent =
      `state: ${st.state || 'unknown'}  push: ${!!st.push_mode}  time: ${formatMs(st.media_time_ms)}  serverStart: ${formatMs(st.last_server_start_ms)}\n` +
      `last command: ${st.last_command || ''}  pushed: ${st.bytes_pushed || 0} bytes in ${st.push_buffers || 0} buffers  flushes: ${st.flushes || 0}  seeks: ${st.seeks || 0}  eos: ${!!st.eos}\n` +
      `video src: ${(st.source_rect || []).join(',')}  dst: ${(st.dest_rect || []).join(',')}  size: ${(st.video_size || []).join('x')}\n` +
      `ffmpeg: ${videoStatus.running ? 'running' : 'stopped'}  player: ${videoStatus.player_mode || 'hls'}  encoder: ${videoStatus.encoder || ''}  latency=${videoStatus.encoder_latency_mode || (encoderLatencyModeEl ? encoderLatencyModeEl.value : 'faststart')}  qsv=${videoStatus.qsv_effective_decode_mode || 'off'}/${videoStatus.qsv_effective_filter_mode || ''}  in: ${videoStatus.bytes_in || 0} bytes / ${videoStatus.chunks_in || 0} chunks  q:${videoStatus.queued_chunks || 0}\n` +
      `source: ${videoStatus.input_source || 'push'}  input: ${videoStatus.direct_input_path || ''}  pull: ${videoStatus.pull_url || ''}  seek: ${Number(videoStatus.input_seek_seconds || 0).toFixed(3)}s  fill=${effectiveSourceFillLabel()}\n` +
      `storage: ${videoStatus.hls_storage_mode || (hlsStorageModeEl ? hlsStorageModeEl.value : 'disk')}  ram=${!!videoStatus.hls_storage_is_ram}  path=${videoStatus.hls_storage_path || ''}  note=${videoStatus.hls_storage_note || ''}\n` +
      `ffmpeg input: ${videoStatus.ffmpeg_buffer_preset || selectedFfmpegBufferPreset()}  flags=${videoStatus.ffmpeg_input_flags || ''}  maxDelay=${videoStatus.ffmpeg_max_delay ?? ''}  threadQ=${videoStatus.ffmpeg_thread_queue_size || ''}  probe=${videoStatus.ffmpeg_probesize || ''}  analyze=${videoStatus.ffmpeg_analyzeduration || ''}  muxQ=${videoStatus.ffmpeg_mux_queue_size || ''}  vbv=${videoStatus.video_bufsize || ''}\n` +
      `quality: maxH=${videoStatus.requested_max_height || ''}  fps=${videoStatus.video_fps || (videoFpsEl ? videoFpsEl.value : 'source')}→${videoStatus.effective_output_fps || 'source'}  gop=${videoStatus.effective_gop || ''}  bitrate=${videoStatus.requested_bitrate || ''}  effective=${videoStatus.effective_bitrate || ''}  audio=${videoStatus.audio_bitrate || (audioBitrateEl ? audioBitrateEl.value : '128k')}  audioOffset=${videoStatus.audio_offset_ms || 0}ms  pts=${videoStatus.pts_mode || ''}\n` +
      `segments: mode=${videoStatus.hls_mode || ''}  startup=${videoStatus.hls_init_time ?? selectedHlsInitSeconds()}s  max=${videoStatus.hls_time || selectedHlsSegmentSeconds()}s  start=${startSegmentsLabel(videoStatus)}  deleteThreshold=${videoStatus.hls_delete_threshold || ''}  capture=${!!videoStatus.capture_enabled}  bp=${videoStatus.backpressure_events || 0} drop=${videoStatus.dropped_input_chunks || 0}\n` +
      `hls: ${videoStatus.playlist_url || ''}  ready: ${!!videoStatus.playlist_ready}  segs: ${videoStatus.segments || 0}  error: ${videoStatus.last_error || ''}\n` +
      `${bufferDebugLine()}\n` +
      (videoStatus.ts_sync_state ? `ts sync: ${videoStatus.ts_sync_state} (${videoStatus.ts_sync_bytes || 0} buffered)\n` : '') +
      (videoStatus.fallback_reason ? `start/restart reason: ${videoStatus.fallback_reason}\n` : '') +
      (videoStatus.ffmpeg_log_tail ? `ffmpeg tail: ${String(videoStatus.ffmpeg_log_tail).replace(/\\s+/g, ' ').slice(-VIDEO_DEBUG_MAX_LOG_TAIL)}\n` : '') +
      `url: ${shortUrl}`;
  }

  function normalizeVideoBounds(dst, allowPlaybackFallback) {
    const d = Array.isArray(dst) ? dst : [];
    let x = Number(d[0] || 0), y = Number(d[1] || 0), w = Number(d[2] || 0), h = Number(d[3] || 0);
    if (w > 0 && h > 0) return [x, y, w, h];

    // v117: keep the player element alive if playback starts before a valid video
    // rectangle arrives, but mark this as untrusted. Untrusted fallback bounds are
    // only used to size the hidden/behind video player; they must not punch the GUI
    // canvas transparent or the Media Browser becomes dim and stale-looking.
    if (allowPlaybackFallback && videoLayerActive) {
      const cur = Array.isArray(currentVideoDst) ? currentVideoDst : [];
      const cw = Number(cur[2] || 0), ch = Number(cur[3] || 0);
      if (currentVideoDstTrusted && cw > 0 && ch > 0) return [Number(cur[0] || 0), Number(cur[1] || 0), cw, ch];
      if (screen && screen.width > 0 && screen.height > 0) return [0, 0, screen.width, screen.height];
    }
    return [0, 0, 0, 0];
  }

  function applyVideoBoundsStyles(dst) {
    if (!videoBox || !videoLayer) return;
    const x = Number(dst[0] || 0), y = Number(dst[1] || 0), w = Number(dst[2] || 0), h = Number(dst[3] || 0);
    if (w <= 0 || h <= 0) return;
    const r = screen.getBoundingClientRect();
    const sx = r.width / screen.width;
    const sy = r.height / screen.height;
    const left = `${x * sx}px`, top = `${y * sy}px`, width = `${w * sx}px`, height = `${h * sy}px`;
    for (const el of [videoBox, videoLayer]) {
      el.style.left = left; el.style.top = top; el.style.width = width; el.style.height = height;
    }
  }

  function updateVideoBounds(dst, options) {
    const allowPlaybackFallback = !options || options.allowPlaybackFallback !== false;
    const rawHasArea = rectHasArea(dst);
    const trusted = !!(options && options.trusted === true) || (rawHasArea && (!options || options.trusted !== false));
    dst = normalizeVideoBounds(dst, allowPlaybackFallback);
    currentVideoDst = dst;
    currentVideoDstTrusted = trusted && rectHasArea(dst);
    if (currentVideoDstTrusted) lastTrustedVideoDst = dst.slice();
    if (!videoBox || !videoLayer) return;
    const w = Number(dst[2] || 0), h = Number(dst[3] || 0);
    if (w <= 0 || h <= 0) {
      currentVideoDstTrusted = false;
      hideVideoBox();
      // Only hide the DOM video player when playback has really stopped. During
      // menu navigation SageTV may keep audio/video alive and later send a new
      // preview/OSD rectangle.
      if (!videoStreamActive) hideVideoLayer();
      return;
    }
    applyVideoBoundsStyles(dst);
    const pmLabel = (videoStatus.player_mode || '').toLowerCase();
    const playerLabel = pmLabel === 'videojsfmp4' ? 'Video.js HLS fMP4' : (pmLabel === 'videojs' ? 'Video.js HLS' : 'HTML5 video');
    setVideoBox(videoStatus.playlist_url ? `Starting ${playerLabel}…` : 'Waiting for FFmpeg/HLS stream…');
    if (videoLayerActive || videoStreamActive) showActiveVideoLayer(true);
    if (videoLayerActive && !videoPresentationSuspended && currentVideoDstTrusted) clearVideoHole(dstCtx);
  }

  function updateVideoBoundsFromMediaStatus(st) {
    if (!st || !Array.isArray(st.dest_rect)) return;
    if (rectHasArea(st.dest_rect)) updateVideoBounds(st.dest_rect, {trusted:true});
  }

  function hlsSessionIdFromUrl(url) {
    const m = String(url || '').match(/\/hls\/([^\/]+)\//);
    return m ? m[1] : '';
  }


  function numberFromSelect(el, fallback, minValue, maxValue) {
    try {
      const n = Number(el ? el.value : fallback);
      if (!Number.isFinite(n)) return fallback;
      return Math.max(minValue, Math.min(maxValue, n));
    } catch (e) {
      return fallback;
    }
  }

  function selectedBufferPreset() {
    return (bufferPresetEl ? bufferPresetEl.value : 'ios') || 'ios';
  }

  function selectedHlsSegmentSeconds() {
    return numberFromSelect(hlsSegmentSecondsEl, selectedBufferPreset() === 'maximum' ? 8 : 4, 1, 12);
  }

  function selectedHlsInitSeconds() {
    const maxSeg = selectedHlsSegmentSeconds();
    const n = numberFromSelect(hlsInitSecondsEl, 1, 0, 4);
    return Math.max(0, Math.min(maxSeg, n));
  }

  function selectedHlsStartSegments() {
    // 0 = Auto by encode/fill rate.
    return numberFromSelect(hlsStartSegmentsEl, 0, 0, 10);
  }

  function requiredStartSegmentsForStatus(st) {
    const manual = selectedHlsStartSegments();
    if (manual > 0) return manual;
    const rate = Number((st && st.video && st.video.hls_fill_rate) || (st && st.hls_fill_rate) || videoStatus.hls_fill_rate || 0);
    if (!Number.isFinite(rate) || rate <= 0) return 1;
    if (rate >= 1.50) return 1;
    if (rate >= 1.15) return 2;
    if (rate >= 1.00) return 3;
    return 4;
  }

  function startSegmentsLabel(st) {
    const manual = selectedHlsStartSegments();
    if (manual > 0) return String(manual);
    return `auto/${requiredStartSegmentsForStatus(st)}`;
  }

  function selectedHlsJsMaxBufferSeconds() {
    return numberFromSelect(hlsJsMaxBufferEl, selectedBufferPreset() === 'lowdelay' ? 60 : (selectedBufferPreset() === 'maximum' ? 300 : 180), 30, 600);
  }

  function selectedPlaybackSource() {
    const src = ((playbackSourceEl ? playbackSourceEl.value : 'direct') || 'direct').toLowerCase();
    return src === 'web' ? 'direct' : src;
  }

  function selectedDirectReadMode() {
    const v = ((directReadModeEl ? directReadModeEl.value : 'auto') || 'auto').toLowerCase();
    if (v === 'realtime') return 'realtime';
    if (v === 'fast') return 'fast';
    return 'auto';
  }

  function selectedFfmpegBufferPreset() {
    const v = ((ffmpegBufferPresetEl ? ffmpegBufferPresetEl.value : 'normal') || 'normal').toLowerCase();
    if (v === 'huge') return 'huge';
    if (v === 'large') return 'large';
    return 'normal';
  }


  function sanitizeRemovedPlayerModeSetting() {
    try {
      const removedRtcMode = 'web' + 'rtc';
      const removedAbrMode = 'hls' + 'abr';
      if (playerModeEl && (
        !playerModeEl.value ||
        playerModeEl.value === removedRtcMode ||
        playerModeEl.value === removedAbrMode
      )) playerModeEl.value = 'hls';
      if (playbackSourceEl && (!playbackSourceEl.value || playbackSourceEl.value === 'web')) {
        playbackSourceEl.value = 'direct';
      }
    } catch (e) {}
  }

  function selectedPlayerMode() {
    return String(playerModeEl ? playerModeEl.value : 'hls').toLowerCase();
  }

  function settingRowFor(el) {
    if (!el) return null;
    return el.closest('label') || el;
  }

  function setSettingVisible(el, visible, hiddenTitle) {
    const row = settingRowFor(el);
    if (row) row.classList.toggle('settingHidden', !visible);
    if (!el) return;
    el.disabled = !visible;
    if (!visible) {
      if (!el.dataset.origTitle) el.dataset.origTitle = el.getAttribute('title') || '';
      if (hiddenTitle) el.setAttribute('title', hiddenTitle);
    } else if (el.dataset.origTitle !== undefined) {
      el.setAttribute('title', el.dataset.origTitle);
    }
  }

  function setGroupVisible(selector, visible) {
    const group = document.querySelector(selector);
    if (group) group.classList.toggle('settingHidden', !visible);
  }

  function isHlsJsPlayerMode(pm) {
    return pm === 'hls' || pm === 'hlsfmp4';
  }

  function isVideoJsPlayerMode(pm) {
    return pm === 'videojs' || pm === 'videojsfmp4';
  }


  function updatePlayerSpecificSettingAvailability() {
    const pm = selectedPlayerMode();
    const src = selectedPlaybackSource();
    const hlsJs = isHlsJsPlayerMode(pm);
    const videoJs = isVideoJsPlayerMode(pm);
    const hlsFamily = hlsJs || videoJs;
    const ffmpegFamily = true;
    const usesAudioSync = true;
    const sourceCanFill = src !== 'push';
    const rootsUseful = src === 'direct' || src === 'auto';
    const webUseful = true;
    const hlsRamUseful = hlsFamily && hlsStorageModeEl && hlsStorageModeEl.value === 'ram';

    // Source/server settings.
    setSettingVisible(directPathMapListEl, rootsUseful, 'Used only by Direct File/SMB or Auto mode.');
    setSettingVisible(directSageRootEl, rootsUseful, 'Used only by Direct File/SMB or Auto mode.');
    setSettingVisible(directLocalRootEl, rootsUseful, 'Used only by Direct File/SMB or Auto mode.');
    setSettingVisible(directPathMapSaveBtn, rootsUseful, 'Used only by Direct File/SMB or Auto mode.');
    setSettingVisible(directPathMapAddBtn, rootsUseful, 'Used only by Direct File/SMB or Auto mode.');
    setSettingVisible(directPathMapDeleteBtn, rootsUseful, 'Used only by Direct File/SMB or Auto mode.');
    setSettingVisible(webInterfaceServerEl, webUseful);
    setSettingVisible(webInterfaceUsernameEl, webUseful);
    setSettingVisible(webInterfacePasswordEl, webUseful);
    setSettingVisible(hlsStorageModeEl, hlsFamily, 'Used only by HLS players because they write playlists and segment files.');
    setSettingVisible(hlsRamRootEl, hlsRamUseful, 'Used only when HLS Storage is RAM/tmpfs/RAM disk.');

    // Player-level controls.
    setSettingVisible(hlsModeEl, hlsFamily, 'Used only by HLS players.');
    setSettingVisible(videoMutedEl, true);
    setSettingVisible(videoDebugOverlayEl, true);


    // Buffer/stability controls.
    setGroupVisible('.bufferGroup', ffmpegFamily);
    setSettingVisible(bufferPresetEl, hlsFamily, 'Used only by HLS players.');
    setSettingVisible(hlsSegmentSecondsEl, hlsFamily, 'Used only by HLS players.');
    setSettingVisible(hlsInitSecondsEl, hlsFamily, 'Used only by HLS players.');
    setSettingVisible(hlsStartSegmentsEl, hlsFamily, 'Used only by HLS players.');
    setSettingVisible(hlsJsMaxBufferEl, hlsJs, 'Used only by hls.js players. Video.js/VHS and native HLS manage their own browser buffer.');
    setSettingVisible(directReadModeEl, sourceCanFill, 'Used only by Direct File/SMB, SageTV PULL, or Auto source with FFmpeg players. PUSHBUFFER is always live-paced.');
    setSettingVisible(ffmpegBufferPresetEl, ffmpegFamily, 'Used by FFmpeg-based HLS/Video.js players.');

    // Quality/sync controls.
    setGroupVisible('.qualityGroup', ffmpegFamily || usesAudioSync);
    setSettingVisible(videoEncoderEl, ffmpegFamily, 'Used only by FFmpeg-based HLS/Video.js players.');
    setSettingVisible(encoderLatencyModeEl, ffmpegFamily, 'Fast Start applies low-latency FFmpeg encoder options per encoder family.');
    const qsvSelected = ffmpegFamily && videoEncoderEl && String(videoEncoderEl.value || '').toLowerCase().includes('qsv');
    setSettingVisible(qsvDecodeModeEl, qsvSelected, 'Used only with Intel QSV encoders. Auto uses Windows D3D11VA or Linux DRM when available.');
    setSettingVisible(qsvFilterModeEl, qsvSelected, 'Used only with Intel QSV encoders. Auto uses QSV deinterlace/scale and FPS guard.');
    setSettingVisible(videoMaxHeightEl, ffmpegFamily, 'Used only by FFmpeg-based HLS/Video.js players.');
    setSettingVisible(videoFpsEl, ffmpegFamily, 'Used only by FFmpeg-based HLS/Video.js players.');
    setSettingVisible(videoBitrateEl, ffmpegFamily, 'Used only by FFmpeg-based HLS/Video.js players.');
    setSettingVisible(audioBitrateEl, ffmpegFamily, 'Used only by FFmpeg-based HLS/Video.js players.');
    setSettingVisible(audioOffsetEl, usesAudioSync, 'Optional FFmpeg audio offset. Negative delays video. Positive delays audio.');

    const msg = document.getElementById('playerModeHelp');
    if (msg) {
      if (hlsJs) msg.textContent = 'hls.js HLS shows HLS buffer, segment, FFmpeg, quality, and source-fill controls.';
      else if (videoJs) msg.textContent = 'Video.js HLS shows HLS segment/storage, FFmpeg, quality, and source-fill controls. hls.js-only buffer controls are hidden.';
      else msg.textContent = 'Only settings used by the selected player are shown.';
    }
  }

  function effectiveSourceFillLabel() {
    const src = String(videoStatus.input_source || selectedPlaybackSource() || '').toLowerCase();
    if (src === 'push') return 'push-live';
    return videoStatus.direct_read_mode || selectedDirectReadMode();
  }

  async function waitForPlaylist(url, serial, timeoutMs = 75000) {
    const started = performance.now();
    const sid = hlsSessionIdFromUrl(url);
    let lastLog = 0;
    let lastWaitBytes = -1;
    let lastWaitSegments = -1;
    while (performance.now() - started < timeoutMs) {
      if (serial !== videoSerial) return false;
      try {
        if (sid) {
          const stRes = await fetch(`/api/hls_ready/${sid}`, {cache: 'no-store'});
          if (stRes.ok) {
            const st = await stRes.json();
            if (st.video) {
              videoStatus = st.video;
              updateMediaStatus(lastMediaStatus || {});
              setVideoBox(`Waiting for FFmpeg/HLS… ${videoStatus.bytes_in || 0} bytes, ${videoStatus.segments || 0}/${startSegmentsLabel(st)} start segments, rate=${Number(videoStatus.hls_fill_rate || 0).toFixed(2)}x`);
            }
            const needSegments = requiredStartSegmentsForStatus(st);
            if (st.ready && (!st.video || Number(st.video.segments || 0) >= needSegments)) return true;
          }
        } else {
          const res = await fetch(url, {cache: 'no-store'});
          if (res.ok) {
            const txt = await res.text();
            if (txt.includes('#EXTM3U')) return true;
          }
        }
      } catch (e) {}
      const waitBytes = Number(videoStatus.bytes_in || 0);
      const waitSegments = Number(videoStatus.segments || 0);
      const progressChanged = waitBytes !== lastWaitBytes || waitSegments !== lastWaitSegments;
      const now = performance.now();
      if ((progressChanged && now - lastLog > 1000) || (now - lastLog > 15000)) {
        lastLog = now;
        lastWaitBytes = waitBytes;
        lastWaitSegments = waitSegments;
        log(`Waiting for HLS playlist from FFmpeg… ${waitBytes} bytes received, ${waitSegments} segments`);
      }
      await new Promise(r => setTimeout(r, 500));
    }
    return false;
  }

  function playVideoElement() {
    if (!sageVideo) return;
    sageVideo.play().catch(err => {
      log(`Video play blocked/delayed: ${err.message || err}`);
      if (!sageVideo.muted) {
        log('Retrying muted so video can start. Uncheck/check Mute video and restart playback for audio.');
        sageVideo.muted = true;
        sageVideo.play().catch(err2 => log(`Muted video play also failed: ${err2.message || err2}`));
      }
    });
  }

  function activeNativeVideoElement() {
    if (usingVideoJsPlayer() && sageVideoJs) return sageVideoJs;
    return sageVideo || sageVideoJs;
  }

  function pauseActiveVideoPlayback(reason) {
    let did = false;
    try {
      if (videoJsPlayer) { videoJsPlayer.pause(); did = true; }
    } catch (e) {}
    for (const v of [sageVideo, sageVideoJs]) {
      try { if (v && !v.paused) { v.pause(); did = true; } } catch (e) {}
    }
    if (reason && did) log(`Local video paused: ${reason}`);
    updateMediaStatus(lastMediaStatus || {});
    return did;
  }

  function playActiveVideoPlayback(reason) {
    showActiveVideoLayer(true);
    let did = false;
    try {
      if (videoJsPlayer && usingVideoJsPlayer()) {
        const r = videoJsPlayer.play();
        if (r && typeof r.catch === 'function') r.catch(err => log(`Video.js play blocked/delayed: ${err.message || err}`));
        did = true;
      }
    } catch (e) {}
    const v = activeNativeVideoElement();
    if (v && v !== sageVideoJs) {
      try {
        const r = v.play();
        if (r && typeof r.catch === 'function') r.catch(err => log(`Video play blocked/delayed: ${err.message || err}`));
        did = true;
      } catch (e) {}
    } else if (v && !usingVideoJsPlayer()) {
      try {
        const r = v.play();
        if (r && typeof r.catch === 'function') r.catch(err => log(`Video play blocked/delayed: ${err.message || err}`));
        did = true;
      } catch (e) {}
    }
    if (reason && did) log(`Local video play: ${reason}`);
    updateMediaStatus(lastMediaStatus || {});
    return did;
  }

  function applyLocalMediaControlFromCommand(cmd) {
    const c = String(cmd || '').toLowerCase();
    if (!['play', 'pause', 'play_pause', 'stop'].includes(c)) return false;
    if (!activeVideoStreamLikely() && c !== 'stop') return false;

    let action = c;
    if (action === 'play_pause') {
      const v = activeNativeVideoElement();
      action = (v && v.paused) ? 'play' : 'pause';
    }

    if (action === 'pause') {
      pauseActiveVideoPlayback('user command');
      send({type:'localMediaControl', action:'pause'});
      return true;
    }
    if (action === 'play') {
      videoPresentationSuspended = false;
      if (videoStreamActive) videoLayerActive = true;
      playActiveVideoPlayback('user command');
      send({type:'localMediaControl', action:'play'});
      return true;
    }
    if (action === 'stop') {
      // v129: stop the local HLS/DOM player immediately.  SageTV may first show
      // an OSD/Stop menu and delay MEDIACMD_STOP until a second Stop press; the
      // browser video bridge should not keep playing behind that menu.
      send({type:'localMediaControl', action:'stop'});
      stopVideoStream(Object.assign({}, videoStatus || {}, {running:false, state:'stopped'}));
      updateVideoBounds([0,0,0,0], {allowPlaybackFallback:false});
      return true;
    }
    return false;
  }

  if (sageVideo) {
    sageVideo.addEventListener('error', () => {
      const code = sageVideo.error ? sageVideo.error.code : '?';
      log(`HTML video element error code=${code}`);
    });
  }

  async function startVideoJsHlsStream(url, st, serial) {
    const ok = await waitForPlaylist(url, serial);
    if (serial !== videoSerial) return;
    if (!ok) {
      setVideoBox('Timed out waiting for HLS playlist');
      log('Timed out waiting for Video.js HLS playlist. Check FFmpeg log/status.');
      return;
    }

    videoJsErrorWindowStartMs = performance.now();
    videoJsErrorCount = 0;
    videoJsFallbackToHlsJs = false;

    const player = ensureVideoJsPlayer();
    if (!player) {
      setVideoBox('Video.js is not loaded; falling back to hls.js HLS');
      log('Video.js script is not loaded. Falling back to hls.js/native HLS.');
      await startHlsJsOrNativeStream(url, serial);
      return;
    }

    pauseAndClearRawVideo();
    player.muted(!!(videoMutedEl && videoMutedEl.checked));
    player.controls(false);
    player.autoplay(false);
    setVideoBox(((videoStatus.player_mode || '').toLowerCase() === 'videojsfmp4') ? 'Starting Video.js HLS fMP4…' : 'Starting Video.js HLS…');
    try {
      videoJsLastSerial = serial;
      videoJsSourceApplyCount = 0;
      applyVideoJsSource(player, url);
      player.ready(() => {
        if (serial !== videoSerial) return;
        hideVideoBox();
        showVideoJsLayer();
        try { player.currentTime(0); } catch (e) {}
        const p = player.play();
        if (p && p.catch) {
          p.catch(err => {
            log(`Video.js play blocked/delayed: ${err.message || err}`);
            if (!player.muted()) {
              log('Retrying Video.js muted so video can start. Uncheck/check Mute video and restart playback for audio.');
              player.muted(true);
              const p2 = player.play();
              if (p2 && p2.catch) p2.catch(err2 => log(`Muted Video.js play also failed: ${err2.message || err2}`));
            }
          });
        }
      });
    } catch (e) {
      log(`Video.js start failed: ${e.message || e}`);
      if (noFallbackEnabled()) {
        setVideoBox('Video.js start failed; strict mode is enabled.');
      } else {
        setVideoBox('Video.js start failed; trying hls.js HLS…');
        await startHlsJsOrNativeStream(url, serial);
      }
    }
  }

  async function startHlsJsOrNativeStream(url, serial) {
    if (hls) { try { hls.destroy(); } catch (e) {} hls = null; }
    try { Object.keys(hlsErrorLogState).forEach(k => delete hlsErrorLogState[k]); } catch (e) {}
    if (window.Hls && window.Hls.isSupported()) {
      if (serial !== videoSerial) return;
      showRawVideoLayer();
      const preset = selectedBufferPreset();
      const startSegs = selectedHlsStartSegments();
      const maxBuf = selectedHlsJsMaxBufferSeconds();
      const lowDelay = preset === 'lowdelay';
      hls = new Hls({
        lowLatencyMode: false,
        startPosition: 0,
        liveSyncDurationCount: lowDelay ? 4 : Math.max(8, startSegs + 4),
        liveMaxLatencyDurationCount: lowDelay ? 20 : Math.max(60, startSegs * 12),
        maxLiveSyncPlaybackRate: 1.0,
        maxBufferLength: lowDelay ? 45 : maxBuf,
        maxMaxBufferLength: lowDelay ? 60 : Math.max(maxBuf, 180),
        backBufferLength: lowDelay ? 30 : Math.min(maxBuf, 180),
        liveBackBufferLength: lowDelay ? 30 : Math.min(maxBuf, 180),
        maxBufferHole: lowDelay ? 0.75 : 2.0,
        maxSeekHole: lowDelay ? 0.75 : 2.0,
        fragLoadingMaxRetry: lowDelay ? 8 : 20,
        manifestLoadingMaxRetry: lowDelay ? 8 : 20,
        levelLoadingMaxRetry: lowDelay ? 8 : 20,
        fragLoadingRetryDelay: lowDelay ? 500 : 1000,
        fragLoadingMaxRetryTimeout: lowDelay ? 8000 : 30000,
        capLevelToPlayerSize: false
      });
      hls.on(Hls.Events.ERROR, (event, data) => {
        const type = data ? (data.type || 'error') : 'error';
        const details = data ? (data.details || 'unknown') : 'unknown';
        const fatal = !!(data && data.fatal);
        const interval = (details === 'bufferSeekOverHole' || details === 'bufferStalledError') ? 12000 : 5000;
        if (shouldLogHlsEvent(`hls:${type}:${details}:${fatal ? 'fatal' : 'soft'}`, interval)) {
          log(`hls.js ${type} ${details}${fatal ? ' fatal' : ''}`);
        }
        // Keep v122 playback behavior: only recover fatal hls.js errors.
        // Do not call recoverMediaError() for non-fatal bufferStalled/bufferSeekOverHole
        // events because v123's extra soft recovery could make audio disappear.
        if (data && data.fatal && hls) {
          if (data.type === Hls.ErrorTypes.NETWORK_ERROR) hls.startLoad();
          else if (data.type === Hls.ErrorTypes.MEDIA_ERROR) hls.recoverMediaError();
        }
      });
      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        hideVideoBox();
        showRawVideoLayer();
        try { if (sageVideo.currentTime < 0.25) sageVideo.currentTime = 0; } catch (e) {}
        playVideoElement();
      });
      hls.loadSource(url);
      hls.attachMedia(sageVideo);
      try { hls.startLoad(0); } catch (e) {}
    } else if (sageVideo.canPlayType('application/vnd.apple.mpegurl')) {
      if (serial !== videoSerial) return;
      showRawVideoLayer();
      sageVideo.src = url;
      sageVideo.addEventListener('loadedmetadata', () => {
        hideVideoBox();
        showRawVideoLayer();
        playVideoElement();
      }, {once:true});
    } else {
      setVideoBox('This browser needs hls.js or Video.js for HLS playback');
      log('HLS playback unsupported: hls.js/Video.js not loaded and native HLS unavailable.');
    }
  }

  async function startVideoStream(url, st) {
    // Do not snapshot/restore menus around playback; SageTV may navigate to a
    // different menu while the media stream stays alive.
    videoStreamActive = true;
    videoPresentationSuspended = false;
    videoLayerActive = true;
    if (stageWrap) stageWrap.classList.add('video-active');
    videoStatus = st || {};
    videoStatus.playlist_url = url || videoStatus.playlist_url;
    updateMediaStatus(lastMediaStatus || {});
    updateVideoBounds((videoStatus && videoStatus.dest_rect) || currentVideoDst, {trusted: rectHasArea(videoStatus && videoStatus.dest_rect)});
    if (!url || !sageVideo) return;

    if (hls) { try { hls.destroy(); } catch (e) {} hls = null; }
    cleanupVideoJsSource();
    pauseAndClearRawVideo();
    // v29: default to audio ON. If your browser blocks autoplay, check Mute video
    // in the top bar or click/tap the page once and retry.
    sageVideo.muted = !!(videoMutedEl && videoMutedEl.checked);
    sageVideo.controls = false;
    setVideoBox('Waiting for HLS playlist…');
    const serial = ++videoSerial;
    const playerMode = (videoStatus.player_mode || selectedPlayerMode() || 'hls').toLowerCase();
    if (playerMode === 'videojs' || playerMode === 'videojsfmp4') {
      await startVideoJsHlsStream(url, videoStatus, serial);
      return;
    }

    const ok = await waitForPlaylist(url, serial);
    if (serial !== videoSerial) return;
    if (!ok) {
      setVideoBox('Timed out waiting for HLS playlist');
      log('Timed out waiting for HLS playlist. Check FFmpeg log/status.');
      return;
    }

    await startHlsJsOrNativeStream(url, serial);
  }

  function stopVideoStream(st) {
    videoSerial++;
    videoStreamActive = false;
    videoLayerActive = false;
    videoPresentationSuspended = false;
    currentVideoDstTrusted = false;
    lastTrustedVideoDst = [0,0,0,0];
    if (stageWrap) stageWrap.classList.remove('video-active');
    videoStatus = st || {};
    if (hls) { try { hls.destroy(); } catch (e) {} hls = null; }
    cleanupVideoJsSource();
    pauseAndClearRawVideo();
    hideVideoLayer();
    hideVideoBox();
    updateMediaStatus(lastMediaStatus || {});
  }

  function resizeCanvas(w, h) {
    screen.width = w;
    screen.height = h;
    lastMenuSnapshot = null;
    surfaces[0] = screen;
    curSurface = screen;
    curCtx = dstCtx;
    log(`Canvas resized to ${w}x${h}`);
    if (videoLayerActive) updateVideoBounds(currentVideoDst, {trusted: currentVideoDstTrusted});
    else updateVideoBounds([0,0,0,0], {allowPlaybackFallback:false});
  }

  function makeSurface(w, h) {
    const c = document.createElement('canvas');
    c.width = Math.max(1, w);
    c.height = Math.max(1, h);
    return c;
  }

  function withClip(cmd, fn) {
    if (cmd.clip && cmd.clip[2] > 0 && cmd.clip[3] > 0) {
      curCtx.save();
      curCtx.beginPath();
      curCtx.rect(cmd.clip[0], cmd.clip[1], cmd.clip[2], cmd.clip[3]);
      curCtx.clip();
      fn();
      curCtx.restore();
    } else {
      fn();
    }
  }

  function roundedRectPath(ctx, x, y, w, h, r) {
    r = Math.max(0, Math.min(r || 0, Math.abs(w) / 2, Math.abs(h) / 2));
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
  }

  function renderCommands(commands) {
    for (const cmd of commands) {
      try { renderCommand(cmd); }
      catch (e) { log(`Render error ${cmd.op}: ${e}`); }
    }
  }

  function renderCommand(cmd) {
    switch (cmd.op) {
      case 'init':
        setStatus('SageTV GUI initialized');
        break;
      case 'deinit':
        setStatus('SageTV GUI deinitialized');
        break;
      case 'start':
        curSurface = screen;
        curCtx = dstCtx;
        frameHadClearRect = false;
        frameHadVideoMask = false;
        frameDrawOps = 0;
        if (restoreMenuSnapshotOnNextFrame) {
          restoreMenuSnapshot('start frame menu restore');
        } else if (CLEAR_EACH_FRAME || forcedOpaqueMenuClearFrames > 0) {
          clearCanvasOpaque(curCtx, 'start frame transparent clear');
        }
        forcedOpaqueMenuClearFrames = 0;
        if (videoLayerActive && !videoPresentationSuspended) {
          // Only punch the video rectangle. Do not clear the full SageTV canvas.
          clearVideoHole(curCtx);
        }
        break;
      case 'flip':
        if (curSurface !== screen) dstCtx.drawImage(curSurface, 0, 0);
        // Android MiniClient renderer rule: if a SageTV frame has no CLEARRECT,
        // it is a menu/dialog frame, even if the media stream is still alive.
        // Save menu frames and stop video compositing so Back returns cleanly.
        if (!frameHadClearRect) {
          if (activeVideoStreamLikely()) markMenuModeFromSage('START/FLIP without CLEAR');
        } else if (frameHadClearRect && videoStreamActive && !videoPresentationSuspended) {
          videoLayerActive = true;
          if (stageWrap) stageWrap.classList.add('video-active');
          if (frameDrawOps <= 0 && currentVideoDstTrusted) clearVideoHole(dstCtx);
        }
        if (firstFrame) {
          firstFrame = false;
          setStatus('SageTV GUI rendering');
          send({type:'resize', width: screen.width, height: screen.height});
        }
        break;
      case 'fillRect':
        if (commandLooksLikeVideoMask(cmd)) {
          frameHadVideoMask = true;
          // SageTV's video mask/color-key rectangle should reveal the video layer,
          // not paint a black box over it. Later OSD/timeline draw calls remain on top.
          clearMaskedVideoIntersection(cmd);
          break;
        }
        frameDrawOps++;
        curCtx.save();
        curCtx.globalCompositeOperation = 'source-over';
        curCtx.fillStyle = cmd.color || 'black';
        curCtx.fillRect(cmd.x, cmd.y, cmd.w, cmd.h);
        curCtx.restore();
        break;
      case 'clearRect':
        frameHadClearRect = true;
        if (commandLooksLikeVideoMask(cmd)) {
          frameHadVideoMask = true;
          clearMaskedVideoIntersection(cmd);
          break;
        }
        frameDrawOps++;
        curCtx.save();
        // Desktop/Android MiniClient behavior for CLEAR_RECT is SRC/copy of the
        // supplied ARGB. This is different from canvas clearRect(); transparent
        // ARGB should really clear pixels, opaque ARGB should repaint them.
        curCtx.globalCompositeOperation = 'copy';
        curCtx.fillStyle = cmd.color || 'rgba(0,0,0,0)';
        curCtx.fillRect(cmd.x, cmd.y, cmd.w, cmd.h);
        curCtx.restore();
        break;
      case 'drawRect':
        frameDrawOps++;
        curCtx.save();
        curCtx.strokeStyle = cmd.color || 'white';
        curCtx.lineWidth = Math.max(1, cmd.thickness || 1);
        curCtx.strokeRect(cmd.x, cmd.y, cmd.w, cmd.h);
        curCtx.restore();
        break;
      case 'drawLine':
        frameDrawOps++;
        curCtx.save();
        curCtx.strokeStyle = cmd.color || 'white';
        curCtx.beginPath();
        curCtx.moveTo(cmd.x1, cmd.y1);
        curCtx.lineTo(cmd.x2, cmd.y2);
        curCtx.stroke();
        curCtx.restore();
        break;
      case 'drawOval':
        frameDrawOps++;
        withClip(cmd, () => {
          curCtx.save();
          curCtx.strokeStyle = cmd.color || 'white';
          curCtx.lineWidth = Math.max(1, cmd.thickness || 1);
          curCtx.beginPath();
          curCtx.ellipse(cmd.x + cmd.w/2, cmd.y + cmd.h/2, Math.abs(cmd.w/2), Math.abs(cmd.h/2), 0, 0, Math.PI*2);
          curCtx.stroke();
          curCtx.restore();
        });
        break;
      case 'fillOval':
        frameDrawOps++;
        withClip(cmd, () => {
          curCtx.save();
          curCtx.fillStyle = cmd.color || 'white';
          curCtx.beginPath();
          curCtx.ellipse(cmd.x + cmd.w/2, cmd.y + cmd.h/2, Math.abs(cmd.w/2), Math.abs(cmd.h/2), 0, 0, Math.PI*2);
          curCtx.fill();
          curCtx.restore();
        });
        break;
      case 'drawRoundRect':
        frameDrawOps++;
        withClip(cmd, () => {
          curCtx.save(); curCtx.strokeStyle = cmd.color || 'white'; curCtx.lineWidth = Math.max(1, cmd.thickness || 1);
          roundedRectPath(curCtx, cmd.x, cmd.y, cmd.w, cmd.h, cmd.arc); curCtx.stroke(); curCtx.restore();
        });
        break;
      case 'fillRoundRect':
        frameDrawOps++;
        withClip(cmd, () => {
          curCtx.save(); curCtx.fillStyle = cmd.color || 'white';
          roundedRectPath(curCtx, cmd.x, cmd.y, cmd.w, cmd.h, cmd.arc); curCtx.fill(); curCtx.restore();
        });
        break;
      case 'createSurface':
        surfaces[cmd.handle] = makeSurface(cmd.w, cmd.h);
        break;
      case 'setSurface':
        curSurface = surfaces[cmd.handle] || screen;
        curCtx = curSurface.getContext('2d');
        break;
      case 'imageAlloc':
        // Server-side allocation notice only.  The real image usually arrives in a later
        // registerImage command.  Do not log these; SageTV sends many during startup.
        break;
      case 'registerImage': {
        const img = new Image();
        img.onload = () => { images[cmd.handle] = img; };
        img.onerror = () => { /* keep quiet during startup; failed handles are retried/redrawn */ };
        img.src = `data:${cmd.mime || 'image/png'};base64,${cmd.data}`;
        images[cmd.handle] = img;
        break;
      }
      case 'unloadImage':
        delete images[cmd.handle];
        delete surfaces[cmd.handle];
        break;
      case 'drawTexture': {
        const img = images[cmd.handle] || surfaces[cmd.handle];
        // Missing/incomplete texture handles are common while the image cache warms up.
        // Logging each miss makes arrow-key response very sluggish.
        if (!img) break;
        if (img instanceof HTMLImageElement && !img.complete) break;
        frameDrawOps++;
        curCtx.save();
        curCtx.globalAlpha = cmd.alpha == null ? 1.0 : cmd.alpha;
        const w = Math.abs(cmd.w), h = Math.abs(cmd.h);
        try { curCtx.drawImage(img, cmd.sx, cmd.sy, cmd.sw, cmd.sh, cmd.x, cmd.y, w, h); }
        catch (e) { /* suppress noisy image decode/race errors */ }
        curCtx.restore();
        break;
      }
      case 'drawText':
        // v117: do not paint fallback DRAWTEXT in normal browser rendering.
        // With GFX_TEXTMODE=NONE, real menu text is already sent as textures;
        // drawing this fallback caused duplicate/overlapping labels during video.
        if (!RENDER_FALLBACK_DRAWTEXT) break;
        frameDrawOps++;
        withClip(cmd, () => {
          curCtx.save();
          curCtx.fillStyle = cmd.color || 'white';
          curCtx.font = '20px Arial';
          curCtx.textBaseline = 'top';
          curCtx.fillText(cmd.text || '', cmd.x, cmd.y);
          curCtx.restore();
        });
        break;
      case 'videoBounds':
        updateVideoBounds(cmd.dst || [0,0,0,0], {trusted:true});
        break;
      case 'pushTransform':
        curCtx.save();
        break;
      case 'popTransform':
        try { curCtx.restore(); } catch (e) {}
        break;
      case 'debug':
        log(cmd.message);
        break;
      default:
        log(`Unhandled render op ${JSON.stringify(cmd).slice(0, 200)}`);
    }
  }

  attachSettingsPersistence();
  if (osdTriggerModeEl) osdTriggerModeEl.addEventListener('change', saveClientSettings);
  if (fullscreenOnConnectEl) fullscreenOnConnectEl.addEventListener('change', saveClientSettings);
  sanitizeRemovedPlayerModeSetting();
  updatePlayerSpecificSettingAvailability();

  [videoEncoderEl, encoderLatencyModeEl, qsvDecodeModeEl, qsvFilterModeEl, videoMaxHeightEl, videoFpsEl, videoBitrateEl, audioBitrateEl, audioOffsetEl, hlsModeEl, bufferPresetEl, hlsSegmentSecondsEl, hlsInitSecondsEl, hlsStartSegmentsEl, hlsJsMaxBufferEl, directReadModeEl, ffmpegBufferPresetEl, playerModeEl, playbackSourceEl, directSageRootEl, directLocalRootEl, hlsStorageModeEl, hlsRamRootEl].forEach(el => {
    if (el) el.addEventListener('change', () => { updatePlayerSpecificSettingAvailability(); sendLiveVideoSettings(); });
  });

  if (directPathMapListEl) directPathMapListEl.addEventListener('change', fillDirectPathMapTextboxesFromSelection);
  if (directPathMapSaveBtn) directPathMapSaveBtn.addEventListener('click', () => saveDirectPathMapRow(false));
  if (directPathMapAddBtn) directPathMapAddBtn.addEventListener('click', () => saveDirectPathMapRow(true));
  if (directPathMapDeleteBtn) directPathMapDeleteBtn.addEventListener('click', deleteDirectPathMapRow);
  renderDirectPathMapList();

  connectBtn.addEventListener('click', () => { saveServerSettings(); saveClientSettings(); connect(); });
  disconnectBtn.addEventListener('click', () => send({type:'disconnect'}));

  document.querySelectorAll('[data-cmd]').forEach(btn => {
    btn.addEventListener('click', ev => {
      if (btn.dataset && btn.dataset.repeatFired === '1') {
        btn.dataset.repeatFired = '';
        ev.preventDefault();
        return;
      }
      const cmd = btn.getAttribute('data-cmd');
      if (navOverlay && btn.closest('#navOverlay')) command(cmd);
      else command(cmd);
      if (navOverlay && btn.closest('#navOverlay') && btn.getAttribute('data-close-overlay') === 'true') hideNavOverlay();
    });
  });

  screen.addEventListener('keydown', ev => {
    const lower = (ev.key || '').toLowerCase();
    const keyMap = {
      ArrowUp: 'up', ArrowDown: 'down', ArrowLeft: 'left', ArrowRight: 'right',
      Enter: 'select', NumpadEnter: 'select', Escape: 'back', Backspace: 'back', ' ': 'play_pause',
      PageUp: 'page_up', PageDown: 'page_down', Home: 'home', End: 'stop',
      MediaPlayPause: 'play_pause', MediaStop: 'stop', MediaTrackNext: 'skip_fwd_2', MediaTrackPrevious: 'skip_back_2'
    };
    const letterMap = {
      p: 'play_pause', d: 'play', s: 'pause', f: 'ff', g: 'rew',
      t: 'record', i: 'info', o: 'options', x: 'guide', h: 'home', m: 'mute'
    };
    const cmd = keyMap[ev.key] || letterMap[lower];
    if (cmd) {
      ev.preventDefault();
      command(cmd);
    } else {
      send({type:'key', key: ev.key, keyCode: ev.keyCode || ev.which || 0});
    }
  });

  function canvasCoords(ev) {
    const r = screen.getBoundingClientRect();
    const sx = screen.width / r.width;
    const sy = screen.height / r.height;
    return {x: Math.round((ev.clientX - r.left) * sx), y: Math.round((ev.clientY - r.top) * sy)};
  }

  function command(cmd) {
    const lowerCmd = String(cmd || '').toLowerCase();
    applyLocalMediaControlFromCommand(lowerCmd);
    send({type:'command', command:cmd});
    if (VIDEO_MENU_NAV_COMMANDS.has(lowerCmd) && lowerCmd !== 'stop') {
      // Let the SageTV command reach the server first, then locally switch the
      // browser back to GUI mode while SageTV repaints the menu. Stop is handled
      // by applyLocalMediaControlFromCommand() so the video bridge stops on the
      // first press instead of waiting for a second SageTV MEDIACMD_STOP.
      setTimeout(() => forceMenuCompositingMode(`command ${cmd}`), 35);
    }
    screen.focus();
  }

  function remoteCommand(cmd) {
    // v142: Use the same command path as the regular remote keys/buttons instead
    // of Android-style raw IR delivery.
    command(cmd);
  }

  // v24: SageTV responds more reliably to the same event sequence the
  // native MiniClient sends: move -> press -> release -> click.
  // v133: Restore native full-click behavior as the default.
  // v133: SageMC's Guide grid can ignore the MiniClient MCLICK event even
  // though arrow keys and OK work. Keep native mouse events, but optionally
  // follow a Guide click with SageTV SELECT if the menu did not change.
  // v134: optionally map the browser mouse back/side button to SageTV Back.
  // v137: the long-press overlay now behaves like a full Android MiniClient remote OSD with hold-to-repeat buttons.
  // v145: the OSD open gesture is configurable: left/right long click, left/right double click, or center click.
  let lastShortClickMs = 0;
  let lastMouseBackButtonCommandMs = 0;
  let lastGuideSafeClick = {x:-9999, y:-9999, button:0, ms:0};
  const GUIDE_SAFE_DOUBLE_CLICK_MS = 700;
  const GUIDE_SAFE_DOUBLE_CLICK_PX = 10;

  function mouseClickMode() {
    const v = String(mouseClickModeEl ? mouseClickModeEl.value : 'native').toLowerCase();
    // v133 migration: v131 saved guide_safe as the default. That mode made
    // the Guide ignore mouse clicks because it omitted the MCLICK event. Treat
    // the old saved value as native unless the user explicitly selects the new
    // double_select mode.
    if (!v || v === 'guide_safe') return 'native';
    return v;
  }

  function sendMousePressRelease(x, y, button) {
    send({type:'mouse', event:'move', x, y});
    send({type:'mouse', event:'down', x, y, button, clicks:1});
    send({type:'mouse', event:'up', x, y, button, clicks:1});
  }

  function sendMouseFullClick(x, y, button) {
    sendMousePressRelease(x, y, button);
    send({type:'mouse', event:'click', x, y, button, clicks:1});
  }

  function currentMenuIsGuide() {
    return /(?:^|[,;\s])menuName\s*:\s*Guide(?:[,;]|$)/i.test(currentMenuHint || '');
  }

  function guideOkAssistEnabled() {
    if (!guideMouseOkAssistEl) return true;
    return !!guideMouseOkAssistEl.checked;
  }

  function mouseBackButtonSageBackEnabled() {
    if (!mouseBackButtonSageBackEl) return true;
    return !!mouseBackButtonSageBackEl.checked;
  }

  function eventIsMouseBackButton(ev) {
    // Browser/OS usually reports XButton1 / Browser Back as button 3.
    // Some PointerEvents also expose it in the buttons bitmask as bit 8.
    const b = Number(ev && ev.button);
    const buttons = Number(ev && ev.buttons || 0);
    return b === 3 || !!(buttons & 8);
  }

  function handleMouseBackButtonAsSageBack(ev, phase) {
    if (!mouseBackButtonSageBackEnabled()) return false;
    if (!eventIsMouseBackButton(ev)) return false;
    try { ev.preventDefault(); ev.stopPropagation(); } catch (e) {}

    // PointerEvent and MouseEvent can both fire for the same physical side-button
    // press. Only send one SageTV Back command per press.
    const now = performance.now();
    if (phase === 'down' && (now - lastMouseBackButtonCommandMs) > 250) {
      lastMouseBackButtonCommandMs = now;
      command('back');
      log('Mouse Back button: sent SageTV Back');
    }
    return true;
  }

  function maybeSendGuideOkAssist(x, y, button, reason) {
    if (Number(button || 1) !== 1) return;
    if (!guideOkAssistEnabled()) return;
    if (!currentMenuIsGuide()) return;
    const hintAtClick = currentMenuHint || '';
    // SageMC Guide often accepts remote OK but ignores MCLICK. Wait briefly so
    // the normal mouse event can update focus or open a standard-STV popup.
    // If the menu changed, do not inject OK. If it is still Guide, send SELECT.
    setTimeout(() => {
      if (!guideOkAssistEnabled()) return;
      if (!currentMenuIsGuide()) return;
      if ((currentMenuHint || '') !== hintAtClick) return;
      send({type:'command', command:'select'});
      log(`Guide mouse OK assist: sent SELECT after click at ${x},${y}${reason ? ' (' + reason + ')' : ''}`);
    }, 180);
  }

  function sendCanvasClick(x, y, button) {
    const now = performance.now();
    // Avoid duplicate click when both pointerup and the browser click fallback fire.
    if (now - lastShortClickMs < 220) return;
    lastShortClickMs = now;
    const b = Number(button || 1);
    const mode = mouseClickMode();

    // Keep middle/right click native so SageTV/STV context menus keep working.
    if (b !== 1 || mode === 'native') {
      sendMouseFullClick(x, y, b);
      if (b === 1 && mode === 'native') maybeSendGuideOkAssist(x, y, b, 'native');
      screen.focus();
      return;
    }

    if (mode === 'press_release') {
      sendMousePressRelease(x, y, b);
      screen.focus();
      return;
    }

    if (mode !== 'double_select') {
      sendMouseFullClick(x, y, b);
      maybeSendGuideOkAssist(x, y, b, mode);
      screen.focus();
      return;
    }

    // double_select optional mode: first click sends move/press/release only;
    // a quick second click on the same target sends the full MCLICK activation.
    // This mode is optional because Guide grids need MCLICK for normal selection.
    const dx = x - lastGuideSafeClick.x;
    const dy = y - lastGuideSafeClick.y;
    const sameTarget = lastGuideSafeClick.button === b && Math.hypot(dx, dy) <= GUIDE_SAFE_DOUBLE_CLICK_PX;
    const doubleClick = sameTarget && (now - lastGuideSafeClick.ms) <= GUIDE_SAFE_DOUBLE_CLICK_MS;
    if (doubleClick) {
      sendMouseFullClick(x, y, b);
      maybeSendGuideOkAssist(x, y, b, 'double_select');
      lastGuideSafeClick = {x:-9999, y:-9999, button:0, ms:0};
      log('Mouse double-click: sent SageTV select/click');
    } else {
      sendMousePressRelease(x, y, b);
      lastGuideSafeClick = {x, y, button:b, ms:now};
    }
    screen.focus();
  }

  function centerNavOverlayOverCanvas() {
    if (!navOverlay || navOverlay.classList.contains('hidden')) return;
    const card = navOverlay.querySelector('.navCard');
    if (!card) return;

    // Fit the transparent Android-style OSD exactly over the rendered SageTV canvas.
    const r = screen.getBoundingClientRect();
    card.style.left = `${Math.max(0, r.left)}px`;
    card.style.top = `${Math.max(0, r.top)}px`;
    card.style.width = `${Math.max(0, r.width)}px`;
    card.style.height = `${Math.max(0, r.height)}px`;
    card.style.maxHeight = `${Math.max(0, r.height)}px`;
  }

  function showNavOverlay(clientX, clientY) {
    if (!navOverlay) return;
    navOverlay.classList.remove('hidden');
    navOverlay.setAttribute('aria-hidden', 'false');
    centerNavOverlayOverCanvas();
    screen.focus();
  }

  function hideNavOverlay() {
    if (!navOverlay) return;
    navOverlay.classList.add('hidden');
    navOverlay.setAttribute('aria-hidden', 'true');
    screen.focus();
  }

  if (showOverlayBtn) showOverlayBtn.addEventListener('click', () => showNavOverlay());

  function toggleNavKeyboardPanel(force) {
    if (!navKeyboardPanel) return;
    const show = force == null ? navKeyboardPanel.classList.contains('hidden') : !!force;
    navKeyboardPanel.classList.toggle('hidden', !show);
    if (show && navKeyboardInput) setTimeout(() => navKeyboardInput.focus(), 30);
    else screen.focus();
  }

  function sendKeyboardTextToSage(text) {
    const value = String(text || '');
    if (!value) return;
    for (const ch of value) {
      send({type:'key', key: ch, keyCode: ch.length ? ch.charCodeAt(0) : 0});
    }
    log(`Android OSD keyboard: sent ${value.length} character${value.length === 1 ? '' : 's'}`);
  }

  function setRenderOnlyMode(enabled) {
    renderOnlyMode = !!enabled;
    document.body.classList.toggle('renderOnlyMode', renderOnlyMode);
    const fsBtn = document.querySelector('.osdFullscreenToggleBtn');
    if (fsBtn) {
      fsBtn.classList.toggle('active', renderOnlyMode);
      fsBtn.setAttribute('title', renderOnlyMode ? 'Exit render-only view' : 'Enter render-only view');
      fsBtn.setAttribute('aria-label', renderOnlyMode ? 'Exit render-only view' : 'Enter render-only view');
    }
    if (renderOnlyMode) {
      hideNavOverlay();
      window.scrollTo(0, 0);
      log('Render-only view: enabled');
    } else {
      log('Render-only view: disabled');
    }
    setTimeout(() => {
      if (typeof updateVideoBounds === 'function' && Array.isArray(currentVideoDst) && currentVideoDst.length >= 4) {
        updateVideoBounds(currentVideoDst, {trusted: currentVideoDstTrusted, allowPlaybackFallback: true});
      }
      centerNavOverlayOverCanvas();
      screen.focus();
    }, 20);
    setTimeout(() => {
      centerNavOverlayOverCanvas();
    }, 120);
  }

  function toggleRenderOnlyMode(force) {
    setRenderOnlyMode(force == null ? !renderOnlyMode : !!force);
  }

  function fullscreenOnConnectEnabled() {
    return !!(fullscreenOnConnectEl && fullscreenOnConnectEl.checked);
  }

  function sendKeyboardAction(action) {
    if (action === 'keyboard') {
      toggleNavKeyboardPanel();
      return;
    }
    if (action === 'toggle-render-fullscreen') {
      toggleRenderOnlyMode();
      return;
    }
    if (action === 'keyboard-send') {
      if (navKeyboardInput) {
        sendKeyboardTextToSage(navKeyboardInput.value || '');
        navKeyboardInput.value = '';
        navKeyboardInput.focus();
      }
      return;
    }
    if (action === 'keyboard-backspace') {
      send({type:'key', key:'Backspace', keyCode:8});
      return;
    }
    if (action === 'keyboard-enter') {
      send({type:'key', key:'Enter', keyCode:13});
      return;
    }
  }

  let navRepeatTimer = null;
  let navRepeatInterval = null;
  let navRepeatButton = null;

  function clearNavButtonRepeat() {
    if (navRepeatTimer) clearTimeout(navRepeatTimer);
    if (navRepeatInterval) clearInterval(navRepeatInterval);
    navRepeatTimer = null;
    navRepeatInterval = null;
    navRepeatButton = null;
  }

  if (navOverlay) {
    navOverlay.addEventListener('click', ev => {
      const closeBtn = ev.target.closest('[data-close-overlay], .closeNav');
      if (ev.target === navOverlay || closeBtn) {
        hideNavOverlay();
        ev.preventDefault();
        return;
      }
      const actionBtn = ev.target.closest('[data-overlay-action]');
      if (actionBtn) {
        sendKeyboardAction(actionBtn.getAttribute('data-overlay-action'));
        ev.preventDefault();
      }
    });

    navOverlay.addEventListener('pointerdown', ev => {
      const btn = ev.target.closest('button[data-cmd][data-repeat="true"]');
      if (!btn || !btn.closest('#navOverlay')) return;
      clearNavButtonRepeat();
      navRepeatButton = btn;
      btn.dataset.repeatFired = '';
      const cmd = btn.getAttribute('data-cmd');
      navRepeatTimer = setTimeout(() => {
        btn.dataset.repeatFired = '1';
        remoteCommand(cmd);
        navRepeatInterval = setInterval(() => remoteCommand(cmd), 150);
      }, 420);
    });
    ['pointerup','pointercancel','pointerleave'].forEach(name => navOverlay.addEventListener(name, clearNavButtonRepeat));
  }

  if (navKeyboardInput) {
    navKeyboardInput.addEventListener('keydown', ev => {
      if (ev.key === 'Enter') {
        ev.preventDefault();
        sendKeyboardTextToSage(navKeyboardInput.value || '');
        navKeyboardInput.value = '';
      }
    });
  }

  // v24: old Android MiniClient supported click-and-hold to open a navigation OSD.
  // Use pointer events so it works on mouse, touch, and pen.  A short click sends a
  // SageTV mouse click; a long hold shows the local HTML5 navigation panel instead.
  let lastMouseSend = 0;
  let lastMouseX = -1;
  let lastMouseY = -1;
  let pointerDown = false;
  let longPressTimer = null;
  let longPressFired = false;
  const LONG_PRESS_MS = 575;
  const DOUBLE_CLICK_MS = 420;
  const DOUBLE_CLICK_PX = 18;
  const MOVE_CANCEL_PX = 12;
  let downClientX = 0;
  let downClientY = 0;
  let downPoint = {x: 0, y: 0};
  let downButton = 1;
  let downBrowserButton = 0;
  let lastOsdTriggerClick = {button:-1, x:-9999, y:-9999, ms:0};

  function osdTriggerMode() {
    const v = String(osdTriggerModeEl ? osdTriggerModeEl.value : 'left_long').toLowerCase();
    if (['left_double','left_long','right_double','right_long','center_click'].includes(v)) return v;
    return 'left_long';
  }

  function browserButtonName(button, pointerType) {
    if (pointerType && pointerType !== 'mouse') return 'left';
    if (button === 2) return 'right';
    if (button === 1) return 'center';
    return 'left';
  }

  function osdTriggerUsesRightButton() {
    const mode = osdTriggerMode();
    return mode === 'right_double' || mode === 'right_long';
  }

  function shouldStartOsdLongPress(ev) {
    const mode = osdTriggerMode();
    const button = browserButtonName(ev.button, ev.pointerType);
    return (mode === 'left_long' && button === 'left') || (mode === 'right_long' && button === 'right');
  }

  function shouldTriggerOsdOnClick(ev) {
    const mode = osdTriggerMode();
    const button = browserButtonName(ev.button, ev.pointerType);
    if (mode === 'center_click') return button === 'center';
    if (mode !== 'left_double' && mode !== 'right_double') return false;
    if ((mode === 'left_double' && button !== 'left') || (mode === 'right_double' && button !== 'right')) return false;
    const now = performance.now();
    const dx = ev.clientX - lastOsdTriggerClick.x;
    const dy = ev.clientY - lastOsdTriggerClick.y;
    const sameButton = lastOsdTriggerClick.button === ev.button;
    const isDouble = sameButton && (now - lastOsdTriggerClick.ms) <= DOUBLE_CLICK_MS && Math.hypot(dx, dy) <= DOUBLE_CLICK_PX;
    lastOsdTriggerClick = {button:ev.button, x:ev.clientX, y:ev.clientY, ms:now};
    return isDouble;
  }

  function clearLongPressTimer() {
    if (longPressTimer) {
      clearTimeout(longPressTimer);
      longPressTimer = null;
    }
  }

  screen.addEventListener('pointermove', ev => {
    const now = performance.now();
    const p = canvasCoords(ev);
    if (pointerDown && !longPressFired) {
      const dx = ev.clientX - downClientX;
      const dy = ev.clientY - downClientY;
      if (Math.hypot(dx, dy) > MOVE_CANCEL_PX) clearLongPressTimer();
    }
    if (p.x === lastMouseX && p.y === lastMouseY) return;
    if (now - lastMouseSend < 40) return;
    lastMouseSend = now;
    lastMouseX = p.x;
    lastMouseY = p.y;
    send({type:'mouse', event:'move', x:p.x, y:p.y});
  });

  screen.addEventListener('pointerdown', ev => {
    screen.focus();
    if (handleMouseBackButtonAsSageBack(ev, 'down')) {
      pointerDown = false;
      longPressFired = false;
      clearLongPressTimer();
      return;
    }
    pointerDown = true;
    longPressFired = false;
    downClientX = ev.clientX;
    downClientY = ev.clientY;
    downPoint = canvasCoords(ev);

    // Browser button: 0=left, 1=middle, 2=right.
    // Java/MiniClient button: 1=left, 2=middle, 3=right.
    downBrowserButton = ev.button;
    downButton = ev.button === 2 ? 3 : (ev.button === 1 ? 2 : 1);

    clearLongPressTimer();

    // v145: The OSD trigger is configurable. Left long click remains the
    // default/original behavior. Right long click is also supported, while
    // middle/center click and double-click modes are handled on pointerup.
    if (shouldStartOsdLongPress(ev)) {
      longPressTimer = setTimeout(() => {
        longPressFired = true;
        try { screen.releasePointerCapture(ev.pointerId); } catch (e) {}
        showNavOverlay(ev.clientX, ev.clientY);
      }, LONG_PRESS_MS);
    }

    try { screen.setPointerCapture(ev.pointerId); } catch (e) {}
    ev.preventDefault();
  });

  screen.addEventListener('pointerup', ev => {
    if (handleMouseBackButtonAsSageBack(ev, 'up')) {
      pointerDown = false;
      longPressFired = false;
      clearLongPressTimer();
      return;
    }
    const p = canvasCoords(ev);
    clearLongPressTimer();
    try { screen.releasePointerCapture(ev.pointerId); } catch (e) {}
    if (!longPressFired) {
      if (shouldTriggerOsdOnClick(ev)) {
        showNavOverlay(ev.clientX, ev.clientY);
      } else {
        sendCanvasClick(p.x, p.y, downButton);
      }
    }
    pointerDown = false;
    longPressFired = false;
    ev.preventDefault();
  });

  // Fallback for browsers/platforms that expose mouse side buttons through
  // MouseEvent but not PointerEvent. The up/auxclick handlers only suppress
  // browser navigation; the down handler sends SageTV Back.
  screen.addEventListener('mousedown', ev => { handleMouseBackButtonAsSageBack(ev, 'down'); }, true);
  screen.addEventListener('mouseup', ev => { handleMouseBackButtonAsSageBack(ev, 'up'); }, true);
  screen.addEventListener('auxclick', ev => { handleMouseBackButtonAsSageBack(ev, 'up'); }, true);

  screen.addEventListener('pointercancel', () => {
    clearLongPressTimer();
    pointerDown = false;
    longPressFired = false;
  });

  // Some mobile browsers can cancel pointerup after a canvas/touch gesture.
  // Keep a normal click fallback so quick taps still select.  The duplicate
  // guard inside sendCanvasClick prevents double selection on desktop.
  screen.addEventListener('click', ev => {
    // Left-click/tap fallback only. Right click is handled through pointerup
    // or auxclick and should not be converted into a left click.
    if (longPressFired) return;
    if (ev.button && ev.button !== 0) return;
    const p = canvasCoords(ev);
    sendCanvasClick(p.x, p.y, 1);
  });

  screen.addEventListener('auxclick', ev => {
    if (handleMouseBackButtonAsSageBack(ev, 'up')) return;
    // Fallback for middle/right click on browsers that do not deliver a normal
    // click event for non-left buttons. The duplicate guard in sendCanvasClick
    // prevents double-sending when pointerup already handled it.
    ev.preventDefault();
    const p = canvasCoords(ev);
    const b = ev.button === 2 ? 3 : 2;
    sendCanvasClick(p.x, p.y, b);
  });

  screen.addEventListener('contextmenu', ev => {
    // Disable the browser menu, but do NOT open the local HTML5 navigation menu.
    // SageTV/STVs use right click for their own context menus, so right click
    // is sent to SageTV through the pointer/auxclick path above.
    ev.preventDefault();
  });


  window.addEventListener('resize', () => {
    if (navOverlay && !navOverlay.classList.contains('hidden')) centerNavOverlayOverCanvas();
  });
  window.addEventListener('scroll', () => {
    if (navOverlay && !navOverlay.classList.contains('hidden')) centerNavOverlayOverCanvas();
  }, {passive: true});

  setInterval(() => {
    if (videoLayerActive || (videoStatus && videoStatus.running)) updateMediaStatus(lastMediaStatus || {});
  }, 1000);

  setInterval(flushClientLog, 5000);

  fetch('/api/status').then(r => r.json()).then(s => {
    if (!serverEl.value) serverEl.value = s.default_server || serverEl.value;
  }).finally(async () => {
    await initializeClientIdFromCookieOrServer();
    await loadAllSettings();
  });
})();


  window.addEventListener('keydown', ev => {
    if (ev.key === 'Escape' && renderOnlyMode) {
      toggleRenderOnlyMode(false);
      ev.preventDefault();
    }
  });

  window.addEventListener('resize', () => {
    if (renderOnlyMode && typeof updateVideoBounds === 'function' && Array.isArray(currentVideoDst) && currentVideoDst.length >= 4) {
      updateVideoBounds(currentVideoDst, {trusted: currentVideoDstTrusted, allowPlaybackFallback: true});
    }
    centerNavOverlayOverCanvas();
  });

  window.addEventListener('scroll', () => {
    centerNavOverlayOverCanvas();
  }, {passive:true});

