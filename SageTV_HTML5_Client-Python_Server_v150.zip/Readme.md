# SageTV Pure Python HTML5 GUI v137

Pure Python + HTML5/JavaScript SageTV MiniClient experiment.

This project connects to a SageTV server as a MiniClient, renders the SageTV GUI in a browser canvas, sends keyboard/mouse/remote events back to SageTV, and can transcode SageTV media playback to browser video.

It does **not** use Java, Gradle, Android, Firebase, Crashlytics, ExoPlayer, or IJKPlayer.

## Current focus

The GUI and remote path are working. Video playback is experimental. v137 adds an Android MiniClient-style long-press remote OSD with full command groups and hold-to-repeat behavior, restores native mouse click handling as the default so the SageTV Guide responds to single clicks, and keeps the better v122 transparent video/menu compositor, v124 safe log throttling, and v125 local Play/Pause/Stop behavior. It also keeps the cleaned FFmpeg/HLS-only playback paths, Fast Start HLS, Encoder Latency Mode, Intel QSV hardware decode/filter controls, and editable multi-root Direct File/SMB mappings. The Server field is host/IP only for the MiniClient connection on standard port 31099. v137 keeps the standalone Web HTTP source removed and replaces Web Interface/Webpage path resolution with SageX API path resolution. The SageX API SERVER:PORT, username, and password settings remain in the Connection section and are used to find the current MediaFile path and to poll GetRawMediaTime when SageTV does not send useful PUSHBUFFER seek timing. Playback then uses Direct File/SMB, SageTV PULL, or PUSHBUFFER when possible. If Source is Direct File/SMB and the media file must be identified through SageX while SageTV opened the item as PUSHBUFFER, v137 uses the resolved file as the FFmpeg input and uses SageX GetRawMediaTime plus any real PUSHBUFFER mux timing as the seek/timeline control channel. If no mappable file path exists but SageX exposes an HTTP media URL, it can still use that HTTP URL internally as a last-resort FFmpeg input and restart it at the SageTV seek time. The first HLS segments can be short, such as 1 second, then FFmpeg grows to the selected max segment length. Multiple browser/iPhone/iPad sessions can connect at the same time. If a new browser requests a Client ID that is already active, the server keeps that requested ID for settings/log folders but connects to SageTV with a unique effective MiniClient ID so the older client is not disconnected.

Recommended first Direct File/SMB video test:

```text
Source: Direct File/SMB
Root Mappings: /var/media/tv = \\192.168.10.175\sagemedia\tv
Sage Root / Local Root text boxes edit the selected mapping row
Player: HLS hls.js TS, HLS hls.js fMP4, Video.js HLS TS, or Video.js HLS fMP4
Encoder: h264_qsv, h264_nvenc, h264_amf, or libx264
Encoder Latency: Fast Start / Low Latency
QSV Decode: Auto, when using h264_qsv
QSV Filter: Auto deint+scale, when using h264_qsv
Max H: 720p or Source
Bitrate: 3500k or Source
HLS Segments: Stable during playback
Buffer Preset: iOS Safe
Startup Segment: 1 sec
Max HLS Segment: 4 sec
Start Buffer: Auto by encode rate
Source Fill: Auto live fill, or Fast fill buffer for completed recordings
FPS: Source, or 30/24/15 to reduce stream size. With QSV Auto deinterlace, Source is guarded to about 29.97 fps so 59.94i recordings do not become 119.88 fps.
Audio Bitrate: 128k, or 96k/64k to reduce stream size
FFmpeg Input Mode: Fast Startup, or Normal/Large if a file needs more conservative probing
```

If `bp=` or backpressure messages rise quickly in the debug panel, the transcode is falling behind. Lower Max H or Bitrate, or use Intel QSV if it is stable. In Direct File/SMB mode, FFmpeg reads the media file directly instead of waiting for SageTV PUSHBUFFER chunks. With Source Fill set to **Fast fill buffer**, Direct File/SMB does not use `-re` and SageTV PULL reads ahead, so FFmpeg can create HLS segments faster than real time while you watch. PUSHBUFFER stays live-paced because SageTV controls when chunks arrive. If FFmpeg segment creation still pauses or the input/mux queue looks tight, try **FFmpeg Input Mode = Normal or Large**.

## Direct File/SMB multi-root mapping

SageTV can send media paths from more than one storage root. v137 stores a shared editable mapping list in `server_settings/settings.json` as `directPathMap`. Each row displays as:

```text
Sage Root = Local Root
/var/media/tv = \\192.168.10.175\sagemedia\tv
```

When the server sees a new SageTV path root that cannot be read directly on the current OS, it automatically adds a blank row, for example:

```text
/var/media/movies =
```

Select that row, enter the matching SMB/local path in **Local Root**, then click **Save Root Mapping**. Direct File/SMB will use the longest matching Sage Root first, so more-specific mappings can coexist with broader mappings. The old single **Sage Root** and **Local Root** text boxes are still used as the editor for the selected row and remain compatible with older saved settings.


## SageX API lookup and timeline polling for Video Library items

Some imported Video Library playback requests arrive as pure `push:`/PUSHBUFFER media commands without an embedded file path. v137 keeps the shared lookup settings in the **Connection** section, but the broken Web HTTP source is not selectable:

```text
SageX API: 192.168.10.175:8080
SageX Username: optional Basic Auth username
SageX Password: optional Basic Auth password
```

The setting accepts `SERVER:PORT`, a full URL, `/sagex`, or `/sagex/api`. The app normalizes it and calls `/sagex/api` commands such as `GetCurrentMediaFile`, `GetFileForSegment`, `GetSegmentFiles`, `GetRawMediaTime`, and `GetMediaDuration`.

When SageTV sends a PUSHBUFFER-only media URL, or when Direct File/SMB cannot resolve the current OPENURL, the app asks SageX for the current MediaFile, extracts file paths and MediaFileID values, then maps the file path through Direct File/SMB root mappings. If SageX exposes an exact MediaFile path that maps to a local/SMB path, Direct File/SMB still uses that file path as the FFmpeg input. For SageTV `push:` items in this lookup-only case, v137 keeps the PUSHBUFFER media session alive only as a timing/control channel and also polls SageX `GetRawMediaTime()` about twice per second. A large jump between SageX RawMediaTime and the local FFmpeg/HLS media time is treated as a SageTV seek, and FFmpeg is restarted at the SageX time.

If no mappable path exists but SageX exposes an HTTP media/playlist URL, v137 can use that HTTP URL internally as a last-resort FFmpeg input and restart it at SageTV's requested media time. If neither a mappable path nor an HTTP media URL is available, the app logs the reason and falls back to PUSHBUFFER when SageTV is in PUSH mode. Native/backend database lookup is removed and no 42024 connection is attempted.

## Run on Windows

Run:

```cmd
run_windows.bat
```

Open:

```text
http://localhost:8088
```

Default SageTV server:

```text
192.168.10.175
```

The Windows launcher checks for FFmpeg in this order:

```text
1. FFMPEG environment variable
2. tools\ffmpeg\bin\ffmpeg.exe
3. ffmpeg.exe on PATH
4. Auto-download Gyan.dev ffmpeg-release-full.7z
```

The auto-install location is:

```text
tools\ffmpeg\bin\ffmpeg.exe
tools\ffmpeg\bin\ffprobe.exe
```

## Run tests

```cmd
test_windows.bat
```

Expected:

```text
16 passed
```

## Server-side client settings

v72 saves shared server settings separately from per-client settings. Each SageTV Client ID still gets its own folder:

```text
client_settings/<safe_client_id>/settings.json
```

For example, Client ID `02:51:56:00:10:18` saves to:

```text
client_settings/02_51_56_00_10_18/settings.json
```

When the Client ID field changes, the browser loads that client's per-client settings. When any other setting changes, the browser saves back to that same folder. This makes iPhone, iPad, desktop, and test clients easier to keep separate.

Each client also gets its own browser/app log:

```text
client_settings/<safe_client_id>/client.log
```

Overall server-side HTTP/WebSocket errors are logged here:

```text
server_settings/server_errors.log
```

The browser prints both paths in the log after settings load.

## Main browser settings

### Media/video caps

Enable this to advertise media capability to SageTV. Leave it disabled for GUI-only testing.

### Source controls the input method

The old **Force PUSH** checkbox and the **Strict source mode** checkbox have both been removed. Use the **Source** dropdown instead:

```text
Direct File/SMB: advertise stv/file URLs so Python can map them to SMB/local files
SageTV PULL: advertise stv:// PULL and read from SageTV's PULL socket
PUSHBUFFER: advertise PUSHBUFFER only
Auto Direct/PULL/PUSH: allow the app to try Direct, then PULL, then PUSH
```

Explicit source selections stay fixed. If Direct fails, it stops and logs the reason instead of silently switching to PULL or PUSH. Use **Auto Direct/PULL/PUSH** when you want fallback.

### HLS Storage

HLS playback normally uses files because FFmpeg's HLS muxer writes `stream.m3u8` plus `.ts` or `.m4s` segment files. v73 can choose where those runtime files are written:

```text
Disk: app runtime_hls folder
OS temp folder
RAM/tmpfs/RAM disk
```

On Linux, **RAM/tmpfs/RAM disk** uses `/dev/shm/sagetv_python_proxy/runtime_hls` if no custom RAM Path is supplied. On Windows, Python cannot create a true RAM disk by itself, so create or mount a RAM disk first, then put that path in **RAM Path**, for example:

```text
R:\sagetv_hls
```

If RAM is selected but no usable RAM path is found, the app falls back to the normal disk `runtime_hls` folder and shows that in the Video Debug `storage:` line. The browser still snapshots each segment into memory before sending it, but the main storage change is where FFmpeg writes the HLS files.

### Source Fill

Source Fill applies to **Direct File/SMB** and **SageTV PULL** playback.

```text
Auto live fill: starts with a fast fill burst, then switches to live-paced reading so Live TV/growing recordings do not race to EOF and stop.
Fast fill buffer: Direct File/SMB reads/transcodes without -re, and SageTV PULL issues READ requests as fast as FFmpeg can accept data. Playback can start after a small Start Buffer while future HLS segments are created in the background.
Realtime / live safe: Direct File/SMB uses -re and SageTV PULL uses light input pacing. Use this for Live TV or in-progress recordings where the file is still growing.
PUSHBUFFER: always live-paced; SageTV controls when chunks arrive. The app can queue/prebuffer PUSH data but cannot read future data faster than SageTV sends it.
```

For already-recorded files on an iPhone, try **Fast fill buffer** with **Start Buffer = 1 or 2 segments**. If the file is still recording and playback stops when FFmpeg catches up to the current end of the file, switch Source Fill back to **Realtime / live safe**.

### FFmpeg RAM Buffer

This is not the same as the browser HLS buffer or HLS Storage. It changes FFmpeg's internal queues and buffers:

```text
Normal: default/light RAM use
Large: larger input/probe/mux queues and larger encoder VBV buffer
Huge / diagnostic: very large queues for testing; may increase startup time and RAM use
```

The setting affects FFmpeg options such as `-thread_queue_size`, `-analyzeduration`, `-probesize`, `-max_muxing_queue_size`, and the H.264 `-bufsize` value. Video Debug shows the active values on the `ffmpeg buffer:` line. Start with **Large**. Use **Huge / diagnostic** only to prove whether larger FFmpeg queues help. If Huge does not improve stability, the bottleneck is probably encoder speed, network/client buffering, or HLS/iOS behavior rather than FFmpeg RAM queues.

### Source

```text
Direct File/SMB
SageTV PULL
PUSHBUFFER
Auto Direct/PULL/PUSH
```

`PUSHBUFFER` is the original path. SageTV pushes transport-stream chunks to Python, and Python feeds FFmpeg over stdin.

`SageTV PULL` asks SageTV to use `stv://` pull URLs when possible. Python then reads from SageTV's pull socket and feeds FFmpeg. This is experimental and restarts from the beginning after seek/flush because byte-accurate PULL seeking is not implemented yet.

`Direct File/SMB` tries to resolve a SageTV file or `stv://` path into a local path that Python/FFmpeg can read directly. Use `Sage Root` and `Local Root` to map the SageTV path to your mounted SMB/NFS path. Example:

```text
Sage Root:  /var/media/tv
Local Root: \\192.168.10.175\sagemedia\tv
```

Linux example:

```text
Sage Root:  /var/media/tv
Local Root: /mnt/sagetv
```

You can also set multiple mappings with:

```text
SAGEWEB_DIRECT_PATH_MAP=\\SAGETV\Recordings=Z:\Recordings|/var/media/tv=/mnt/sagetv
```

`Auto Direct/PULL/PUSH` tries direct file playback for non-push URLs, then PULL for `stv://`, then PUSHBUFFER if SageTV still sends PUSH.

### Player

```text
HLS hls.js TS
HLS hls.js fMP4
Video.js HLS TS
Video.js HLS fMP4
```

`HLS hls.js TS` uses FFmpeg HLS output with `.m3u8` and `.ts` segments and hls.js in the browser. This is the recommended default player.

`HLS hls.js fMP4` uses FFmpeg HLS output with `init.mp4` and `.m4s` segments.

`Video.js HLS TS` and `Video.js HLS fMP4` use the same FFmpeg HLS output, but play it through Video.js/VHS. Use these modes for comparison after hls.js works.

Removed player modes such as WebRTC, ABR HLS, and MSE are normalized back to **HLS hls.js TS** if they are still present in old saved browser settings.

### Buffer / Stability

Use this when the browser starts but later stops, especially on iPhone/iPad where Safari may use native HLS behavior.

Recommended iOS-safe settings:

```text
Buffer Preset: iOS Safe
HLS Segment: 6 sec
Start Buffer: 4 segments
hls.js Max Buffer: 180 sec
```

What these do:

```text
HLS Segment
- Longer segments reduce playlist churn and help native HLS avoid stalls.
- 6 sec is a good iOS-safe starting point.
- 8 sec is maximum stability but adds more startup delay.

Start Buffer
- The browser waits for this many completed HLS segments before starting.
- 4 segments at 6 sec means about 24 seconds of startup buffer.
- Use 6 segments if video still stops on Wi-Fi/VPN.

hls.js Max Buffer
- Applies mostly to desktop hls.js.
- iOS native HLS controls most of its own buffer, but the larger startup buffer still helps.
```

For low-delay testing, use 2 second segments and 1-2 start segments, but that is less stable.

### Encoder

Start with:

```text
libx264
```

Hardware encoders can be tested later, but software x264 is usually better for debugging stability.

### Max H

```text
Source
1080p
720p
576p
480p
360p
240p
```

`Source` does not scale the source video. v66 defaults to Source. If the PC falls behind, lower this to 720p or 480p.

### Bitrate

```text
Source
Auto
800k
1200k
1600k
2500k
3500k
5000k
8000k
```

v66 defaults to Source. If the PC falls behind, lower this to Auto, 2500k, or 1600k.

### Audio Sync

```text
Audio -500ms
Audio -300ms
Audio -200ms
Audio -100ms
0ms
Audio +100ms
Audio +200ms
Audio +300ms
Audio +500ms
```

Positive values delay audio. Negative values advance audio. Changing this live restarts only the FFmpeg/browser video stream; SageTV playback keeps running.

### HLS Segments

```text
Stable during playback
Rolling cleanup
Debug keep all
```

`Stable during playback` keeps all `.ts` files for the active playback session and cleans the session when playback stops. This prevents the browser from requesting a segment that was just deleted.

`Rolling cleanup` deletes old `.ts` files during playback. It saves disk space but can cause jumps if the browser falls behind.

`Debug keep all` keeps everything and enables `push_capture.ts` for troubleshooting.

## Video pipelines

### Direct File/SMB pipeline

```text
SageTV file/stv path
  -> Python path mapping
  -> local SMB/NFS path
  -> FFmpeg reads file directly
  -> stream.m3u8 + HLS segments
  -> browser player
```

### SageTV PULL pipeline

```text
SageTV stv:// URL
  -> Python pull socket reader
  -> FFmpeg stdin
  -> stream.m3u8 + HLS segments
  -> browser player
```

### HLS PUSH pipeline

```text
SageTV PUSHBUFFER
  -> Python
  -> FFmpeg stdin
  -> stream.m3u8 + seg_00001.ts, seg_00002.ts, ...
  -> hls.js or Video.js/VHS
  -> HTML5 video
```

## Troubleshooting

### Browser still shows an old version

Hard refresh:

```text
Ctrl + F5
```

Confirm the debug panel says:

```text
Media / Video Debug v66
```

### Video jumps or gets jerky

Use:

```text
Player: HLS hls.js TS
Encoder: libx264 or h264_qsv
Max H: Source first, then 720p or 480p if needed
Bitrate: Source first, then 3500k or 1600k if needed
```

Watch the debug status:

```text
bp=<number> drop=<number>
```

`bp` means backpressure. If it climbs, the player/encoder/browser is falling behind. Lower bitrate or height, or use a hardware encoder that is stable on the machine.

`drop` should stay at 0. If it increases, report the debug panel text.

### NVIDIA NVENC does not start

Use the encoder dropdown in this order:

```text
h264_nvenc NVIDIA safe
h264_nvenc NVIDIA bare compat
h264_nvenc NVIDIA CUDA upload
h264_nvenc NVIDIA low latency
```

If all NVIDIA modes fail but Intel QSV and x264 work, run these commands from the project folder and copy the output:

```cmd
tools\ffmpeg\bin\ffmpeg.exe -hide_banner -encoders | findstr /i nvenc
nvidia-smi
tools\ffmpeg\bin\ffmpeg.exe -hide_banner -f lavfi -i testsrc2=size=1280x720:rate=30 -t 5 -pix_fmt yuv420p -c:v h264_nvenc -f null -
```

If the test command fails, FFmpeg or the NVIDIA driver cannot access NVENC outside the app. If it passes, the `CUDA upload` mode is the next best app-side test.

### Playback stops or SageTV shows an error after stopping

Stop the server and kill leftover FFmpeg:

```cmd
taskkill /IM ffmpeg.exe /F
```

Then restart `run_windows.bat`.

### Clean HLS files manually

After stopping the app:

```powershell
Remove-Item -Recurse -Force .\runtime_hls\*
```

## Changelog


### v137 - Android/Web Remote IR command mode
- Changed the long-press remote OSD to send SageTV remote-style IR events when an Android MiniClient IR code exists, matching the built-in SageTV Web Remote behavior more closely.
- Falls back to normal SageCommand events for commands without an IR mapping.
- Expanded the command map to include the remaining Android MiniClient commands and aliases, including aspect toggle, DVD commands, custom commands, smooth FF/REW, eject, input, and scroll commands.
- Kept local Play/Pause/Stop handling so browser video still responds immediately.

### v137 - Android-style long-press remote OSD

- Replaced the small long-press navigation panel with a full Android MiniClient-style remote OSD.
- Added navigation, media, TV/library, page/channel/volume, feature/aspect/DVD/power/delete, number pad, and keyboard helper sections.
- Long-press/hold on arrows, media seek, page, channel, and volume buttons now repeats the SageTV command while held.
- The OSD stays open after sending commands so multiple remote actions can be used without reopening it; close with Dismiss, X, or by tapping outside the card.

### v134 - Mouse Back button mapping
- Added a Connection setting: **Mouse Back button = SageTV Back**. When enabled, Browser Back / side-button 4 sends SageTV Back and prevents the browser from navigating away.
- Added PointerEvent and MouseEvent fallback handling so the mapping works on more browsers/mice.
- Kept v133 SageMC Guide mouse assist and v130 SageX path/timeline support.

### v133 - SageMC Guide mouse assist
- Added AWT-style mouse button modifiers to MiniClient mouse events.
- Added optional SageMC Guide OK assist. When the current MENU_HINT is menuName:Guide and the menu does not change after a click, the browser sends SELECT so SageMC Guide behaves like pressing OK.
- Kept v130 SageX path/timeline support and v132 native mouse default.


### v132

- Fixed v131 Guide mouse regression by restoring native MiniClient-style mouse clicks as the default. The SageTV Guide requires the final MCLICK event for normal grid selection, so legacy saved `guide_safe` settings are auto-treated as native. A separate optional Double-click to select mode remains available.

### v131

- Added a Mouse mode setting. Default was Guide Safe: a single left click sent mouse move/press/release only, and a second click on the same target sent SageTV click/select. This was later changed in v132 because some Guide screens ignored press/release without MCLICK.
- Right/middle clicks still use the native SageTV click path so STV context menus continue to work.
- Kept v130 SageX file lookup and GetRawMediaTime timeline polling.

### v130
- Replaced Web Interface/Webpage MediaFile path lookup with SageX API lookup.
- SageX API setting accepts `SERVER:PORT`, a full URL, `/sagex`, or `/sagex/api`; `/sagex/api` is appended automatically when needed.
- Added SageX `GetRawMediaTime()` / `GetMediaDuration()` polling for Direct File/SMB playback when a file is resolved through SageX but SageTV opened the item as PUSHBUFFER.
- Large SageX RawMediaTime jumps are mirrored into local FFmpeg/HLS restarts so the video follows SageTV's timeline even when PUSHBUFFER sends no useful mux/seek timing.
- Kept v122 transparent compositor, v124 safe log throttling, v125 local Play/Pause/Stop behavior, and v129 Direct File/SMB + PUSH timing support.

### v129
- Corrected the Direct File/SMB + Web Interface/Webpage lookup behavior for SageTV `push:` sessions.
- If Source is **Direct File/SMB** and the file can only be found through the Web Interface/Webpage plugin, the client now keeps using the resolved local/SMB file path as the FFmpeg input.
- In that same case, SageTV PUSHBUFFER stays active only as the timing/control channel. The client reads the PUSHBUFFER request/mux times, including zero-byte timing packets, and mirrors those times into Direct File/SMB FFmpeg restarts for seek/skip.
- A FLUSH without an explicit SEEK no longer restarts Direct File/SMB at 0; it waits for the next SageTV PUSHBUFFER timing packet.
- If Direct File/SMB cannot resolve a file at all, PUSHBUFFER fallback is still available.
- Kept v122 transparent video compositor behavior, v124 safe log throttling, and v125 local Play/Pause/Stop behavior.

### v122
- Reworked video/menu compositing again based on the Android MiniClient START/CLEAR/FLIP behavior, but adapted for the browser where video is a separate DOM layer under the SageTV canvas.
- STARTFRAME now clears the HTML5 SageTV UI canvas to transparent, not black or opaque blue, so old menu pixels are removed without covering the video subwindow.
- Back/Home/menu navigation no longer hides or tears down the actual `<video>`/Video.js element while the stream is still active. Audio/video remain alive until SageTV sends Stop.
- Removed pre-video menu snapshot restoration from navigation paths. The browser now lets SageTV repaint the current menu instead of restoring an old Media Browser frame.
- Video-mask and CLEAR_RECT commands can update the trusted video rectangle, which allows returning from menus to the video OSD or preview window without needing to press Stop first.

### v121

- Fixed the regression where returning from a menu to the video/OSD window showed a black video rectangle while audio continued. The renderer now restores the actual HTML5/Video.js player element, not just the parent video layer.
- Preserves the last trusted SageTV video rectangle while menu navigation temporarily suspends video compositing, so SageTV can return to the OSD/video screen even if it does not send a fresh video-bounds command.
- Allows large dark video-mask frames, as well as color-key masks, to resume video compositing after Back/Home/menu navigation. This keeps menus opaque but lets the active video window reappear.
- Changed the forced menu repaint clear color from black to the normal SageTV/stage blue so menus do not look black while the stream is still active.

### v120

- Fixed the remaining Back/menu overlay problem while video is still active. The browser no longer restores the pre-video menu snapshot, because that snapshot can be the old Media Browser while SageTV is drawing the Start/Home menu.
- Changed the browser renderer to clear the UI framebuffer opaquely at STARTFRAME, matching the Android MiniClient/OpenGL renderer behavior. This prevents old menu cards/text from stacking on top of the current menu while playback continues in the background.
- Added a short forced opaque-clear window after Back/Home/Stop/menu navigation so SageTV partial redraws start from a clean framebuffer instead of stale playback/menu pixels.

### v119

- Changed the browser renderer to follow the Android MiniClient START/CLEAR/FLIP state logic: START+CLEAR+FLIP is video, START+FLIP with no CLEAR is menu, and START+CLEAR+DRAW+FLIP is video OSD/timebar.
- Stopped clearing the entire HTML5 canvas on every STARTFRAME. SageTV often sends partial menu redraws, and clearing the full canvas caused the broken partial/overlapped menu after pressing Back during playback.
- Added a last-good menu snapshot. When Back/Home/Guide/etc. returns from playback while the stream is still alive, the browser restores the snapshot first, then applies SageTV's partial redraws.
- Kept Web Interface/Webpage as lookup-only for MediaFile paths. The broken Web HTTP source remains removed.

### v117

- Fixed duplicate/overlapping Media Browser text while video playback is active by no longer painting browser fallback `DRAWTEXT` commands when SageTV text is already provided as texture images.
- Changed video rectangle fallback handling so an untrusted full-canvas fallback is used only to keep the HLS player alive; it no longer punches the whole SageTV GUI canvas transparent.
- Removed the extra dark radial `video-active` stage background so active playback does not dim normal menu screens.

### v116

- Fixed the playback video-layer refresh/bounds issue where starting a video could leave the old SageTV menu dimmed or stale instead of showing the video layer.
- Browser renderer now applies `GFXCMD_SETVIDEOPROP` / `videoBounds` commands instead of ignoring them.
- Browser now also updates video bounds from `mediaStatus.dest_rect`.
- If SageTV starts playback before it sends a valid video rectangle, the browser keeps the video layer active and falls back to the last known rectangle, then full canvas, instead of hiding the video layer and painting the dark video mask on the GUI canvas.

### v115

- Removed **Source = SageTV Web Interface** from the browser UI because Web HTTP/playlist playback is not working reliably.
- Legacy saved/cookie `web` source values now normalize to **Direct File/SMB**.
- Kept the Web Interface/Webpage settings for MediaFile path lookup only. Direct File/SMB now asks the Web Interface for the current file path whenever the direct OPENURL cannot be mapped, including PUSHBUFFER-only Video Library items.
- Auto source is now **Auto Direct/PULL/PUSH**. It no longer attempts Web HTTP playback.

### v114

- Fixed SageTV Web Interface HTML parsing for older/unquoted links such as `<a href=/sage/...>m3u</a>`.
- Handles bracketed playlist link text like `[m3u]`, `[pls]`, `[wmx]`, and `[wvx]`.
- Expands DetailedInfo lookup using `AiringID` as well as `MediaFileID`.
- Fetches playlist links that use query parameters such as `type=m3u` or `Format=pls`, not only URLs ending in `.m3u`/`.pls`.
- Prevents local filesystem playlist entries such as `/var/media/...` from being treated as fake HTTP URLs.

### v113

- Changed **Source = SageTV Web Interface** to be true Web/HTTP input only. It no longer uses the Web Interface file path through Direct File/SMB when the source is explicitly set to Web.
- Added Web Interface HTTP input status as `source=web` and `fill=web-http`.
- Improved Web Interface anchor parsing for `[m3u]`, `[pls]`, `[wmx]`, `[wvx]`, `File Playlists`, `Streaming Playlists`, and `Watch (Streamed)` links.
- If a current/status page contains a MediaFileID, the Web lookup now follows the real DetailedInfo page to find playlist/streaming links.
- FFmpeg Web HTTP input sends the configured Web Interface Basic Auth credentials as HTTP headers when username/password are set. The debug command line hides those headers.

### v112
- Fixed Video Library startup ordering when SageTV sends PUSHBUFFER data before the OPENURL. Direct/Web modes now buffer early PUSHBUFFER briefly and wait for OPENURL so the Web Interface MediaFile path can be used first instead of starting a PUSH bridge prematurely.
- Re-enabled automatic encoder startup fallback. If a selected hardware encoder such as `h264_qsv` starts but does not create an HLS segment, the bridge retries with `libx264` unless `SAGEWEB_STRICT_ENCODER=1` is set for diagnostics.
- Avoids adding duplicate blank Root Mapping rows when the legacy Sage Root/Local Root fields already cover the discovered Web Interface path.

### v111
- Moved **Web Interface**, **Web Username**, and **Web Password** controls from **Source / Server Paths** to the **Connection** section.
- Web Interface source/lookup behavior is unchanged; the setting is still shared server-side and used by Source = Web Interface and Auto/Direct fallback.

### v109
- Removed the native SageTV backend/database lookup path. The app no longer attempts the native client/server backend connection.
- Auto/Web/Direct fallback now uses only Direct File/SMB, SageTV Web Interface detail/playlist lookup, and PUSHBUFFER fallback.
- Updated GUI/status text from Backend File/Format to Web File/Format.
- Kept Server as host/IP only for the MiniClient connection on standard port `31099`. Web Interface keeps its own `SERVER:PORT`, username, and password settings.

### v108

- Added **Source = SageTV Web Interface**.
- Added shared Web Interface settings under **Source / Server Paths**: **Web Interface**, **Web Username**, and **Web Password**.
- Web Interface setting accepts `SERVER:PORT` or a full URL and defaults to `http://<SageTV server>:8080`.
- The Web Interface lookup uses normal Webpage plugin pages/detail/playlist parsing and does not require `/sagex/api`.
- When a PUSHBUFFER-only item is played, Web Interface mode can use an HTTP media URL/playlist target or a mapped file path when the Web UI exposes it.
- Auto source order is now Direct File/SMB, SageTV Web Interface, PULL, then PUSHBUFFER.
- Added parser tests for Web Interface detail pages, MediaFileID extraction, and M3U/PLS playlist URLs.

### v107

- Removed the web API plugin dependency and removed the backend API/context fields from the GUI.
- The Server setting is now host/IP only. Standard SageTV ports are used internally: `31099` for MiniClient UI/media and `42024` for native backend lookup.
- Direct File/SMB now tries native SageTV Client backend lookup when SageTV sends PUSHBUFFER with no file path.
- Backend MediaFile file/format hints are still displayed as **Backend File** and **Backend Format**.
- Legacy `host:port` server values are accepted but normalized to the host only.
- Added tests for host-only server parsing and backend MediaFile parsing.

### v106

- Replaced the v105 Video Detail screen-text capture fallback with a SageTV backend API fallback.
- Direct File/SMB now calls `GetCurrentMediaFile` through the optional `sagex-services` REST API when SageTV sends PUSHBUFFER with no file path.
- Added **SageX API** and **SageX Context** fields under **Source / Server Paths**. Blank/auto uses `http://<SageTV server>:8080/sagex/api` and the Client ID without colons.
- Removed the active `GFX_TEXTMODE=DRAWTEXT` request and the **Capture detail text** UI option.
- Backend API results populate **Backend File** and **Backend Format**, auto-discovering new Sage roots when needed.

### v105

- Added **Capture detail text**. When enabled, the client requests SageTV `DRAWTEXT` commands so Python can read the text shown on Video Detail screens.
- Captures the displayed **File:** path and **Format:** line from SageTV Video Detail pages.
- If SageTV later sends a PUSHBUFFER-only `OPENURL` with no file path, Direct File/SMB tries the most recently captured Video Detail file path before falling back to PUSHBUFFER.
- Captured Video Detail paths also auto-discover new Sage roots. For example `/var/media/videos/...` adds `/var/media/videos =` to the Root Mappings list.
- The GUI now shows the last captured Video Detail File and Format under **Source / Server Paths**.
- Parsed format hints are stored in session status for future FFmpeg input-hint tuning, such as container, codec, resolution, FPS, and bitrate where SageTV displays them.

### v104

- Direct File/SMB now tries to extract and map a real file path from `push:` OPENURL values before refusing PUSHBUFFER in strict Direct mode.
- This helps SageTV video-library files that are announced as PUSHBUFFER even though SageTV still includes the backing file location.
- Auto source mode also tries Direct File/SMB first for `push:` URLs with embedded paths before falling back to PUSHBUFFER.
- If the embedded path is from a new storage root, the server auto-adds the Sage Root to the Root Mappings list with a blank Local Root for editing.
- SageTV push flags such as `?bf=vid` are stripped before mapping the embedded filesystem path.

### v103

- Added editable multi-root Direct File/SMB mapping list.
- Auto-discovers new SageTV source roots and adds them with blank Local Root entries.
- Direct path mapping now uses the longest matching Sage Root first and still supports legacy single-root settings.

### v102 - Windows/Linux QSV hardware decode/filter path
- Added **QSV Decode** under **Quality / Encoder**. Auto uses `d3d11va` on Windows and `/dev/dri/renderD128` on Linux when available. Off keeps the older compatible decode path.
- Added **QSV Filter** under **Quality / Encoder**. Auto uses `deinterlace_qsv,scale_qsv` with Intel QSV so MPEG-2 decode, deinterlace, scale, and H.264 encode can stay on the Intel GPU.
- Added a QSV FPS guard. When QSV Auto deinterlace is used with **FPS = Source**, the FFmpeg command now outputs about `30000/1001` fps and `-g 30` instead of allowing 59.94i input to become 119.88 fps.
- Added **FFmpeg Input Mode = Fast Startup**. This applies the low-delay input/probe settings tested from the MITM script: `-fflags +genpts+nobuffer+flush_packets`, `-probesize 300000`, `-analyzeduration 300000`, and `-max_delay 0`. Normal/Large/Huge remain available as compatibility fallbacks.
- Media debug now shows QSV effective decode/filter mode, FFmpeg input flags, effective output FPS, and GOP.

### v101 - Encoder Fast Start / Low Latency mode
- Added **Encoder Latency** setting under **Quality / Encoder**. Default is **Fast Start / Low Latency**.
- **Normal / Compatible** keeps the previous conservative encoder profiles.
- **Fast Start / Low Latency** applies the closest low-latency options per encoder family:
  - `libx264`: keeps `ultrafast` / `zerolatency` and disables B-frames.
  - `h264_qsv`: keeps `veryfast`, disables lookahead, uses `async_depth=1`, requests forced IDR frames, and disables B-frames.
  - `h264_nvenc`: uses `p1`, `tune=ull`, `zerolatency=1`, `rc-lookahead=0`, forced IDR frames, and disables B-frames.
  - `h264_nvenc_bare`: stays mostly bare for compatibility and only disables B-frames in Fast Start mode.
  - `h264_amf`: keeps `quality=speed`, adds `usage=ultralowlatency`, and disables B-frames.
- Media debug now shows the active encoder latency mode next to the running encoder.

### v100 - Fast Start HLS and smaller-stream controls
- Added **Startup Segment** setting. Default is **1 sec**, while **Max HLS Segment** defaults to **4 sec**. The FFmpeg command now uses `-hls_init_time` for short startup segments and `-hls_time` for the selected max segment length.
- Added **Start Buffer = Auto by encode rate**. The browser waits for 1-4 startup segments depending on measured FFmpeg/HLS fill rate. Faster encodes start after fewer segments; slower encodes wait for more buffer.
- Added **FPS** setting under Quality / Encoder. Default is **Source**. Lower FPS options can reduce encode load, bandwidth, and startup pressure.
- Added **Audio Bitrate** setting under Quality / Encoder. Lower audio bitrates make the HLS stream smaller for Wi-Fi/VPN/mobile testing.
- HLS fill-rate reporting now parses actual playlist `#EXTINF` durations, so startup 1-second segments are counted correctly instead of assuming every segment equals the max segment length.
- Keyframe forcing now uses the startup segment cadence when Fast Start is enabled so FFmpeg can cut the short initial segments.

### v99 - Removed MSE player modes
- Removed the **Player = MSE separate A/V** option from the browser UI.
- Removed the **Player = MSE fMP4 combined** option from the browser UI.
- Removed the browser Media Source Extensions playback code for custom fMP4 streaming.
- Removed the server-side `/mse/...` and `/mseav/...` streaming endpoints.
- Removed the FFmpeg command branches that generated fragmented MP4 output for MSE.
- Existing saved `playerMode=mse` or `playerMode=mseav` settings are normalized back to **HLS hls.js TS**.

### v98 - Removed HLS hls.js ABR TS test mode
- Removed the **Player = HLS hls.js ABR TS** option from the browser UI.
- Removed the server-side multi-rendition HLS/master-playlist FFmpeg command path.
- Existing saved `playerMode=hlsabr` client/server settings are normalized back to **HLS hls.js TS**.
- hls.js playback now uses the fixed single-playlist `stream.m3u8` path for TS/fMP4 HLS.

### v97 - Removed experimental WebRTC/aiortc player
- Removed the **Player = WebRTC aiortc Experimental** option from the browser UI.
- Removed browser WebRTC offer/answer signaling and connection-state handling.
- Removed the server-side `app/webrtc_bridge.py` module and all active aiortc session paths.
- Removed optional `aiortc` and `av` Python dependencies from `requirements.txt`.
- Existing saved `playerMode=webrtc` client settings are normalized back to HLS in the browser and server.

### v87 - Private generated client IDs
- Removed first-run MAC/ARP-based client identity from the browser flow.
- New clients generate a private locally-administered Client ID in the browser and save it in the `sage_html5_client_id` cookie.
- The ID remains MAC-format only because SageTV MiniClient expects six ID bytes; it is not the device hardware MAC address.
- Kept `/api/default_client_id` only as a compatibility fallback for older cached browser files.


### v85 - Multi-Client SageTV ID Isolation

- Added automatic duplicate Client ID protection for simultaneous browser clients.
- If a second browser connects using the same Client ID, the server keeps the requested ID for settings/logs but uses a unique effective SageTV MiniClient ID for the socket connection.
- This prevents SageTV from disconnecting the first browser session when a second browser/iPhone/iPad connects.
- Connection logs now show both the requested Client ID and the effective SageTV Client ID.

### v83 - WebRTC Seek/Sync Test

- Fixed a seek/skip problem where a SageTV `SEEK` followed by `FLUSH` could reset the local WebRTC restart time back to 0.
- WebRTC Direct File/SMB restarts now preserve a recent SageTV seek target for local-only WebRTC restarts.
- Added experimental WebRTC Audio Sync using the existing Audio Sync control.
  - Positive values delay audio.
  - Negative values delay video.
- WebRTC answer logging now reports the applied sync note and audio offset.
- Updated UI help so Audio Sync is no longer marked as HLS/FFmpeg-only when WebRTC is selected.

### v82 - WebRTC Bitrate Hints
- Added **WebRTC aiortc** settings group.
- Added **Bitrate Control** presets: Auto, Low, Balanced, High, and Manual.
- Added Manual **Lower**, **Start**, and **Upper** bitrate hints in kbps.
- WebRTC offers now send the selected bitrate hints to the server.
- aiortc answers now try two best-effort bitrate-control methods:
  - `RTCRtpSender` maxBitrate parameters when the installed aiortc version supports them.
  - SDP bitrate hints (`b=AS`, `b=TIAS`, and common `x-google-*bitrate` fmtp hints).
- Video Debug now shows WebRTC received bitrate, decoded frames, packet loss, and selected caps.
- This is not HLS ABR and does not create multiple streams.

### v81 - Remove Startup Quality Ramp
- Removed **Startup Quality** from the UI and client settings.
- Removed **Upgrade Buffer** from the UI and client settings.
- Browser no longer sends `qualityRampUpgrade` messages or restarts FFmpeg after the buffer fills.
- Video Debug no longer shows quality-ramp status.
- Server ignores old saved quality-ramp settings; selected Max H and Bitrate are used directly.

### v80 - WebRTC seek/settings cleanup
- Added best-effort WebRTC Direct File/SMB seeking using PyAV container seek before aiortc tracks start.
- WebRTC seek/skip restarts from the cached Direct File/SMB path when SageTV reports the current OPENURL as PUSHBUFFER-only.
- WebRTC answer logs now show requested seek seconds and whether the PyAV seek call was applied.
- Browser disables HLS/FFmpeg-only settings while **Player = WebRTC aiortc Experimental** is selected.

### v79 - WebRTC aiortc Experimental
- Added **Player = WebRTC aiortc Experimental**.
- Added optional `app/webrtc_bridge.py` using `aiortc` and `MediaPlayer`.
- Browser now negotiates WebRTC over the existing WebSocket using `webrtcOffer` / `webrtcAnswer`.
- First implementation supports **Direct File/SMB** only. PULL/PUSH WebRTC are intentionally not hidden behind fallback yet.
- Video Debug now shows WebRTC connection and ICE state.
- Existing HLS/MSE/Video.js players are unchanged.


### v78 - Direct Restart Cache Fix
- Fixed Direct File/SMB local restarts when SageTV's current OPENURL is PUSHBUFFER-only.
- The server now caches the last resolved Direct SMB/local path and can reuse it for encoder/player/buffer changes.
- Startup Quality upgrades now restart Direct File/SMB from the cached path instead of logging that Direct cannot be used from PUSHBUFFER-only OPENURL.
- This keeps the SageTV GUI session connected and avoids requiring the user to re-open the video after changing settings.

### v76 - Startup Quality Ramp

- Added **Startup Quality** under Quality / Encoder.
- New modes: Off, Low start then selected, and Very low start then selected.
- Low start begins at 480p/1600k; Very low start begins at 360p/900k.
- Added **Upgrade Buffer** threshold. The browser asks the server to upgrade once buffered-ahead seconds reach the target.
- The upgrade restarts only the local video bridge at the selected Max H/Bitrate. It does not reconnect the SageTV GUI session.
- Video Debug now shows quality-ramp mode, phase, startup profile, target profile, and threshold.



### v75 - FFmpeg RAM Buffer Presets
- Added **FFmpeg RAM Buffer** client setting: Normal, Large, and Huge/diagnostic.
- Large/Huge increase FFmpeg input packet queue, probe/analyze size, muxing queue, and encoder VBV buffer.
- Video Debug now shows the active FFmpeg buffer preset and queue values.
- The setting is saved per Client ID so iPhone/iPad/desktop clients can use different buffer tuning.
- Existing HLS Storage RAM/tmpfs setting remains separate and controls where HLS files are written.

### v74 - Source Change Local Video Restart
- Changing **Source**, **Sage Root**, or **Local Root** no longer disconnects/reconnects the SageTV GUI/media session.
- The server now stops the local FFmpeg/PULL bridge, clears the browser video, and restarts from the current SageTV `OPENURL` using the newly selected source when possible.
- Direct File/SMB and SageTV PULL can usually switch immediately when the current `OPENURL` is `stv://...` or a mappable file path.
- PUSHBUFFER can restart locally only when the current SageTV stream is already PUSH. Switching from a non-PUSH `stv://`/file URL to PUSH still requires SageTV to send a new `OPENURL`, so use **Auto** or reopen the media if needed.
- Explicit source modes remain strict. **Auto Direct/PULL/PUSH** is still the only fallback mode.

### v73 - RAM/Temp HLS Storage

- Added **HLS Storage** server setting: Disk, OS temp, or RAM/tmpfs/RAM-disk.
- Added optional **RAM Path** for Windows RAM disks or custom tmpfs folders.
- HLS serving now uses the active session output folder instead of assuming only `runtime_hls`.
- Video Debug now shows the active storage mode, path, RAM flag, and storage note.
- RAM mode uses Linux `/dev/shm` automatically when available. On Windows, supply a RAM-disk path such as `R:\sagetv_hls`.

### v72 - Source Change Auto Reconnect

- Changing **Source** now automatically reconnects the SageTV session so SageTV renegotiates PUSH/PULL/file capabilities.
- Changing **Sage Root** or **Local Root** also auto-reconnects so Direct File/SMB mapping changes take effect immediately.
- The browser no longer needs a manual Disconnect/Connect after changing Source.
- The reconnect sends a `videoStop` first so the old HLS/MSE player is cleared before the new source starts.

### v71 - Buffer Debug and Logs

- Added visible buffer monitoring in the Media / Video Debug panel:
  - browser buffer ahead/behind
  - active buffered ranges
  - video ready/network state
  - HLS seconds produced by FFmpeg
  - server fill rate such as `1.00x`, `2.50x`, or higher
  - latest segment age/name and ENDLIST status
- Added per-client browser/app log files under `client_settings/<client_id>/client.log`.
- Added overall server error logging under `server_settings/server_errors.log`.
- Added `/api/log_paths` and `/api/client_log` endpoints for troubleshooting.

### v70 - Auto Live Fill Startup Fix

- Fixed browser startup error `ReferenceError: selectedPlaybackSource is not defined`.
- Preserved **Source Fill = Auto live fill: fast then live** instead of converting it to Fast Fill in the browser payload.
- Startup/debug status can now render before the first video status arrives.

### v69 - Auto Live Fill

- Added **Source Fill: Auto live fill: fast then live**.
- Direct File/SMB now uses an FFmpeg read-rate burst: it starts filling quickly, then paces at live speed so Live TV or growing recordings do not run to EOF and stop.
- SageTV PULL now uses the same behavior in Python: fast burst, then live pacing. If it reaches the current file end, it waits for growth instead of immediately ending.
- PUSHBUFFER remains `push-live` because SageTV controls when PUSH chunks arrive.

Recommended for iPhone/Live TV:

```text
Source: Direct File/SMB
Player: HLS hls.js TS
Encoder: h264_qsv
Buffer Preset: iOS Safe
HLS Segment: 6 sec
Start Buffer: 1 or 2 segments
Source Fill: Auto live fill: fast then live
```

### v69
- Extended **Fast fill buffer** behavior to **SageTV PULL**.
- Renamed the UI label from **Direct Fill** to **Source Fill**.
- Direct File/SMB and SageTV PULL can fill ahead faster than real time for completed recordings.
- PUSHBUFFER is now shown as **push-live** because SageTV controls the chunk rate and it cannot truly fill faster than real time.
- Added light realtime pacing for SageTV PULL when Source Fill is set to **Realtime / live safe**.



### v67 - Fast Direct File buffer fill

- Added **Direct Fill** under Buffer / Stability.
- **Fast fill buffer** removes FFmpeg `-re` for Direct File/SMB playback so FFmpeg can create HLS segments faster than real time. Playback can start after a small Start Buffer while the browser continues to build a larger buffer in the background.
- **Realtime / live safe** keeps `-re` and is recommended for live TV or in-progress recordings where the media file is still growing.
- Direct Fill is saved per Client ID.


### v66 - Split server settings and client settings

- Added `server_settings/settings.json` for shared SageTV/server environment settings.
- Kept `client_settings/<client_id>/settings.json` for per-device playback preferences.
- Moved Server, Source, Sage Root, and Local Root to shared server settings.
- Kept Player, Quality/Encoder, Buffer/Stability, Audio Sync, mute, media caps, and debug overlay as per-client settings.
- Added legacy compatibility so v66 can read server fields from an existing v66 client settings file until the shared server settings are saved.

### v66 - Server-side per-client settings

- Removed cookie/localStorage as the primary settings store.
- Added `client_settings/<client>/settings.json` folders on the Python server.
- Added `/api/client_settings` load/save endpoints.
- The browser now loads settings based on the **Client ID** field.
- Each client can keep its own Source, Player, Direct File/SMB roots, encoder, quality, and buffer settings.

### v64 - Buffer/Stability options for iOS/native HLS

- Added **Buffer Preset** options: Normal, iOS Safe, Maximum Stability, and Low Delay.
- Added HLS segment length control.
- Added Start Buffer control so the browser can wait for more completed HLS segments before attaching playback.
- Added hls.js max buffer control for desktop browsers.
- Debug panel now shows HLS segment length and start-buffer target.
- QSV H.264 now requests no B-frames to make HLS/iOS recovery more conservative.

### v63 - Remove No fallback and make explicit modes strict

- Removed the **No fallback** checkbox from the UI.
- Explicit Source choices are now always strict:
  - Direct File/SMB only uses the mapped file path.
  - SageTV PULL only uses `stv://` PULL.
  - PUSHBUFFER only uses pushed chunks.
- `Auto Direct/PULL/PUSH` is now the only source mode that falls back.
- Explicit Player choices are also strict; Video.js no longer switches to hls.js unless a future Auto Player option is added.
- Updated debug text to show strict source behavior more clearly.

### v62 - Settings cleanup and Source-only streaming selection

- Removed the old **Force PUSH** checkbox.
- The **Source** dropdown now fully controls how SageTV media is requested and played:
  - Direct File/SMB advertises stv/file URLs and maps them to SMB/local paths.
  - SageTV PULL advertises stv:// PULL.
  - PUSHBUFFER advertises PUSH only.
  - Auto allows Direct/PULL/PUSH selection.
- Kept **Strict source mode** as the strict testing control.
- Reorganized browser settings into Connection, Source, Player, and Quality/Encoder groups.
- Updated defaults to Direct File/SMB + hls.js HLS TS for the current SMB/direct-file test path.
- Debug status now shows the selected source before FFmpeg starts instead of always showing push when the bridge is stopped.

### v61 - Video.js HLS source fix

- Added explicit Video.js HTTP Streaming/VHS CDN script after Video.js.
- Video.js now applies HLS playlists using multiple MIME spellings: `application/vnd.apple.mpegurl`, `application/x-mpegURL`, and `application/mpegurl`.
- Desktop browsers now force Video.js/VHS for HLS instead of relying on native HLS detection.
- Video.js recovery now re-applies the same selected playlist only if the source list becomes empty, instead of immediately changing player modes when Strict source mode is enabled.
- Direct File/SMB fixes from v60 remain unchanged.

### v60 - Direct File/SMB stv:// parser fix
- Fixed `Direct File/SMB not used: could not parse stv:// path: name 'parse_stv_url' is not defined`.
- Direct File/SMB now imports the same SageTV `stv://` parser used by the PULL reader.
- Direct File/SMB no longer refuses to start only because `Path.exists()` cannot verify a UNC/share path. It now starts FFmpeg and shows the real FFmpeg/open error if the share is not reachable.
- Keep `strict Source mode when testing Direct File/SMB so the debug panel shows only the selected source and does not hide failures by switching to PULL/PUSH.

### v58 - Direct File/SMB and SageTV PULL source modes
- Added `Source` dropdown with `PUSHBUFFER`, `SageTV PULL`, `Direct File/SMB`, and `Auto Direct/PULL/PUSH`.
- Added optional `Sage Root` and `Local Root` mapping fields for SMB/NFS direct-file playback.
- FFmpeg can now read a mapped file path directly instead of only using `pipe:0`.
- Added Direct File/SMB seek restart using the current SageTV media time as FFmpeg `-ss`.
- Promoted the existing `stv://` PULL reader into a selectable playback source.
- Debug panel now shows the active input source, direct path, pull URL, and direct seek offset.
- Kept PUSHBUFFER as the default and fallback path.

### v57 - HLS no-drop input mode
- HLS now uses no-drop input mode by default.
- Increased HLS FFmpeg input queue size.
- If FFmpeg falls behind, it waits/backpressures instead of dropping SageTV chunks.
- Added forced HLS keyframes at segment boundaries.
- Kept the v56 fMP4 HLS `init.mp4` fix.

### v56 - fMP4 HLS init segment fix
- Fixed fMP4 HLS startup. FFmpeg now runs from the per-session HLS folder so `init.mp4` is created beside `stream.m3u8` and the `.m4s` segments.
- Added a fallback for FFmpeg `stream_m3u8.tmp` startup playlists. If FFmpeg has generated `.m4s` segments but the final `stream.m3u8` is not visible yet, the server can use the temp playlist snapshot instead of waiting forever.
- This fixes the symptom where the debug panel showed many `.m4s` segments but `ready:false`, and the browser stayed at "Waiting for HLS playlist from FFmpeg" forever.
- Kept the v55 player choices: HLS hls.js TS, HLS hls.js fMP4, Video.js HLS TS, and Video.js HLS fMP4.




### v55 - HLS fMP4 stability test mode

- Added `HLS hls.js fMP4` and `Video.js HLS fMP4` player modes.
- fMP4 HLS uses `init.mp4` plus `.m4s` segments instead of MPEG-TS `.ts` segments. This keeps the HLS audio/video sync path but gives browsers cleaner fragmented MP4 media.
- HLS fMP4 readiness now waits for both the playlist and the init segment before starting playback.
- The `/hls` route now serves `.m4s` and `.mp4` files as `video/mp4`.
- Increased hls.js seek-hole tolerance slightly for rough SageTV stream boundaries.

### v54 - Optional Video.js HLS player

- Added `Video.js HLS` to the Player dropdown.
- Added Video.js CSS/JS from jsDelivr CDN.
- Added a separate Video.js video element so the custom MSE modes are not taken over by Video.js.
- Kept `MSE separate A/V` as the default for player-side audio sync.
- Added Video.js recovery that reloads the current HLS playlist after Video.js player errors.
- Updated the server player-mode normalization so `videojs`, `video-js`, and `vjs` map to the HLS backend while reporting `videojs` to the browser.

### v53 - Separate MSE audio/video streams, player-side sync, cookies

- Added Player mode `MSE separate A/V` as the default.
- FFmpeg now writes separate fragmented MP4 outputs for video and audio.
- Browser creates separate MSE SourceBuffers for video and audio.
- Audio Sync is now applied on the browser side in separate A/V mode.
- Default Audio Sync is `Audio -200ms`. Negative values delay video; positive values delay audio.
- Added coarse audio sync values from -2000 ms to +2000 ms.
- Saved UI settings in cookies and localStorage so browser settings survive refresh/restart.

### v51 - NVIDIA profiles and audio sync

- Removed a duplicate `pipe:1` from the MSE fMP4 FFmpeg command.
- Changed MSE video timestamp default to `PTS-STARTPTS` instead of rebuilding every timestamp from frame count. This should reduce long-play audio drift on some MPEG-TS captures.
- Changed audio resampling to `aresample=async=1000:first_pts=0` for better long-play audio/video sync.
- Added an `Audio Sync` dropdown from -500 ms to +500 ms.
- Added `h264_nvenc NVIDIA bare compat` for a minimal NVENC command path.
- Added `h264_nvenc NVIDIA CUDA upload` for systems where implicit NVIDIA upload fails.
- NVIDIA modes now use `nv12` format before NVENC instead of `yuv420p`.

### v50 - NVIDIA NVENC compatibility options

- Added encoder aliases so `h264_NVenc`, `NVENC`, `nvidia`, and `h264_nvenc` all normalize to the correct lowercase FFmpeg encoder name.
- Changed the normal `h264_nvenc` option to a conservative NVIDIA-safe command path.
- Added `h264_nvenc NVIDIA low latency` as a separate option for testing the newer low-latency NVENC settings after the safe option works.
- Kept `h264_qsv Intel UHD` as a separate explicit option because Intel Quick Sync has been working on this test machine.
- If the FFmpeg build does not expose the selected hardware encoder, the server falls back to `libx264` instead of starting a doomed FFmpeg process.

NVIDIA test commands for Windows:

```cmd
tools\ffmpeg\bin\ffmpeg.exe -hide_banner -encoders | findstr /i nvenc
nvidia-smi
tools\ffmpeg\bin\ffmpeg.exe -hide_banner -f lavfi -i testsrc2=size=1280x720:rate=30 -t 5 -pix_fmt yuv420p -c:v h264_nvenc -bf 0 -f null -
```

If that last command fails, the issue is outside the MiniClient app. Check the NVIDIA driver and whether FFmpeg can see NVENC on the RTX A2000. If it passes, use `h264_nvenc NVIDIA safe` first, then try `h264_nvenc NVIDIA low latency`.


### v50 - MSE and Source defaults

- Defaults Player to `MSE fMP4 test`.
- Defaults Max H to `Source`, so FFmpeg does not scale unless requested.
- Defaults Bitrate to `Source`, so FFmpeg uses the SageTV push URL bitrate when available.
- Server-side defaults now match the browser UI defaults when a saved/cached value is missing.

### v48 - MSE no-drop / backpressure playback

- MSE mode no longer drops SageTV `PUSHBUFFER` input when FFmpeg input is backed up.
- MSE waits and applies backpressure instead of corrupting the fMP4 stream.
- Browser MSE append queue no longer drops complete fMP4 fragments.
- Browser fetch loop slows down when the SourceBuffer is already far ahead.
- Old MSE back-buffer is trimmed behind the playhead to avoid quota errors.
- MSE video timestamps are regenerated with FFmpeg `setpts` by default.
- Debug status shows backpressure events and dropped input count.
- Consolidated all project markdown into this single `Readme.md`.

### v47 - MSE recovery and live settings

- Parses MP4 boxes before appending to `SourceBuffer`.
- Appends complete fMP4 init/media fragments instead of random fetch chunks.
- Recovers if the browser hits an `HTMLMediaElement.error`.
- Larger FFmpeg input queue in MSE mode.
- Live setting changes restart only the FFmpeg/browser stream while SageTV playback continues.

### v46 - MSE fMP4 test mode

- Added `Player` dropdown with `HLS` and `MSE fMP4 test`.
- Added `/mse/<session>/stream.mp4` direct fragmented MP4 stream.
- Added browser MediaSource / SourceBuffer playback path.
- Avoids HLS `.m3u8` playlists and `.ts` files in MSE mode.

### v45 - Stable-session HLS

- Added `Stable during playback` HLS segment mode.
- Keeps all `.ts` segments during active playback.
- Cleans the session folder on stop, disconnect, media reconnect, or new video.
- hls.js starts from the first segment of the current playback session.

### v44 - Stable HLS and fixed debug panel

- Changed hls.js from low-latency mode to stable buffering mode.
- Increased HLS live buffer sizes.
- Changed FFmpeg HLS segment time from 1 second to 2 seconds.
- Fixed the Media / Video Debug panel height to stop layout jumps.
- Reduced video status updates in the hot `PUSHBUFFER` path.

### v43 - Clean disconnect

- Fixed WebSocket disconnect error after the Disconnect button, refresh, tab close, or network disconnect.
- Stops SageTV/media/FFmpeg first, then exits the WebSocket loop cleanly.
- Prevents late debug/status sends after browser close.

### v42 - Windows batch fix

- Fixed `The system cannot find the batch label specified - ensure_ffmpeg`.
- Reworked `run_windows.bat` to avoid batch subroutine labels.
- Saved the batch file with Windows CRLF line endings.

### v41 - FFmpeg auto-install

- `run_windows.bat` checks for FFmpeg and auto-downloads Gyan.dev `ffmpeg-release-full.7z` if missing.
- Installs FFmpeg to `tools\ffmpeg\bin`.
- Added `tools/install_ffmpeg.ps1`.

### v40 - Connect fix

- Fixed v39 browser-side recursion in `hideVideoBox()`.
- Added defensive connect startup error logging.

### v39 - GUI overlay repaint

- Video debug box hidden by default.
- Removed yellow dashed startup overlay during normal playback.
- Video remains under the SageTV GUI canvas.
- GUI canvas repaints during playback.
- SageTV timeline, OSD, and menus can draw on top of video.
- Stage fallback background changed to SageMC-style blue.

### v38 - Video under GUI

- Video element moved under the SageTV GUI canvas.
- Canvas background changed to transparent during video playback.
- Video mask/color-key rectangles are treated as transparent.
- `PUSHBUFFER` debug status throttled for better responsiveness.

### v37 - HLS cleanup

- Added `HLS Segments` dropdown.
- Added rolling cleanup and debug keep-all modes.
- Added startup cleanup for abandoned `runtime_hls` folders.

### v36 - Quality dropdowns

- Added Max H dropdown with Source, 1080p, 720p, 576p, 480p, 360p, and 240p.
- Added Bitrate dropdown with Source, Auto, and fixed bitrates.
- Debug panel shows requested and effective quality.

### v35 - Playback lifecycle

- Replaced StaticFiles HLS serving with a byte-snapshot route.
- Fixed `Response content longer than Content-Length`.
- Added SageTV GFX `MEDIA_RECONNECT` handling.
- Stops FFmpeg and clears HLS files on STOP / DEINIT.
- Cancels stale browser HLS wait loops.
- FFmpeg input queue changed to non-blocking for HLS mode.

### v34 - Diagnostics

- Added no-cache headers for browser files.
- Simplified FFmpeg HLS command for live SageTV PUSH testing.
- Defaults first-test video to 480p / 1600k.
- Added raw aligned SageTV PUSH capture as `runtime_hls\<session>\push_capture.ts` in debug mode.
- Retries video-only if audio blocks HLS startup.

### v33 - Hardware fallback

- Hardware encoder stalls fall back to `libx264`.
- Re-feeds SageTV TS prebuffer after fallback.
- HLS uses `split_by_time` during testing.

### v32 - TS sync

- Defaults encoder to `libx264` for stability.
- Waits for MPEG-TS `0x47` sync before feeding FFmpeg.
- Shows TS sync status in the debug panel.
- Removes HLS temp-file mode so playlist and segments appear sooner.

### v31 - PUSH autostart

- Media/video caps checked by default.
- FFmpeg auto-starts on the first non-empty SageTV `PUSHBUFFER`.
- PUSHBUFFER data is fed to FFmpeg even if OPENURL startup was missed.
- FFmpeg start/write errors appear in the debug panel.

### v30 - HLS fallback

- Added rolling SageTV TS prebuffer.
- Auto mode falls back from `h264_nvenc` to `libx264` if no HLS segment appears.
- Re-feeds prebuffer after fallback.
- Adds deinterlace, scale, format, and timestamp reset filters.

### v29 - HLS stability

- Browser polls `/api/hls_ready/<session>` instead of directly polling `/hls/...` before playlist exists.
- Increased HLS wait timeout.
- Added FFmpeg log tail to the debug panel.
- Forced FFmpeg input as MPEG-TS for known TS streams.
- Kept HLS segments during testing.

### v28 - Force PUSH and pull fallback

- Added Force PUSH checkbox.
- Advertises `PULL_AV_CONTAINERS=NONE` when forcing PUSH.
- Added fallback SageTV port 7818 pull reader for `stv://` URLs.

### v27 - First FFmpeg/HLS video bridge

- Added experimental SageTV `PUSHBUFFER -> FFmpeg stdin -> HLS -> HTML5 video` path.
- HTML5 video positioned using SageTV `SETVIDEORECT` destination rectangle.

### v26 - Navigation overlay

- Long-click navigation overlay centered over the SageTV render area.
- Right-click reserved for SageTV context menus.

### v25 - Right-click handling

- Right-click forwards to SageTV as mouse button 3.
- Browser context menu suppressed.

### v24 - Click fix

- Short canvas clicks send mouse move, press, release, and click events to SageTV.

### v23 - Remote keys

- Added long-click/touch navigation overlay and media key buttons.

### v22 - Media trace

- Added media command parser/stub player.
- Traces OPENURL, PLAY, PAUSE, PUSHBUFFER, FLUSH, SEEK, and SETVIDEORECT.

### v21 - SageMC fixes

- Corrected Sage command IDs.
- Changed renderer capabilities for SageMC/custom STVs.
- Disabled surfaces and hires surfaces.

### v20 - GUI performance

- Batches GFX draw commands between STARTFRAME and FLIPBUFFER.
- Reduced browser log spam and capped log size.

### v19 - SET_PROPERTY fix

- Fixed SET_PROPERTY decoding.
- Honored `ADVANCED_IMAGE_CACHING=FALSE`.
- Added GFX packet trace.

### v18 and earlier

- Initial pure Python + HTML5 GUI starter.
- Basic MiniClient socket handshake.
- Initial GFX parser and browser canvas renderer.

### v87 - Player-aware settings UI
- Organized the settings panel around the selected Player and Source.
- Hidden settings that do not apply to the active player instead of merely disabling them.
- hls.js, Video.js, and MSE modes each show only the HLS/MSE/FFmpeg controls they actually use.
- Source-specific path/fill controls now hide when the selected Source does not use them.

### v137 - Android transparent long-press OSD

- Reworked the long-press remote overlay to match the Android MiniClient OSD style more closely.
- Removed the dark full-screen modal/card background. Controls are transparent/floating over the SageTV screen.
- Added the Android-style left menu rail, floating D-pad, top-right Info/REC/Help/Close, right-side page controls, bottom media transport, bottom display controls, app shortcuts, optional number pad, and keyboard helper.
- Kept raw IR remote delivery from v136, SageMC mouse fixes, mouse Back mapping, and SageX lookup/timeline support.


## v138
- Removed the colored Android-style bottom shortcut icons from the long-press OSD.
- Removed the left-side TV / Videos / Music / Photos / Search / Online / Setup / Exit text rail from the transparent long-press OSD.
- Kept the remaining transparent Android-style controls.


## v139
- Replaced the remaining long-press OSD glyph buttons with transparent image-based controls cropped from the Android MiniClient layout reference.
- Added transparent PNG assets for Home, Help/Close, D-pad, Keyboard, right rail, media transport, and display controls.
- Added invisible command hotspots over each image so the buttons still send the correct SageTV commands.


## v141
- Switched the long-press OSD icon font from Material Symbols to Material Icons Outlined.
- Enabled ligature rendering so icon names do not appear as literal text like `_OUTLINE`.
- Adjusted the D-pad arrow icons and center OK icon to better match the Android MiniClient look.


## v142
- Changed the long-press OSD buttons to use the same SageTV command path as the regular remote keys instead of remote/IR-style delivery.
- Moved Home, Help, Close, and the right-side Exit/Page controls farther outward to reduce overlap with the underlying UI.
- Added semi-transparent shaded backgrounds to the D-pad/top controls and matching panel shading for the right rail and bottom button groups.
- Replaced the center OK icon with a filled dot for a closer Android MiniClient look.


## v143
- Tightened the D-pad top row and directional pad buttons so they touch with no visible spacing.
- Tightened the right-side button rail so the buttons stack without gaps.
- Switched the D-pad arrows to closer Material arrow icons (`expand_less`, `expand_more`, `chevron_left`, `chevron_right`).
- Switched the right-side up/down icons to arrow-style icons for a closer MiniClient look.


## v144
- Restored the right-side page up/page down icon style to the prior look.
- Rebuilt the left D-pad as a tight grid so the top row and directional buttons touch with no visible spacing.
- Made the left-side directional buttons equal size for a closer Android MiniClient layout match.
- Kept the corrected left-side arrow icons while leaving the right-side rail icons reverted.


## v145
- Added an **OSD Trigger** dropdown in the Connection settings.
- Available trigger modes: **Left double click**, **Left long click**, **Right double click**, **Right long click**, and **Center click**.
- Left long click remains the default and preserves the previous behavior.
- Right-click OSD trigger modes suppress the browser context menu on the SageTV canvas.
- Center click maps to the mouse middle/wheel button.


## v146
- Added a local render-only fullscreen toggle to the Android-style OSD display controls.
- The fullscreen button now uses the provided fullscreen icon image.
- Toggling fullscreen hides the surrounding web UI and leaves only the render window visible from the top-left corner.
- Press Esc to exit render-only fullscreen mode.

## v147
- Removed the uploaded fullscreen image asset from the OSD.
- Uses the existing open-with / four-arrow Material icon for the local render-only view toggle.
- The local render-only toggle no longer calls the browser Fullscreen API.
- The normal SageTV Full Screen command button remains available separately.


## v148
- Fixed Android-style OSD positioning after entering or exiting render-only mode.
- The OSD is now re-centered over the SageTV render canvas after mode changes, on window resize, and on scroll.
- This fixes the case where the overlay stayed at the old fullscreen-size position after exiting render-only mode.

## v149
- Fixed client-setting persistence for OSD Trigger. The server-side whitelist now allows `osdTriggerMode` to be saved in `client_settings/<client_id>/settings.json`.
- Added missing client-setting whitelist entries for mouse options and QSV options so those settings save per client too.
- Added `Fullscreen on connect` as a client/user setting.
- `Fullscreen on connect` enters local render-only view after connect, without requesting browser fullscreen.

## v150
- Changed the default Audio Sync setting to `0ms`.
