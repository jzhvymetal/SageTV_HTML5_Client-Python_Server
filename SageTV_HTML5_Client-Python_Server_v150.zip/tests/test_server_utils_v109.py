from app.sagetv_server import normalize_server_host, parse_miniclient_server, SAGETV_MINICLIENT_PORT
from app.sagetv_session import parse_media_detail_current_file, parse_server


def test_server_host_normalization_stays_miniclient_only():
    assert normalize_server_host("http://sagetv.local:8080/sage/Home") == "sagetv.local"
    assert parse_miniclient_server("sagetv.local:42024") == ("sagetv.local", SAGETV_MINICLIENT_PORT)
    assert parse_server("192.168.10.175:31099") == ("192.168.10.175", 31099)


def test_parse_media_file_detail_from_web_result():
    data = {
        "file_path": "/var/media/videos/movie.mp4",
        "format": "Quicktime[H.264/480x360@25fps, AAC]",
    }
    detail = parse_media_detail_current_file(data)
    assert detail["file_path"] == "/var/media/videos/movie.mp4"
    assert "/var/media/videos/movie.mp4" in detail["file_candidates"]
    assert detail["format_hint"]["container"] == "Quicktime"
