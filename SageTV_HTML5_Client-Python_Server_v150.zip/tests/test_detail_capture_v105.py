from app.sagetv_session import parse_sagetv_detail_text_lines, guess_sage_storage_root


def test_parse_video_detail_file_and_format_from_wrapped_lines():
    lines = [
        'Video Detail',
        '[kisscartoon.io]-The-Octonauts-Season-01-Episode-002-',
        'undersea-storm',
        'Date / Duration:',
        'Friday, June 2, 2017',
        '11 minutes',
        'Language: und',
        'File: [/var/media/videos/KID_CARTOON/Octonauts/Season',
        '01/[kisscartoon.io]-The-Octonauts-Season-01-',
        'Episode-002-undersea-storm.mp4]',
        'Format: Quicktime[H.264/380Kbps 4:3 480x360@25fps,',
        'AAC@44.1kHz Stereo und]',
        'File Size: 39.72 MB',
    ]
    detail = parse_sagetv_detail_text_lines(lines)
    assert detail['file_path'] == '/var/media/videos/KID_CARTOON/Octonauts/Season 01/[kisscartoon.io]-The-Octonauts-Season-01-Episode-002-undersea-storm.mp4'
    assert detail['format'].startswith('Quicktime[H.264/380Kbps')
    assert detail['format_hint']['container'] == 'Quicktime'
    assert detail['format_hint']['height'] == 360
    assert detail['format_hint']['fps'] == 25.0


def test_guess_sage_storage_root_prefers_var_media_library_root():
    assert guess_sage_storage_root('/var/media/videos/KID_CARTOON/file.mp4') == '/var/media/videos'
    assert guess_sage_storage_root('/var/media/tv/60Minutes.ts') == '/var/media/tv'
