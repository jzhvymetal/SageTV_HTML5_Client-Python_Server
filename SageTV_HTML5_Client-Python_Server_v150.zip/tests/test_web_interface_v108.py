from app.web_interface import normalize_web_base, parse_detail_html, parse_playlist_urls, mediafile_ids_from_text


def test_normalize_web_base_defaults_to_host_8080():
    assert normalize_web_base('', '192.168.10.175') == 'http://192.168.10.175:8080'
    assert normalize_web_base('192.168.10.175:8180', 'x') == 'http://192.168.10.175:8180'


def test_parse_web_interface_detail_page_file_format_and_ids():
    html = '''
    <html><body>
    File Format: MPEG2-TS[MPEG2-VIDEO 16:9 1080i@30fps, Dolby Digital]
    <br>Files:<br>/var/media/tv/TheBigBangTheory-TheHeliumInsufficiency-64447085-0.ts<br>
    File Playlists: <a href="/sage/playlist?MediaFileID=64545689&type=m3u">m3u</a>
    <br>Internal details: MediaFileID=64545689 , AiringID=64447085
    </body></html>
    '''
    d = parse_detail_html(html, 'http://sagetv:8080/sage/DetailedInfo?MediaFileID=64545689')
    assert d['file_path'] == '/var/media/tv/TheBigBangTheory-TheHeliumInsufficiency-64447085-0.ts'
    assert d['media_file_id'] == '64545689'
    assert d['airing_id'] == '64447085'
    assert 'MPEG2-TS' in d['format']
    assert d['playlist_links'][0].startswith('http://sagetv:8080/')


def test_parse_m3u_and_pls_playlist_urls():
    assert parse_playlist_urls('#EXTM3U\nhttp://sagetv:8080/stream/64545689.ts\n') == ['http://sagetv:8080/stream/64545689.ts']
    assert parse_playlist_urls('[playlist]\nFile1=http://sagetv:8080/file.mp4\n') == ['http://sagetv:8080/file.mp4']


def test_mediafile_id_from_push_or_internal_details():
    assert mediafile_ids_from_text('push:f=AVI;mfid=12345;dur=1000') == ['12345']
    assert mediafile_ids_from_text('Internal details: MediaFileID=64545689, AiringID=1') == ['64545689']


def test_parse_web_interface_file_path_with_spaces():
    html = '\n    <html><body>\n    File Format: AVI[MPEG4-Video 512x384@25fps, MP3]\n    <br>Files:<br>/var/media/videos/KID_CARTOON_PL/Reksio/03. Reksio wychowawca.avi<br>\n    File Playlists: <a href="/sage/playlist?MediaFileID=123&type=m3u">m3u</a>\n    <br>Internal details: MediaFileID=123\n    </body></html>\n    '
    d = parse_detail_html(html, 'http://sagetv:8080/sage/DetailedInfo?MediaFileID=123')
    assert d['file_path'] == '/var/media/videos/KID_CARTOON_PL/Reksio/03. Reksio wychowawca.avi'
    assert d['file_candidates'] == ['/var/media/videos/KID_CARTOON_PL/Reksio/03. Reksio wychowawca.avi']


def test_parse_web_interface_percent_encoded_file_path_with_spaces():
    html = '\n    Files:<br>/var/media/videos/KID_CARTOON_PL/Reksio/03.%20Reksio%20wychowawca.avi<br>\n    Internal details: MediaFileID=123\n    '
    d = parse_detail_html(html, 'http://sagetv:8080/sage/DetailedInfo?MediaFileID=123')
    assert d['file_path'].endswith('/03. Reksio wychowawca.avi')


def test_parse_web_interface_streaming_playlist_anchor_text_without_playlist_word():
    html = '''
    <html><body>
    Files:<br>/var/media/videos/KID_CARTOON_PL/Reksio/01. Reksio poliglota.avi<br>
    Streaming Playlists: [<a href="/sage/stream?MediaFileId=123&type=m3u">m3u</a>] [<a href="/sage/stream?MediaFileId=123&type=pls">pls</a>]
    <br>Internal details: MediaFileID=123
    </body></html>
    '''
    d = parse_detail_html(html, 'http://sagetv:8080/sage/DetailedInfo?MediaFileId=123')
    assert len(d['playlist_links']) == 2
    assert d['playlist_links'][0] == 'http://sagetv:8080/sage/stream?MediaFileId=123&type=m3u'


def test_parse_web_interface_watch_streamed_anchor_as_web_media_url():
    html = '''
    <html><body>
    <a href="/sage/stream/123">Watch (Streamed)</a>
    <br>Files:<br>/var/media/videos/test.avi<br>
    <br>Internal details: MediaFileID=123
    </body></html>
    '''
    d = parse_detail_html(html, 'http://sagetv:8080/sage/DetailedInfo?MediaFileId=123')
    assert 'http://sagetv:8080/sage/stream/123' in d['web_media_urls']


def test_parse_web_interface_unquoted_playlist_links_with_brackets():
    html = '''
    <html><body>
    File Format: AVI[MPEG4-Video 336x256@25fps, MP3]
    <br>Files:<br>/var/media/videos/KID_CARTOON_PL/Reksio/01. Reksio poliglota.avi<br>
    File Playlists: [<a href=/sage/MediaFile?MediaFileId=123&Format=m3u>m3u</a>] [<a href=/sage/MediaFile?MediaFileId=123&Format=pls>pls</a>]
    Streaming Playlists: [<a href=/sage/MediaFile?MediaFileId=123&Format=m3u&Transcode=true>[m3u]</a>]
    <br>Internal details: MediaFileID=123 , AiringID=456
    </body></html>
    '''
    d = parse_detail_html(html, 'http://sagetv:8080/sage/DetailedInfo?MediaFileId=123')
    assert d['media_file_id'] == '123'
    assert d['airing_id'] == '456'
    assert 'http://sagetv:8080/sage/MediaFile?MediaFileId=123&Format=m3u' in d['playlist_links']
    assert 'http://sagetv:8080/sage/MediaFile?MediaFileId=123&Format=m3u&Transcode=true' in d['playlist_links']


def test_parse_playlist_ignores_local_files_but_keeps_relative_web_urls():
    body = '''#EXTM3U
/var/media/videos/KID_CARTOON_PL/Reksio/01. Reksio poliglota.avi
/sage/MediaFile?MediaFileId=123&Segment=0
'''
    assert parse_playlist_urls(body, 'http://sagetv:8080/sage/playlist?x=1') == ['http://sagetv:8080/sage/MediaFile?MediaFileId=123&Segment=0']
