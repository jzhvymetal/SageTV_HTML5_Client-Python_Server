from app.sagex_api import normalize_sagex_base, extract_paths_from_sagex_response, extract_first_int


def test_normalize_sagex_base_accepts_host_port_and_endpoint():
    assert normalize_sagex_base('', '192.168.10.175') == 'http://192.168.10.175:8080'
    assert normalize_sagex_base('192.168.10.175:8080/sagex/api', 'x') == 'http://192.168.10.175:8080/sagex/api'
    assert normalize_sagex_base('http://sagetv:8080/sagex', 'x') == 'http://sagetv:8080/sagex'


def test_extract_paths_from_sagex_json_or_xml_response():
    body = '{"Result":"/var/media/videos/KID_CARTOON_PL/Reksio/01. Reksio poliglota.avi"}'
    assert extract_paths_from_sagex_response(body) == ['/var/media/videos/KID_CARTOON_PL/Reksio/01. Reksio poliglota.avi']
    xml = '<Result>C:\\\\Videos\\\\Movie File.mkv</Result>'
    paths = extract_paths_from_sagex_response(xml)
    assert paths[0] == 'C:\\Videos\\Movie File.mkv'


def test_extract_first_int_for_sagex_timeline():
    assert extract_first_int('12345') == 12345
    assert extract_first_int('<Result>67890</Result>') == 67890
    assert extract_first_int('{"RawMediaTime": 25000}') == 25000
