
from app import main

def test_client_settings_whitelist_contains_recent_client_options():
    required = {
        "qsvDecodeMode",
        "qsvFilterMode",
        "mouseClickMode",
        "guideMouseOkAssist",
        "mouseBackButtonSageBack",
        "osdTriggerMode",
        "fullscreenOnConnect",
    }
    assert required.issubset(main.CLIENT_SETTING_IDS)
