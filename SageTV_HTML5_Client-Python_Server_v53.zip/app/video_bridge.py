import asyncio
import os
import shutil
import signal
import subprocess
import time
import re
from dataclasses import dataclass, field
from collections import deque
from pathlib import Path
from typing import Optional


ROOT = Path(__file__).resolve().parent.parent
RUNTIME_HLS = ROOT / "runtime_hls"


def find_executable(name: str) -> Optional[str]:
    env_name = "FFMPEG" if name.lower().startswith("ffmpeg") else "FFPROBE"
    env_path = os.environ.get(env_name)
    if env_path and Path(env_path).exists():
        return env_path

    exe = f"{name}.exe" if os.name == "nt" and not name.endswith(".exe") else name
    candidates = [
        ROOT / "tools" / "ffmpeg" / "bin" / exe,
        ROOT / "tools" / "ffmpeg" / exe,
    ]
    for c in candidates:
        if c.exists():
            return str(c)

    # Common extracted gyan.dev layout: tools/ffmpeg/ffmpeg-*-essentials_build/bin/ffmpeg.exe
    for c in (ROOT / "tools" / "ffmpeg").glob("**/bin/" + exe):
        if c.exists():
            return str(c)

    found = shutil.which(name)
    return found


def list_ffmpeg_encoders(ffmpeg: str) -> str:
    try:
        p = subprocess.run([ffmpeg, "-hide_banner", "-encoders"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=8)
        return p.stdout or ""
    except Exception:
        return ""


def normalize_encoder_name(requested: str) -> str:
    """Normalize browser/env encoder names.

    FFmpeg encoder names are lowercase.  This also lets users type common aliases
    such as h264_NVenc, nvenc, qsv, or nvidia.
    """
    enc = (requested or "auto").strip().lower().replace("-", "_")
    aliases = {
        "x264": "libx264",
        "software": "libx264",
        "intel": "h264_qsv",
        "qsv": "h264_qsv",
        "quick_sync": "h264_qsv",
        "quicksync": "h264_qsv",
        "nvidia": "h264_nvenc",
        "nvenc": "h264_nvenc",
        "h264_nvenc_safe": "h264_nvenc",
        "h264_nvenc_compat": "h264_nvenc",
        "nvenc_safe": "h264_nvenc",
        "nvenc_compat": "h264_nvenc",
        "nvenc_ll": "h264_nvenc_ll",
        "nvidia_ll": "h264_nvenc_ll",
        "h264_nvenc_bare": "h264_nvenc_bare",
        "nvenc_bare": "h264_nvenc_bare",
        "nvidia_bare": "h264_nvenc_bare",
        "h264_nvenc_cuda": "h264_nvenc_cuda",
        "nvenc_cuda": "h264_nvenc_cuda",
        "nvidia_cuda": "h264_nvenc_cuda",
        "amd": "h264_amf",
        "amf": "h264_amf",
    }
    return aliases.get(enc, enc or "auto")


def ffmpeg_encoder_name(encoder: str) -> str:
    enc = normalize_encoder_name(encoder)
    if enc in ("h264_nvenc_ll", "h264_nvenc_bare", "h264_nvenc_cuda"):
        return "h264_nvenc"
    return enc


def choose_encoder(ffmpeg: str, requested: str = "auto") -> str:
    requested_norm = normalize_encoder_name(requested)
    encoders = list_ffmpeg_encoders(ffmpeg)
    if requested_norm and requested_norm != "auto":
        actual = ffmpeg_encoder_name(requested_norm)
        # If the FFmpeg build clearly does not expose the requested hardware
        # encoder, fall back to x264 instead of starting a doomed FFmpeg process.
        if encoders and actual != "libx264" and actual not in encoders:
            return "libx264"
        return requested_norm
    # Keep auto conservative. libx264 is still the most compatible first choice
    # for this MiniClient pipeline. Hardware can be selected explicitly.
    for enc in ("libx264", "h264_qsv", "h264_nvenc", "h264_amf"):
        if not encoders or enc in encoders:
            return enc
    return "libx264"


def encoder_args(encoder: str) -> list[str]:
    encoder = normalize_encoder_name(encoder)
    if encoder == "libx264":
        return [
            "-c:v", "libx264",
            "-preset", os.environ.get("SAGEWEB_X264_PRESET", "ultrafast"),
            "-tune", "zerolatency",
            "-x264-params", os.environ.get("SAGEWEB_X264_PARAMS", "keyint=60:min-keyint=60:scenecut=0"),
            "-sc_threshold", "0",
        ]
    if encoder == "h264_nvenc":
        # Conservative NVIDIA path for workstation cards such as RTX A2000.
        # Avoid p1..p7 and tune options first because they are driver/API sensitive.
        return [
            "-c:v", "h264_nvenc",
            "-preset", os.environ.get("SAGEWEB_NVENC_PRESET", "default"),
            "-bf", "0",
        ]
    if encoder == "h264_nvenc_bare":
        # Absolute minimum NVENC path.  Use this if the safe/LL profiles fail.
        # The normal -b:v/-g options are still applied later by build_command.
        return ["-c:v", "h264_nvenc"]
    if encoder == "h264_nvenc_cuda":
        # CPU decode/filter, then explicit CUDA upload before NVENC.  Useful on
        # systems where implicit upload fails with NVIDIA but QSV/x264 work.
        return [
            "-c:v", "h264_nvenc",
            "-preset", os.environ.get("SAGEWEB_NVENC_PRESET", "default"),
            "-bf", "0",
        ]
    if encoder == "h264_nvenc_ll":
        # Optional low-latency NVENC path. Use only after the safe/bare profiles work.
        return [
            "-c:v", "h264_nvenc",
            "-preset", os.environ.get("SAGEWEB_NVENC_LL_PRESET", "llhq"),
            "-bf", "0",
        ]
    if encoder == "h264_qsv":
        return ["-c:v", "h264_qsv", "-preset", os.environ.get("SAGEWEB_QSV_PRESET", "veryfast")]
    if encoder == "h264_amf":
        return ["-c:v", "h264_amf", "-quality", os.environ.get("SAGEWEB_AMF_QUALITY", "speed"), "-bf", "0"]
    return ["-c:v", encoder]


def _bitrate_to_kbps(text: str) -> int:
    t = str(text or "").strip().lower()
    if not t:
        return 0
    try:
        if t.endswith("m"):
            return int(float(t[:-1]) * 1000)
        if t.endswith("k"):
            return int(float(t[:-1]))
        return int(float(t))
    except Exception:
        return 0


def _kbps_to_bitrate(kbps: int) -> str:
    kbps = max(100, int(kbps))
    return f"{kbps}k"




def audio_sync_filter(offset_ms: int) -> str:
    """Return an FFmpeg audio filter that keeps audio/video aligned.

    Positive values delay audio. Negative values advance audio by trimming the
    beginning. The aresample async value lets FFmpeg stretch/drop tiny amounts
    to follow the video clock instead of drifting on long MPEG-TS captures.
    """
    try:
        offset = int(offset_ms or 0)
    except Exception:
        offset = 0
    base = "aresample=async=1000:first_pts=0"
    if offset > 0:
        return f"{base},adelay={offset}|{offset},asetpts=PTS-STARTPTS"
    if offset < 0:
        sec = abs(offset) / 1000.0
        return f"{base},atrim=start={sec:.3f},asetpts=PTS-STARTPTS"
    return base

def source_bitrate_from_url(media_url: str) -> int:
    """Return source bitrate from SageTV push URL as kbps, if present."""
    m = re.search(r"(?:^|;)br=(\d+)", media_url or "", re.IGNORECASE)
    if not m:
        return 0
    # SageTV reports br in bits/second. FFmpeg wants kbits/second when using k suffix.
    return max(100, int(int(m.group(1)) / 1000))


def auto_bitrate_for_height(max_height: int, media_url: str = "") -> str:
    src = source_bitrate_from_url(media_url)
    h = int(max_height or 0)
    if h <= 0:
        return _kbps_to_bitrate(src or 3500)
    if h <= 240:
        return "500k"
    if h <= 360:
        return "900k"
    if h <= 480:
        return "1600k"
    if h <= 576:
        return "2200k"
    if h <= 720:
        return "3000k"
    if h <= 1080:
        # Do not exceed source bitrate by much when known.
        return _kbps_to_bitrate(min(max(src, 4500), 6500) if src else 6000)
    return _kbps_to_bitrate(src or 8000)


def resolve_video_bitrate(choice: str, max_height: int, media_url: str = "") -> str:
    c = str(choice or "source").strip().lower()
    if c in ("source", "src", "original", "native"):
        src = source_bitrate_from_url(media_url)
        return _kbps_to_bitrate(src) if src else auto_bitrate_for_height(max_height, media_url)
    if c in ("auto", "adaptive"):
        return auto_bitrate_for_height(max_height, media_url)
    if c.endswith(("k", "m")):
        return c
    try:
        int(c)
        return c + "k"
    except Exception:
        return auto_bitrate_for_height(max_height, media_url)


@dataclass
class VideoBridgeStatus:
    running: bool = False
    encoder: str = ""
    playlist_url: str = ""
    playlist_path: str = ""
    bytes_in: int = 0
    chunks_in: int = 0
    restarts: int = 0
    last_error: str = ""
    ffmpeg_log_tail: str = ""
    playlist_ready: bool = False
    segments: int = 0
    command_line: str = ""
    capture_path: str = ""
    exited_returncode: str = ""
    audio_enabled: bool = True
    audio_offset_ms: int = 0
    pts_mode: str = ""
    queued_chunks: int = 0
    queued_bytes_est: int = 0
    fallback_reason: str = ""
    ts_sync_state: str = ""
    ts_sync_bytes: int = 0
    requested_max_height: str = ""
    requested_bitrate: str = "source"
    effective_bitrate: str = ""
    hls_mode: str = "stable"
    hls_delete_threshold: int = 24
    capture_enabled: bool = False
    player_mode: str = "mseav"
    mse_mime: str = "video/mp4; codecs=\"avc1.4D4028, mp4a.40.2\""
    mse_video_url: str = ""
    mse_audio_url: str = ""
    mse_video_mime: str = "video/mp4; codecs=\"avc1.4D4028\""
    mse_audio_mime: str = "audio/mp4; codecs=\"mp4a.40.2\""
    mse_av_sync_mode: str = ""
    mse_bytes_out: int = 0
    mse_chunks_out: int = 0
    mse_restarts: int = 0
    backpressure_events: int = 0
    dropped_input_chunks: int = 0

    def to_json(self) -> dict:
        return {
            "running": self.running,
            "encoder": self.encoder,
            "playlist_url": self.playlist_url,
            "playlist_path": self.playlist_path,
            "bytes_in": self.bytes_in,
            "chunks_in": self.chunks_in,
            "restarts": self.restarts,
            "last_error": self.last_error,
            "ffmpeg_log_tail": self.ffmpeg_log_tail[-2400:],
            "playlist_ready": self.playlist_ready,
            "segments": self.segments,
            "command_line": self.command_line[-2400:],
            "capture_path": self.capture_path,
            "exited_returncode": self.exited_returncode,
            "audio_enabled": self.audio_enabled,
            "audio_offset_ms": self.audio_offset_ms,
            "pts_mode": self.pts_mode,
            "queued_chunks": self.queued_chunks,
            "queued_bytes_est": self.queued_bytes_est,
            "fallback_reason": self.fallback_reason,
            "ts_sync_state": self.ts_sync_state,
            "ts_sync_bytes": self.ts_sync_bytes,
            "requested_max_height": self.requested_max_height,
            "requested_bitrate": self.requested_bitrate,
            "effective_bitrate": self.effective_bitrate,
            "hls_mode": self.hls_mode,
            "hls_delete_threshold": self.hls_delete_threshold,
            "capture_enabled": self.capture_enabled,
            "player_mode": self.player_mode,
            "mse_mime": self.mse_mime,
            "mse_video_url": self.mse_video_url,
            "mse_audio_url": self.mse_audio_url,
            "mse_video_mime": self.mse_video_mime,
            "mse_audio_mime": self.mse_audio_mime,
            "mse_av_sync_mode": self.mse_av_sync_mode,
            "mse_bytes_out": self.mse_bytes_out,
            "mse_chunks_out": self.mse_chunks_out,
            "mse_restarts": self.mse_restarts,
            "backpressure_events": self.backpressure_events,
            "dropped_input_chunks": self.dropped_input_chunks,
        }


@dataclass
class FfmpegHlsBridge:
    session_id: str
    encoder_request: str = "libx264"
    max_height: int = 0
    video_bitrate: str = "source"
    audio_bitrate: str = "160k"
    audio_offset_ms: int = 0
    hls_time: float = 2.0
    hls_list_size: int = 36
    hls_mode: str = "stable"
    hls_delete_threshold: int = 36
    capture_push_stream: bool = False
    player_mode: str = "mseav"
    queue_size: int = 768
    startup_fallback_seconds: float = 16.0
    prebuffer_limit: int = 10 * 1024 * 1024
    video_only_mode: bool = False
    media_url: str = ""
    status: VideoBridgeStatus = field(default_factory=VideoBridgeStatus)

    process: Optional[asyncio.subprocess.Process] = None
    writer_task: Optional[asyncio.Task] = None
    stderr_task: Optional[asyncio.Task] = None
    stdout_task: Optional[asyncio.Task] = None
    monitor_task: Optional[asyncio.Task] = None
    queue: Optional[asyncio.Queue] = None
    mse_queue: Optional[asyncio.Queue] = None
    output_dir: Optional[Path] = None
    log_lines: list[str] = field(default_factory=list)
    prebuffer_chunks: deque = field(default_factory=deque)
    prebuffer_bytes: int = 0
    ts_started: bool = False
    ts_sync_buffer: bytes = b""
    restart_lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    capture_file = None

    @property
    def ffmpeg_path(self) -> str:
        ffmpeg = find_executable("ffmpeg")
        if not ffmpeg:
            raise FileNotFoundError("ffmpeg was not found. Put ffmpeg.exe in tools/ffmpeg/bin or set FFMPEG.")
        return ffmpeg



    def normalize_hls_mode(self) -> str:
        mode = str(self.hls_mode or os.environ.get("SAGEWEB_HLS_MODE", "rolling")).strip().lower()
        if mode in ("debug", "keep", "keep_all", "keepall"):
            return "debug"
        if mode in ("rolling", "delete", "delete_segments"):
            return "rolling"
        # v45 default: keep segments for the current playback session so hls.js
        # never has the active segment deleted underneath it. The whole session
        # folder is still removed on STOP/DEINIT/disconnect/new video.
        return "stable"


    def normalize_player_mode(self) -> str:
        mode = str(self.player_mode or os.environ.get("SAGEWEB_PLAYER_MODE", "mseav")).strip().lower()
        if mode in ("mseav", "mse-av", "mse_sep", "mse-sep", "separate", "separate_av", "split"):
            return "mseav"
        if mode in ("mse", "mse-fmp4", "fmp4", "mp4", "direct"):
            return "mse"
        return "hls"

    def mse_mime_for_encoder(self, encoder: str) -> str:
        # Combined fMP4 mode: audio and video in one SourceBuffer.
        return os.environ.get("SAGEWEB_MSE_MIME", 'video/mp4; codecs="avc1.4D4028, mp4a.40.2"')

    def mse_video_mime_for_encoder(self, encoder: str) -> str:
        return os.environ.get("SAGEWEB_MSE_VIDEO_MIME", 'video/mp4; codecs="avc1.4D4028"')

    def mse_audio_mime(self) -> str:
        return os.environ.get("SAGEWEB_MSE_AUDIO_MIME", 'audio/mp4; codecs="mp4a.40.2"')

    def refresh_ready_state(self) -> bool:
        if self.normalize_player_mode() in ("mse", "mseav"):
            # There is no playlist in MSE mode. Treat the stream as ready as
            # soon as FFmpeg is running; the browser fetch waits for fMP4 bytes.
            ready = bool(self.status.running)
            self.status.playlist_ready = ready
            self.status.segments = 0
            return ready
        if not self.output_dir:
            self.status.playlist_ready = False
            self.status.segments = 0
            return False
        playlist = self.output_dir / "stream.m3u8"
        segs = sorted(self.output_dir.glob("seg_*.ts"))
        self.status.segments = len(segs)
        try:
            txt = playlist.read_text(encoding="utf-8", errors="replace")
            ready = "#EXTM3U" in txt and len(segs) > 0
        except Exception:
            ready = False
        self.status.playlist_ready = ready
        return ready

    def input_format_args(self) -> list[str]:
        forced = os.environ.get("SAGEWEB_INPUT_FORMAT", "").strip()
        if forced:
            return ["-f", forced]
        u = (self.media_url or "").upper()
        if "F=MPEG2-TS" in u or "F=MPEGTS" in u:
            return ["-f", "mpegts"]
        if "F=MPEG2-PS" in u or "F=MPEG1-PS" in u:
            return ["-f", "mpeg"]
        # Unknown or non-TS stream. Let FFmpeg probe instead of forcing MPEG-TS.
        return []


    def build_command(self, ffmpeg: str, out_dir: Path, encoder: str) -> list[str]:
        player_mode = self.normalize_player_mode()
        playlist = out_dir / "stream.m3u8"
        seg_pattern = out_dir / "seg_%05d.ts"
        effective_bitrate = resolve_video_bitrate(self.video_bitrate, self.max_height, self.media_url)
        br_kbps = _bitrate_to_kbps(effective_bitrate)
        maxrate = os.environ.get("SAGEWEB_VIDEO_MAXRATE") or _kbps_to_bitrate(int(br_kbps * 1.25) if br_kbps else 3600)
        bufsize = os.environ.get("SAGEWEB_VIDEO_BUFSIZE") or _kbps_to_bitrate(int(br_kbps * 2.0) if br_kbps else 6000)
        self.status.requested_max_height = "source" if not self.max_height else str(self.max_height)
        self.status.requested_bitrate = str(self.video_bitrate)
        self.status.effective_bitrate = effective_bitrate
        self.status.audio_offset_ms = int(self.audio_offset_ms or 0)
        self.status.pts_mode = os.environ.get("SAGEWEB_MSE_PTS_MODE", "start").strip().lower()

        filters: list[str] = []
        enc_norm = normalize_encoder_name(encoder)
        deint = os.environ.get("SAGEWEB_DEINTERLACE", "yadif=0:-1:0")
        if deint:
            filters.append(deint)
        if self.max_height and self.max_height > 0:
            filters.append(f"scale=-2:{int(self.max_height)}")
        pts_mode = os.environ.get("SAGEWEB_MSE_PTS_MODE", "start").strip().lower()
        if player_mode in ("mse", "mseav"):
            if pts_mode in ("rebuild", "steady", "frame"):
                # Rebuild timestamps from decoded frame order. This can help with
                # badly discontinuous captures, but may drift audio on some files.
                filters.append("setpts=N/FRAME_RATE/TB")
            elif pts_mode not in ("keep", "passthrough", "source"):
                # Default MSE behavior: preserve the stream cadence but make timestamps start
                # at zero so fMP4/MSE and AAC start from the same clock.
                filters.append("setpts=PTS-STARTPTS")
        if enc_norm == "h264_nvenc_cuda":
            filters.append("format=nv12")
            filters.append("hwupload_cuda")
        elif enc_norm.startswith("h264_nvenc"):
            filters.append("format=nv12")
        else:
            filters.append("format=yuv420p")
        vf = ["-vf", ",".join(f for f in filters if f)]

        audio_enabled = not self.video_only_mode
        cmd = [
            ffmpeg,
            "-hide_banner",
            "-loglevel", os.environ.get("SAGEWEB_FFMPEG_LOGLEVEL", "info"),
            "-nostats",
            "-y",
            "-fflags", "+genpts+discardcorrupt",
            "-err_detect", "ignore_err",
            "-analyzeduration", os.environ.get("SAGEWEB_ANALYZE_DURATION", "2000000"),
            "-probesize", os.environ.get("SAGEWEB_PROBE_SIZE", "2000000"),
            *self.input_format_args(),
            "-i", "pipe:0",
            "-map", "0:v:0",
        ]
        if audio_enabled:
            cmd += ["-map", "0:a:0?"]
        cmd += ["-sn", "-dn", *vf, *encoder_args(encoder)]

        # MSE/fMP4 is pickier than HLS. Keep a normal 2-second GOP and force a
        # widely-supported H.264 profile when using libx264. Hardware encoder
        # profile flags differ by vendor, so only set this for x264.
        if player_mode == "mse" and encoder == "libx264":
            cmd += ["-profile:v", os.environ.get("SAGEWEB_MSE_X264_PROFILE", "main"), "-level:v", os.environ.get("SAGEWEB_MSE_X264_LEVEL", "4.0")]

        cmd += [
            "-g", os.environ.get("SAGEWEB_GOP", "60"),
            "-keyint_min", os.environ.get("SAGEWEB_KEYINT_MIN", "60"),
            "-sc_threshold", "0",
            "-b:v", effective_bitrate,
            "-maxrate", maxrate,
            "-bufsize", bufsize,
        ]
        if audio_enabled:
            cmd += [
                "-af", audio_sync_filter(self.audio_offset_ms),
                "-c:a", "aac",
                "-ar", "48000",
                "-b:a", self.audio_bitrate,
                "-ac", "2",
            ]
        else:
            cmd += ["-an"]

        cmd += [
            "-max_muxing_queue_size", "2048",
            "-muxdelay", "0",
            "-muxpreload", "0",
            "-flush_packets", "1",
        ]

        if player_mode == "mseav":
            # Separate MSE A/V mode. FFmpeg writes two growing fragmented MP4
            # files. The browser opens two SourceBuffers and applies the audio
            # sync offset on the player side using timestampOffset.
            movflags = os.environ.get("SAGEWEB_MSE_MOVFLAGS", "frag_keyframe+empty_moov+default_base_moof+separate_moof+omit_tfhd_offset")
            frag_duration = os.environ.get("SAGEWEB_MSE_FRAG_DURATION", "2000000")
            video_path = out_dir / "video.mp4"
            audio_path = out_dir / "audio.mp4"
            sep = [
                ffmpeg,
                "-hide_banner",
                "-loglevel", os.environ.get("SAGEWEB_FFMPEG_LOGLEVEL", "info"),
                "-nostats",
                "-fflags", "+genpts+discardcorrupt",
                "-err_detect", "ignore_err",
                "-analyzeduration", os.environ.get("SAGEWEB_ANALYZE_DURATION", "2000000"),
                "-probesize", os.environ.get("SAGEWEB_PROBE_SIZE", "2000000"),
                *self.input_format_args(),
                "-i", "pipe:0",
                "-map", "0:v:0",
                "-sn", "-dn",
                *vf, *encoder_args(encoder),
            ]
            if encoder == "libx264":
                sep += ["-profile:v", os.environ.get("SAGEWEB_MSE_X264_PROFILE", "main"), "-level:v", os.environ.get("SAGEWEB_MSE_X264_LEVEL", "4.0")]
            sep += [
                "-g", os.environ.get("SAGEWEB_GOP", "60"),
                "-keyint_min", os.environ.get("SAGEWEB_KEYINT_MIN", "60"),
                "-sc_threshold", "0",
                "-b:v", effective_bitrate,
                "-maxrate", maxrate,
                "-bufsize", bufsize,
                "-an",
                "-fps_mode", os.environ.get("SAGEWEB_MSE_FPS_MODE", "cfr"),
                "-avoid_negative_ts", "make_zero",
                "-max_muxing_queue_size", "2048",
                "-muxdelay", "0",
                "-muxpreload", "0",
                "-flush_packets", "1",
                "-f", "mp4",
                "-movflags", movflags,
                "-frag_duration", frag_duration,
                str(video_path),
            ]
            if audio_enabled:
                sep += [
                    "-map", "0:a:0?",
                    "-vn",
                    # In separate-A/V mode sync is performed on the browser side.
                    # Keep audio timestamps normalized but do not apply adelay/atrim.
                    "-af", "aresample=async=1000:first_pts=0",
                    "-c:a", "aac",
                    "-ar", "48000",
                    "-b:a", self.audio_bitrate,
                    "-ac", "2",
                    "-avoid_negative_ts", "make_zero",
                    "-max_muxing_queue_size", "2048",
                    "-muxdelay", "0",
                    "-muxpreload", "0",
                    "-flush_packets", "1",
                    "-f", "mp4",
                    "-movflags", movflags,
                    "-frag_duration", frag_duration,
                    str(audio_path),
                ]
            return sep

        if player_mode == "mse":
            cmd += ["-fps_mode", os.environ.get("SAGEWEB_MSE_FPS_MODE", "cfr"), "-avoid_negative_ts", "make_zero"]
            # Direct browser streaming. No playlist and no .ts files. FFmpeg writes
            # fragmented MP4 to stdout, Python streams stdout to fetch()+MSE.
            cmd += [
                "-f", "mp4",
                "-movflags", os.environ.get("SAGEWEB_MSE_MOVFLAGS", "frag_keyframe+empty_moov+default_base_moof+separate_moof+omit_tfhd_offset"),
                "-frag_duration", os.environ.get("SAGEWEB_MSE_FRAG_DURATION", "2000000"),
                "pipe:1",
            ]
            return cmd

        cmd += [
            "-f", "hls",
            "-hls_time", str(os.environ.get("SAGEWEB_HLS_TIME", str(self.hls_time))),
            "-hls_segment_type", "mpegts",
        ]

        mode = self.normalize_hls_mode()
        if mode == "debug":
            cmd += [
                "-hls_list_size", "0",
                "-hls_playlist_type", "event",
                "-hls_flags", os.environ.get("SAGEWEB_HLS_FLAGS", "append_list+omit_endlist+independent_segments"),
            ]
        elif mode == "stable":
            cmd += [
                "-hls_list_size", "0",
                "-hls_playlist_type", "event",
                "-hls_flags", os.environ.get("SAGEWEB_HLS_FLAGS", "append_list+omit_endlist+independent_segments"),
            ]
        else:
            list_size = int(os.environ.get("SAGEWEB_HLS_LIST_SIZE", str(self.hls_list_size or 36)))
            delete_threshold = int(os.environ.get("SAGEWEB_HLS_DELETE_THRESHOLD", str(self.hls_delete_threshold or 36)))
            cmd += [
                "-hls_list_size", str(max(12, list_size)),
                "-hls_delete_threshold", str(max(6, delete_threshold)),
                "-hls_flags", os.environ.get("SAGEWEB_HLS_FLAGS", "delete_segments+omit_endlist+independent_segments"),
            ]

        cmd += [
            "-hls_segment_filename", str(seg_pattern),
            str(playlist),
        ]
        return cmd

    def _append_prebuffer(self, data: bytes):
        if not data:
            return
        self.prebuffer_chunks.append(data)
        self.prebuffer_bytes += len(data)
        while self.prebuffer_bytes > self.prebuffer_limit and self.prebuffer_chunks:
            old = self.prebuffer_chunks.popleft()
            self.prebuffer_bytes -= len(old)

    def _prebuffer_blob(self) -> bytes:
        if not self.prebuffer_chunks:
            return b""
        return b"".join(self.prebuffer_chunks)

    async def start(self, encoder_override: Optional[str] = None, refeed_prebuffer: bool = False, reason: str = "") -> str:
        async with self.restart_lock:
            await self.stop(remove_files=True, keep_prebuffer=True)
            RUNTIME_HLS.mkdir(parents=True, exist_ok=True)
            self.output_dir = RUNTIME_HLS / self.session_id
            self.output_dir.mkdir(parents=True, exist_ok=True)
            ffmpeg = self.ffmpeg_path
            encoder = encoder_override or choose_encoder(ffmpeg, self.encoder_request)
            cmd = self.build_command(ffmpeg, self.output_dir, encoder)
            self.log_lines.clear()
            self.ts_started = False
            self.ts_sync_buffer = b""
            player_mode = self.normalize_player_mode()
            q_size = self.queue_size
            if player_mode in ("mse", "mseav"):
                q_size = max(q_size, int(os.environ.get("SAGEWEB_MSE_INPUT_QUEUE_SIZE", "8192")))
            self.queue = asyncio.Queue(maxsize=q_size)
            self.mse_queue = asyncio.Queue(maxsize=int(os.environ.get("SAGEWEB_MSE_QUEUE_SIZE", "4096"))) if player_mode == "mse" else None
            rev = int(time.time())
            if player_mode == "mseav":
                stream_url = f"/mseav/{self.session_id}/video.mp4?rev={rev}"
                audio_url = f"/mseav/{self.session_id}/audio.mp4?rev={rev}"
            else:
                stream_url = (f"/mse/{self.session_id}/stream.mp4?rev={rev}" if player_mode == "mse" else f"/hls/{self.session_id}/stream.m3u8?rev={rev}")
                audio_url = ""
            self.status = VideoBridgeStatus(
                running=True,
                encoder=encoder,
                playlist_url=stream_url,
                playlist_path=("" if player_mode in ("mse", "mseav") else str(self.output_dir / "stream.m3u8")),
                restarts=self.status.restarts + 1,
                command_line=" ".join(str(x) for x in cmd),
                fallback_reason=reason,
                capture_path=str(self.output_dir / "push_capture.ts"),
                audio_enabled=not self.video_only_mode,
                audio_offset_ms=int(self.audio_offset_ms or 0),
                pts_mode=os.environ.get("SAGEWEB_MSE_PTS_MODE", "start").strip().lower(),
                requested_max_height="source" if not self.max_height else str(self.max_height),
                requested_bitrate=str(self.video_bitrate),
                effective_bitrate=resolve_video_bitrate(self.video_bitrate, self.max_height, self.media_url),
                hls_mode=self.normalize_hls_mode(),
                hls_delete_threshold=int(os.environ.get("SAGEWEB_HLS_DELETE_THRESHOLD", str(self.hls_delete_threshold or 24))),
                capture_enabled=bool(self.capture_push_stream or self.normalize_hls_mode() == "debug" or os.environ.get("SAGEWEB_CAPTURE_PUSH", "0").lower() in ("1", "true", "yes", "on")),
                player_mode=player_mode,
                mse_mime=self.mse_mime_for_encoder(encoder),
                mse_video_url=stream_url if player_mode == "mseav" else "",
                mse_audio_url=audio_url if player_mode == "mseav" else "",
                mse_video_mime=self.mse_video_mime_for_encoder(encoder),
                mse_audio_mime=self.mse_audio_mime(),
                mse_av_sync_mode=("player-side separate A/V" if player_mode == "mseav" else ""),
                playlist_ready=(player_mode in ("mse", "mseav")),
                mse_restarts=self.status.mse_restarts,
                backpressure_events=self.status.backpressure_events,
                dropped_input_chunks=self.status.dropped_input_chunks,
            )
            creationflags = 0
            if os.name == "nt":
                creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            self.process = await asyncio.create_subprocess_exec(
                *cmd,
                stdin=asyncio.subprocess.PIPE,
                stdout=(asyncio.subprocess.PIPE if player_mode == "mse" else asyncio.subprocess.DEVNULL),
                stderr=asyncio.subprocess.PIPE,
                creationflags=creationflags,
            )
            self.writer_task = asyncio.create_task(self._writer_loop(), name=f"ffmpeg-writer-{self.session_id}")
            self.stderr_task = asyncio.create_task(self._stderr_loop(), name=f"ffmpeg-stderr-{self.session_id}")
            if player_mode == "mse":
                self.stdout_task = asyncio.create_task(self._stdout_loop(), name=f"ffmpeg-stdout-{self.session_id}")
            else:
                self.stdout_task = None
            self.monitor_task = asyncio.create_task(self._startup_monitor_loop(), name=f"ffmpeg-monitor-{self.session_id}")
            if refeed_prebuffer:
                blob = self._prebuffer_blob()
                if blob:
                    try:
                        # Schedule the aligned prebuffer feed outside the lock so startup cannot deadlock.
                        asyncio.create_task(self.write(blob), name=f"ffmpeg-refeed-{self.session_id}")
                        self.status.fallback_reason = (reason + f"; queued {len(blob)} bytes of SageTV TS prebuffer for aligned re-feed").strip("; ")
                    except Exception as exc:
                        self.status.last_error = f"could not queue prebuffer after restart: {exc}"
            return self.status.playlist_url

    async def stop(self, remove_files: bool = False, keep_prebuffer: bool = False):
        if self.queue:
            try:
                self.queue.put_nowait(None)
            except Exception:
                pass
        current = asyncio.current_task()
        if self.mse_queue:
            try:
                self.mse_queue.put_nowait(None)
            except Exception:
                pass
        for task in (self.writer_task, self.stderr_task, self.stdout_task, self.monitor_task):
            # Important: startup monitor can call start()->stop() to fall back from
            # a stalled hardware encoder.  Do not cancel the task that is currently
            # performing the fallback or the fallback never completes.
            if task and task is not current and not task.done():
                task.cancel()
        self.writer_task = None
        self.stderr_task = None
        self.stdout_task = None
        self.monitor_task = None
        if self.process:
            try:
                if self.process.stdin:
                    self.process.stdin.close()
            except Exception:
                pass
            if self.process.returncode is None:
                try:
                    self.process.terminate()
                    await asyncio.wait_for(self.process.wait(), timeout=2.5)
                except Exception:
                    try:
                        self.process.kill()
                        await self.process.wait()
                    except Exception:
                        pass
            if self.process and self.process.returncode is not None:
                self.status.exited_returncode = str(self.process.returncode)
            self.process = None
        self.queue = None
        self.mse_queue = None
        self.status.running = False
        self.status.queued_chunks = 0
        self.status.queued_bytes_est = 0
        if remove_files and self.output_dir and self.output_dir.exists():
            shutil.rmtree(self.output_dir, ignore_errors=True)
            self.status.playlist_ready = False
            self.status.segments = 0
            self.status.playlist_url = ""
            self.status.playlist_path = ""
        if not keep_prebuffer:
            self.prebuffer_chunks.clear()
            self.prebuffer_bytes = 0
            self.ts_started = False
            self.ts_sync_buffer = b""
            self.status.ts_sync_state = ""
            self.status.ts_sync_bytes = 0

    async def restart(self) -> str:
        # A SageTV FLUSH/seek means the transport stream continuity changes. Keep a
        # short prebuffer until new data arrives, but restart FFmpeg from clean HLS files.
        return await self.start()

    async def restart_with_current_settings(self, reason: str = "settings changed") -> str:
        """Restart the current FFmpeg/browser stream without asking SageTV to stop playback."""
        self.status.mse_restarts += 1
        return await self.start(refeed_prebuffer=True, reason=reason)

    async def _restart_with_fallback(self, reason: str):
        """Always fall back to libx264 when a hardware encoder stalls.

        v30-v32 only fell back when Encoder was set to auto.  In real testing the
        browser dropdown can still be on h264_nvenc from a prior run, so FFmpeg
        kept reading SageTV data but never produced HLS segments.  For now the
        safe behavior is: any non-libx264 encoder that fails to create the first
        segment gets restarted with libx264 and the rolling TS prebuffer is
        re-fed.  Once the software path is stable we can re-enable optional
        hardware-only testing.
        """
        if self.status.encoder == "libx264":
            self.status.last_error = reason + "; already using libx264, keeping current process for diagnostics"
            return
        await self.start(encoder_override="libx264", refeed_prebuffer=True, reason=reason + "; automatic safe fallback to libx264")

    def _find_mpegts_sync(self, data: bytes) -> int:
        """Return offset of a likely 188-byte MPEG-TS sync pattern, or -1."""
        max_scan = min(len(data), 188 * 12)
        for off in range(max_scan):
            good = 0
            pos = off
            while pos < len(data) and good < 5:
                if data[pos] != 0x47:
                    break
                good += 1
                pos += 188
            if good >= 3:
                return off
        return -1

    def _align_to_mpegts_sync(self, data: bytes) -> bytes:
        """Drop leading bytes until a TS packet sync boundary is found.

        SageTV PUSHBUFFER can begin in the middle of a TS packet after a seek or
        client reconnect. FFmpeg can usually recover, but starting FFmpeg on a
        clean 0x47/188-byte boundary makes first segment creation much more
        reliable and reduces the repeated 'Invalid frame dimensions 0x0' startup
        noise.
        """
        if self.ts_started:
            return data
        if not data:
            return b""
        self.ts_sync_buffer += data
        # Keep a bounded startup buffer while looking for sync.
        if len(self.ts_sync_buffer) > 2 * 1024 * 1024:
            self.ts_sync_buffer = self.ts_sync_buffer[-1024 * 1024:]
        self.status.ts_sync_bytes = len(self.ts_sync_buffer)
        off = self._find_mpegts_sync(self.ts_sync_buffer)
        if off < 0:
            self.status.ts_sync_state = f"waiting for MPEG-TS sync ({len(self.ts_sync_buffer)} bytes)"
            return b""
        out = self.ts_sync_buffer[off:]
        self.ts_started = True
        self.status.ts_sync_state = f"MPEG-TS sync found at offset {off}; feeding aligned stream"
        self.ts_sync_buffer = b""
        return out

    async def write(self, data: bytes):
        if not data:
            return
        self._append_prebuffer(data)

        aligned = self._align_to_mpegts_sync(data)
        if not aligned:
            return

        # v37: raw SageTV PUSH capture is useful for diagnostics but it grows
        # very quickly. Keep it only in Debug/keep-all mode or when explicitly
        # enabled by SAGEWEB_CAPTURE_PUSH=1.
        capture_enabled = bool(self.capture_push_stream or self.normalize_hls_mode() == "debug" or os.environ.get("SAGEWEB_CAPTURE_PUSH", "0").lower() in ("1", "true", "yes", "on"))
        self.status.capture_enabled = capture_enabled
        if capture_enabled:
            try:
                if self.output_dir:
                    self.output_dir.mkdir(parents=True, exist_ok=True)
                    with open(self.output_dir / "push_capture.ts", "ab") as f:
                        f.write(aligned)
                    self.status.capture_path = str(self.output_dir / "push_capture.ts")
            except Exception as exc:
                self.status.last_error = f"could not write push_capture.ts: {exc}"
        else:
            self.status.capture_path = ""

        if not self.process or self.process.returncode is not None:
            await self.start(refeed_prebuffer=False, reason="FFmpeg was not running; started after MPEG-TS sync")
        if not self.queue:
            return
        self.status.bytes_in += len(aligned)
        self.status.chunks_in += 1
        if self.status.chunks_in % 10 == 0:
            self.refresh_ready_state()
        self.status.queued_chunks = self.queue.qsize()
        self.status.queued_bytes_est = self.queue.qsize() * 32768
        try:
            self.queue.put_nowait(aligned)
        except asyncio.QueueFull:
            # v48 MSE no-drop mode: never discard SageTV TS input in MSE mode.
            # Dropping even one PUSHBUFFER creates a discontinuity that later shows
            # up as random jumps in the browser.  Instead, let backpressure slow the
            # media socket/FFmpeg chain.  This can add delay if the selected bitrate
            # or height is too heavy, but it preserves sequential playback.
            if self.normalize_player_mode() in ("mse", "mseav"):
                self.status.backpressure_events += 1
                self.status.last_error = "MSE backpressure: FFmpeg input queue full; waiting instead of dropping video data"
                await self.queue.put(aligned)
                if self.queue:
                    self.status.queued_chunks = self.queue.qsize()
                    self.status.queued_bytes_est = self.queue.qsize() * 32768
                return
            # HLS fallback behavior: keep SageTV responsive and preserve recent data
            # in the rolling prebuffer for a fallback/restart.
            self.status.dropped_input_chunks += 1
            self.status.last_error = "FFmpeg input queue full; dropped oldest chunk to keep SageTV responsive"
            try:
                _ = self.queue.get_nowait()
            except Exception:
                pass
            try:
                self.queue.put_nowait(aligned)
            except Exception:
                pass
            if not self.status.playlist_ready:
                asyncio.create_task(self._restart_with_fallback("FFmpeg input queue filled before HLS was ready"))

    async def _writer_loop(self):
        assert self.process is not None
        try:
            while True:
                item = await self.queue.get()
                if item is None:
                    break
                if not self.process or not self.process.stdin or self.process.returncode is not None:
                    break
                self.process.stdin.write(item)
                await self.process.stdin.drain()
                if self.queue:
                    self.status.queued_chunks = self.queue.qsize()
                    self.status.queued_bytes_est = self.queue.qsize() * 32768
        except asyncio.CancelledError:
            pass
        except Exception as exc:
            self.status.last_error = f"FFmpeg stdin error: {exc}"
        finally:
            try:
                if self.process and self.process.stdin:
                    self.process.stdin.close()
            except Exception:
                pass

    async def _stdout_loop(self):
        """Read FFmpeg fMP4 stdout and queue it for the browser MSE endpoint."""
        assert self.process is not None
        try:
            while self.process and self.process.stdout:
                chunk = await self.process.stdout.read(int(os.environ.get("SAGEWEB_MSE_READ_SIZE", "65536")))
                if not chunk:
                    break
                self.status.mse_bytes_out += len(chunk)
                self.status.mse_chunks_out += 1
                q = self.mse_queue
                if q is not None:
                    if q.qsize() > int(os.environ.get("SAGEWEB_MSE_QUEUE_WARN", "2048")):
                        self.status.backpressure_events += 1
                        self.status.last_error = "MSE HTTP/browser queue is backing up; waiting instead of dropping fMP4 data"
                    await q.put(chunk)
        except asyncio.CancelledError:
            pass
        except Exception as exc:
            self.status.last_error = f"FFmpeg stdout/MSE error: {exc}"
        finally:
            q = self.mse_queue
            if q is not None:
                try:
                    q.put_nowait(None)
                except Exception:
                    pass

    async def stream_mse_chunks(self):
        """Async generator used by /mse/<session>/stream.mp4."""
        # Wait a little for FFmpeg stdout to start.  Returning an empty response
        # immediately makes the browser mark the MSE stream as ended.
        idle = 0
        while True:
            q = self.mse_queue
            if q is None:
                if not self.status.running:
                    break
                await asyncio.sleep(0.05)
                idle += 1
                if idle > 200:
                    break
                continue
            try:
                item = await asyncio.wait_for(q.get(), timeout=1.0)
            except asyncio.TimeoutError:
                if not self.status.running and q.empty():
                    break
                continue
            if item is None:
                break
            yield item


    async def stream_growing_file(self, filename: str):
        """Stream a growing fMP4 file written by FFmpeg for separate MSE A/V."""
        safe = "audio.mp4" if str(filename).lower().startswith("audio") else "video.mp4"
        waited = 0
        pos = 0
        while True:
            path = (self.output_dir / safe) if self.output_dir else None
            if path and path.exists():
                break
            if not self.status.running and (not path or not path.exists()):
                return
            await asyncio.sleep(0.05)
            waited += 1
            if waited > 400:
                self.status.last_error = f"timed out waiting for {safe}"
                return
        while True:
            path = (self.output_dir / safe) if self.output_dir else None
            if not path or not path.exists():
                if not self.status.running:
                    return
                await asyncio.sleep(0.05)
                continue
            try:
                size = path.stat().st_size
                if size > pos:
                    with open(path, "rb") as f:
                        f.seek(pos)
                        data = f.read(min(262144, size - pos))
                    if data:
                        pos += len(data)
                        self.status.mse_bytes_out += len(data)
                        self.status.mse_chunks_out += 1
                        yield data
                        continue
            except Exception as exc:
                self.status.last_error = f"MSE separate file stream error for {safe}: {exc}"
                if not self.status.running:
                    return
            if not self.status.running:
                # Give the client one final chance to read what FFmpeg flushed.
                try:
                    final_size = path.stat().st_size if path and path.exists() else pos
                except Exception:
                    final_size = pos
                if final_size <= pos:
                    return
            await asyncio.sleep(0.03)

    async def _stderr_loop(self):
        assert self.process is not None
        try:
            while self.process and self.process.stderr:
                line = await self.process.stderr.readline()
                if not line:
                    break
                text = line.decode("utf-8", errors="replace").rstrip()
                if text:
                    self.log_lines.append(text)
                    if len(self.log_lines) > 90:
                        self.log_lines = self.log_lines[-90:]
                    self.status.ffmpeg_log_tail = "\n".join(self.log_lines[-45:])
                    self.refresh_ready_state()
            if self.process:
                rc = await self.process.wait()
                self.status.running = False
                if rc not in (0, None):
                    self.status.last_error = f"FFmpeg exited with code {rc}"
                    if not self.status.playlist_ready:
                        await self._restart_with_fallback(f"FFmpeg exited before HLS was ready, rc={rc}")
        except asyncio.CancelledError:
            pass
        except Exception as exc:
            self.status.last_error = f"FFmpeg stderr error: {exc}"

    async def _startup_monitor_loop(self):
        try:
            started = time.monotonic()
            while True:
                await asyncio.sleep(1.0)
                self.refresh_ready_state()
                if self.status.playlist_ready:
                    return
                if not self.process or self.process.returncode is not None:
                    return
                age = time.monotonic() - started
                # If hardware encoder initialization/drain stalls, FFmpeg can read a
                # little input, print stream mapping, but never produce a segment. In
                # auto mode restart with libx264 using the rolling SageTV TS prebuffer.
                if age >= self.startup_fallback_seconds and self.status.encoder != "libx264":
                    await self._restart_with_fallback(
                        f"No HLS segment after {int(age)}s with {self.status.encoder}"
                    )
                    return
                if age >= (self.startup_fallback_seconds + 8) and self.status.encoder == "libx264" and not self.video_only_mode and self.status.bytes_in > 1024 * 1024:
                    # If video+audio does not segment, try video-only. This isolates
                    # AC3/AAC interleave issues and at least proves the MPEG-2 video
                    # decode/encode/HLS path. Audio can be re-enabled after video is stable.
                    self.video_only_mode = True
                    await self.start(encoder_override="libx264", refeed_prebuffer=True, reason=f"No HLS segment after {int(age)}s with audio; retrying video-only")
                    return
        except asyncio.CancelledError:
            pass
        except Exception as exc:
            self.status.last_error = f"startup monitor error: {exc}"

def parse_stv_url(url: str) -> tuple[str, str]:
    """Return (host, path) for SageTV stv://host/path URLs.

    The Java MiniClient SimplePullDataSource connects to host:7818 and sends
    OPEN <path>.  For URLs like stv://server//var/media/file.ts the path sent
    to SageTV intentionally begins with /var/...
    """
    if not url.lower().startswith("stv://"):
        raise ValueError(f"not an stv:// URL: {url}")
    rest = url[6:]
    slash = rest.find("/")
    if slash < 0:
        raise ValueError(f"stv:// URL is missing path: {url}")
    host = rest[:slash]
    path = rest[slash + 1:]
    if not host:
        raise ValueError(f"stv:// URL is missing host: {url}")
    return host, path


async def _read_sage_line(reader: asyncio.StreamReader, timeout: float = 8.0) -> str:
    data = await asyncio.wait_for(reader.readline(), timeout=timeout)
    return data.decode("latin-1", errors="replace").strip()


async def _send_sage_line(writer: asyncio.StreamWriter, line: str):
    writer.write((line + "\r\n").encode("latin-1", errors="replace"))
    await writer.drain()


@dataclass
class SagePullStreamPump:
    """Small Python port of SimplePullDataSource for stv:// fallback.

    This is not the ideal long-term video path.  The preferred path is SageTV PUSHBUFFER
    because SageTV owns timeline/seek/comskip.  This exists so v28 can still play when
    SageTV chooses a stv:// pull URL instead of push:.
    """

    url: str
    bridge: FfmpegHlsBridge
    chunk_size: int = 256 * 1024
    start_offset: int = 0
    task: Optional[asyncio.Task] = None
    bytes_read: int = 0
    last_error: str = ""

    async def run(self):
        reader: Optional[asyncio.StreamReader] = None
        writer: Optional[asyncio.StreamWriter] = None
        try:
            host, path = parse_stv_url(self.url)
            reader, writer = await asyncio.wait_for(asyncio.open_connection(host, 7818), timeout=8.0)
            await _send_sage_line(writer, "OPEN " + path)
            open_reply = await _read_sage_line(reader)
            await _send_sage_line(writer, "SIZE")
            size_reply = await _read_sage_line(reader)
            try:
                size = int((size_reply.split() or ["-1"])[0])
            except Exception:
                size = -1

            offset = max(0, int(self.start_offset))
            while True:
                if size >= 0 and offset >= size:
                    break
                want = self.chunk_size if size < 0 else min(self.chunk_size, max(0, size - offset))
                if want <= 0:
                    break
                await _send_sage_line(writer, f"READ {offset} {want}")
                try:
                    data = await reader.readexactly(want)
                except asyncio.IncompleteReadError as e:
                    data = e.partial or b""
                    if data:
                        await self.bridge.write(data)
                        self.bytes_read += len(data)
                    break
                if not data:
                    break
                await self.bridge.write(data)
                self.bytes_read += len(data)
                offset += len(data)
                await asyncio.sleep(0)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            self.last_error = str(exc)
            self.bridge.status.last_error = f"Sage pull stream error: {exc}"
        finally:
            if writer:
                try:
                    await _send_sage_line(writer, "CLOSE")
                except Exception:
                    pass
                try:
                    writer.close()
                    await writer.wait_closed()
                except Exception:
                    pass
