import asyncio
import json
import os
import shutil
import time
import uuid
from pathlib import Path
from typing import Dict

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from starlette.websockets import WebSocketState
from fastapi.responses import HTMLResponse, JSONResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles

from .sagetv_session import SageTVWebSession

ROOT = Path(__file__).resolve().parent.parent
STATIC = ROOT / "static"
RUNTIME_HLS = ROOT / "runtime_hls"
RUNTIME_HLS.mkdir(parents=True, exist_ok=True)

app = FastAPI(title="SageTV Pure Python HTML5 MiniClient GUI")
app.mount("/static", StaticFiles(directory=str(STATIC)), name="static")

sessions: Dict[str, SageTVWebSession] = {}


def cleanup_runtime_hls(max_age_minutes: int = 240, include_active: bool = False) -> dict:
    """Delete old HLS session folders.

    Active sessions are skipped unless include_active=True. This keeps old .ts
    segments from previous crashes/runs from filling the disk.
    """
    RUNTIME_HLS.mkdir(parents=True, exist_ok=True)
    active = set(sessions.keys())
    cutoff = time.time() - max(1, int(max_age_minutes)) * 60
    removed = []
    kept = []
    for child in RUNTIME_HLS.iterdir():
        if not child.is_dir():
            continue
        if (not include_active) and child.name in active:
            kept.append(child.name)
            continue
        try:
            newest = max((p.stat().st_mtime for p in child.rglob('*') if p.is_file()), default=child.stat().st_mtime)
        except Exception:
            newest = 0
        if include_active or newest < cutoff:
            shutil.rmtree(child, ignore_errors=True)
            removed.append(child.name)
        else:
            kept.append(child.name)
    return {"removed": removed, "kept": kept, "max_age_minutes": max_age_minutes}


@app.on_event("startup")
async def startup_cleanup():
    # Clean abandoned session folders from prior crashes/runs. Active playback uses
    # rolling FFmpeg cleanup in v37; this handles folders left behind by older builds.
    cleanup_runtime_hls(int(os.environ.get("SAGEWEB_HLS_CLEANUP_AGE_MIN", "240")))


@app.middleware("http")
async def no_cache_for_dev(request, call_next):
    response = await call_next(request)
    # Do not run HLS through Starlette StaticFiles. FFmpeg can grow/rename HLS
    # files while the browser is reading them, and StaticFiles may compute a
    # Content-Length before the write is complete. The custom /hls route below
    # returns a byte snapshot with a matching length.
    response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"
    return response



def default_server() -> str:
    return os.environ.get("SAGETV_SERVER", "192.168.10.175:31099")


@app.get("/")
async def index():
    html = (STATIC / "index.html").read_text(encoding="utf-8")
    return HTMLResponse(html)


@app.get("/hls/{session_id}/{filename:path}")
async def hls_file(session_id: str, filename: str):
    # Snapshot HLS files into memory before returning them. This avoids
    # "Response content longer than Content-Length" when FFmpeg is still
    # writing a playlist/segment while the browser requests it.
    safe_name = Path(filename).name
    path = RUNTIME_HLS / session_id / safe_name
    if not path.exists() or not path.is_file():
        return Response(status_code=404)
    try:
        data = path.read_bytes()
    except Exception:
        return Response(status_code=404)
    if safe_name.endswith(".m3u8"):
        media_type = "application/vnd.apple.mpegurl"
    elif safe_name.endswith(".ts"):
        media_type = "video/mp2t"
    else:
        media_type = "application/octet-stream"
    return Response(
        content=data,
        media_type=media_type,
        headers={
            "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
            "Pragma": "no-cache",
            "Expires": "0",
            "Accept-Ranges": "none",
        },
    )



@app.get("/mse/{session_id}/stream.mp4")
async def mse_stream(session_id: str):
    s = sessions.get(session_id)
    if not s:
        return Response(status_code=404)
    headers = {
        "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
        "Pragma": "no-cache",
        "Expires": "0",
        "X-Accel-Buffering": "no",
        "Accept-Ranges": "none",
    }
    return StreamingResponse(
        s.video.stream_mse_chunks(),
        media_type="video/mp4",
        headers=headers,
    )

@app.get("/mseav/{session_id}/video.mp4")
async def mseav_video_stream(session_id: str):
    s = sessions.get(session_id)
    if not s:
        return Response(status_code=404)
    headers = {
        "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
        "Pragma": "no-cache",
        "Expires": "0",
        "X-Accel-Buffering": "no",
        "Accept-Ranges": "none",
    }
    return StreamingResponse(
        s.video.stream_growing_file("video.mp4"),
        media_type="video/mp4",
        headers=headers,
    )

@app.get("/mseav/{session_id}/audio.mp4")
async def mseav_audio_stream(session_id: str):
    s = sessions.get(session_id)
    if not s:
        return Response(status_code=404)
    headers = {
        "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
        "Pragma": "no-cache",
        "Expires": "0",
        "X-Accel-Buffering": "no",
        "Accept-Ranges": "none",
    }
    return StreamingResponse(
        s.video.stream_growing_file("audio.mp4"),
        media_type="audio/mp4",
        headers=headers,
    )

@app.get("/api/status")
async def status():
    return {
        "default_server": default_server(),
        "sessions": {sid: s.snapshot() for sid, s in sessions.items()},
        "version": "v53",
        "note": "Pure Python/HTML5 GUI bridge. v53 adds separate MSE audio/video streams, player-side sync, and cookie-saved settings."
    }


@app.get("/api/hls_ready/{session_id}")
async def hls_ready(session_id: str):
    s = sessions.get(session_id)
    if not s:
        return JSONResponse({"ready": False, "exists": False, "error": "session not found"}, status_code=404)
    try:
        ready = s.video.refresh_ready_state()
    except Exception as exc:
        return {"ready": False, "exists": False, "error": str(exc), "video": s.video.status.to_json()}
    playlist_path = Path(s.video.status.playlist_path) if s.video.status.playlist_path else None
    return {
        "ready": bool(ready),
        "exists": bool(playlist_path and playlist_path.exists()),
        "segments": s.video.status.segments,
        "video": s.video.status.to_json(),
    }


@app.post("/api/stop_all")
async def stop_all():
    for s in list(sessions.values()):
        await s.close()
    sessions.clear()
    cleanup_runtime_hls(include_active=True)
    return {"ok": True}


@app.post("/api/cleanup_hls")
async def cleanup_hls(max_age_minutes: int = 60):
    return cleanup_runtime_hls(max_age_minutes=max_age_minutes)


@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    # Browsers can close during page refresh or while the Disconnect button is
    # processing.  Treat those cases as normal disconnects instead of letting
    # Starlette/Uvicorn print an exception stack trace.
    try:
        await ws.accept()
    except Exception:
        return

    sid = uuid.uuid4().hex[:12]
    session = SageTVWebSession(session_id=sid, websocket=ws)
    sessions[sid] = session
    try:
        await session.send_log(f"Session {sid} connected. Default SageTV server {default_server()}")
        while True:
            try:
                msg = await ws.receive_text()
            except WebSocketDisconnect:
                break
            except RuntimeError as exc:
                # Happens if the server/browser side already closed the socket,
                # for example after the Disconnect button intentionally ends the
                # session.  Do not treat it as an application error.
                if "WebSocket is not connected" in str(exc) or ws.application_state != WebSocketState.CONNECTED:
                    break
                raise

            try:
                data = json.loads(msg)
            except Exception:
                await session.send_log(f"Invalid JSON from browser: {msg[:120]}")
                continue

            await session.handle_browser_message(data)
            if data.get("type") == "disconnect":
                break
    finally:
        await session.close()
        sessions.pop(sid, None)
