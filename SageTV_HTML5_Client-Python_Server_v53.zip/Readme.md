# SageTV Pure Python HTML5 GUI v53

Pure Python + HTML5/JavaScript SageTV MiniClient experiment.

This project connects to a SageTV server as a MiniClient, renders the SageTV GUI in a browser canvas, sends keyboard/mouse/remote events back to SageTV, and can transcode SageTV media playback to browser video.

It does **not** use Java, Gradle, Android, Firebase, Crashlytics, ExoPlayer, or IJKPlayer.

## Current focus

The GUI and remote path are working. Video playback is experimental. v53 defaults to separate MSE audio/video playback with Source height, Source bitrate, and Audio -200 ms so testing starts from the least-modified video path while allowing player-side A/V sync.

Recommended first video test:

```text
Player: MSE fMP4 test
Encoder: libx264
Max H: Source
Bitrate: Source
Force PUSH: checked
HLS Segments: Stable during playback, if using HLS mode
```

If `bp=` or backpressure messages rise quickly in the debug panel, the transcode is falling behind. Lower Max H or Bitrate. MSE tries to delay instead of dropping chunks, so the video should be more sequential but can build latency if the PC cannot encode fast enough.

## Run on Windows

Run:

```cmd
run_windows.bat
```

Open:

```text
http://localhost:8088
```

Default SageTV server:

```text
192.168.10.175:31099
```

The Windows launcher checks for FFmpeg in this order:

```text
1. FFMPEG environment variable
2. tools\ffmpeg\bin\ffmpeg.exe
3. ffmpeg.exe on PATH
4. Auto-download Gyan.dev ffmpeg-release-full.7z
```

The auto-install location is:

```text
tools\ffmpeg\bin\ffmpeg.exe
tools\ffmpeg\bin\ffprobe.exe
```

## Run tests

```cmd
test_windows.bat
```

Expected:

```text
16 passed
```

## Main browser settings

### Media/video caps

Enable this to advertise media capability to SageTV. Leave it disabled for GUI-only testing.

### Force PUSH

When checked, the client advertises:

```text
PULL_AV_CONTAINERS=NONE
```

This pushes SageTV toward `PUSHBUFFER` media playback instead of `stv://` pull playback.

### Player

```text
HLS
MSE fMP4 test
```

`HLS` uses FFmpeg HLS output with `.m3u8` and `.ts` segments.

`MSE fMP4 test` uses FFmpeg fragmented MP4 output streamed directly to the browser through Media Source Extensions. This avoids HLS playlists and `.ts` segment selection.

### Encoder

Start with:

```text
libx264
```

Hardware encoders can be tested later, but software x264 is usually better for debugging stability.

### Max H

```text
Source
1080p
720p
576p
480p
360p
240p
```

`Source` does not scale the source video. v53 defaults to Source. If the PC falls behind, lower this to 720p or 480p.

### Bitrate

```text
Source
Auto
800k
1200k
1600k
2500k
3500k
5000k
8000k
```

v53 defaults to Source. If the PC falls behind, lower this to Auto, 2500k, or 1600k.

### Audio Sync

```text
Audio -500ms
Audio -300ms
Audio -200ms
Audio -100ms
0ms
Audio +100ms
Audio +200ms
Audio +300ms
Audio +500ms
```

Positive values delay audio. Negative values advance audio. Changing this live restarts only the FFmpeg/browser video stream; SageTV playback keeps running.

### HLS Segments

```text
Stable during playback
Rolling cleanup
Debug keep all
```

`Stable during playback` keeps all `.ts` files for the active playback session and cleans the session when playback stops. This prevents the browser from requesting a segment that was just deleted.

`Rolling cleanup` deletes old `.ts` files during playback. It saves disk space but can cause jumps if the browser falls behind.

`Debug keep all` keeps everything and enables `push_capture.ts` for troubleshooting.

## Video pipelines

### HLS pipeline

```text
SageTV PUSHBUFFER
  -> Python
  -> FFmpeg stdin
  -> stream.m3u8 + seg_00001.ts, seg_00002.ts, ...
  -> hls.js
  -> HTML5 video
```

### MSE fMP4 pipeline

```text
SageTV PUSHBUFFER
  -> Python
  -> FFmpeg stdin
  -> fragmented MP4 stdout
  -> /mse/<session>/stream.mp4
  -> browser MediaSource SourceBuffer
  -> HTML5 video
```

MSE mode avoids HLS segment deletion and live-edge behavior. v53 defaults to separate MSE audio/video streams and avoids dropping SageTV TS input or fMP4 fragments when the pipeline falls behind.

## Troubleshooting

### Browser still shows an old version

Hard refresh:

```text
Ctrl + F5
```

Confirm the debug panel says:

```text
Media / Video Debug v53
```

### Video jumps or gets jerky

Use:

```text
Player: MSE fMP4 test
Encoder: libx264
Max H: Source first, then 480p if needed
Bitrate: Source first, then 1600k if needed
```

Watch the debug status:

```text
bp=<number> drop=<number>
```

`bp` means backpressure. If it climbs, the player/encoder/browser is falling behind. v53 defaults to Source height/bitrate and should avoid dropping in MSE mode, but the video may drift behind. Lower bitrate or height.

`drop` should stay at 0 in MSE mode. If it increases, report the debug panel text.

### NVIDIA NVENC does not start

Use the encoder dropdown in this order:

```text
h264_nvenc NVIDIA safe
h264_nvenc NVIDIA bare compat
h264_nvenc NVIDIA CUDA upload
h264_nvenc NVIDIA low latency
```

If all NVIDIA modes fail but Intel QSV and x264 work, run these commands from the project folder and copy the output:

```cmd
tools\ffmpeg\bin\ffmpeg.exe -hide_banner -encoders | findstr /i nvenc
nvidia-smi
tools\ffmpeg\bin\ffmpeg.exe -hide_banner -f lavfi -i testsrc2=size=1280x720:rate=30 -t 5 -pix_fmt yuv420p -c:v h264_nvenc -f null -
```

If the test command fails, FFmpeg or the NVIDIA driver cannot access NVENC outside the app. If it passes, the `CUDA upload` mode is the next best app-side test.

### Playback stops or SageTV shows an error after stopping

Stop the server and kill leftover FFmpeg:

```cmd
taskkill /IM ffmpeg.exe /F
```

Then restart `run_windows.bat`.

### Clean HLS files manually

After stopping the app:

```powershell
Remove-Item -Recurse -Force .\runtime_hls\*
```

## Changelog


### v53 - Separate MSE audio/video streams, player-side sync, cookies

- Added Player mode `MSE separate A/V` as the default.
- FFmpeg now writes separate fragmented MP4 outputs for video and audio.
- Browser creates separate MSE SourceBuffers for video and audio.
- Audio Sync is now applied on the browser side in separate A/V mode.
- Default Audio Sync is `Audio -200ms`. Negative values delay video; positive values delay audio.
- Added coarse audio sync values from -2000 ms to +2000 ms.
- Saved UI settings in cookies and localStorage so browser settings survive refresh/restart.

### v51 - NVIDIA profiles and audio sync

- Removed a duplicate `pipe:1` from the MSE fMP4 FFmpeg command.
- Changed MSE video timestamp default to `PTS-STARTPTS` instead of rebuilding every timestamp from frame count. This should reduce long-play audio drift on some MPEG-TS captures.
- Changed audio resampling to `aresample=async=1000:first_pts=0` for better long-play audio/video sync.
- Added an `Audio Sync` dropdown from -500 ms to +500 ms.
- Added `h264_nvenc NVIDIA bare compat` for a minimal NVENC command path.
- Added `h264_nvenc NVIDIA CUDA upload` for systems where implicit NVIDIA upload fails.
- NVIDIA modes now use `nv12` format before NVENC instead of `yuv420p`.

### v50 - NVIDIA NVENC compatibility options

- Added encoder aliases so `h264_NVenc`, `NVENC`, `nvidia`, and `h264_nvenc` all normalize to the correct lowercase FFmpeg encoder name.
- Changed the normal `h264_nvenc` option to a conservative NVIDIA-safe command path.
- Added `h264_nvenc NVIDIA low latency` as a separate option for testing the newer low-latency NVENC settings after the safe option works.
- Kept `h264_qsv Intel UHD` as a separate explicit option because Intel Quick Sync has been working on this test machine.
- If the FFmpeg build does not expose the selected hardware encoder, the server falls back to `libx264` instead of starting a doomed FFmpeg process.

NVIDIA test commands for Windows:

```cmd
tools\ffmpeg\bin\ffmpeg.exe -hide_banner -encoders | findstr /i nvenc
nvidia-smi
tools\ffmpeg\bin\ffmpeg.exe -hide_banner -f lavfi -i testsrc2=size=1280x720:rate=30 -t 5 -pix_fmt yuv420p -c:v h264_nvenc -bf 0 -f null -
```

If that last command fails, the issue is outside the MiniClient app. Check the NVIDIA driver and whether FFmpeg can see NVENC on the RTX A2000. If it passes, use `h264_nvenc NVIDIA safe` first, then try `h264_nvenc NVIDIA low latency`.


### v50 - MSE and Source defaults

- Defaults Player to `MSE fMP4 test`.
- Defaults Max H to `Source`, so FFmpeg does not scale unless requested.
- Defaults Bitrate to `Source`, so FFmpeg uses the SageTV push URL bitrate when available.
- Server-side defaults now match the browser UI defaults when a saved/cached value is missing.

### v48 - MSE no-drop / backpressure playback

- MSE mode no longer drops SageTV `PUSHBUFFER` input when FFmpeg input is backed up.
- MSE waits and applies backpressure instead of corrupting the fMP4 stream.
- Browser MSE append queue no longer drops complete fMP4 fragments.
- Browser fetch loop slows down when the SourceBuffer is already far ahead.
- Old MSE back-buffer is trimmed behind the playhead to avoid quota errors.
- MSE video timestamps are regenerated with FFmpeg `setpts` by default.
- Debug status shows backpressure events and dropped input count.
- Consolidated all project markdown into this single `Readme.md`.

### v47 - MSE recovery and live settings

- Parses MP4 boxes before appending to `SourceBuffer`.
- Appends complete fMP4 init/media fragments instead of random fetch chunks.
- Recovers if the browser hits an `HTMLMediaElement.error`.
- Larger FFmpeg input queue in MSE mode.
- Live setting changes restart only the FFmpeg/browser stream while SageTV playback continues.

### v46 - MSE fMP4 test mode

- Added `Player` dropdown with `HLS` and `MSE fMP4 test`.
- Added `/mse/<session>/stream.mp4` direct fragmented MP4 stream.
- Added browser MediaSource / SourceBuffer playback path.
- Avoids HLS `.m3u8` playlists and `.ts` files in MSE mode.

### v45 - Stable-session HLS

- Added `Stable during playback` HLS segment mode.
- Keeps all `.ts` segments during active playback.
- Cleans the session folder on stop, disconnect, media reconnect, or new video.
- hls.js starts from the first segment of the current playback session.

### v44 - Stable HLS and fixed debug panel

- Changed hls.js from low-latency mode to stable buffering mode.
- Increased HLS live buffer sizes.
- Changed FFmpeg HLS segment time from 1 second to 2 seconds.
- Fixed the Media / Video Debug panel height to stop layout jumps.
- Reduced video status updates in the hot `PUSHBUFFER` path.

### v43 - Clean disconnect

- Fixed WebSocket disconnect error after the Disconnect button, refresh, tab close, or network disconnect.
- Stops SageTV/media/FFmpeg first, then exits the WebSocket loop cleanly.
- Prevents late debug/status sends after browser close.

### v42 - Windows batch fix

- Fixed `The system cannot find the batch label specified - ensure_ffmpeg`.
- Reworked `run_windows.bat` to avoid batch subroutine labels.
- Saved the batch file with Windows CRLF line endings.

### v41 - FFmpeg auto-install

- `run_windows.bat` checks for FFmpeg and auto-downloads Gyan.dev `ffmpeg-release-full.7z` if missing.
- Installs FFmpeg to `tools\ffmpeg\bin`.
- Added `tools/install_ffmpeg.ps1`.

### v40 - Connect fix

- Fixed v39 browser-side recursion in `hideVideoBox()`.
- Added defensive connect startup error logging.

### v39 - GUI overlay repaint

- Video debug box hidden by default.
- Removed yellow dashed startup overlay during normal playback.
- Video remains under the SageTV GUI canvas.
- GUI canvas repaints during playback.
- SageTV timeline, OSD, and menus can draw on top of video.
- Stage fallback background changed to SageMC-style blue.

### v38 - Video under GUI

- Video element moved under the SageTV GUI canvas.
- Canvas background changed to transparent during video playback.
- Video mask/color-key rectangles are treated as transparent.
- `PUSHBUFFER` debug status throttled for better responsiveness.

### v37 - HLS cleanup

- Added `HLS Segments` dropdown.
- Added rolling cleanup and debug keep-all modes.
- Added startup cleanup for abandoned `runtime_hls` folders.

### v36 - Quality dropdowns

- Added Max H dropdown with Source, 1080p, 720p, 576p, 480p, 360p, and 240p.
- Added Bitrate dropdown with Source, Auto, and fixed bitrates.
- Debug panel shows requested and effective quality.

### v35 - Playback lifecycle

- Replaced StaticFiles HLS serving with a byte-snapshot route.
- Fixed `Response content longer than Content-Length`.
- Added SageTV GFX `MEDIA_RECONNECT` handling.
- Stops FFmpeg and clears HLS files on STOP / DEINIT.
- Cancels stale browser HLS wait loops.
- FFmpeg input queue changed to non-blocking for HLS mode.

### v34 - Diagnostics

- Added no-cache headers for browser files.
- Simplified FFmpeg HLS command for live SageTV PUSH testing.
- Defaults first-test video to 480p / 1600k.
- Added raw aligned SageTV PUSH capture as `runtime_hls\<session>\push_capture.ts` in debug mode.
- Retries video-only if audio blocks HLS startup.

### v33 - Hardware fallback

- Hardware encoder stalls fall back to `libx264`.
- Re-feeds SageTV TS prebuffer after fallback.
- HLS uses `split_by_time` during testing.

### v32 - TS sync

- Defaults encoder to `libx264` for stability.
- Waits for MPEG-TS `0x47` sync before feeding FFmpeg.
- Shows TS sync status in the debug panel.
- Removes HLS temp-file mode so playlist and segments appear sooner.

### v31 - PUSH autostart

- Media/video caps checked by default.
- FFmpeg auto-starts on the first non-empty SageTV `PUSHBUFFER`.
- PUSHBUFFER data is fed to FFmpeg even if OPENURL startup was missed.
- FFmpeg start/write errors appear in the debug panel.

### v30 - HLS fallback

- Added rolling SageTV TS prebuffer.
- Auto mode falls back from `h264_nvenc` to `libx264` if no HLS segment appears.
- Re-feeds prebuffer after fallback.
- Adds deinterlace, scale, format, and timestamp reset filters.

### v29 - HLS stability

- Browser polls `/api/hls_ready/<session>` instead of directly polling `/hls/...` before playlist exists.
- Increased HLS wait timeout.
- Added FFmpeg log tail to the debug panel.
- Forced FFmpeg input as MPEG-TS for known TS streams.
- Kept HLS segments during testing.

### v28 - Force PUSH and pull fallback

- Added Force PUSH checkbox.
- Advertises `PULL_AV_CONTAINERS=NONE` when forcing PUSH.
- Added fallback SageTV port 7818 pull reader for `stv://` URLs.

### v27 - First FFmpeg/HLS video bridge

- Added experimental SageTV `PUSHBUFFER -> FFmpeg stdin -> HLS -> HTML5 video` path.
- HTML5 video positioned using SageTV `SETVIDEORECT` destination rectangle.

### v26 - Navigation overlay

- Long-click navigation overlay centered over the SageTV render area.
- Right-click reserved for SageTV context menus.

### v25 - Right-click handling

- Right-click forwards to SageTV as mouse button 3.
- Browser context menu suppressed.

### v24 - Click fix

- Short canvas clicks send mouse move, press, release, and click events to SageTV.

### v23 - Remote keys

- Added long-click/touch navigation overlay and media key buttons.

### v22 - Media trace

- Added media command parser/stub player.
- Traces OPENURL, PLAY, PAUSE, PUSHBUFFER, FLUSH, SEEK, and SETVIDEORECT.

### v21 - SageMC fixes

- Corrected Sage command IDs.
- Changed renderer capabilities for SageMC/custom STVs.
- Disabled surfaces and hires surfaces.

### v20 - GUI performance

- Batches GFX draw commands between STARTFRAME and FLIPBUFFER.
- Reduced browser log spam and capped log size.

### v19 - SET_PROPERTY fix

- Fixed SET_PROPERTY decoding.
- Honored `ADVANCED_IMAGE_CACHING=FALSE`.
- Added GFX packet trace.

### v18 and earlier

- Initial pure Python + HTML5 GUI starter.
- Basic MiniClient socket handshake.
- Initial GFX parser and browser canvas renderer.
