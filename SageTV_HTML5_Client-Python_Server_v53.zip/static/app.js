(() => {
  const serverEl = document.getElementById('server');
  const clientIdEl = document.getElementById('clientId');
  const connectBtn = document.getElementById('connectBtn');
  const disconnectBtn = document.getElementById('disconnectBtn');
  const mediaCapsEl = document.getElementById('mediaCaps');
  const forcePushMediaEl = document.getElementById('forcePushMedia');
  const videoEncoderEl = document.getElementById('videoEncoder');
  const videoMaxHeightEl = document.getElementById('videoMaxHeight');
  const videoBitrateEl = document.getElementById('videoBitrate');
  const audioOffsetEl = document.getElementById('audioOffset');
  const videoMutedEl = document.getElementById('videoMuted');
  const videoDebugOverlayEl = document.getElementById('videoDebugOverlay');
  const hlsModeEl = document.getElementById('hlsMode');
  const playerModeEl = document.getElementById('playerMode');
  const logEl = document.getElementById('log');
  const statusEl = document.getElementById('status');
  const mediaStatusEl = document.getElementById('mediaStatus');
  const sageVideo = document.getElementById('sageVideo');
  const videoBox = document.getElementById('videoBox');
  const navOverlay = document.getElementById('navOverlay');
  const showOverlayBtn = document.getElementById('showOverlayBtn');
  const screen = document.getElementById('screen');
  const stageWrap = document.getElementById('stageWrap');
  const dstCtx = screen.getContext('2d', { alpha: true });

  let ws = null;
  let curSurface = screen;
  let curCtx = dstCtx;
  let surfaces = {0: screen};
  let images = {};
  let firstFrame = true;
  let hls = null;
  let mseAbortController = null;
  let mseObjectUrl = null;
  let mseSourceBuffer = null;
  let mseMediaSource = null;
  let mseAppendQueue = [];
  let mseByteBuffer = new Uint8Array(0);
  let mseInitBoxes = [];
  let msePendingSegmentBoxes = [];
  let mseSeenMoov = false;
  let mseStartedPlayback = false;
  let mseAppendErrors = 0;
  let mseRecovering = false;
  let mseLastRecoverMs = 0;
  let mseAppendHighWaterLogged = false;
  let mseBackpressureWaits = 0;
  let mseAvTracks = [];
  let settingsDebounce = null;
  let currentVideoDst = [0,0,0,0];
  let videoStatus = {};
  let videoSerial = 0;
  let videoLayerActive = false;
  const CLEAR_EACH_FRAME = true;
  const VIDEO_DEBUG_MAX_LOG_TAIL = 240;
  // v39: keep repainting the SageTV GUI even during playback. The video layer is
  // under the canvas; SageTV video-mask/color-key commands punch only the actual
  // video rectangle transparent so OSD/timeline/menu elements can draw on top.
  const VIDEO_COLORKEY_RGB = [8, 0, 16];

  const logLines = [];
  const MAX_LOG_LINES = 160;

  function log(msg) {
    const ts = new Date().toLocaleTimeString();
    logLines.unshift(`[${ts}] ${msg}`);
    if (logLines.length > MAX_LOG_LINES) logLines.length = MAX_LOG_LINES;
    // Rebuilding a very large <pre> on every render log was a major source of UI lag.
    logEl.textContent = logLines.join('\n');
  }



  const SAVED_SETTING_IDS = [
    'server','clientId','mediaCaps','forcePushMedia','videoEncoder','videoMaxHeight',
    'videoBitrate','audioOffset','videoMuted','videoDebugOverlay','hlsMode','playerMode'
  ];

  function cookieName(id) { return 'sageweb_' + id; }

  function setCookie(name, value, days = 365) {
    const maxAge = Math.floor(days * 24 * 60 * 60);
    document.cookie = `${encodeURIComponent(name)}=${encodeURIComponent(String(value))}; Max-Age=${maxAge}; Path=/; SameSite=Lax`;
  }

  function getCookie(name) {
    const key = encodeURIComponent(name) + '=';
    for (const part of document.cookie.split(';')) {
      const p = part.trim();
      if (p.startsWith(key)) return decodeURIComponent(p.slice(key.length));
    }
    return '';
  }

  function getSettingElement(id) { return document.getElementById(id); }

  function saveUiSettings() {
    for (const id of SAVED_SETTING_IDS) {
      const el = getSettingElement(id);
      if (!el) continue;
      const value = el.type === 'checkbox' ? (el.checked ? '1' : '0') : el.value;
      setCookie(cookieName(id), value);
      try { localStorage.setItem(cookieName(id), value); } catch (e) {}
    }
  }

  function loadUiSettings() {
    for (const id of SAVED_SETTING_IDS) {
      const el = getSettingElement(id);
      if (!el) continue;
      let value = getCookie(cookieName(id));
      if (value === '') { try { value = localStorage.getItem(cookieName(id)) || ''; } catch (e) {} }
      if (value === '') continue;
      if (el.type === 'checkbox') el.checked = value === '1' || value === 'true' || value === 'yes';
      else {
        const hasOption = !el.options || Array.from(el.options).some(o => o.value === value);
        if (hasOption) el.value = value;
      }
    }
  }

  function attachSettingsPersistence() {
    for (const id of SAVED_SETTING_IDS) {
      const el = getSettingElement(id);
      if (!el) continue;
      el.addEventListener('change', () => { saveUiSettings(); sendLiveVideoSettings(); });
      if (el.tagName === 'INPUT' && el.type !== 'checkbox') el.addEventListener('input', saveUiSettings);
    }
  }

  function videoDebugOverlayEnabled() {
    return !!(videoDebugOverlayEl && videoDebugOverlayEl.checked);
  }

  function setVideoBox(text) {
    if (!videoBox) return;
    if (!videoDebugOverlayEnabled()) {
      videoBox.classList.add('hidden');
      return;
    }
    if (text != null) videoBox.textContent = text;
    videoBox.classList.remove('hidden');
  }

  function hideVideoBox() {
    if (!videoBox) return;
    videoBox.classList.add('hidden');
  }

  function send(obj) {
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(obj));
    }
  }

  function getVideoSettingsPayload() {
    return {
      video_encoder: videoEncoderEl ? videoEncoderEl.value : 'libx264',
      video_max_height: videoMaxHeightEl ? videoMaxHeightEl.value : 'source',
      video_bitrate: videoBitrateEl ? videoBitrateEl.value : 'source',
      audio_offset_ms: audioOffsetEl ? audioOffsetEl.value : '0',
      hls_mode: hlsModeEl ? hlsModeEl.value : 'stable',
      player_mode: playerModeEl ? playerModeEl.value : 'mse'
    };
  }

  function sendLiveVideoSettings() {
    if (!ws || ws.readyState !== WebSocket.OPEN) return;
    if (settingsDebounce) clearTimeout(settingsDebounce);
    settingsDebounce = setTimeout(() => {
      send(Object.assign({type: 'videoSettings'}, getVideoSettingsPayload()));
    }, 150);
  }

  function setStatus(s) { statusEl.textContent = s; }


  function parseRgba(css) {
    const m = String(css || '').match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([0-9.]+))?\)/i);
    if (!m) return null;
    return {r: Number(m[1]), g: Number(m[2]), b: Number(m[3]), a: m[4] == null ? 1 : Number(m[4])};
  }

  function isVideoColorKey(css) {
    const c = parseRgba(css);
    if (!c) return false;
    return Math.abs(c.r - VIDEO_COLORKEY_RGB[0]) <= 2 && Math.abs(c.g - VIDEO_COLORKEY_RGB[1]) <= 2 && Math.abs(c.b - VIDEO_COLORKEY_RGB[2]) <= 2 && c.a > 0.5;
  }

  function isDarkMaskColor(css) {
    const c = parseRgba(css);
    if (!c) return false;
    return c.a < 0.05 || (c.a > 0.5 && c.r <= 12 && c.g <= 12 && c.b <= 18);
  }

  function rectIntersection(a, b) {
    const ax1 = Number(a[0] || 0), ay1 = Number(a[1] || 0), ax2 = ax1 + Number(a[2] || 0), ay2 = ay1 + Number(a[3] || 0);
    const bx1 = Number(b[0] || 0), by1 = Number(b[1] || 0), bx2 = bx1 + Number(b[2] || 0), by2 = by1 + Number(b[3] || 0);
    const x1 = Math.max(ax1, bx1), y1 = Math.max(ay1, by1), x2 = Math.min(ax2, bx2), y2 = Math.min(ay2, by2);
    if (x2 <= x1 || y2 <= y1) return null;
    return [x1, y1, x2 - x1, y2 - y1];
  }

  function clearTransparentRect(ctx, x, y, w, h) {
    if (!ctx || w <= 0 || h <= 0) return;
    ctx.save();
    ctx.globalCompositeOperation = 'destination-out';
    ctx.globalAlpha = 1;
    ctx.fillStyle = 'rgba(0,0,0,1)';
    ctx.fillRect(x, y, w, h);
    ctx.restore();
  }

  function currentVideoRect() {
    const v = currentVideoDst || [0,0,0,0];
    return [Number(v[0] || 0), Number(v[1] || 0), Number(v[2] || 0), Number(v[3] || 0)];
  }

  function clearVideoHole(ctx) {
    if (!videoLayerActive) return;
    const v = currentVideoRect();
    if (v[2] <= 0 || v[3] <= 0) return;
    // Expand by one pixel to avoid a thin color-key edge around the video.
    clearTransparentRect(ctx || dstCtx, v[0] - 1, v[1] - 1, v[2] + 2, v[3] + 2);
  }

  function commandLooksLikeVideoMask(cmd) {
    if (!videoLayerActive) return false;
    const v = currentVideoRect();
    if (v[2] <= 0 || v[3] <= 0) return false;
    const r = [cmd.x || 0, cmd.y || 0, cmd.w || 0, cmd.h || 0];
    const hit = rectIntersection(r, v);
    if (!hit) return false;
    const hitArea = hit[2] * hit[3];
    const videoArea = Math.max(1, v[2] * v[3]);
    const rectArea = Math.max(1, Math.abs((cmd.w || 0) * (cmd.h || 0)));
    const screenArea = Math.max(1, screen.width * screen.height);
    const coversMostVideo = hitArea >= videoArea * 0.70;
    const coversMostScreen = rectArea >= screenArea * 0.75;
    return isVideoColorKey(cmd.color) || (isDarkMaskColor(cmd.color) && (coversMostVideo || coversMostScreen));
  }

  function clearMaskedVideoIntersection(cmd) {
    const v = currentVideoRect();
    const hit = rectIntersection([cmd.x || 0, cmd.y || 0, cmd.w || 0, cmd.h || 0], v);
    if (hit) clearTransparentRect(curCtx, hit[0] - 1, hit[1] - 1, hit[2] + 2, hit[3] + 2);
  }

  function connect() {
    if (ws) ws.close();
    const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
    ws = new WebSocket(`${proto}//${location.host}/ws`);
    ws.onopen = () => {
      log('WebSocket opened');
      try {
        resetRenderer();
        send({
          type: 'connect',
          server: serverEl.value.trim(),
          client_id: clientIdEl.value.trim(),
          width: screen.width,
          height: screen.height,
          media_caps: mediaCapsEl.checked,
          force_push_media: forcePushMediaEl ? forcePushMediaEl.checked : true,
          ...getVideoSettingsPayload()
        });
        screen.focus();
      } catch (e) {
        log(`Connect startup error: ${e && e.stack ? e.stack : e}`);
        setStatus('Browser connect error');
      }
    };
    ws.onmessage = (ev) => {
      const data = JSON.parse(ev.data);
      if (data.type === 'log') log(data.message);
      else if (data.type === 'gfx') renderCommands(data.commands || []);
      else if (data.type === 'resizeCanvas') resizeCanvas(data.width, data.height);
      else if (data.type === 'menuHint') setStatus(`Menu: ${data.value}`);
      else if (data.type === 'mediaStatus') updateMediaStatus(data.status || {});
      else if (data.type === 'videoBounds') updateVideoBounds(data.dst || [0,0,0,0]);
      else if (data.type === 'videoStream') startVideoStream(data.url, data.status || {});
      else if (data.type === 'videoStatus') { videoStatus = data.status || {}; updateMediaStatus(lastMediaStatus || {}); }
      else if (data.type === 'videoStop') stopVideoStream(data.status || {});
      else log(`Unknown message ${ev.data}`);
    };
    ws.onclose = () => { log('WebSocket closed'); setStatus('Disconnected'); stopVideoStream({}); };
    ws.onerror = () => log('WebSocket error');
  }

  function resetRenderer() {
    dstCtx.clearRect(0, 0, screen.width, screen.height);
    surfaces = {0: screen};
    images = {};
    curSurface = screen;
    curCtx = dstCtx;
    firstFrame = true;
    setStatus('Connecting...');
    updateMediaStatus({state:'not connected'});
    stopVideoStream({});
    updateVideoBounds([0,0,0,0]);
  }


  function formatMs(ms) {
    ms = Math.max(0, Math.floor(Number(ms || 0)));
    const s = Math.floor(ms / 1000);
    const hh = Math.floor(s / 3600);
    const mm = Math.floor((s % 3600) / 60);
    const ss = s % 60;
    if (hh > 0) return `${hh}:${String(mm).padStart(2,'0')}:${String(ss).padStart(2,'0')}`;
    return `${mm}:${String(ss).padStart(2,'0')}`;
  }

  let lastMediaStatus = null;

  function updateMediaStatus(st) {
    lastMediaStatus = st || lastMediaStatus || {};
    st = lastMediaStatus;
    if (!mediaStatusEl) return;
    const url = st.url || '';
    const shortUrl = url.length > 140 ? url.slice(0, 140) + '…' : url;
    mediaStatusEl.textContent =
      `state: ${st.state || 'unknown'}  push: ${!!st.push_mode}  time: ${formatMs(st.media_time_ms)}  serverStart: ${formatMs(st.last_server_start_ms)}\n` +
      `last command: ${st.last_command || ''}  pushed: ${st.bytes_pushed || 0} bytes in ${st.push_buffers || 0} buffers  flushes: ${st.flushes || 0}  seeks: ${st.seeks || 0}  eos: ${!!st.eos}\n` +
      `video src: ${(st.source_rect || []).join(',')}  dst: ${(st.dest_rect || []).join(',')}  size: ${(st.video_size || []).join('x')}\n` +
      `ffmpeg: ${videoStatus.running ? 'running' : 'stopped'}  player: ${videoStatus.player_mode || 'hls'}  encoder: ${videoStatus.encoder || ''}  in: ${videoStatus.bytes_in || 0} bytes / ${videoStatus.chunks_in || 0} chunks  q:${videoStatus.queued_chunks || 0}\n` +
      `quality: maxH=${videoStatus.requested_max_height || ''}  bitrate=${videoStatus.requested_bitrate || ''}  effective=${videoStatus.effective_bitrate || ''}  audioOffset=${videoStatus.audio_offset_ms || 0}ms  pts=${videoStatus.pts_mode || ''}\n` +
      `segments: mode=${videoStatus.hls_mode || ''}  deleteThreshold=${videoStatus.hls_delete_threshold || ''}  capture=${!!videoStatus.capture_enabled}  mseOut=${videoStatus.mse_bytes_out || 0}/${videoStatus.mse_chunks_out || 0}  bp=${videoStatus.backpressure_events || 0} drop=${videoStatus.dropped_input_chunks || 0}\n` +
      `hls: ${videoStatus.playlist_url || ''}  ready: ${!!videoStatus.playlist_ready}  segs: ${videoStatus.segments || 0}  error: ${videoStatus.last_error || ''}\n` +
      (videoStatus.ts_sync_state ? `ts sync: ${videoStatus.ts_sync_state} (${videoStatus.ts_sync_bytes || 0} buffered)\n` : '') +
      (videoStatus.fallback_reason ? `fallback: ${videoStatus.fallback_reason}\n` : '') +
      (videoStatus.ffmpeg_log_tail ? `ffmpeg tail: ${String(videoStatus.ffmpeg_log_tail).replace(/\\s+/g, ' ').slice(-VIDEO_DEBUG_MAX_LOG_TAIL)}\n` : '') +
      `url: ${shortUrl}`;
  }

  function updateVideoBounds(dst) {
    currentVideoDst = dst || [0,0,0,0];
    if (!videoBox || !sageVideo) return;
    const x = Number(dst[0] || 0), y = Number(dst[1] || 0), w = Number(dst[2] || 0), h = Number(dst[3] || 0);
    if (w <= 0 || h <= 0) {
      hideVideoBox();
      sageVideo.classList.add('hidden');
      return;
    }
    const r = screen.getBoundingClientRect();
    const sx = r.width / screen.width;
    const sy = r.height / screen.height;
    const left = `${x * sx}px`, top = `${y * sy}px`, width = `${w * sx}px`, height = `${h * sy}px`;
    for (const el of [videoBox, sageVideo]) {
      el.style.left = left; el.style.top = top; el.style.width = width; el.style.height = height;
    }
    setVideoBox(videoStatus.playlist_url ? 'Starting HTML5 HLS video…' : 'Waiting for FFmpeg/HLS stream…');
    if (videoStatus.playlist_url) sageVideo.classList.remove('hidden');
    if (videoLayerActive) clearVideoHole(dstCtx);
  }

  function hlsSessionIdFromUrl(url) {
    const m = String(url || '').match(/\/hls\/([^\/]+)\//);
    return m ? m[1] : '';
  }

  async function waitForPlaylist(url, serial, timeoutMs = 75000) {
    const started = performance.now();
    const sid = hlsSessionIdFromUrl(url);
    let lastLog = 0;
    while (performance.now() - started < timeoutMs) {
      if (serial !== videoSerial) return false;
      try {
        if (sid) {
          const stRes = await fetch(`/api/hls_ready/${sid}`, {cache: 'no-store'});
          if (stRes.ok) {
            const st = await stRes.json();
            if (st.video) {
              videoStatus = st.video;
              updateMediaStatus(lastMediaStatus || {});
              setVideoBox(`Waiting for FFmpeg/HLS… ${videoStatus.bytes_in || 0} bytes, ${videoStatus.segments || 0} segments`);
            }
            if (st.ready) return true;
          }
        } else {
          const res = await fetch(url, {cache: 'no-store'});
          if (res.ok) {
            const txt = await res.text();
            if (txt.includes('#EXTM3U')) return true;
          }
        }
      } catch (e) {}
      if (performance.now() - lastLog > 5000) {
        lastLog = performance.now();
        log(`Waiting for HLS playlist from FFmpeg… ${videoStatus.bytes_in || 0} bytes received, ${videoStatus.segments || 0} segments`);
      }
      await new Promise(r => setTimeout(r, 500));
    }
    return false;
  }

  function playVideoElement() {
    sageVideo.play().catch(err => {
      log(`Video play blocked/delayed: ${err.message || err}`);
      if (!sageVideo.muted) {
        log('Retrying muted so video can start. Uncheck/check Mute video and restart playback for audio.');
        sageVideo.muted = true;
        sageVideo.play().catch(err2 => log(`Muted video play also failed: ${err2.message || err2}`));
      }
    });
  }

  if (sageVideo) {
    sageVideo.addEventListener('error', () => {
      const code = sageVideo.error ? sageVideo.error.code : '?';
      log(`HTML video element error code=${code}`);
      const mode = (videoStatus.player_mode || '').toLowerCase();
      if (videoLayerActive && (mode === 'mse' || mode === 'mseav')) recoverMseStream(`HTML video element error code=${code}`);
    });
  }

  function cleanupMse() {
    if (mseAbortController) { try { mseAbortController.abort(); } catch (e) {} }
    mseAbortController = null;
    mseSourceBuffer = null;
    mseMediaSource = null;
    mseAppendQueue = [];
    mseByteBuffer = new Uint8Array(0);
    mseInitBoxes = [];
    msePendingSegmentBoxes = [];
    mseSeenMoov = false;
    mseStartedPlayback = false;
    mseAppendErrors = 0;
    mseRecovering = false;
    mseAppendHighWaterLogged = false;
    mseBackpressureWaits = 0;
    mseAvTracks = [];
    if (mseObjectUrl) { try { URL.revokeObjectURL(mseObjectUrl); } catch (e) {} }
    mseObjectUrl = null;
  }

  function pickMseMime(st) {
    const candidates = [
      st && st.mse_mime,
      'video/mp4; codecs="avc1.4D4028, mp4a.40.2"',
      'video/mp4; codecs="avc1.42E01E, mp4a.40.2"',
      'video/mp4; codecs="avc1.640028, mp4a.40.2"',
      'video/mp4; codecs="avc1.4D4028"',
      'video/mp4'
    ].filter(Boolean);
    for (const c of candidates) {
      try { if (window.MediaSource && MediaSource.isTypeSupported(c)) return c; } catch (e) {}
    }
    return candidates[0];
  }

  function concatUint8Arrays(arrays) {
    const total = arrays.reduce((n, a) => n + (a ? a.byteLength : 0), 0);
    const out = new Uint8Array(total);
    let off = 0;
    for (const a of arrays) {
      if (!a || !a.byteLength) continue;
      out.set(a, off);
      off += a.byteLength;
    }
    return out;
  }

  function boxType(buf, off) {
    if (buf.byteLength < off + 8) return '';
    return String.fromCharCode(buf[off+4], buf[off+5], buf[off+6], buf[off+7]);
  }

  function readMp4BoxSize(buf, off) {
    if (buf.byteLength < off + 8) return 0;
    let size = ((buf[off] << 24) >>> 0) + (buf[off+1] << 16) + (buf[off+2] << 8) + buf[off+3];
    if (size === 1) {
      if (buf.byteLength < off + 16) return 0;
      const hi = ((buf[off+8] << 24) >>> 0) + (buf[off+9] << 16) + (buf[off+10] << 8) + buf[off+11];
      const lo = ((buf[off+12] << 24) >>> 0) + (buf[off+13] << 16) + (buf[off+14] << 8) + buf[off+15];
      if (hi > 0) return -1; // too large for JS safe slicing in this app
      size = lo;
    } else if (size === 0) {
      return 0; // wait; FFmpeg fragmented MP4 should not use open-ended boxes here
    }
    return size;
  }

  function enqueueMseSegmentFromBoxes(boxes) {
    if (!boxes || !boxes.length) return;
    mseAppendQueue.push(concatUint8Arrays(boxes).buffer);
    // v48 no-drop MSE: never discard complete fMP4 fragments during normal
    // playback. Dropping fragments is what makes playback jump.  Backpressure in
    // the fetch loop/server will slow the pipeline instead.
    if (mseAppendQueue.length > 120 && !mseAppendHighWaterLogged) {
      mseAppendHighWaterLogged = true;
      log('MSE append queue is high; applying backpressure instead of dropping fragments. Lower bitrate/height if playback falls behind.');
    }
  }

  function handleMseMp4Box(box) {
    const type = boxType(box, 0);
    if (!mseSeenMoov) {
      mseInitBoxes.push(box);
      if (type === 'moov') {
        enqueueMseSegmentFromBoxes(mseInitBoxes);
        mseInitBoxes = [];
        mseSeenMoov = true;
      }
      return;
    }
    // Append complete media fragments, ideally moof+mdat together. This is more
    // reliable than appending arbitrary fetch() chunks that may split MP4 boxes.
    if (type === 'moof') {
      if (msePendingSegmentBoxes.length) enqueueMseSegmentFromBoxes(msePendingSegmentBoxes);
      msePendingSegmentBoxes = [box];
    } else if (msePendingSegmentBoxes.length) {
      msePendingSegmentBoxes.push(box);
      if (type === 'mdat') {
        enqueueMseSegmentFromBoxes(msePendingSegmentBoxes);
        msePendingSegmentBoxes = [];
      }
    } else if (type === 'styp' || type === 'sidx') {
      msePendingSegmentBoxes = [box];
    } else {
      enqueueMseSegmentFromBoxes([box]);
    }
  }

  function enqueueMseBytes(value) {
    const incoming = value instanceof Uint8Array ? value : new Uint8Array(value);
    if (!incoming.byteLength) return;
    const merged = new Uint8Array(mseByteBuffer.byteLength + incoming.byteLength);
    merged.set(mseByteBuffer, 0);
    merged.set(incoming, mseByteBuffer.byteLength);
    mseByteBuffer = merged;

    while (mseByteBuffer.byteLength >= 8) {
      const size = readMp4BoxSize(mseByteBuffer, 0);
      if (size === 0) break;
      if (size < 8 || size > 128 * 1024 * 1024) {
        log(`MSE MP4 parser lost sync; invalid box size=${size}. Requesting clean restart.`);
        recoverMseStream('MSE MP4 parser lost sync');
        return;
      }
      if (mseByteBuffer.byteLength < size) break;
      const box = mseByteBuffer.slice(0, size);
      mseByteBuffer = mseByteBuffer.slice(size);
      handleMseMp4Box(box);
    }
    if (mseByteBuffer.byteLength > 8 * 1024 * 1024) {
      log('MSE MP4 parser buffered too much partial data. Requesting clean restart.');
      recoverMseStream('MSE MP4 partial buffer too large');
    }
    pumpMseAppend();
  }

  function recoverMseStream(reason) {
    const now = performance.now();
    if (mseRecovering || now - mseLastRecoverMs < 5000) return;
    mseRecovering = true;
    mseLastRecoverMs = now;
    log(`MSE recovery: ${reason}`);
    setVideoBox('Recovering MSE stream…');
    try { cleanupMse(); } catch (e) {}
    try { sageVideo.pause(); sageVideo.removeAttribute('src'); sageVideo.load(); } catch (e) {}
    send({type:'videoRestart', reason});
  }


  function sleepMs(ms) { return new Promise(r => setTimeout(r, ms)); }

  function mseBufferedAheadSeconds() {
    try {
      if (!sageVideo || !sageVideo.buffered || sageVideo.buffered.length === 0) return 0;
      const t = Number(sageVideo.currentTime || 0);
      let maxEnd = 0;
      for (let i = 0; i < sageVideo.buffered.length; i++) {
        const start = sageVideo.buffered.start(i);
        const end = sageVideo.buffered.end(i);
        if (t >= start - 0.1 && t <= end + 0.1) maxEnd = Math.max(maxEnd, end);
        else if (start > t && maxEnd === 0) maxEnd = Math.max(maxEnd, end);
      }
      return Math.max(0, maxEnd - t);
    } catch (e) { return 0; }
  }

  function trimMseBackBuffer() {
    const sb = mseSourceBuffer;
    if (!sb || sb.updating || !sageVideo || !sb.buffered || sb.buffered.length === 0) return false;
    try {
      const keepBehind = 45;
      const t = Number(sageVideo.currentTime || 0);
      const removeEnd = t - keepBehind;
      if (removeEnd <= 0) return false;
      const start = sb.buffered.start(0);
      if (removeEnd > start + 2) {
        sb.remove(start, removeEnd);
        return true;
      }
    } catch (e) {}
    return false;
  }

  async function waitForMseAppendRoom(serial) {
    const maxQueue = 45;      // complete fMP4 fragments, usually ~2s each
    const maxAhead = 55;      // seconds of buffered video ahead of playhead
    while (serial === videoSerial) {
      const ahead = mseBufferedAheadSeconds();
      if (mseAppendQueue.length <= maxQueue && ahead <= maxAhead) return true;
      mseBackpressureWaits += 1;
      if (mseBackpressureWaits % 50 === 1) {
        log(`MSE backpressure: appendQ=${mseAppendQueue.length} ahead=${ahead.toFixed(1)}s. Waiting, not dropping.`);
      }
      pumpMseAppend();
      await sleepMs(100);
    }
    return false;
  }

  function pumpMseAppend() {
    const sb = mseSourceBuffer;
    if (!sb || sb.updating || mseAppendQueue.length === 0) return;
    if (sageVideo && sageVideo.error) {
      recoverMseStream(`HTML video error code ${sageVideo.error.code || '?'}`);
      return;
    }
    if (trimMseBackBuffer()) return;
    const chunk = mseAppendQueue.shift();
    try {
      sb.appendBuffer(chunk);
      mseAppendErrors = 0;
      if (!mseStartedPlayback) {
        mseStartedPlayback = true;
        hideVideoBox();
        sageVideo.classList.remove('hidden');
        playVideoElement();
      }
    } catch (e) {
      mseAppendErrors += 1;
      log(`MSE append error: ${e.message || e}`);
      if (String(e && e.name || '').includes('Quota') || String(e && e.message || '').includes('quota')) {
        try { mseAppendQueue.unshift(chunk); } catch (_) {}
        if (trimMseBackBuffer()) return;
        setTimeout(pumpMseAppend, 500);
        return;
      }
      if ((sageVideo && sageVideo.error) || mseAppendErrors >= 3 || String(e && e.message || '').includes('HTMLMediaElement.error')) {
        recoverMseStream(`MSE append failed: ${e.message || e}`);
        return;
      }
      try { mseAppendQueue.unshift(chunk); } catch (_) {}
      setTimeout(pumpMseAppend, 250);
    }
  }


  function pickMseTrackMime(st, kind) {
    const candidates = kind === 'audio'
      ? [st && st.mse_audio_mime, 'audio/mp4; codecs="mp4a.40.2"', 'audio/mp4']
      : [st && st.mse_video_mime, 'video/mp4; codecs="avc1.4D4028"', 'video/mp4; codecs="avc1.42E01E"', 'video/mp4; codecs="avc1.640028"', 'video/mp4'];
    for (const c of candidates.filter(Boolean)) {
      try { if (window.MediaSource && MediaSource.isTypeSupported(c)) return c; } catch (e) {}
    }
    return candidates.filter(Boolean)[0];
  }

  function createMseTrack(kind, sb, serial) {
    return {
      kind, sb, serial,
      byteBuffer: new Uint8Array(0),
      initBoxes: [],
      pendingBoxes: [],
      seenMoov: false,
      queue: [],
      appendErrors: 0,
      firstAppend: false,
      highWaterLogged: false
    };
  }

  function enqueueTrackSegment(track, boxes) {
    if (!track || !boxes || !boxes.length) return;
    track.queue.push(concatUint8Arrays(boxes).buffer);
    if (track.queue.length > 120 && !track.highWaterLogged) {
      track.highWaterLogged = true;
      log(`${track.kind} MSE append queue high; browser is applying backpressure, not dropping fragments.`);
    }
  }

  function handleTrackBox(track, box) {
    const type = boxType(box, 0);
    if (!track.seenMoov) {
      track.initBoxes.push(box);
      if (type === 'moov') {
        enqueueTrackSegment(track, track.initBoxes);
        track.initBoxes = [];
        track.seenMoov = true;
      }
      return;
    }
    if (type === 'moof') {
      if (track.pendingBoxes.length) enqueueTrackSegment(track, track.pendingBoxes);
      track.pendingBoxes = [box];
    } else if (track.pendingBoxes.length) {
      track.pendingBoxes.push(box);
      if (type === 'mdat') {
        enqueueTrackSegment(track, track.pendingBoxes);
        track.pendingBoxes = [];
      }
    } else if (type === 'styp' || type === 'sidx') {
      track.pendingBoxes = [box];
    } else {
      enqueueTrackSegment(track, [box]);
    }
  }

  function enqueueTrackBytes(track, value) {
    const incoming = value instanceof Uint8Array ? value : new Uint8Array(value);
    if (!incoming.byteLength) return;
    const merged = new Uint8Array(track.byteBuffer.byteLength + incoming.byteLength);
    merged.set(track.byteBuffer, 0);
    merged.set(incoming, track.byteBuffer.byteLength);
    track.byteBuffer = merged;

    while (track.byteBuffer.byteLength >= 8) {
      const size = readMp4BoxSize(track.byteBuffer, 0);
      if (size === 0) break;
      if (size < 8 || size > 128 * 1024 * 1024) {
        log(`${track.kind} MSE parser lost sync; invalid box size=${size}. Requesting clean restart.`);
        recoverMseStream(`${track.kind} MSE parser lost sync`);
        return;
      }
      if (track.byteBuffer.byteLength < size) break;
      const box = track.byteBuffer.slice(0, size);
      track.byteBuffer = track.byteBuffer.slice(size);
      handleTrackBox(track, box);
    }
    if (track.byteBuffer.byteLength > 8 * 1024 * 1024) {
      log(`${track.kind} MSE parser buffered too much partial data. Requesting clean restart.`);
      recoverMseStream(`${track.kind} MSE partial buffer too large`);
    }
    pumpTrackAppend(track);
  }

  function trimTrackBackBuffer(track) {
    const sb = track && track.sb;
    if (!sb || sb.updating || !sageVideo || !sb.buffered || sb.buffered.length === 0) return false;
    try {
      const keepBehind = 45;
      const t = Number(sageVideo.currentTime || 0);
      const removeEnd = t - keepBehind;
      if (removeEnd <= 0) return false;
      const start = sb.buffered.start(0);
      if (removeEnd > start + 2) {
        sb.remove(start, removeEnd);
        return true;
      }
    } catch (e) {}
    return false;
  }

  function maybeStartMseAvPlayback() {
    const required = mseAvTracks.filter(t => t.kind === 'video' || t.kind === 'audio');
    if (!required.length) return;
    if (!required.every(t => t.firstAppend)) return;
    if (!mseStartedPlayback) {
      mseStartedPlayback = true;
      hideVideoBox();
      sageVideo.classList.remove('hidden');
      playVideoElement();
    }
  }

  function pumpTrackAppend(track) {
    const sb = track && track.sb;
    if (!sb || sb.updating || track.queue.length === 0) return;
    if (sageVideo && sageVideo.error) {
      recoverMseStream(`HTML video error code ${sageVideo.error.code || '?'}`);
      return;
    }
    if (trimTrackBackBuffer(track)) return;
    const chunk = track.queue.shift();
    try {
      sb.appendBuffer(chunk);
      track.appendErrors = 0;
      track.firstAppend = true;
      maybeStartMseAvPlayback();
    } catch (e) {
      track.appendErrors += 1;
      log(`${track.kind} MSE append error: ${e.message || e}`);
      if (String(e && e.name || '').includes('Quota') || String(e && e.message || '').includes('quota')) {
        try { track.queue.unshift(chunk); } catch (_) {}
        if (trimTrackBackBuffer(track)) return;
        setTimeout(() => pumpTrackAppend(track), 500);
        return;
      }
      if ((sageVideo && sageVideo.error) || track.appendErrors >= 3 || String(e && e.message || '').includes('HTMLMediaElement.error')) {
        recoverMseStream(`${track.kind} MSE append failed: ${e.message || e}`);
        return;
      }
      try { track.queue.unshift(chunk); } catch (_) {}
      setTimeout(() => pumpTrackAppend(track), 250);
    }
  }

  async function waitForTrackAppendRoom(serial) {
    const maxQueue = 45;
    const maxAhead = 55;
    while (serial === videoSerial) {
      const ahead = mseBufferedAheadSeconds();
      const q = mseAvTracks.reduce((n, t) => Math.max(n, t.queue.length), 0);
      if (q <= maxQueue && ahead <= maxAhead) return true;
      mseBackpressureWaits += 1;
      if (mseBackpressureWaits % 50 === 1) log(`MSE A/V backpressure: maxQ=${q} ahead=${ahead.toFixed(1)}s. Waiting, not dropping.`);
      mseAvTracks.forEach(pumpTrackAppend);
      await sleepMs(100);
    }
    return false;
  }

  async function fetchMseTrack(url, track, serial) {
    try {
      const res = await fetch(url, {cache: 'no-store', signal: mseAbortController.signal});
      if (!res.ok || !res.body) throw new Error(`HTTP ${res.status}`);
      const reader = res.body.getReader();
      while (serial === videoSerial) {
        if (!(await waitForTrackAppendRoom(serial))) break;
        const {done, value} = await reader.read();
        if (done) break;
        if (value && value.byteLength) enqueueTrackBytes(track, value);
      }
    } catch (e) {
      if (String(e && e.name) !== 'AbortError') {
        log(`${track.kind} MSE stream error: ${e.message || e}`);
        setVideoBox(`${track.kind} MSE stream error`);
      }
    }
  }

  async function startMseSeparateStream(url, st, serial) {
    if (!window.MediaSource) {
      setVideoBox('MSE is not supported by this browser');
      log('MSE separate A/V playback unsupported in this browser. Use HLS mode.');
      return;
    }
    cleanupMse();
    const videoMime = pickMseTrackMime(st || {}, 'video');
    const audioMime = pickMseTrackMime(st || {}, 'audio');
    const audioUrl = (st && st.mse_audio_url) || url.replace('/video.mp4', '/audio.mp4');
    if (!MediaSource.isTypeSupported(videoMime)) {
      setVideoBox('MSE video MIME not supported');
      log(`MSE video MIME not supported: ${videoMime}`);
      return;
    }
    if (audioUrl && !MediaSource.isTypeSupported(audioMime)) {
      log(`MSE audio MIME not supported: ${audioMime}; trying video-only.`);
    }
    mseAbortController = new AbortController();
    mseMediaSource = new MediaSource();
    mseObjectUrl = URL.createObjectURL(mseMediaSource);
    sageVideo.src = mseObjectUrl;
    sageVideo.load();
    setVideoBox('Starting separate MSE A/V streams…');

    mseMediaSource.addEventListener('sourceopen', async () => {
      if (serial !== videoSerial) return;
      try {
        const audioOffset = Number((audioOffsetEl && audioOffsetEl.value) || (st && st.audio_offset_ms) || -200) || 0;
        const videoDelay = audioOffset < 0 ? Math.abs(audioOffset) / 1000.0 : 0;
        const audioDelay = audioOffset > 0 ? audioOffset / 1000.0 : 0;
        const vSb = mseMediaSource.addSourceBuffer(videoMime);
        try { vSb.mode = 'segments'; } catch (e) {}
        try { if (videoDelay) vSb.timestampOffset = videoDelay; } catch (e) { log(`video timestampOffset failed: ${e.message || e}`); }
        const vTrack = createMseTrack('video', vSb, serial);
        vSb.addEventListener('updateend', () => pumpTrackAppend(vTrack));
        mseAvTracks.push(vTrack);

        let aTrack = null;
        if (audioUrl && MediaSource.isTypeSupported(audioMime)) {
          const aSb = mseMediaSource.addSourceBuffer(audioMime);
          try { aSb.mode = 'segments'; } catch (e) {}
          try { if (audioDelay) aSb.timestampOffset = audioDelay; } catch (e) { log(`audio timestampOffset failed: ${e.message || e}`); }
          aTrack = createMseTrack('audio', aSb, serial);
          aSb.addEventListener('updateend', () => pumpTrackAppend(aTrack));
          mseAvTracks.push(aTrack);
        }
        log(`MSE A/V sync: setting=${audioOffset}ms, videoDelay=${Math.round(videoDelay*1000)}ms, audioDelay=${Math.round(audioDelay*1000)}ms`);
        fetchMseTrack(url, vTrack, serial);
        if (aTrack) fetchMseTrack(audioUrl, aTrack, serial);
      } catch (e) {
        log(`MSE separate SourceBuffer error: ${e.message || e}`);
        setVideoBox('MSE separate SourceBuffer error');
      }
    }, {once:true});
  }

  async function startMseStream(url, st, serial) {
    if (!window.MediaSource) {
      setVideoBox('MSE is not supported by this browser');
      log('MSE fMP4 playback unsupported in this browser. Use HLS mode.');
      return;
    }
    cleanupMse();
    const mime = pickMseMime(st || {});
    if (!MediaSource.isTypeSupported(mime)) {
      setVideoBox('MSE MIME not supported');
      log(`MSE MIME not supported: ${mime}`);
      return;
    }
    mseAbortController = new AbortController();
    mseMediaSource = new MediaSource();
    mseObjectUrl = URL.createObjectURL(mseMediaSource);
    sageVideo.src = mseObjectUrl;
    sageVideo.load();
    setVideoBox('Starting MSE fMP4 stream…');

    mseMediaSource.addEventListener('sourceopen', async () => {
      if (serial !== videoSerial) return;
      try {
        mseSourceBuffer = mseMediaSource.addSourceBuffer(mime);
        try { mseSourceBuffer.mode = 'sequence'; } catch (e) {}
        mseSourceBuffer.addEventListener('updateend', pumpMseAppend);
      } catch (e) {
        log(`MSE SourceBuffer error: ${e.message || e}`);
        setVideoBox('MSE SourceBuffer error');
        return;
      }

      try {
        const res = await fetch(url, {cache: 'no-store', signal: mseAbortController.signal});
        if (!res.ok || !res.body) throw new Error(`HTTP ${res.status}`);
        const reader = res.body.getReader();
        while (serial === videoSerial) {
          if (!(await waitForMseAppendRoom(serial))) break;
          const {done, value} = await reader.read();
          if (done) break;
          if (value && value.byteLength) {
            enqueueMseBytes(value);
          }
        }
        try {
          if (mseMediaSource && mseMediaSource.readyState === 'open' && mseSourceBuffer && !mseSourceBuffer.updating) {
            mseMediaSource.endOfStream();
          }
        } catch (e) {}
      } catch (e) {
        if (String(e && e.name) !== 'AbortError') {
          log(`MSE stream error: ${e.message || e}`);
          setVideoBox('MSE stream error');
        }
      }
    }, {once:true});
  }

  async function startVideoStream(url, st) {
    videoLayerActive = true;
    if (stageWrap) stageWrap.classList.add('video-active');
    videoStatus = st || {};
    videoStatus.playlist_url = url || videoStatus.playlist_url;
    updateMediaStatus(lastMediaStatus || {});
    updateVideoBounds(currentVideoDst);
    if (!url || !sageVideo) return;

    if (hls) { try { hls.destroy(); } catch (e) {} hls = null; }
    cleanupMse();
    sageVideo.pause();
    sageVideo.removeAttribute('src');
    sageVideo.load();
    // v29: default to audio ON. If your browser blocks autoplay, check Mute video
    // in the top bar or click/tap the page once and retry.
    sageVideo.muted = !!(videoMutedEl && videoMutedEl.checked);
    sageVideo.controls = false;
    setVideoBox('Waiting for HLS playlist…');
    const serial = ++videoSerial;
    const inferredPlayer = url.indexOf('/mseav/') >= 0 ? 'mseav' : (url.indexOf('/mse/') >= 0 ? 'mse' : 'hls');
    const playerMode = (videoStatus.player_mode || inferredPlayer).toLowerCase();
    if (playerMode === 'mseav') {
      await startMseSeparateStream(url, videoStatus, serial);
      return;
    }
    if (playerMode === 'mse') {
      await startMseStream(url, videoStatus, serial);
      return;
    }

    const ok = await waitForPlaylist(url, serial);
    if (serial !== videoSerial) return;
    if (!ok) {
      setVideoBox('Timed out waiting for HLS playlist');
      log('Timed out waiting for HLS playlist. Check FFmpeg log/status.');
      return;
    }

    if (window.Hls && window.Hls.isSupported()) {
      if (serial !== videoSerial) return;
      // v45: favor smooth/stable playback over low latency.  The SageTV UI
      // stays responsive through the separate GUI socket, so the video player
      // should not aggressively chase the live HLS edge; doing so caused random
      // segment jumps and jerky playback while FFmpeg was still writing segments.
      hls = new Hls({
        // v45: stable-session HLS. Start at the first available session segment
        // and buffer normally instead of chasing the live edge. Random jumps were
        // mostly caused by live-edge correction plus rolling deletion.
        lowLatencyMode: false,
        startPosition: 0,
        liveSyncDurationCount: 12,
        liveMaxLatencyDurationCount: 60,
        maxLiveSyncPlaybackRate: 1.0,
        maxBufferLength: 90,
        maxMaxBufferLength: 180,
        backBufferLength: 90,
        liveBackBufferLength: 90,
        maxBufferHole: 0.8,
        maxSeekHole: 0.8,
        fragLoadingMaxRetry: 12,
        manifestLoadingMaxRetry: 12,
        levelLoadingMaxRetry: 12,
        capLevelToPlayerSize: false
      });
      hls.on(Hls.Events.ERROR, (event, data) => {
        if (data && data.details) log(`hls.js ${data.type || 'error'} ${data.details}`);
        if (data && data.fatal && hls) {
          if (data.type === Hls.ErrorTypes.NETWORK_ERROR) hls.startLoad();
          else if (data.type === Hls.ErrorTypes.MEDIA_ERROR) hls.recoverMediaError();
        }
      });
      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        hideVideoBox();
        sageVideo.classList.remove('hidden');
        try { if (sageVideo.currentTime < 0.25) sageVideo.currentTime = 0; } catch (e) {}
        playVideoElement();
      });
      hls.loadSource(url);
      hls.attachMedia(sageVideo);
      try { hls.startLoad(0); } catch (e) {}
    } else if (sageVideo.canPlayType('application/vnd.apple.mpegurl')) {
      if (serial !== videoSerial) return;
      sageVideo.src = url;
      sageVideo.addEventListener('loadedmetadata', () => {
        hideVideoBox();
        sageVideo.classList.remove('hidden');
        playVideoElement();
      }, {once:true});
    } else {
      setVideoBox('This browser needs hls.js for HLS playback');
      log('HLS playback unsupported: hls.js not loaded and native HLS unavailable.');
    }
  }

  function stopVideoStream(st) {
    videoSerial++;
    videoLayerActive = false;
    if (stageWrap) stageWrap.classList.remove('video-active');
    videoStatus = st || {};
    if (hls) { try { hls.destroy(); } catch (e) {} hls = null; }
    cleanupMse();
    if (sageVideo) {
      sageVideo.pause();
      sageVideo.removeAttribute('src');
      sageVideo.load();
      sageVideo.classList.add('hidden');
    }
    hideVideoBox();
    updateMediaStatus(lastMediaStatus || {});
  }

  function resizeCanvas(w, h) {
    screen.width = w;
    screen.height = h;
    surfaces[0] = screen;
    curSurface = screen;
    curCtx = dstCtx;
    log(`Canvas resized to ${w}x${h}`);
    updateVideoBounds([0,0,0,0]);
  }

  function makeSurface(w, h) {
    const c = document.createElement('canvas');
    c.width = Math.max(1, w);
    c.height = Math.max(1, h);
    return c;
  }

  function withClip(cmd, fn) {
    if (cmd.clip && cmd.clip[2] > 0 && cmd.clip[3] > 0) {
      curCtx.save();
      curCtx.beginPath();
      curCtx.rect(cmd.clip[0], cmd.clip[1], cmd.clip[2], cmd.clip[3]);
      curCtx.clip();
      fn();
      curCtx.restore();
    } else {
      fn();
    }
  }

  function roundedRectPath(ctx, x, y, w, h, r) {
    r = Math.max(0, Math.min(r || 0, Math.abs(w) / 2, Math.abs(h) / 2));
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
  }

  function renderCommands(commands) {
    for (const cmd of commands) {
      try { renderCommand(cmd); }
      catch (e) { log(`Render error ${cmd.op}: ${e}`); }
    }
  }

  function renderCommand(cmd) {
    switch (cmd.op) {
      case 'init':
        setStatus('SageTV GUI initialized');
        break;
      case 'deinit':
        setStatus('SageTV GUI deinitialized');
        break;
      case 'start':
        // v21 conservative renderer: SageTV is now told to use FULLSCREEN draw mode
        // and no offscreen surfaces. Reset the target and clear before every frame
        // to avoid stale text/images when switching STVs such as SageMC.
        curSurface = screen;
        curCtx = dstCtx;
        if (CLEAR_EACH_FRAME) {
          curCtx.save();
          curCtx.setTransform(1, 0, 0, 1, 0, 0);
          curCtx.globalAlpha = 1;
          curCtx.globalCompositeOperation = 'copy';
          curCtx.fillStyle = 'rgba(0,0,0,0)';
          curCtx.fillRect(0, 0, screen.width, screen.height);
          curCtx.restore();
        }
        if (videoLayerActive) {
          // Start every playback frame with the video rectangle transparent. Then
          // let SageTV draw its menu/timeline/OSD over the top. Video-mask commands
          // later in the frame punch the same rectangle again, but never the whole
          // GUI background.
          clearVideoHole(curCtx);
        }
        break;
      case 'flip':
        if (curSurface !== screen) dstCtx.drawImage(curSurface, 0, 0);
        if (firstFrame) {
          firstFrame = false;
          setStatus('SageTV GUI rendering');
          send({type:'resize', width: screen.width, height: screen.height});
        }
        break;
      case 'fillRect':
        if (commandLooksLikeVideoMask(cmd)) {
          // SageTV's video mask/color-key rectangle should reveal the video layer,
          // not paint a black box over it. Later OSD/timeline draw calls remain on top.
          clearMaskedVideoIntersection(cmd);
          break;
        }
        curCtx.save();
        curCtx.globalCompositeOperation = 'source-over';
        curCtx.fillStyle = cmd.color || 'black';
        curCtx.fillRect(cmd.x, cmd.y, cmd.w, cmd.h);
        curCtx.restore();
        break;
      case 'clearRect':
        if (commandLooksLikeVideoMask(cmd)) {
          clearMaskedVideoIntersection(cmd);
          break;
        }
        curCtx.save();
        // Desktop MiniClient uses AlphaComposite.SRC for clearRect. Canvas equivalent
        // is copy, not normal source-over, otherwise transparent clears do nothing.
        curCtx.globalCompositeOperation = 'copy';
        curCtx.fillStyle = cmd.color || 'rgba(0,0,0,0)';
        curCtx.fillRect(cmd.x, cmd.y, cmd.w, cmd.h);
        curCtx.restore();
        break;
      case 'drawRect':
        curCtx.save();
        curCtx.strokeStyle = cmd.color || 'white';
        curCtx.lineWidth = Math.max(1, cmd.thickness || 1);
        curCtx.strokeRect(cmd.x, cmd.y, cmd.w, cmd.h);
        curCtx.restore();
        break;
      case 'drawLine':
        curCtx.save();
        curCtx.strokeStyle = cmd.color || 'white';
        curCtx.beginPath();
        curCtx.moveTo(cmd.x1, cmd.y1);
        curCtx.lineTo(cmd.x2, cmd.y2);
        curCtx.stroke();
        curCtx.restore();
        break;
      case 'drawOval':
        withClip(cmd, () => {
          curCtx.save();
          curCtx.strokeStyle = cmd.color || 'white';
          curCtx.lineWidth = Math.max(1, cmd.thickness || 1);
          curCtx.beginPath();
          curCtx.ellipse(cmd.x + cmd.w/2, cmd.y + cmd.h/2, Math.abs(cmd.w/2), Math.abs(cmd.h/2), 0, 0, Math.PI*2);
          curCtx.stroke();
          curCtx.restore();
        });
        break;
      case 'fillOval':
        withClip(cmd, () => {
          curCtx.save();
          curCtx.fillStyle = cmd.color || 'white';
          curCtx.beginPath();
          curCtx.ellipse(cmd.x + cmd.w/2, cmd.y + cmd.h/2, Math.abs(cmd.w/2), Math.abs(cmd.h/2), 0, 0, Math.PI*2);
          curCtx.fill();
          curCtx.restore();
        });
        break;
      case 'drawRoundRect':
        withClip(cmd, () => {
          curCtx.save(); curCtx.strokeStyle = cmd.color || 'white'; curCtx.lineWidth = Math.max(1, cmd.thickness || 1);
          roundedRectPath(curCtx, cmd.x, cmd.y, cmd.w, cmd.h, cmd.arc); curCtx.stroke(); curCtx.restore();
        });
        break;
      case 'fillRoundRect':
        withClip(cmd, () => {
          curCtx.save(); curCtx.fillStyle = cmd.color || 'white';
          roundedRectPath(curCtx, cmd.x, cmd.y, cmd.w, cmd.h, cmd.arc); curCtx.fill(); curCtx.restore();
        });
        break;
      case 'createSurface':
        surfaces[cmd.handle] = makeSurface(cmd.w, cmd.h);
        break;
      case 'setSurface':
        curSurface = surfaces[cmd.handle] || screen;
        curCtx = curSurface.getContext('2d');
        break;
      case 'imageAlloc':
        // Server-side allocation notice only.  The real image usually arrives in a later
        // registerImage command.  Do not log these; SageTV sends many during startup.
        break;
      case 'registerImage': {
        const img = new Image();
        img.onload = () => { images[cmd.handle] = img; };
        img.onerror = () => { /* keep quiet during startup; failed handles are retried/redrawn */ };
        img.src = `data:${cmd.mime || 'image/png'};base64,${cmd.data}`;
        images[cmd.handle] = img;
        break;
      }
      case 'unloadImage':
        delete images[cmd.handle];
        delete surfaces[cmd.handle];
        break;
      case 'drawTexture': {
        const img = images[cmd.handle] || surfaces[cmd.handle];
        // Missing/incomplete texture handles are common while the image cache warms up.
        // Logging each miss makes arrow-key response very sluggish.
        if (!img) break;
        if (img instanceof HTMLImageElement && !img.complete) break;
        curCtx.save();
        curCtx.globalAlpha = cmd.alpha == null ? 1.0 : cmd.alpha;
        const w = Math.abs(cmd.w), h = Math.abs(cmd.h);
        try { curCtx.drawImage(img, cmd.sx, cmd.sy, cmd.sw, cmd.sh, cmd.x, cmd.y, w, h); }
        catch (e) { /* suppress noisy image decode/race errors */ }
        curCtx.restore();
        break;
      }
      case 'drawText':
        // Fallback only. v21 requests GFX_TEXTMODE=NONE so most SageTV text
        // should arrive as pre-rendered images with correct font metrics.
        withClip(cmd, () => {
          curCtx.save();
          curCtx.fillStyle = cmd.color || 'white';
          curCtx.font = '20px Arial';
          curCtx.textBaseline = 'top';
          curCtx.fillText(cmd.text || '', cmd.x, cmd.y);
          curCtx.restore();
        });
        break;
      case 'videoBounds':
        // Reserved for next phase.
        break;
      case 'pushTransform':
        curCtx.save();
        break;
      case 'popTransform':
        try { curCtx.restore(); } catch (e) {}
        break;
      case 'debug':
        log(cmd.message);
        break;
      default:
        log(`Unhandled render op ${JSON.stringify(cmd).slice(0, 200)}`);
    }
  }

  loadUiSettings();
  attachSettingsPersistence();

  [videoEncoderEl, videoMaxHeightEl, videoBitrateEl, audioOffsetEl, hlsModeEl, playerModeEl].forEach(el => {
    if (el) el.addEventListener('change', sendLiveVideoSettings);
  });

  connectBtn.addEventListener('click', () => { saveUiSettings(); connect(); });
  disconnectBtn.addEventListener('click', () => send({type:'disconnect'}));

  document.querySelectorAll('[data-cmd]').forEach(btn => {
    btn.addEventListener('click', () => {
      command(btn.getAttribute('data-cmd'));
      if (navOverlay && btn.closest('#navOverlay')) hideNavOverlay();
    });
  });

  screen.addEventListener('keydown', ev => {
    const lower = (ev.key || '').toLowerCase();
    const keyMap = {
      ArrowUp: 'up', ArrowDown: 'down', ArrowLeft: 'left', ArrowRight: 'right',
      Enter: 'select', NumpadEnter: 'select', Escape: 'back', Backspace: 'back', ' ': 'play_pause',
      PageUp: 'page_up', PageDown: 'page_down', Home: 'home', End: 'stop',
      MediaPlayPause: 'play_pause', MediaStop: 'stop', MediaTrackNext: 'skip_fwd_2', MediaTrackPrevious: 'skip_back_2'
    };
    const letterMap = {
      p: 'play_pause', d: 'play', s: 'pause', f: 'ff', g: 'rew',
      t: 'record', i: 'info', o: 'options', x: 'guide', h: 'home', m: 'mute'
    };
    const cmd = keyMap[ev.key] || letterMap[lower];
    if (cmd) {
      ev.preventDefault();
      send({type:'command', command:cmd});
    } else {
      send({type:'key', key: ev.key, keyCode: ev.keyCode || ev.which || 0});
    }
  });

  function canvasCoords(ev) {
    const r = screen.getBoundingClientRect();
    const sx = screen.width / r.width;
    const sy = screen.height / r.height;
    return {x: Math.round((ev.clientX - r.left) * sx), y: Math.round((ev.clientY - r.top) * sy)};
  }

  function command(cmd) {
    send({type:'command', command:cmd});
    screen.focus();
  }

  // v24: SageTV responds more reliably to the same event sequence the
  // native MiniClient sends: move -> press -> release -> click.
  // v24 only sent MCLICK, which worked on some STVs but did not trigger
  // selection in others.
  let lastShortClickMs = 0;
  function sendCanvasClick(x, y, button) {
    const now = performance.now();
    // Avoid duplicate click when both pointerup and the browser click fallback fire.
    if (now - lastShortClickMs < 220) return;
    lastShortClickMs = now;
    const b = Number(button || 1);
    send({type:'mouse', event:'move', x, y});
    send({type:'mouse', event:'down', x, y, button:b, clicks:1});
    send({type:'mouse', event:'up', x, y, button:b, clicks:1});
    send({type:'mouse', event:'click', x, y, button:b, clicks:1});
    screen.focus();
  }

  function centerNavOverlayOverCanvas() {
    if (!navOverlay) return;
    const card = navOverlay.querySelector('.navCard');
    if (!card) return;

    // Center the Android-style remote over the rendered SageTV canvas, not the
    // whole browser viewport.  This keeps it aligned with the video/render area
    // when the debug panels/logs are visible below the canvas.
    const r = screen.getBoundingClientRect();

    // Make sure the card has measurable dimensions before positioning.
    const wasHidden = navOverlay.classList.contains('hidden');
    if (wasHidden) navOverlay.classList.remove('hidden');
    const cw = card.offsetWidth || 420;
    const ch = card.offsetHeight || 370;

    let left = r.left + (r.width - cw) / 2;
    let top = r.top + (r.height - ch) / 2;

    // Keep the overlay fully reachable on smaller screens.
    left = Math.max(8, Math.min(left, window.innerWidth - cw - 8));
    top = Math.max(8, Math.min(top, window.innerHeight - ch - 8));

    card.style.left = `${left}px`;
    card.style.top = `${top}px`;
    if (wasHidden) navOverlay.classList.add('hidden');
  }

  function showNavOverlay(clientX, clientY) {
    if (!navOverlay) return;
    navOverlay.classList.remove('hidden');
    navOverlay.setAttribute('aria-hidden', 'false');
    centerNavOverlayOverCanvas();
    screen.focus();
  }

  function hideNavOverlay() {
    if (!navOverlay) return;
    navOverlay.classList.add('hidden');
    navOverlay.setAttribute('aria-hidden', 'true');
    screen.focus();
  }

  if (showOverlayBtn) showOverlayBtn.addEventListener('click', () => showNavOverlay());
  if (navOverlay) {
    navOverlay.addEventListener('click', ev => {
      if (ev.target === navOverlay || ev.target.classList.contains('closeNav')) hideNavOverlay();
    });
  }

  // v24: old Android MiniClient supported click-and-hold to open a navigation OSD.
  // Use pointer events so it works on mouse, touch, and pen.  A short click sends a
  // SageTV mouse click; a long hold shows the local HTML5 navigation panel instead.
  let lastMouseSend = 0;
  let lastMouseX = -1;
  let lastMouseY = -1;
  let pointerDown = false;
  let longPressTimer = null;
  let longPressFired = false;
  const LONG_PRESS_MS = 575;
  const MOVE_CANCEL_PX = 12;
  let downClientX = 0;
  let downClientY = 0;
  let downPoint = {x: 0, y: 0};
  let downButton = 1;

  function clearLongPressTimer() {
    if (longPressTimer) {
      clearTimeout(longPressTimer);
      longPressTimer = null;
    }
  }

  screen.addEventListener('pointermove', ev => {
    const now = performance.now();
    const p = canvasCoords(ev);
    if (pointerDown && !longPressFired) {
      const dx = ev.clientX - downClientX;
      const dy = ev.clientY - downClientY;
      if (Math.hypot(dx, dy) > MOVE_CANCEL_PX) clearLongPressTimer();
    }
    if (p.x === lastMouseX && p.y === lastMouseY) return;
    if (now - lastMouseSend < 40) return;
    lastMouseSend = now;
    lastMouseX = p.x;
    lastMouseY = p.y;
    send({type:'mouse', event:'move', x:p.x, y:p.y});
  });

  screen.addEventListener('pointerdown', ev => {
    screen.focus();
    pointerDown = true;
    longPressFired = false;
    downClientX = ev.clientX;
    downClientY = ev.clientY;
    downPoint = canvasCoords(ev);

    // Browser button: 0=left, 1=middle, 2=right.
    // Java/MiniClient button: 1=left, 2=middle, 3=right.
    // Keep right click available for SageTV/STV context menus.
    downButton = ev.button === 2 ? 3 : (ev.button === 1 ? 2 : 1);

    clearLongPressTimer();

    // Only left mouse click and touch/pen primary press should open the local
    // long-press navigation overlay.  Right click belongs to SageTV.
    const allowLocalLongPress = ev.pointerType !== 'mouse' || ev.button === 0;
    if (allowLocalLongPress) {
      longPressTimer = setTimeout(() => {
        longPressFired = true;
        try { screen.releasePointerCapture(ev.pointerId); } catch (e) {}
        showNavOverlay(ev.clientX, ev.clientY);
      }, LONG_PRESS_MS);
    }

    try { screen.setPointerCapture(ev.pointerId); } catch (e) {}
    ev.preventDefault();
  });

  screen.addEventListener('pointerup', ev => {
    const p = canvasCoords(ev);
    clearLongPressTimer();
    try { screen.releasePointerCapture(ev.pointerId); } catch (e) {}
    if (!longPressFired) {
      sendCanvasClick(p.x, p.y, downButton);
    }
    pointerDown = false;
    longPressFired = false;
    ev.preventDefault();
  });

  screen.addEventListener('pointercancel', () => {
    clearLongPressTimer();
    pointerDown = false;
    longPressFired = false;
  });

  // Some mobile browsers can cancel pointerup after a canvas/touch gesture.
  // Keep a normal click fallback so quick taps still select.  The duplicate
  // guard inside sendCanvasClick prevents double selection on desktop.
  screen.addEventListener('click', ev => {
    // Left-click/tap fallback only. Right click is handled through pointerup
    // or auxclick and should not be converted into a left click.
    if (longPressFired) return;
    if (ev.button && ev.button !== 0) return;
    const p = canvasCoords(ev);
    sendCanvasClick(p.x, p.y, 1);
  });

  screen.addEventListener('auxclick', ev => {
    // Fallback for middle/right click on browsers that do not deliver a normal
    // click event for non-left buttons. The duplicate guard in sendCanvasClick
    // prevents double-sending when pointerup already handled it.
    ev.preventDefault();
    const p = canvasCoords(ev);
    const b = ev.button === 2 ? 3 : 2;
    sendCanvasClick(p.x, p.y, b);
  });

  screen.addEventListener('contextmenu', ev => {
    // Disable the browser menu, but do NOT open the local HTML5 navigation menu.
    // SageTV/STVs use right click for their own context menus, so right click
    // is sent to SageTV through the pointer/auxclick path above.
    ev.preventDefault();
  });


  window.addEventListener('resize', () => {
    if (navOverlay && !navOverlay.classList.contains('hidden')) centerNavOverlayOverCanvas();
  });
  window.addEventListener('scroll', () => {
    if (navOverlay && !navOverlay.classList.contains('hidden')) centerNavOverlayOverCanvas();
  }, {passive: true});

  fetch('/api/status').then(r => r.json()).then(s => {
    const savedServer = getCookie(cookieName('server')) || (() => { try { return localStorage.getItem(cookieName('server')) || ''; } catch (e) { return ''; } })();
    if (!savedServer) serverEl.value = s.default_server || serverEl.value;
  });
})();
